import copy
import json
import unittest
from universal_portfolio import cost_coverage_reconciliation_a24 as p
from universal_portfolio import learned_policy_account_context_a24 as scoped
from universal_portfolio import economic_action_evidence_a24 as evidence
from universal_portfolio import economic_action_plan_a24 as actions

class Coverage(unittest.TestCase):
    def setUp(self):
        self.row=dict(trade_event_id='EVENT',trade_event_hash='HASH',instrument_id='I',account_id='ACCOUNT',currency='EUR',side='BUY')
        self.scope=dict(schema=scoped.SCHEMA,status='LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY',scenarios=[dict(account_id='ACCOUNT',currency='EUR',legs=[dict(instrument_id='I')])],**scoped.flags())
        self.alt=dict(case_id='CASE',alternative_id='ALT',account_id='ACCOUNT',currency='EUR',instrument_id='I',legs=[],historical_trade_refs=[dict(event_id='EVENT',event_hash='HASH',side='BUY')])
        self.evidence=dict(schema=evidence.SCHEMA,status='ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY',alternatives=[self.alt],historical_trade_population_count=1,**actions.flags())

    def reconcile(self):return p.reconcile(self.scope,[self.row],self.evidence)

    def test_full_actions_and_cash_counts_are_distinct(self):
        self.scope['scenarios'][0]['legs'][0]['instrument_id']='OTHER'
        r=self.reconcile();self.assertEqual(r['historical_trades_in_full_action_evidence'],1);self.assertEqual(r['full_action_alternatives_with_historical_evidence'],1);self.assertEqual(r['historical_trades_in_current_cash_distributions'],0);self.assertEqual(r['historical_trade_scope_reason_counts'],{'INSTRUMENT_NOT_IN_CURRENT_CASH_DISTRIBUTIONS':1})

    def test_exact_cash_match_and_deduplication(self):
        self.scope['scenarios']*=3
        r=self.reconcile();self.assertEqual(r['historical_trades_in_current_cash_distributions'],1)

    def test_account_difference_explained_without_remapping(self):
        self.scope['scenarios'][0]['account_id']='OTHER'
        self.assertEqual(self.reconcile()['historical_trade_scope_reason_counts'],{'OTHER_ACCOUNT_IN_CURRENT_CASH_DISTRIBUTIONS':1})

    def test_currency_difference_explained_without_fx(self):
        self.scope['scenarios'][0]['currency']='BRL'
        self.assertEqual(self.reconcile()['historical_trade_scope_reason_counts'],{'OTHER_CURRENCY_IN_CURRENT_CASH_DISTRIBUTIONS':1})

    def test_opposite_side_not_reused(self):
        self.row['side']='SELL';self.alt['historical_trade_refs'][0]['side']='SELL'
        self.assertEqual(self.reconcile()['historical_trade_scope_reason_counts'],{'OTHER_TRADE_SIDE_IN_CURRENT_CASH_DISTRIBUTIONS':1})

    def test_empty_cash_selection_does_not_erase_full_action_evidence(self):
        self.scope['scenarios']=[]
        r=self.reconcile();self.assertEqual(r['historical_trades_in_full_action_evidence'],1);self.assertEqual(r['historical_trades_in_current_cash_distributions'],0)

    def test_missing_full_action_input_is_unknown_not_zero(self):
        r=p.reconcile(self.scope,[self.row]);self.assertIsNone(r['historical_trades_in_full_action_evidence']);self.assertEqual(r['full_action_evidence_status'],'UNAVAILABLE')

    def test_hash_or_scope_mismatch_refuses_full_population_claim(self):
        for key in ['account_id','currency','instrument_id']:
            with self.subTest(key=key):
                original=self.alt[key];self.alt[key]='OTHER';self.assertIsNone(self.reconcile()['historical_trades_in_full_action_evidence']);self.alt[key]=original
        self.alt['historical_trade_refs'][0]['event_hash']='OTHER'
        self.assertIsNone(self.reconcile()['historical_trades_in_full_action_evidence'])

    def test_duplicate_action_evidence_refused(self):
        self.evidence['alternatives']*=2
        self.assertIsNone(self.reconcile()['full_action_alternatives_with_historical_evidence'])

    def test_authorizing_contracts_refused(self):
        self.evidence['execution_authorized']=True
        self.assertIsNone(self.reconcile()['historical_trades_in_full_action_evidence'])
        self.scope['execution_authorized']=True
        with self.assertRaises(ValueError):self.reconcile()

    def test_different_or_duplicate_historical_population_refused(self):
        self.evidence['historical_trade_population_count']=2
        self.assertIsNone(self.reconcile()['historical_trades_in_full_action_evidence'])
        with self.assertRaises(ValueError):p.reconcile(self.scope,[self.row,self.row])

    def test_readonly_arbitrary_currency_and_private_output(self):
        self.scope['scenarios'][0]['currency']=self.row['currency']=self.alt['currency']='JPY'
        before=copy.deepcopy((self.scope,self.row,self.evidence));r=self.reconcile();self.assertEqual(before,(self.scope,self.row,self.evidence));self.assertEqual(r['historical_trades_in_current_cash_distributions'],1)
        s=json.dumps(r);self.assertNotIn(json.dumps('ACCOUNT'),s);self.assertNotIn(json.dumps('EVENT'),s);self.assertNotIn(json.dumps('HASH'),s);self.assertFalse(r['execution_authorized']);self.assertFalse(r['historical_fee_is_future_tariff'])
