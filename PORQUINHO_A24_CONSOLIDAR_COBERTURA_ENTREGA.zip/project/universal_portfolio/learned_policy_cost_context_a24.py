"""Reuse exact realized evidence and reviewed quotes without selecting a venue.
Budget fractions are hypothetical research capital, never an order or reservation.
"""
from collections import Counter
from fractions import Fraction
from . import account_cost_evidence_a24 as quotes
from . import observed_trade_costs_a24 as observed
from .explicit_market_bindings_a24 import digest

SCHEMA = 'porquinho.learned-policy-cost-context-a24/1.0'


def flags():
    return {'financial_mutation': False, 'history_write_performed': False,
            'execution_authorized': False, 'canonical_publication_authorized': False,
            'future_tariff_inferred': False, 'execution_venue_selected': False,
            'order_notional_created': False, 'net_return_validated': False}


def match_leg(scenario, leg, observations, reviews, registry, estimate):
    key = (scenario['account_id'], leg['instrument_id'], scenario['currency'], 'BUY')
    if leg['quote_currency'] != scenario['currency']:
        raise ValueError('COST_LEG_CURRENCY_MISMATCH')
    fraction = Fraction(leg['fraction_numerator'], leg['fraction_denominator'])
    if not 0 < fraction <= 1:
        raise ValueError('POSITIVE_RESEARCH_FRACTION_REQUIRED')
    notional = Fraction(str(scenario['budget_reference_capital'])) * fraction
    if notional <= 0:
        raise ValueError('POSITIVE_RESEARCH_CAPITAL_REQUIRED')
    def scope(row):
        return (row['account_id'], row['instrument_id'], row['currency'], row['side'])
    history = [r for r in observations if scope(r) == key]
    candidates = []
    for row in reviews.values():
        if scope(row) != key or Fraction(row['reference_amount']) != notional:
            continue
        try:
            quotes.current_scope(row, registry)
        except quotes.CostError:
            continue
        query = {k: row[k] for k in quotes.SCOPE}
        query['evidence_id'] = row['evidence_id']
        result = estimate(query)
        candidates.append({'evidence_id': row['evidence_id'],
                           'execution_venue_id': row['execution_venue_id'],
                           'cost_evidence': result})
    return {'instrument_id': key[1], 'currency': key[2], 'side': key[3],
            'research_capital_fraction': str(fraction),
            'reference_semantics': 'HYPOTHETICAL_BUDGET_FRACTION_NOT_ORDER',
            'historical_trade_count': len(history),
            'historical_evidence': [{'trade_event_id': r['trade_event_id'],
                'trade_event_hash': r['trade_event_hash'], 'fee_event_ids': r['fee_event_ids'],
                'fee_event_hashes': r['fee_event_hashes'], 'executed_at': r['executed_at'],
                'observed_fee_amount': r['observed_fee_amount'],
                'observed_fee_to_gross_fraction': r['observed_fee_to_gross_fraction']} for r in history],
            'reviewed_quote_candidates': sorted(candidates, key=lambda r: r['evidence_id']),
            'future_cost_estimate': None, 'total_cost_status': 'UNKNOWN', **flags()}


def attach(root, basis, scope, *, now, action_evidence=None):
    """Failures affect this diagnostic only; no historical fee becomes a quote."""
    base = {'schema': SCHEMA, 'status': 'CANDIDATE_COST_CONTEXT_UNAVAILABLE', **flags()}
    try:
        from . import learned_policy_economic_basis_a24 as economic
        from . import learned_policy_account_context_a24 as scoped
        if basis.get('schema') != economic.SCHEMA or scope.get('schema') != scoped.SCHEMA:
            raise ValueError('CURRENT_SCENARIO_CONTRACT_REQUIRED')
        if any(basis.get(k) != v for k,v in economic.flags().items()):
            raise ValueError('NONAUTHORIZING_BASIS_REQUIRED')
        data = observed.read(root, now=now)
        if data['status'] not in ('EXISTING_LEDGER_NOT_PRESENT', 'EXISTING_TRADE_COSTS_OBSERVED'):
            raise ValueError('OBSERVED_COST_READ_UNAVAILABLE')
        reviews = quotes.load(root, now=now)
        registry, registry_digest = quotes.accounts(root)
        def estimate(query):
            return quotes.estimate(root, query, now=now)
        scenarios = scope['scenarios']
        if len(scenarios) != len(basis['rows']):
            raise ValueError('EXACT_SCENARIO_ROW_COUNT_REQUIRED')
        contexts = []
        for scenario, row in zip(scenarios, basis['rows']):
            if any(scenario[k] != row[k] for k in ('candidate_id','policy_version_digest','account_id','currency','budget_id','plan_id')):
                raise ValueError('EXACT_SCENARIO_COST_SCOPE_REQUIRED')
            contexts.append({'legs': [match_leg(scenario, leg, data['observations'], reviews, registry, estimate)
                                      for leg in scenario['legs']]})
        if digest(reviews) != digest(quotes.load(root, now=now)) or registry_digest != quotes.accounts(root)[1] or digest(data) != digest(observed.read(root, now=now)):
            raise ValueError('COST_SOURCES_CHANGED_DURING_SCOPE')
        legs = [leg for c in contexts for leg in c['legs']]
        states = Counter(q['cost_evidence']['status'] for leg in legs for q in leg['reviewed_quote_candidates'])
        summary = {**base, 'status': 'CANDIDATE_COST_CONTEXTS_LINKED_RESEARCH_ONLY',
            'scenario_count': len(contexts), 'leg_count': len(legs),
            'legs_with_realized_fee_evidence': sum(bool(l['historical_trade_count']) for l in legs),
            'legs_with_reviewed_quote_candidates': sum(bool(l['reviewed_quote_candidates']) for l in legs),
            'reviewed_quote_status_counts': dict(states),
            'future_cost_complete_scenario_count': 0, 'financial_amounts_exported': False}
        for row, context in zip(basis['rows'], contexts):
            row['cost_context'] = {**context, **base, 'status': summary['status']}
        from .cost_coverage_reconciliation_a24 import reconcile
        try:
            summary['coverage'] = reconcile(scope, data['observations'], action_evidence)
        except Exception as exc:
            summary['coverage'] = {'status': 'COST_COVERAGE_UNAVAILABLE', 'error_type': type(exc).__name__}
        basis['cost_context_summary'] = summary
    except Exception as exc:
        basis['cost_context_summary'] = {**base, 'error_type': type(exc).__name__}
    return basis
