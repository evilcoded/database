"""Reconcile preserved realized evidence across full actions and cash candidates.
No widening of financial identity, currency, account, side, or fee applicability.
"""
from collections import Counter
from . import economic_action_evidence_a24 as evidence
from . import economic_action_plan_a24 as actions

SCHEMA = 'porquinho.cost-coverage-reconciliation-a24/1.0'


def reason(row, scopes):
    same = [s for s in scopes if s[0] == row['instrument_id']]
    if not same:
        return 'INSTRUMENT_NOT_IN_CURRENT_CASH_DISTRIBUTIONS'
    same = [s for s in same if s[1] == row['account_id']]
    if not same:
        return 'OTHER_ACCOUNT_IN_CURRENT_CASH_DISTRIBUTIONS'
    same = [s for s in same if s[2] == row['currency']]
    if not same:
        return 'OTHER_CURRENCY_IN_CURRENT_CASH_DISTRIBUTIONS'
    return 'MATCHED_CURRENT_CASH_DISTRIBUTION' if any(s[3] == row['side'] for s in same) else 'OTHER_TRADE_SIDE_IN_CURRENT_CASH_DISTRIBUTIONS'


def reconcile(scope, observations, action_evidence=None):
    from . import learned_policy_account_context_a24 as scoped
    if scope.get('schema') != scoped.SCHEMA or scope.get('status') != 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY' or any(scope.get(k) != v for k,v in scoped.flags().items()):
        raise ValueError('CURRENT_NONAUTHORIZING_CASH_SCOPE_REQUIRED')
    population = {r['trade_event_id']: r for r in observations}
    if len(population) != len(observations):
        raise ValueError('UNIQUE_REALIZED_COST_EVENTS_REQUIRED')
    scopes = {(l['instrument_id'], s['account_id'], s['currency'], 'BUY') for s in scope['scenarios'] for l in s['legs']}
    counts = Counter(reason(r, scopes) for r in population.values())
    result = {'schema': SCHEMA, 'status': 'REALIZED_COST_COVERAGE_RECONCILED',
        'historical_trade_population_count': len(population),
        'historical_trades_in_current_cash_distributions': counts['MATCHED_CURRENT_CASH_DISTRIBUTION'],
        'historical_trade_scope_reason_counts': dict(counts),
        'full_action_evidence_status': 'UNAVAILABLE',
        'full_action_alternatives_with_historical_evidence': None,
        'historical_trades_in_full_action_evidence': None,
        'scope': 'FULL_ACTION_POPULATION_SEPARATE_FROM_SELECTED_CASH_DISTRIBUTIONS',
        'financial_identifiers_exported': False, 'financial_amounts_exported': False,
        'historical_fee_is_future_tariff': False, **actions.flags()}
    if action_evidence is None:
        return result
    try:
        if action_evidence.get('schema') != evidence.SCHEMA or action_evidence.get('status') != 'ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY' or any(action_evidence.get(k) != v for k,v in actions.flags().items()):
            raise ValueError('NONAUTHORIZING_FULL_ACTION_EVIDENCE_REQUIRED')
        used = set(); count = 0; seen = set()
        for alternative in action_evidence['alternatives']:
            key = alternative['case_id'], alternative['alternative_id']
            if key in seen:
                raise ValueError('UNIQUE_ACTION_EVIDENCE_REQUIRED')
            seen.add(key)
            refs = alternative['historical_trade_refs']
            count += bool(refs)
            for ref in refs:
                observed = population.get(ref['event_id'])
                if observed is None or observed['trade_event_hash'] != ref['event_hash'] or observed['side'] != ref['side'] or (observed['account_id'], observed['currency']) != (alternative['account_id'], alternative['currency']):
                    raise ValueError('EXACT_OBSERVED_EVENT_SCOPE_AND_HASH_REQUIRED')
                identities = {alternative['instrument_id'], *(l['instrument_id'] for l in alternative['legs'])}
                if observed['instrument_id'] not in identities:
                    raise ValueError('EXACT_ACTION_HISTORICAL_IDENTITY_REQUIRED')
                used.add(ref['event_id'])
        if action_evidence['historical_trade_population_count'] != len(population):
            raise ValueError('SAME_HISTORICAL_POPULATION_REQUIRED')
        result.update(full_action_evidence_status='VERIFIED_SAME_REALIZED_EVENT_POPULATION',
            full_action_alternatives_with_historical_evidence=count,
            historical_trades_in_full_action_evidence=len(used))
    except Exception as exc:
        result['full_action_evidence_error_type'] = type(exc).__name__
    return result
