"""Global market reader with separate unit evidence and lossless legacy compatibility.

Current EUR code contracts are supporting context, never historical attestation.
No data writes, identity binding, backfill, model training or authority creation.
"""
import ast,io,json
from collections import Counter
from pathlib import Path
from .explicit_market_bindings_a24 import local
from .global_market_migration_a24 import SOURCE,STORE,MigrationError,parse,sha,read_bundle,number
SCHEMA='porquinho.global-market-reader-a24/1.0'

def quote(value):
 return value if isinstance(value,str) and value.isascii() and value.isalpha() and value.isupper() and len(value)<=16 else None

def legacy_contract(root):
 p=local(root,'tools/fetch_history.py')
 if not p.exists():return {'status':'NOT_AVAILABLE','sha256':None,'historical_row_attestation':False}
 raw=p.read_bytes()
 if len(raw)>2*1024*1024:raise MigrationError('SOURCE_CODE_SIZE_LIMIT')
 tree=ast.parse(raw);functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fetch_daily']
 supported=False
 if len(functions)==1:
  fn=functions[0];default=False;request=False
  for n in ast.walk(fn):
   if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='quote' for t in n.targets) and isinstance(n.value,ast.IfExp):
    x=n.value
    default=isinstance(x.test,ast.Name) and x.test.id=='legacy_call' and isinstance(x.body,ast.Constant) and x.body.value=='EUR' and isinstance(x.orelse,ast.Name) and x.orelse.id=='quote_currency'
   if isinstance(n,ast.Dict):
    for k,v in zip(n.keys,n.values):
     if isinstance(k,ast.Constant) and k.value=='vs_currency' and isinstance(v,ast.Call) and isinstance(v.func,ast.Attribute) and isinstance(v.func.value,ast.Name) and v.func.value.id=='quote' and v.func.attr=='lower' and not v.args:request=True
  supported=default and request
 return {'status':'CURRENT_LEGACY_DEFAULT_EUR_REQUEST_CONTRACT' if supported else 'CURRENT_CODE_CONTRACT_NOT_RECOGNIZED','sha256':sha(raw),'historical_row_attestation':False}

def project(raw,contract):
 headers,source=parse(raw);rows=[];counts=Counter()
 for index,values in enumerate(source,1):
  src=dict(zip(headers,values));declared=quote(src.get('quote_currency'));column='price' if src.get('price') not in (None,'') else 'price_eur' if src.get('price_eur') not in (None,'') else None
  candidate=None;resolved=declared if column=='price' else None
  if resolved:status='EXPLICIT_QUOTE_DECLARATION_SOURCE_UNATTESTED'
  elif src.get('quote_currency') and not declared:status='INVALID_QUOTE_DECLARATION_PRESERVED'
  elif declared:status='ROW_QUOTE_DECLARED_LEGACY_MEASURE_UNIT_UNVERIFIED'
  elif column=='price_eur' and str(src.get('source') or '').lower()=='coingecko' and contract['status']=='CURRENT_LEGACY_DEFAULT_EUR_REQUEST_CONTRACT':status='LEGACY_EUR_COMPATIBLE_CURRENT_CODE_ONLY';candidate='EUR'
  else:status='UNIT_UNRESOLVED'
  counts[status]+=1
  rows.append({'source_row':index,'asset_label':src.get('asset'),'observation_date':src.get('date'),
    'instrument_id':src.get('instrument_id') or None,'provider':src.get('provider') or None,'provider_id':src.get('provider_id') or None,
    'declared_row_quote_currency':declared,'price':{'value':src.get(column) if column else None,'source_column':column,'quote_currency':resolved,'numeric_status':number(src.get(column) if column else None,True)},
    'unit_evidence_status':status,'candidate_quote_currency':candidate,'candidate_scope':'CURRENT_CODE_COMPATIBILITY_NOT_HISTORICAL_PROOF' if candidate else None,
    'account_currency':None,'identity_binding_created':False,'historical_row_attestation':False,'canonical_publication_authorized':False})
 return rows,dict(counts)

def read(root):
 root=Path(root).resolve(strict=True);p=local(root,SOURCE)
 if p.stat().st_size>64*1024*1024:raise MigrationError('SOURCE_SIZE_LIMIT_NO_READ')
 raw=p.read_bytes();source_hash=sha(raw);folder=local(root,STORE+'/'+source_hash);storage='LIVE_SOURCE_NOT_ARCHIVED'
 if folder.exists():
  read_bundle(root,source_hash)
  archived=local(root,STORE+'/'+source_hash+'/original.csv').read_bytes()
  if archived!=raw:raise MigrationError('ARCHIVE_AND_LIVE_SOURCE_DIFFER')
  raw=archived;storage='EXACT_CONTENT_MIGRATION_VERIFIED'
 contract=legacy_contract(root);records,counts=project(raw,contract)
 if p.read_bytes()!=raw:raise MigrationError('SOURCE_CHANGED_DURING_GLOBAL_READ')
 # Bind supporting code evidence to the same read, without claiming historical provenance.
 if legacy_contract(root)!=contract:raise MigrationError('CODE_CHANGED_DURING_GLOBAL_READ')
 summary={'schema':SCHEMA,'status':'READ_ONLY_INPUT_INSPECTED_NOT_CERTIFIED','source_sha256':source_hash,'storage_status':storage,
  'source_row_count':len(records),'unit_evidence_counts':counts,'legacy_contract':contract,
  'legacy_values_preserved':True,'historical_row_attestation':False,'training_authorized_by_reader':False,'canonical_publication_authorized':False}
 return raw,records,summary

def read_market_frame(root):
 """Existing feature logic consumes identical cells/dtypes, via this global reader."""
 import pandas as pd
 raw,records,summary=read(root)
 frame=pd.read_csv(io.BytesIO(raw));frame.attrs['a24_input_contract']=summary
 if len(frame)!=len(records):raise MigrationError('PANDAS_ROW_COUNT_DIFFERS_FROM_PRESERVED_SOURCE')
 return frame
