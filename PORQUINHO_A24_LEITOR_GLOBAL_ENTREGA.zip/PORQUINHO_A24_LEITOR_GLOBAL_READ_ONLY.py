import sys,os,json,hashlib,io
from pathlib import Path
root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root))
def guard(event,args):
 if event=='open':
  mode,flags=args[1:3]
  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
 if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
sys.addaudithook(guard)
try:
 import pandas as pd
 from universal_portfolio.global_market_reader_a24 import read_market_frame
 from brain.evolution.prediction_lab import _features
 files=[root/'data/database/market_daily.csv',root/'results/latest.json',root/'results/prediction_lab.json']
 def digests():return [hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None for p in files]
 before=digests();source=files[0].read_bytes();old=pd.read_csv(io.BytesIO(source));new=read_market_frame(root);contract=dict(new.attrs['a24_input_contract'])
 left=old.copy();right=new.copy();left.attrs={};right.attrs={};pd.testing.assert_frame_equal(left,right)
 old_features,old_names=_features(old);new_features,new_names=_features(new)
 old_features.attrs={};new_features.attrs={};pd.testing.assert_frame_equal(old_features,new_features)
 if old_names!=new_names:raise ValueError('FEATURE_NAMES_DIFFER')
 stable=before==digests() and before[0]==contract['source_sha256']
 print(json.dumps({'validation':'A24_GLOBAL_READER_REAL_LOCAL_PARITY_READ_ONLY','status':'PARITY_VERIFIED_RESEARCH_NOT_CERTIFIED' if stable else 'SOURCE_CHANGED_RETRY_REQUIRED',
  'input_contract':contract,'source_files_stable_during_read':stable,'source_cells_and_dtypes_identical':stable,'features_and_maturity_targets_identical':stable,
  'feature_row_count':len(new_features) if stable else None,'snapshots_modified':False,'training_requested':False,'services_restarted':False,'runtime_activation_proven':False,
  'canonical_publication_authorized':False},indent=2))
except Exception as exc:
 print(json.dumps({'validation':'A24_GLOBAL_READER_REAL_LOCAL_PARITY_READ_ONLY','status':'PARITY_NOT_COMPLETED','error_type':type(exc).__name__,
  'snapshots_modified':False,'training_requested':False,'services_restarted':False,'runtime_activation_proven':False,'canonical_publication_authorized':False},indent=2))
