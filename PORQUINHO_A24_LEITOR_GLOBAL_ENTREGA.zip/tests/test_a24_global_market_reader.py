import ast,datetime as dt,io,json,math,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import pandas as pd
from universal_portfolio import global_market_reader_a24 as r
from universal_portfolio import global_market_migration_a24 as m
from brain.evolution import prediction_lab as lab
class Reader(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();self.p=self.root/m.SOURCE;self.p.parent.mkdir(parents=True)
 def write(self,raw=b'asset,date,price_eur,source\nETH,2026-10-01,2000.0100,coingecko\n'):self.p.write_bytes(raw);return raw
 def contract(self):
  p=self.root/'tools/fetch_history.py';p.parent.mkdir(exist_ok=True);p.write_text("def fetch_daily():\n quote='EUR' if legacy_call else quote_currency\n x={'vs_currency':quote.lower()}\n");return p
 def test_supported_contract_is_separate_from_resolved_currency(self):
  self.write();self.contract();_,rows,out=r.read(self.root);self.assertEqual(rows[0]['candidate_quote_currency'],'EUR');self.assertIsNone(rows[0]['price']['quote_currency']);self.assertFalse(rows[0]['historical_row_attestation']);self.assertEqual(out['unit_evidence_counts'],{'LEGACY_EUR_COMPATIBLE_CURRENT_CODE_ONLY':1})
 def test_unsupported_contract_does_not_assume_eur(self):
  self.write();_,rows,_=r.read(self.root);self.assertIsNone(rows[0]['candidate_quote_currency']);self.assertEqual(rows[0]['unit_evidence_status'],'UNIT_UNRESOLVED')
 def test_other_source_not_certified_by_coingecko_contract(self):
  self.write(b'asset,date,price_eur,source\nETH,d,1,other\n');self.contract();_,rows,_=r.read(self.root);self.assertIsNone(rows[0]['candidate_quote_currency'])
 def test_explicit_quote_independent_of_missing_instrument_identity(self):
  self.write(b'asset,date,price,quote_currency\nETH,d,1,BRL\n');_,rows,out=r.read(self.root);self.assertEqual(rows[0]['price']['quote_currency'],'BRL');self.assertIsNone(rows[0]['instrument_id']);self.assertFalse(rows[0]['identity_binding_created'])
 def test_any_explicit_currency_supported(self):
  self.write(b'asset,date,price,quote_currency\nETH,d,1,JPY\nETH,d,2,CHF\n');_,rows,_=r.read(self.root);self.assertEqual([x['price']['quote_currency'] for x in rows],['JPY','CHF'])
 def test_legacy_measure_with_row_quote_is_not_resolved(self):
  self.write(b'asset,date,price_eur,quote_currency\nETH,d,1,BRL\n');_,rows,_=r.read(self.root);self.assertEqual(rows[0]['declared_row_quote_currency'],'BRL');self.assertIsNone(rows[0]['price']['quote_currency']);self.assertIsNone(rows[0]['candidate_quote_currency'])
 def test_invalid_quote_preserved_without_defaulting_to_eur(self):
  self.write(b'asset,date,price_eur,source,quote_currency\nETH,d,1,coingecko,eur\n');self.contract();_,rows,_=r.read(self.root);self.assertEqual(rows[0]['unit_evidence_status'],'INVALID_QUOTE_DECLARATION_PRESERVED');self.assertIsNone(rows[0]['candidate_quote_currency'])
 def test_verified_migration_is_used_for_identical_content(self):
  raw=self.write();bundle=m.migrate(self.root);_,rows,out=r.read(self.root);self.assertEqual(out['storage_status'],'EXACT_CONTENT_MIGRATION_VERIFIED');self.assertEqual(self.p.read_bytes(),raw);self.assertEqual(len(rows),1)
 def test_corrupt_archive_blocks_instead_of_silent_live_fallback(self):
  self.write();bundle=m.migrate(self.root);p=self.root/m.STORE/bundle['bundle_id']/'observations.jsonl';p.write_bytes(p.read_bytes()+b'bad')
  with self.assertRaisesRegex(m.MigrationError,'INTEGRITY'):r.read(self.root)
 def test_current_new_source_does_not_reuse_older_bundle(self):
  self.write();bundle=m.migrate(self.root);old=(self.root/m.STORE/bundle['bundle_id']/'original.csv').read_bytes();self.write(b'asset,date,price_eur\nETH,d,2\n');_,_,out=r.read(self.root);self.assertEqual(out['storage_status'],'LIVE_SOURCE_NOT_ARCHIVED');self.assertEqual((self.root/m.STORE/bundle['bundle_id']/'original.csv').read_bytes(),old)
 def test_frame_values_dtypes_order_match_previous_reader(self):
  raw=self.write(b'asset,date,price_eur,volume_eur,unknown\nETH,2026-10-02,2000.0100,100,x\nBTC,2026-10-01,30000,,\nETH,2026-10-02,2000.0100,100,x\n');m.migrate(self.root);new=r.read_market_frame(self.root);old=pd.read_csv(io.BytesIO(raw));new.attrs={};pd.testing.assert_frame_equal(new,old)
 def test_reader_does_not_touch_snapshots_or_models(self):
  self.write();p=self.root/'results/latest.json';p.parent.mkdir();p.write_bytes(b'preserved-snapshot');before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};r.read_market_frame(self.root);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_source_changes_during_read_refused(self):
  self.write();original=Path.read_bytes;count=0
  def read(p):
   nonlocal count
   if p==self.p:
    count+=1
    if count>1:return b'changed'
   return original(p)
  with patch.object(Path,'read_bytes',read):
   with self.assertRaisesRegex(m.MigrationError,'SOURCE_CHANGED'):r.read(self.root)
 def test_contract_changes_during_read_refused(self):
  self.write();self.contract();original=r.legacy_contract;count=0
  def contract(root):
   nonlocal count
   out=original(root);count+=1
   if count==2:out['sha256']='changed'
   return out
  with patch.object(r,'legacy_contract',contract):
   with self.assertRaisesRegex(m.MigrationError,'CODE_CHANGED'):r.read(self.root)
 def test_feature_and_maturity_targets_preserved_with_new_reader(self):
  rows=[]
  for i in range(180):
   for a,base in [('ETH',100),('BTC',200)]:rows.append({'asset':a,'date':(dt.date(2026,1,1)+dt.timedelta(days=i)).isoformat(),'price_eur':base+i+math.sin(i)*2,'volume_eur':100+i%9,'market_cap_eur':10000,'source':'coingecko'})
  pd.DataFrame(rows).to_csv(self.p,index=False);old=pd.read_csv(self.p);m.migrate(self.root);new=r.read_market_frame(self.root)
  before,features=lab._features(old);after,other=lab._features(new);before.attrs={};after.attrs={};self.assertEqual(features,other);pd.testing.assert_frame_equal(before,after)
 def test_lab_entrypoints_use_global_reader_and_publish_input_contract(self):
  source=(Path(lab.__file__)).read_text();tree=ast.parse(source)
  for name in ('run_all','run_next','run_algorithm'):
   fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);calls=[n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='read_market_frame'];self.assertEqual(len(calls),1)
   keys=[k.value for n in ast.walk(fn) if isinstance(n,ast.Dict) for k in n.keys if isinstance(k,ast.Constant)];self.assertIn('input_contract',keys)
 def test_entrypoint_reads_new_component_without_training_insufficient_data(self):
  self.write();(self.root/'results').mkdir()
  with patch.object(lab,'ROOT',self.root),patch.object(lab,'DB',self.p.parent),patch.object(lab,'RESULTS',self.root/'results'),patch.object(lab,'_features',return_value=(pd.DataFrame(),[])),patch.object(lab,'_walk_forward',side_effect=AssertionError('train')):
   out=lab.run_next();self.assertEqual(out['status'],'DADOS_INSUFICIENTES')
 def test_no_network_or_training_in_reader(self):
  self.write()
  with patch('socket.socket.connect',side_effect=AssertionError('network')),patch('subprocess.Popen',side_effect=AssertionError('process')):_,rows,out=r.read(self.root)
  self.assertFalse(out['training_authorized_by_reader']);self.assertFalse(out['canonical_publication_authorized'])
 def test_no_currency_account_or_identity_inference(self):
  self.write(b'asset,date,price_eur,currency\nETH,d,100,EUR\n');self.contract();_,rows,_=r.read(self.root);self.assertIsNone(rows[0]['account_currency']);self.assertIsNone(rows[0]['instrument_id']);self.assertIsNone(rows[0]['price']['quote_currency'])
 def test_invalid_numeric_value_preserved(self):
  self.write(b'asset,date,price_eur\nETH,d,NaN\n');_,rows,_=r.read(self.root);self.assertEqual(rows[0]['price']['value'],'NaN');self.assertEqual(rows[0]['price']['numeric_status'],'INVALID')
