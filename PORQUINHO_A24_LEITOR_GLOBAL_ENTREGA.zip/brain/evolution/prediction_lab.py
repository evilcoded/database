from __future__ import annotations
import json, time, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from universal_portfolio.global_market_reader_a24 import read_market_frame

ROOT=Path(__file__).resolve().parents[2]
DB=ROOT/'data'/'database'
RESULTS=ROOT/'results'

ALGORITHMS=[
    'LinearRegression','Ridge','ElasticNet','RandomForest','ExtraTrees',
    'GradientBoosting','HistGradientBoosting','SVR','KNN','AdaBoost'
]


def _metrics(pred, actual):
    p=np.asarray(pred,float); a=np.asarray(actual,float)
    if len(p)==0: return {'n':0,'mae':None,'rmse':None,'corr':None,'directional_hit_rate':None}
    mae=float(np.mean(np.abs(p-a))); rmse=float(np.sqrt(np.mean((p-a)**2)))
    corr=float(np.corrcoef(p,a)[0,1]) if np.std(p)>0 and np.std(a)>0 else 0.0
    hit=float(np.mean((p>=0)==(a>=0))*100)
    return {'n':int(len(p)),'mae':mae,'rmse':rmse,'corr':corr,'directional_hit_rate':hit}


def _features(df):
    from brain.evolution.global_market_frame_a24 import prepare
    x=prepare(df)
    x['date']=pd.to_datetime(x['date'],errors='coerce')
    x=x.dropna(subset=['date']).sort_values(['_a24_series_key','date'])
    group_key='_a24_series_key'
    g=x.groupby(group_key,group_keys=False)
    x['ch1']=g['_a24_price'].pct_change(1)*100
    x['ch3']=g['_a24_price'].pct_change(3)*100
    x['ch7']=g['_a24_price'].pct_change(7)*100
    x['ch14']=g['_a24_price'].pct_change(14)*100
    x['ch30']=g['_a24_price'].pct_change(30)*100
    x['vol7']=g.ch1.transform(lambda s:s.rolling(7,min_periods=4).std())
    x['vol14']=g.ch1.transform(lambda s:s.rolling(14,min_periods=7).std())
    x['drawdown30']=g['_a24_price'].transform(lambda s:s/s.rolling(30,min_periods=10).max()-1)*100
    x['rel_volume']=g['_a24_volume'].transform(lambda s:s/s.rolling(14,min_periods=5).mean()) if x['_a24_volume'].notna().any() else 1.0
    x['momentum_persistence']=g.ch1.transform(lambda s:s.rolling(7,min_periods=4).apply(lambda z: float((z>0).mean()),raw=True)*100)
    # Identity-neutral cross-sectional reference; legacy column names retained only for result/model compatibility.
    reference=x.groupby(['date','_a24_quote_cohort'],as_index=False)[['ch7','ch30']].median().rename(columns={'ch7':'btc7','ch30':'btc30'})
    x=x.merge(reference,on=['date','_a24_quote_cohort'],how='left'); x[['btc7','btc30']]=x[['btc7','btc30']].fillna(0)
    x['liq_ratio']=(x['_a24_volume']/x['_a24_market_cap']).replace([np.inf,-np.inf],np.nan).fillna(0)
    x['momentum']=np.clip(50+x.ch7.fillna(0)*2.2+x.ch30.fillna(0)*.7,0,100)
    x['rs']=np.clip(50+(x.ch7.fillna(0)-x.btc7)*2+(x.ch30.fillna(0)-x.btc30)*.4,0,100)
    x['liquidity']=np.clip(35+np.minimum(55,x.liq_ratio*180),0,100)
    x['reversal']=np.clip(30+np.maximum(x.ch7.fillna(0)-12,0)*3+np.maximum(x.ch30.fillna(0)-35,0)*1.2,0,100)
    x['risk']=np.clip(25+abs(x.ch7.fillna(0))*.9+np.maximum(0,35-x.liquidity)*.45,0,100)
    cross=x.groupby(['date','_a24_quote_cohort'])['ch30'].transform('median').fillna(0)
    x['regime']=np.clip(50+(x.btc30-cross)*.7,0,100)
    x['risk_inverse']=100-x.risk
    # P35_PURGED_TARGET_MATURITY: a 30-observation target matures on the actual future observation date.
    x['target_maturity_date']=x.groupby(group_key)['date'].shift(-30)
    x['forward_30d']=x.groupby(group_key)['_a24_price'].shift(-30)/x['_a24_price']*100-100
    features=['ch3','ch7','ch14','ch30','vol7','vol14','drawdown30','rel_volume','momentum_persistence','rs','liquidity','reversal','regime','risk_inverse']
    x=x.replace([np.inf,-np.inf],np.nan).dropna(subset=features)
    return x,features


def _model(name):
    try:
        from sklearn.linear_model import LinearRegression,Ridge,ElasticNet
        from sklearn.ensemble import RandomForestRegressor,ExtraTreesRegressor,GradientBoostingRegressor,HistGradientBoostingRegressor,AdaBoostRegressor
        from sklearn.svm import SVR
        from sklearn.neighbors import KNeighborsRegressor
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler
        if name=='LinearRegression': return make_pipeline(StandardScaler(),LinearRegression())
        if name=='Ridge': return make_pipeline(StandardScaler(),Ridge(alpha=2.0))
        if name=='ElasticNet': return make_pipeline(StandardScaler(),ElasticNet(alpha=.04,l1_ratio=.25,max_iter=5000))
        if name=='RandomForest': return RandomForestRegressor(n_estimators=120,max_depth=8,min_samples_leaf=5,n_jobs=-1,random_state=42)
        if name=='ExtraTrees': return ExtraTreesRegressor(n_estimators=120,max_depth=10,min_samples_leaf=4,n_jobs=-1,random_state=42)
        if name=='GradientBoosting': return GradientBoostingRegressor(n_estimators=120,max_depth=2,learning_rate=.04,loss='huber',random_state=42)
        if name=='HistGradientBoosting': return HistGradientBoostingRegressor(max_iter=140,max_leaf_nodes=15,learning_rate=.05,l2_regularization=1.0,random_state=42)
        if name=='SVR': return make_pipeline(StandardScaler(),SVR(C=1.0,epsilon=.15,gamma='scale'))
        if name=='KNN': return make_pipeline(StandardScaler(),KNeighborsRegressor(n_neighbors=15,weights='distance',p=2,n_jobs=-1))
        if name=='AdaBoost': return AdaBoostRegressor(n_estimators=100,learning_rate=.03,loss='square',random_state=42)
    except Exception as e:
        raise RuntimeError('scikit-learn é necessário para o laboratório de predição: '+str(e))
    raise ValueError(name)


def _walk_forward(x,features,name,max_folds=12):
    dates=np.array(sorted(x['date'].dt.normalize().unique()))
    min_train=120
    step=max(1,(len(dates)-min_train)//max_folds or 1)
    candidates=list(range(min_train,len(dates),step))[-max_folds:]
    preds=[]; actual=[]; fold_metrics=[]
    for j in candidates:
        # A training label is legal only after its 30-observation outcome has matured.
        # Strict inequality avoids same-day availability assumptions.
        tr=(x['target_maturity_date']<dates[j]) & (x['date']<dates[j]) & x['forward_30d'].notna(); te=(x['date'].dt.normalize()==dates[j]) & x['forward_30d'].notna()
        if tr.sum()<200 or te.sum()==0: continue
        model=_model(name); model.fit(x.loc[tr,features],x.loc[tr,'forward_30d']); p=model.predict(x.loc[te,features]); a=x.loc[te,'forward_30d'].to_numpy(float)
        preds.extend(np.asarray(p,float).tolist()); actual.extend(a.tolist())
        fm=_metrics(p,a); fm['date']=str(pd.Timestamp(dates[j]).date()); fold_metrics.append(fm)
    m=_metrics(preds,actual); m['folds']=len(fold_metrics); m['fold_metrics']=fold_metrics
    if fold_metrics:
        maes=[f['mae'] for f in fold_metrics if f.get('mae') is not None]
        hits=[f['directional_hit_rate'] for f in fold_metrics if f.get('directional_hit_rate') is not None]
        corrs=[f['corr'] for f in fold_metrics if f.get('corr') is not None]
        m['mae_std']=float(np.std(maes)) if maes else None
        m['hit_std']=float(np.std(hits)) if hits else None
        m['corr_std']=float(np.std(corrs)) if corrs else None
        m['stability_score']=float(max(0,min(100, 100-(m['mae_std'] or 100)*2-(m['hit_std'] or 100)*1.2-(m['corr_std'] or 1)*20)))
    else:
        m['mae_std']=m['hit_std']=m['corr_std']=None; m['stability_score']=0.0
    return m

def _model_score(rows):
    valid=[r for r in rows if r.get('mae') is not None and np.isfinite(r.get('mae',np.nan))]
    if not valid: return None
    maes=np.array([float(r['mae']) for r in valid]); hits=np.array([float(r.get('directional_hit_rate') or 50) for r in valid]); corrs=np.array([float(r.get('corr') or 0) for r in valid]); stabs=np.array([float(r.get('stability_score') or 0) for r in valid])
    mae_ref=float(np.median(maes)) if np.median(maes)>0 else 1.0
    for r in valid:
        mae=float(r['mae']); hit=float(r.get('directional_hit_rate') or 50); corr=float(r.get('corr') or 0); stab=float(r.get('stability_score') or 0)
        mae_component=max(0,min(100,50+(mae_ref-mae)/mae_ref*50))
        hit_component=max(0,min(100,(hit-50)*4+50))
        corr_component=max(0,min(100,corr*100+50))
        r['model_score']=round(0.35*mae_component+0.25*hit_component+0.20*corr_component+0.20*stab,2)
    return max(valid,key=lambda r:(r.get('model_score',0),r.get('directional_hit_rate',0),r.get('corr',0),-r.get('mae',999)))

# P35B_LATEST_UNLABELED_PREDICTION: predict at the newest feature observation,
# but train only on labels that matured strictly before the prediction timestamp.
def _prediction_frames(x):
    if x.empty or 'target_maturity_date' not in x.columns:
        raise ValueError('P35B_NO_FEATURE_ROWS_OR_MATURITY')
    latest=x.sort_values('date').groupby('_a24_series_key' if '_a24_series_key' in x.columns else ('instrument_id' if 'instrument_id' in x.columns else 'asset'),as_index=False).tail(1).copy()
    cutoff=latest['date'].min()  # conservative shared cutoff across assets
    train=x.loc[x['forward_30d'].notna() & (x['target_maturity_date']<cutoff) & (x['date']<cutoff)].copy()
    if train.empty or latest.empty:
        raise ValueError('P35B_NO_MATURE_TRAINING_LABELS')
    return latest,train

def _ensemble_prediction(x,features,rows):
    valid=[r for r in rows if r.get('mae') is not None and r.get('model_score') is not None]
    if len(valid)<3: return None, None
    top=sorted(valid,key=lambda r:r['model_score'],reverse=True)[:3]
    preds=[]; weights=[]
    latest,train=_prediction_frames(x)
    for r in top:
        model=_model(r['algorithm']); model.fit(train[features],train['forward_30d']); preds.append(model.predict(latest[features])); weights.append(max(0.01,float(r['model_score'])))
    arr=np.vstack(preds); w=np.asarray(weights,float); blend=(arr*w[:,None]).sum(axis=0)/w.sum()
    latest['prediction_30d_pct']=blend; latest['date']=latest['date'].dt.date.astype(str)
    from brain.evolution.global_market_frame_a24 import prediction_columns
    return prediction_columns(latest), [r['algorithm'] for r in top]

def _current_prediction(x,features,name):
    latest,train=_prediction_frames(x)
    model=_model(name); model.fit(train[features],train['forward_30d'])
    latest['prediction_30d_pct']=model.predict(latest[features])
    latest['date']=latest['date'].dt.date.astype(str)
    from brain.evolution.global_market_frame_a24 import prediction_columns
    return prediction_columns(latest)


def _learn(result):
    # P35H_PROVENANCE: mark capture window; no training or source-time attestation.
    import datetime as _p35h_dt
    _p35h_start = _p35h_dt.datetime.now(_p35h_dt.timezone.utc).isoformat()
    # P35E_PROSPECTIVE_ISSUANCE: capture only new real-time research forecasts.
    # Never convert the local journal into independent archival attestation.
    try:
        from brain.evolution.p35e_prospective_issuance import capture
        result['p35e_capture']=capture(result,root=ROOT)
    except Exception as exc:
        result['p35e_capture']={'status':'FAIL_CLOSED','reason':type(exc).__name__,
                                'recorded':0,'authority':'RESEARCH_ONLY'}

    # P35H_PROVENANCE: capture-time source/code fingerprints, research-only.
    try:
        from brain.evolution.p35h_capture_provenance import capture_context
        result['p35h_capture']=capture_context(result,root=ROOT,started_at=_p35h_start)
    except Exception as exc:
        result['p35h_capture']={'status':'FAIL_CLOSED','reason':type(exc).__name__,
                                'recorded':0,'authority':'RESEARCH_ONLY'}

    # P35M15B_AUTO_EVIDENCE_CAPTURE: research-only sidecar after both journals.
    # A failure must be visible, never interpreted as validated economic evidence.
    _p35e_status = (result.get('p35e_capture') or {}).get('status')
    _p35h_status = (result.get('p35h_capture') or {}).get('status')
    if (_p35e_status == 'RESEARCH_FORECASTS_RECORDED'
            and _p35h_status == 'CAPTURE_CONTEXT_RECORDED_UNATTESTED'):
        try:
            from brain.evolution.p35m11_prospective_evidence_journal import capture_new as _p35m15b_capture
            _p35m15b_out = _p35m15b_capture(ROOT)
            if (not isinstance(_p35m15b_out, dict)
                    or _p35m15b_out.get('status') not in
                       ('RESEARCH_EVIDENCE_RECORDED_UNATTESTED', 'NO_NEW_EVIDENCE')
                    or _p35m15b_out.get('authority') != 'RESEARCH_ONLY'
                    or _p35m15b_out.get('economic_comparison_status') != 'NOT_VALIDATED'
                    or _p35m15b_out.get('comparator_promotion') is True
                    or _p35m15b_out.get('execution_performed') is True):
                raise ValueError('UNEXPECTED_P35M11_CAPTURE_RESULT')
            result['p35m15b_evidence_capture'] = _p35m15b_out
        except Exception as exc:
            result['p35m15b_evidence_capture'] = {
                'status': 'FAIL_CLOSED', 'reason': type(exc).__name__,
                'authority': 'RESEARCH_ONLY',
                'economic_comparison_status': 'NOT_VALIDATED',
                'comparator_promotion': False, 'execution_performed': False}
    else:
        result['p35m15b_evidence_capture'] = {
            'status': 'SKIPPED_UPSTREAM_NOT_COMPLETE',
            'p35e_status': _p35e_status, 'p35h_status': _p35h_status,
            'authority': 'RESEARCH_ONLY',
            'economic_comparison_status': 'NOT_VALIDATED',
            'comparator_promotion': False, 'execution_performed': False}

    try:
        from brain.memory.store import MemoryStore
        store=MemoryStore(ROOT/'data')
        champ=result.get('champion') or {}
        if champ:
            store.experiment({'id':'PRED-'+hashlib.sha256((result.get('trained_at','')+champ.get('algorithm','')).encode()).hexdigest()[:14], 'hypothesis_id':'H-PREDICTION-LAB','metric':float(champ.get('directional_hit_rate') or 0),'baseline':50.0,'passed':int((champ.get('directional_hit_rate') or 0)>=50),'params':{'champion':champ.get('algorithm'),'target':result.get('target'),'algorithms_tested':len(result.get('algorithms',[]))},'details':{'champion':champ,'uncertainty_pct':result.get('uncertainty_pct')}})
        store.event('prediction_lab_learning',{'champion':champ.get('algorithm'),'algorithms_tested':len(result.get('algorithms',[]))})
    except Exception:
        pass
    return result

def run_all():
    p=DB/'market_daily.csv'
    if not p.exists(): return {'status':'SEM_HISTORICO','message':'market_daily.csv não existe'}
    raw=read_market_frame(ROOT)
    x,features=_features(raw)
    if len(x)<400: return {'status':'DADOS_INSUFICIENTES','observations':len(x)}
    rows=[]
    for name in ALGORITHMS:
        try:
            started=time.time(); m=_walk_forward(x,features,name); m.update({'algorithm':name,'elapsed_s':round(time.time()-started,2)})
            rows.append(m)
        except Exception as e:
            rows.append({'algorithm':name,'status':'erro','error':str(e),'n':0})
    valid=[r for r in rows if r.get('mae') is not None]
    # Lower MAE is primary; directional accuracy and correlation are tie-breakers.
    champion=_model_score(rows)
    predictions=[]; ensemble_predictions=[]; ensemble_models=[]
    if champion:
        try: predictions=_current_prediction(x,features,champion['algorithm']).to_dict('records')
        except Exception: predictions=[]
        try:
            ens, ensemble_models = _ensemble_prediction(x,features,rows)
            if ens is not None: ensemble_predictions=ens.to_dict('records')
        except Exception: ensemble_predictions=[]; ensemble_models=[]
    residual_std=None
    if champion and champion.get('mae') is not None:
        residual_std=float(champion['mae']*1.4826)
    out={'status':'OK' if champion else 'SEM_RESULTADO','trained_at':pd.Timestamp.utcnow().isoformat(),'target':'forward_30d_return_pct','input_contract':raw.attrs.get('a24_input_contract'),'feature_names':features,'observations':int(len(x)),'assets':int(x.asset.nunique()),'date_min':str(x.date.min().date()),'date_max':str(x.date.max().date()),'algorithms':rows,'champion':champion,'predictions':predictions,'ensemble_predictions':ensemble_predictions,'ensemble_models':ensemble_models,'uncertainty_pct':residual_std,'note':'Benchmark walk-forward de 10 algoritmos comuns. Resultado é pesquisa/experimento, não garantia de retorno futuro.'}
    (RESULTS/'prediction_lab.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
    return _learn(out)


def run_next():
    p=DB/'market_daily.csv'
    if not p.exists(): return {'status':'SEM_HISTORICO'}
    # Run the full benchmark only when there is no valid lab yet; otherwise refresh one
    # algorithm in a deterministic round-robin to keep the monitor responsive.
    existing={}
    lab=RESULTS/'prediction_lab.json'
    if lab.exists():
        try: existing=json.loads(lab.read_text(encoding='utf-8'))
        except Exception: existing={}
    raw=read_market_frame(ROOT); x,features=_features(raw)
    if len(x)<400:return {'status':'DADOS_INSUFICIENTES','observations':len(x)}
    rows_existing=existing.get('algorithms',[])
    # Advance even when a model fails, so one bad algorithm can never lock the laboratory.
    attempts=existing.get('attempt_order',[])
    attempted_set={str(r.get('algorithm')) for r in rows_existing if r.get('algorithm')}
    if not attempts: attempts=[r for r in attempted_set if r in ALGORITHMS]
    next_index=int(existing.get('next_index',0))%len(ALGORITHMS)
    next_name=ALGORITHMS[next_index]
    for _ in range(len(ALGORITHMS)):
        if next_name not in attempted_set or len(attempted_set)>=len(ALGORITHMS): break
        next_index=(next_index+1)%len(ALGORITHMS); next_name=ALGORITHMS[next_index]
    try:
        started=time.time(); m=_walk_forward(x,features,next_name); m.update({'algorithm':next_name,'elapsed_s':round(time.time()-started,2)})
        rows=[r for r in existing.get('algorithms',[]) if r.get('algorithm')!=next_name]; rows.append(m)
        attempted_order=[a for a in existing.get('attempt_order',[]) if a!=next_name] + [next_name]
        valid=[r for r in rows if r.get('mae') is not None]
        champion=_model_score(rows)
        predictions=[]; ensemble_predictions=[]; ensemble_models=[]
        if champion:
            predictions=_current_prediction(x,features,champion['algorithm']).to_dict('records')
            try:
                ens, ensemble_models=_ensemble_prediction(x,features,rows)
                if ens is not None: ensemble_predictions=ens.to_dict('records')
            except Exception: pass
        uncertainty=float(champion['mae']*1.4826) if champion and champion.get('mae') is not None else None
        next_index=(ALGORITHMS.index(next_name)+1)%len(ALGORITHMS)
        out={'status':'OK','algorithm':next_name,'mae':m.get('mae'),'directional_hit_rate':m.get('directional_hit_rate'),'corr':m.get('corr'),'trained_at':pd.Timestamp.utcnow().isoformat(),'target':'forward_30d_return_pct','input_contract':raw.attrs.get('a24_input_contract'),'feature_names':features,'observations':int(len(x)),'assets':int(x.asset.nunique()),'date_min':str(x.date.min().date()),'date_max':str(x.date.max().date()),'algorithms':rows,'attempt_order':attempted_order,'next_index':next_index,'champion':champion,'predictions':predictions,'ensemble_predictions':ensemble_predictions,'ensemble_models':ensemble_models,'uncertainty_pct':uncertainty,'note':'Experimentos incrementais; falhas não travam a sequência. Cada algoritmo é avaliado out-of-sample.'}
        lab.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
        return _learn(out)
    except Exception as e:
        return {'status':'ERRO','algorithm':next_name,'error':str(e)}


def run_algorithm(name):
    aliases={'linear':'LinearRegression','linear regression':'LinearRegression','ridge':'Ridge','elastic net':'ElasticNet','elasticnet':'ElasticNet','random forest':'RandomForest','randomforest':'RandomForest','extra trees':'ExtraTrees','gradient boosting':'GradientBoosting','histgradientboosting':'HistGradientBoosting','hist gradient boosting':'HistGradientBoosting','svr':'SVR','support vector':'SVR','knn':'KNN','k nearest neighbors':'KNN','adaboost':'AdaBoost'}
    name=str(name or '').strip(); name=aliases.get(name.lower(),name)
    if name not in ALGORITHMS: return {'status':'ALGORITMO_NAO_RECONHECIDO','requested':name,'available':ALGORITHMS}
    p=DB/'market_daily.csv'
    if not p.exists(): return {'status':'SEM_HISTORICO','message':'market_daily.csv não existe'}
    try:
        raw=read_market_frame(ROOT); x,features=_features(raw)
        if len(x)<400:return {'status':'DADOS_INSUFICIENTES','observations':len(x)}
        started=time.time(); m=_walk_forward(x,features,name); m.update({'algorithm':name,'elapsed_s':round(time.time()-started,2)})
        lab=RESULTS/'prediction_lab.json'; existing={}
        if lab.exists():
            try: existing=json.loads(lab.read_text(encoding='utf-8'))
            except Exception: existing={}
        rows=[r for r in existing.get('algorithms',[]) if r.get('algorithm')!=name]; rows.append(m)
        valid=[r for r in rows if r.get('mae') is not None]
        champion=_model_score(rows)
        predictions=_current_prediction(x,features,champion['algorithm']).to_dict('records') if champion else []
        ensemble_predictions=[]; ensemble_models=[]
        if champion:
            try:
                ens, ensemble_models=_ensemble_prediction(x,features,rows)
                if ens is not None: ensemble_predictions=ens.to_dict('records')
            except Exception: pass
        uncertainty=float(champion['mae']*1.4826) if champion and champion.get('mae') is not None else None
        attempted=[a for a in existing.get('attempt_order',[]) if a!=name]+[name]
        out={'status':'OK','algorithm':name,'mae':m.get('mae'),'directional_hit_rate':m.get('directional_hit_rate'),'corr':m.get('corr'),'trained_at':pd.Timestamp.utcnow().isoformat(),'target':'forward_30d_return_pct','input_contract':raw.attrs.get('a24_input_contract'),'feature_names':features,'observations':int(len(x)),'assets':int(x.asset.nunique()),'date_min':str(x.date.min().date()),'date_max':str(x.date.max().date()),'algorithms':rows,'attempt_order':attempted,'next_index':(ALGORITHMS.index(name)+1)%len(ALGORITHMS),'champion':champion,'predictions':predictions,'ensemble_predictions':ensemble_predictions,'ensemble_models':ensemble_models,'uncertainty_pct':uncertainty,'note':'Ensaio explícito do algoritmo solicitado, avaliado por walk-forward e absorvido na memória do Porquinho.'}
        lab.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
        return _learn(out)
    except Exception as e:
        # Persist failure so the UI can show it, but never let one algorithm lock the lab.
        lab=RESULTS/'prediction_lab.json'; existing={}
        if lab.exists():
            try: existing=json.loads(lab.read_text(encoding='utf-8'))
            except Exception: existing={}
        failed=[r for r in existing.get('algorithms',[]) if r.get('algorithm')!=name]
        failed.append({'algorithm':name,'status':'erro','error':str(e),'mae':None,'directional_hit_rate':None,'corr':None})
        existing['algorithms']=failed; existing['attempt_order']=[a for a in existing.get('attempt_order',[]) if a!=name]+[name]; existing['next_index']=(ALGORITHMS.index(name)+1)%len(ALGORITHMS); existing['last_error']={'algorithm':name,'error':str(e),'at':pd.Timestamp.utcnow().isoformat()}; lab.write_text(json.dumps(existing,indent=2,ensure_ascii=False),encoding='utf-8')
        return {'status':'ERRO','algorithm':name,'error':str(e),'next_algorithm':ALGORITHMS[(ALGORITHMS.index(name)+1)%len(ALGORITHMS)]}

if __name__=='__main__':
    print(json.dumps(run_all(),indent=2,ensure_ascii=False))

# Compatibility aliases for older Brain/UI imports.
run_prediction_lab = run_all
__all__ = ['ALGORITHMS','run_all','run_prediction_lab','run_next','run_algorithm']
