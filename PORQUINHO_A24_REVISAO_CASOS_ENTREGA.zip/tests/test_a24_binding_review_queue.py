import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import test_a24_research_quote_acquisition as fixture
from universal_portfolio import binding_review_queue_a24 as review
from universal_portfolio.explicit_market_bindings_a24 import BindingError,digest
from tools import review_funded_bindings_a24 as cli

class Review(unittest.TestCase):
 def setUp(self):
  self.fx=fixture.Acquisition();self.fx.setUp();self.addCleanup(self.fx.doCleanups);self.root=self.fx.root
 def queue(self,demand=None):return review.build(self.root,demand or self.fx.demand(),now=fixture.NOW)
 def decisions(self,q):
  return {'schema':review.REVIEW_SCHEMA,'queue_digest':q['queue_digest'],'registry_digest':q['registry_digest'],'decisions':[{'review_id':q['rows'][0]['review_id'],'provider':'coingecko','provider_id':'source-id','identity_source_ref':'https://example.test/explicit-evidence','confirmed_by':'local-reviewer','confirmed_at':'2026-10-16T10:00:00Z','effective_from':'2026-10-16','confirmed':True}]}
 def test_universal_quotes_remain_separate(self):
  q=self.queue(self.fx.demand(('BRL','EUR','USD','JPY')));self.assertEqual(len(q['rows']),4);self.assertEqual({r['quote_currency'] for r in q['rows']},{'BRL','EUR','USD','JPY'})
 def test_duplicate_accounts_deduplicate_without_exporting_account_ids(self):
  q=self.queue(self.fx.demand(duplicate_account=True));self.assertEqual(len(q['rows']),1);self.assertEqual(q['rows'][0]['funded_context_count'],2);s=json.dumps(q);self.assertNotIn('account-BRL',s);self.assertNotIn('second',s);self.assertNotIn('amount',s)
 def test_unknown_legacy_identity_not_reformatted_or_resolved_by_symbol(self):
  d=self.fx.demand();d['research_requests'][0]['instrument_id']='CRYPTO:GLOBAL:BTC';q=self.queue(d);self.assertEqual(q['rows'][0]['instrument_id'],'CRYPTO:GLOBAL:BTC');self.assertEqual(q['rows'][0]['status'],'IDENTITY_NOT_IN_BINDING_CATALOG')
  with self.assertRaisesRegex(BindingError,'NOT_ELIGIBLE'):review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
 def test_valid_selected_case_prepares_only_no_project_writes(self):
  q=self.queue();before={str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()};doc=review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
  self.assertEqual(doc['bindings'][0]['instrument_id'],fixture.IID);self.assertEqual(doc['bindings'][0]['quote_currency'],'BRL');self.assertEqual(before,{str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_empty_selection_refused(self):
  q=self.queue();d=self.decisions(q);d['decisions']=[]
  with self.assertRaisesRegex(BindingError,'SELECTION_REQUIRED'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_confirmation_must_be_boolean_true(self):
  q=self.queue()
  for v in (False,'true',1,None):
   d=self.decisions(q);d['decisions'][0]['confirmed']=v
   with self.assertRaisesRegex(BindingError,'CONFIRMATION_REQUIRED'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_backdated_or_old_confirmation_refused(self):
  q=self.queue()
  for key,value in [('confirmed_at','2026-10-15T10:00:00Z'),('effective_from','2026-10-15'),('confirmed_at','2026-10-16T10:00:00')]:
   d=self.decisions(q);d['decisions'][0][key]=value
   with self.assertRaisesRegex(BindingError,'NO_BACKDATING'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_existing_binding_preserved_not_reconfirmed(self):
  self.fx.save([self.fx.rows()]);q=self.queue();self.assertEqual(q['rows'][0]['status'],'EXISTING_BINDING_PRESERVED')
  with self.assertRaisesRegex(BindingError,'NOT_ELIGIBLE'):review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
 def test_multiple_sources_are_not_arbitrarily_selected(self):
  self.fx.save([self.fx.rows(),self.fx.rows(provider='Other')]);self.assertEqual(self.queue()['rows'][0]['status'],'EXPLICIT_SOURCE_SELECTION_REQUIRED')
 def test_registry_change_refused(self):
  q=self.queue();self.fx.save([self.fx.rows(quote_currency='EUR')])
  with self.assertRaisesRegex(BindingError,'REGISTRY_CHANGED'):review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
 def test_demand_change_refused(self):
  old=self.queue();new=self.queue(self.fx.demand(('BRL','EUR')))
  with self.assertRaisesRegex(BindingError,'DEMAND_DIFFERS'):review.prepare(self.root,new,self.decisions(old),now=fixture.NOW)
 def test_queue_tampering_refused(self):
  q=self.queue();d=self.decisions(q);q['rows'][0]['quote_currency']='USD'
  with self.assertRaisesRegex(BindingError,'INTEGRITY'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_duplicate_case_refused(self):
  q=self.queue();d=self.decisions(q);d['decisions']*=2
  with self.assertRaisesRegex(BindingError,'DUPLICATE_REVIEW'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_source_identity_conflict_refused(self):
  self.fx.save([self.fx.rows(quote_currency='EUR')]);q=self.queue();d=self.decisions(q);d['decisions'][0]['provider_id']='source-id'
  # Existing same identity may be reviewed in another currency; it stays untouched.
  doc=review.prepare(self.root,q,d,now=fixture.NOW);self.assertEqual(len(doc['bindings']),2);self.assertEqual(doc['bindings'][0],self.fx.rows(quote_currency='EUR'))
 def test_funding_context_tampering_refused(self):
  d=self.fx.demand();d['contexts'][0]['currency']='USD'
  # The mismatched context is omitted, never turned into a source candidate.
  self.assertEqual(self.queue(d)['rows'],[])
  d=self.fx.demand();d['contexts'][0]['institution_country']='US'
  with self.assertRaisesRegex(BindingError,'CONTEXT_CHANGED'):self.queue(d)
 def test_request_fingerprint_tampering_refused(self):
  d=self.fx.demand();d['research_requests'][0]['context_fingerprint']='bad'
  with self.assertRaisesRegex(BindingError,'REQUEST_INVALID'):self.queue(d)
 def test_html_escapes_script_payload(self):
  q=self.queue();q['rows'][0]['instrument_id']='</script><script>alert(1)</script>';h=review.html(q)
  self.assertNotIn('</script><script>',h);self.assertIn('\\u003c/script',h);self.assertIn("connect-src 'none'",h);self.assertIn('textContent',h)
 def test_export_exclusive_outside_project_and_no_history_writes(self):
  q=self.queue();before={str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  with tempfile.TemporaryDirectory() as tmp,patch.object(cli,'current',return_value=q):
   output=Path(tmp)/'review';result=cli.export(self.root,output);self.assertEqual(result['status'],'LOCAL_CASE_REVIEW_CREATED');self.assertTrue((output/'REVISAO.html').is_file());self.assertEqual(json.loads((output/'FILA.json').read_text()),q)
   with self.assertRaises(FileExistsError):cli.export(self.root,output)
   with self.assertRaisesRegex(BindingError,'OUTSIDE_PROJECT'):cli.export(self.root,self.root/'review')
  self.assertEqual(before,{str(p):p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_no_provider_candidates_are_filled_in(self):
  d=self.fx.demand();d['research_requests'][0]['source_candidates']=[self.fx.rows()];q=self.queue(d);self.assertNotIn('source-id',json.dumps(q));self.assertNotIn('coingecko',json.dumps(q).lower())
 def test_no_network_or_subprocess_in_build_and_prepare(self):
  with patch('socket.socket.connect',side_effect=AssertionError('network')),patch('subprocess.Popen',side_effect=AssertionError('process')):
   q=self.queue();review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
