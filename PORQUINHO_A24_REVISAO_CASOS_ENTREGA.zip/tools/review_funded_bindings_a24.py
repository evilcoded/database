"""Export local case review; prepare only explicitly confirmed cases. No apply/network."""
import argparse,json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from universal_portfolio.binding_review_queue_a24 import build,prepare,html
from universal_portfolio.explicit_market_bindings_a24 import BindingError,canonical,digest,read
from universal_portfolio.universal_observation_bridge import build_read_only_bridge

def current(root):
 return build(root,build_read_only_bridge(root).intelligence.get('funded_currency_research') or {})
def outside(root,output):
 p=Path(output).expanduser().absolute()
 if p.is_symlink() or any(a.is_symlink() for a in p.parents):raise BindingError('SYMLINK_REFUSED')
 p=p.resolve()
 if p.is_relative_to(Path(root).resolve()):raise BindingError('REVIEW_OUTPUT_MUST_BE_OUTSIDE_PROJECT')
 return p

def export(root,output):
 queue=current(root);folder=outside(root,output);folder.mkdir(mode=0o700)
 # New exclusive directory; never overwrite an older review or project data.
 for name,body in [('REVISAO.html',html(queue)),('FILA.json',json.dumps(queue,ensure_ascii=False,indent=2)+'\n')]:
  with open(folder/name,'x',encoding='utf-8',opener=lambda p,flags:os.open(p,flags,0o600)) as f:f.write(body)
 counts={}
 for r in queue['rows']:counts[r['status']]=counts.get(r['status'],0)+1
 return {'status':'LOCAL_CASE_REVIEW_CREATED','unique_instrument_quote_count':len(queue['rows']),'case_status_counts':counts,'path':str(folder/'REVISAO.html'),
         'identity_binding_created':False,'history_write_performed':False,'network_requests':0,'financial_values_exported':False,'automatic_execution_authorized':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default=str(ROOT));sub=p.add_subparsers(dest='command',required=True)
 e=sub.add_parser('export');e.add_argument('--output',required=True)
 v=sub.add_parser('prepare');v.add_argument('--review',required=True);v.add_argument('--output',required=True)
 args=p.parse_args();root=Path(args.root).resolve(strict=True)
 if args.command=='export':result=export(root,args.output)
 else:
  queue=current(root);document=prepare(root,queue,read(Path(args.review)));output=outside(root,args.output)
  with open(output,'x',encoding='utf-8',opener=lambda p,flags:os.open(p,flags,0o600)) as f:f.write(canonical(document)+'\n')
  result={'status':'PREPARED_NOT_APPLIED','path':str(output),'review_digest':digest(document),'expected_registry_digest':queue['registry_digest'],'identity_binding_created':False,'canonical_publication_authorized':False}
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
