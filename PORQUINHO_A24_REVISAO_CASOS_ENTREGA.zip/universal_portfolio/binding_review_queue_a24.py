"""Case-by-case review of exact funded instrument/quote pairs. No binding writes."""
import datetime as dt
import json
from .explicit_market_bindings_a24 import SCHEMA as BINDING_SCHEMA, BindingError, digest, identities, load, validate
from .research_quote_acquisition_a24 import DEMAND_SCHEMA, AcquisitionError, plan
SCHEMA='porquinho.binding-review-queue-a24/1.0'
REVIEW_SCHEMA='porquinho.binding-review-decisions-a24/1.0'


def build(root,demand,*,now=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 # Use the acquisition contract, including registry validation and journal integrity.
 plan(root,demand,now=now)
 if demand.get('schema')!=DEMAND_SCHEMA:raise AcquisitionError('FUNDED_DEMAND_INVALID')
 known=identities(root);registry=load(root);rows={}
 contexts={(c['account_id'],c['currency']):c for c in demand['contexts']}
 for req in demand['research_requests']:
  ctx=contexts.get((req.get('account_id'),req.get('quote_currency')))
  if not ctx or ctx.get('research_enabled') is not True:continue
  if digest({k:v for k,v in ctx.items() if k!='context_fingerprint'})!=ctx.get('context_fingerprint'):raise BindingError('FUNDING_CONTEXT_CHANGED')
  if req.get('context_fingerprint')!=ctx['context_fingerprint'] or req.get('purpose')!='OBSERVE_AND_MATURE_ONLY' or any(req.get(k) is not False or ctx.get(k) is not False for k in ('execution_authorized','automatic_execution_authorized')):raise BindingError('RESEARCH_REQUEST_INVALID')
  allowed=ctx.get('allowed_asset_classes_from_active_plans') or []
  if allowed and req.get('candidate_asset_class') not in allowed:continue
  iid,q=req['instrument_id'],req['quote_currency']
  if not isinstance(iid,str) or not iid or not isinstance(q,str) or not q.isascii() or not q.isalpha() or not q.isupper():raise BindingError('REVIEW_IDENTITY_OR_QUOTE_INVALID')
  key=(iid,q)
  row=rows.setdefault(key,{'review_id':digest([iid,q]),'instrument_id':iid,'quote_currency':q,'asset_classes':[],
       'funded_context_count':0,'status':'IDENTITY_NOT_IN_BINDING_CATALOG' if iid not in known else 'AWAITING_CASE_REVIEW'})
  if req.get('candidate_asset_class') not in row['asset_classes']:row['asset_classes'].append(req.get('candidate_asset_class'))
  # Private account IDs are used only for deduplication, never exported.
  row.setdefault('_contexts',set()).add((req['account_id'],q))
 for row in rows.values():
  row['funded_context_count']=len(row.pop('_contexts'));row['asset_classes']=sorted(row['asset_classes'],key=str)
  existing=[b for b in registry['bindings'] if (b['instrument_id'],b['quote_currency'])==(row['instrument_id'],row['quote_currency'])]
  if existing:row['status']='EXISTING_BINDING_PRESERVED' if len(existing)==1 else 'EXPLICIT_SOURCE_SELECTION_REQUIRED'
 result={'schema':SCHEMA,'registry_digest':digest(registry),'rows':sorted(rows.values(),key=lambda r:(r['status'],r['instrument_id'],r['quote_currency'])),
         'authority':'RESEARCH_ONLY','independent_attestation':False,'automatic_execution_authorized':False,'canonical_publication_authorized':False}
 result['queue_digest']=digest(result)
 return result


def prepare(root,queue,decisions,*,now=None):
 """Prepare a merged document for the existing explicit digest-checked apply CLI."""
 now=now or dt.datetime.now(dt.timezone.utc)
 body={k:v for k,v in queue.items() if k!='queue_digest'}
 if queue.get('schema')!=SCHEMA or digest(body)!=queue.get('queue_digest'):raise BindingError('QUEUE_INTEGRITY_INVALID')
 if not isinstance(decisions,dict) or set(decisions)!={'schema','queue_digest','registry_digest','decisions'} or decisions.get('schema')!=REVIEW_SCHEMA:raise BindingError('REVIEW_SCHEMA_INVALID')
 registry=load(root)
 if decisions['registry_digest']!=digest(registry) or queue['registry_digest']!=digest(registry):raise BindingError('REGISTRY_CHANGED_SINCE_REVIEW')
 if decisions['queue_digest']!=queue['queue_digest']:raise BindingError('CURRENT_DEMAND_DIFFERS_FROM_REVIEW')
 selected=decisions['decisions']
 if not isinstance(selected,list) or not selected or len(selected)>10000:raise BindingError('EXPLICIT_CASE_SELECTION_REQUIRED')
 choices={r['review_id']:r for r in queue['rows']};seen=set();new=[]
 for item in selected:
  fields={'review_id','provider','provider_id','identity_source_ref','confirmed_by','confirmed_at','effective_from','confirmed'}
  if not isinstance(item,dict) or set(item)!=fields or item.get('confirmed') is not True:raise BindingError('EXPLICIT_CASE_CONFIRMATION_REQUIRED')
  rid=item['review_id'];row=choices.get(rid)
  if rid in seen:raise BindingError('DUPLICATE_REVIEW_CASE')
  seen.add(rid)
  if not row or row['status']!='AWAITING_CASE_REVIEW':raise BindingError('CASE_NOT_ELIGIBLE_FOR_NEW_BINDING')
  b={k:item[k] for k in fields-{'review_id','confirmed'}}
  b.update(instrument_id=row['instrument_id'],quote_currency=row['quote_currency'])
  try:
   confirmed=dt.datetime.fromisoformat(b['confirmed_at'].replace('Z','+00:00'))
   if confirmed.tzinfo is None or confirmed.astimezone(dt.timezone.utc).date()!=now.astimezone(dt.timezone.utc).date() or dt.date.fromisoformat(b['effective_from'])<now.astimezone(dt.timezone.utc).date():raise ValueError()
  except (ValueError,TypeError,AttributeError):raise BindingError('CURRENT_CONFIRMATION_NO_BACKDATING_REQUIRED')
  new.append(b)
 document=validate({'schema':BINDING_SCHEMA,'bindings':registry['bindings']+new},root=root,now=now)
 return document


def html(queue):
 data=json.dumps(queue,ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
 return '''<!doctype html><html lang="pt"><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'none'; base-uri 'none'; form-action 'none'"><title>Porquinho — revisão de fontes</title><style>body{font:16px system-ui;max-width:1000px;margin:30px auto;padding:12px;background:#0c1921;color:#eee}article{border:1px solid #567;padding:14px;margin:16px 0}label{display:block;margin:8px 0}input{width:96%;padding:7px}input[type=checkbox]{width:auto}button{padding:12px}small{color:#aac}h2{font-size:18px}</style><h1>Revisão por instrumento e moeda</h1><p>Preencha apenas casos cuja identidade e moeda de cotação você conferiu na fonte. A localidade da conta não comprova disponibilidade de compra no Brasil ou em outro país. Um vínculo permite pesquisa; não autoriza ordens ou publicação canônica.</p><p>Campos vazios não são confirmados. O arquivo exportado contém apenas os casos selecionados. Datas em UTC. Não inclua senhas, chaves, saldos ou números de contas.</p><div id="rows"></div><button id="save">Exportar casos confirmados</button><p id="message" role="status"></p><script>
const queue=QUEUE_DATA;
const fields=[['provider','Provedor (ex.: coingecko)'],['provider_id','ID exato no provedor'],['identity_source_ref','Referência da evidência de identidade e moeda'],['confirmed_by','Responsável pela revisão'],['confirmed_at','Confirmado em (ISO com fuso, ex.: 2026-10-16T10:00:00Z)'],['effective_from','Início de vigência (AAAA-MM-DD, sem retroagir)']];
const editors=[];
for(const row of queue.rows){const a=document.createElement('article');const h=document.createElement('h2');h.textContent=row.instrument_id+' / '+row.quote_currency;a.append(h);const info=document.createElement('p');info.textContent=row.status+' — '+row.funded_context_count+' contexto(s) com saldo';a.append(info);
if(row.status==='AWAITING_CASE_REVIEW'){const e={row,inputs:{}};for(const [key,label] of fields){const l=document.createElement('label');l.textContent=label;const i=document.createElement('input');i.type='text';i.autocomplete='off';l.append(i);a.append(l);e.inputs[key]=i;}const stamp=document.createElement('button');stamp.textContent='Preencher data/hora atual (UTC)';stamp.onclick=()=>{const t=new Date().toISOString();e.inputs.confirmed_at.value=t;e.inputs.effective_from.value=t.slice(0,10);};a.append(stamp);const l=document.createElement('label');e.confirm=document.createElement('input');e.confirm.type='checkbox';l.append(e.confirm,document.createTextNode(' Conferi este instrumento, este ID de provedor e esta moeda; autorizo preparar este caso para pesquisa.'));a.append(l);editors.push(e);}else{const p=document.createElement('small');p.textContent='Este caso não será alterado nesta ficha. Identidade ausente exige revisão separada; identidades existentes não são reformuladas.';a.append(p);}document.getElementById('rows').append(a);}
document.getElementById('save').onclick=()=>{const decisions=[];for(const e of editors){if(!e.confirm.checked)continue;const item={review_id:e.row.review_id,confirmed:true};for(const [key] of fields){item[key]=e.inputs[key].value.trim();if(!item[key]){document.getElementById('message').textContent='Preencha todos os campos dos casos selecionados.';return;}}decisions.push(item);}if(!decisions.length){document.getElementById('message').textContent='Nenhum caso confirmado; nenhum arquivo gerado.';return;}const obj={schema:'porquinho.binding-review-decisions-a24/1.0',queue_digest:queue.queue_digest,registry_digest:queue.registry_digest,decisions};const url=URL.createObjectURL(new Blob([JSON.stringify(obj,null,2)+'\\n'],{type:'application/json'}));const link=document.createElement('a');link.href=url;link.download='PORQUINHO_A24_CASOS_REVISADOS.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);document.getElementById('message').textContent='Revisão exportada. Nenhum vínculo aplicado ao projeto.';};
</script></html>'''.replace('QUEUE_DATA',data)
