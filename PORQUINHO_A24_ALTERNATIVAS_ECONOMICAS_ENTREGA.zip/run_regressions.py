import sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'tests')]
patterns=[
 'test_universal_runtime_composition_r21386ly11d1.py',
 'test_universal_observation_bridge_r21386ly11c.py',
 'test_universal_economic_decision_r21386ly9.py',
 'test_universal_real_economic_evidence_bridge_r21386ly9a.py',
 'test_universal_economic_edge_authority_r21386ly9k.py',
 'test_adaptive_universal_sizing_authority_r21386ly9l.py',
 'test_capital_economic_evidence_assembly_r21386ij.py',
 'test_capital_relative_utility_r21386ih.py',
 'test_a24_governed_economic_integration.py',
 'test_buy_forecast_live_hook_r2186.py',
 'test_prospective_buy_forecast_store_r2184.py',
 'test_prospective_buy_forecast_r2182.py',
 'test_prospective_buy_outcome_maturation_eligibility_r21104.py',
 'test_a24_current_episode_capture.py', 'test_a24_global_prediction_identity.py', 'test_a24_global_outcome_reconciliation.py','test_a24_explicit_market_bindings.py','test_a24_funded_currency_research.py','test_a24_research_quote_acquisition.py','test_a24_binding_review_queue.py','test_a24_global_market_migration.py','test_a24_global_market_reader.py','test_a24_binding_review_flow.py','test_a24_monitor_consolidation.py','test_a24_research_identity_compatibility.py','test_a24_research_economic_series.py','test_a24_scoped_economic_comparison.py','test_a24_economic_component_set_producer.py','test_a24_global_history_source.py','test_a24_global_research_lab.py','test_a24_research_economic_components.py','test_a24_account_cost_evidence.py','test_a24_observed_trade_costs.py','test_a24_market_context_visibility.py','test_a24_global_model_evaluation.py','test_a24_global_existing_lab.py','test_a24_economic_action_plan.py']
suite=unittest.TestSuite()
for pattern in patterns:suite.addTests(unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern=pattern))
for name in ['test_p35m6_market_evidence_gate', 'test_p35m7_canonical_market_contract_adapter', 'test_p35m9_market_evidence_sidecar', 'test_p35m11_prospective_evidence_journal']:suite.addTests(unittest.defaultTestLoader.loadTestsFromName('brain.evolution.'+name))
r=unittest.TextTestRunner(verbosity=1).run(suite)
if r.testsRun != 814 or not r.wasSuccessful() or r.skipped or r.expectedFailures:raise SystemExit(1)
print('PYTHON_REGRESSION_OK='+str(r.testsRun))

import shutil,subprocess
node=shutil.which("node")
if node is None:raise SystemExit("NODE_REQUIRED_FOR_UI_VERIFICATION")
subprocess.run([node,str(ROOT/"tests/test_a24_monitor_ui.js"),str(ROOT/"static/app.js")],check=True,cwd=ROOT)
