import copy,json,unittest,tempfile
from pathlib import Path
from unittest.mock import patch
import test_a24_funded_currency_research as f
from universal_portfolio import economic_action_plan_a24 as m
from universal_portfolio import funded_currency_research_a24 as funding
I='GLOBAL:CRYPTO:CRYPTO:TEST';J='GLOBAL:CRYPTO:CRYPTO:OTHER'
class Plan(unittest.TestCase):
 def setup(self,*,cash='100',positions=None,registry=None,budgets=None,plans=None,candidates=None,links=(),bindings=()):
  r=registry or f.registry();cashrows=[{'account_id':'account','currency':'BRL','amount':cash}]
  ps=[f.plan()] if plans is None else plans;bs=[f.budget()] if budgets is None else budgets
  cs=[{'instrument_id':I,'asset_class':'CRYPTO'},{'instrument_id':J,'asset_class':'CRYPTO'}] if candidates is None else candidates
  demand=funding.project(cash=cashrows,registry=r,budgets=bs,plans=ps,candidates=cs,bindings=bindings)
  positions=[{'instrument_id':I,'account_id':'account','currency':'BRL','quantity':'2'}] if positions is None else positions
  return dict(positions=positions,cash=cashrows,registry=r,funding=demand,candidates=cs,plans=ps,identity_links=links,bindings=bindings)
 def project(self,**kw):return m.project(**self.setup(**kw))
 def alternatives(self,r):return [a for c in r['cases'] for a in c['alternatives']]
 def test_existing_positions_and_cash_form_cases(self):
  r=m.summarize(self.project());self.assertEqual(r['position_case_count'],1);self.assertEqual(r['cash_case_count'],1)
 def test_all_action_kinds_in_existing_scope(self):self.assertEqual(set(a['kind'] for a in self.alternatives(self.project())),{'KEEP','NO_ALLOCATION','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE'})
 def test_cash_ceiling_from_existing_budget_not_order(self):
  r=self.project();c=next(c for c in r['cases'] if c['resource_kind']=='CASH');self.assertEqual(c['capital_ceiling'],'50');self.assertTrue(c['alternatives_mutually_exclusive'])
  for a in c['alternatives']:self.assertIsNone(a['requested_amount']);self.assertIsNone(a['reference_capital']);self.assertFalse(a['resources_reserved'])
 def test_cash_never_uses_position_cost_as_new_funding(self):
  r=self.project(cash='0');self.assertEqual(m.summarize(r)['cash_case_count'],0);self.assertNotIn('INCREASE',{a['kind'] for a in self.alternatives(r)})
 def test_realocation_does_not_need_free_cash(self):
  r=self.project(cash='0');a=next(a for a in self.alternatives(r) if a['kind']=='REALLOCATE');self.assertEqual(a['source_instrument_id'],I);self.assertEqual(a['destination_instrument_id'],J);self.assertEqual(a['trade_leg_count'],2);self.assertNotIn('POSITIVE_CANONICAL_CASH_REQUIRED',a['blocking_reasons'])
 def test_realocation_same_account_and_currency(self):
  for a in self.alternatives(self.project()):self.assertEqual(a['account_id'],'account');self.assertEqual(a['currency'],'BRL')
 def test_research_alias_never_creates_financial_binding(self):
  links=[{'position_instrument_id':I,'research_instrument_id':J,'evidence_ref':'review'}];r=self.project(links=links)
  for a in self.alternatives(r):
   if a['instrument_id']==J:self.assertIn('RESEARCH_LINK_NOT_FINANCIAL_IDENTITY_BINDING',a['blocking_reasons'])
  self.assertFalse(r['research_alias_used_as_financial_binding'])
 def test_zero_position_excluded_not_sell(self):
  r=self.project(positions=[{'instrument_id':I,'account_id':'account','currency':'BRL','quantity':'0'}]);self.assertEqual(r['excluded_zero_position_count'],1);self.assertEqual(m.summarize(r)['position_case_count'],0)
 def test_missing_position_identity_not_guessed_from_symbol(self):
  with self.assertRaises(ValueError):self.project(positions=[{'asset':'ETH','account_id':'account','currency':'BRL','quantity':'1'}])
 def test_unknown_quantity_blocks_exit_sizing(self):
  r=self.project(positions=[{'instrument_id':I,'account_id':'account','currency':'BRL','quantity':None}])
  for a in self.alternatives(r):
   if a['kind'] in ('REDUCE','SELL','REALLOCATE'):self.assertIn('EXPLICIT_POSITION_QUANTITY_REQUIRED',a['blocking_reasons'])
 def test_duplicate_position_rejected_not_aggregated(self):
  p={'instrument_id':I,'account_id':'account','currency':'BRL','quantity':'1'}
  with self.assertRaises(ValueError):self.project(positions=[p,p])
 def test_short_position_explicitly_unsupported(self):
  with self.assertRaises(ValueError):self.project(positions=[{'instrument_id':I,'account_id':'account','currency':'BRL','quantity':'-1'}])
 def test_position_currency_not_inferred_from_account(self):
  with self.assertRaises(ValueError):self.project(positions=[{'instrument_id':I,'account_id':'account','currency':'EUR','quantity':'1'}])
 def test_funding_cash_change_refused(self):
  kw=self.setup();kw['cash'][0]['amount']='90'
  with self.assertRaises(ValueError):m.project(**kw)
 def test_funding_fingerprint_change_refused(self):
  kw=self.setup();kw['funding']['contexts'][0]['investment_budget_amount']='90'
  with self.assertRaises(ValueError):m.project(**kw)
 def test_no_budget_is_not_capital_authority(self):
  r=self.project(budgets=[]);self.assertEqual(m.summarize(r)['funded_case_with_capital_ceiling_count'],0)
  a=next(a for a in self.alternatives(r) if a['kind']=='DEPLOY_CASH');self.assertIn('ACTIVE_INVESTMENT_BUDGET_REQUIRED',a['blocking_reasons'])
 def test_no_plan_does_not_authorize_new_purchase(self):
  r=self.project(plans=[]);a=next(a for a in self.alternatives(r) if a['kind']=='DEPLOY_CASH');self.assertIn('ACTIVE_MANUAL_INVESTMENT_PLAN_REQUIRED',a['blocking_reasons'])
 def test_execute_plan_refused(self):
  with self.assertRaises(ValueError):self.project(plans=[f.plan(automatic_execution_authorized=True)])
 def test_realocation_destination_class_keeps_plan_restriction(self):
  r=self.project(candidates=[{'instrument_id':J,'asset_class':'BOND'}]);a=next(a for a in self.alternatives(r) if a['kind']=='REALLOCATE');self.assertIn('DESTINATION_OUTSIDE_ACTIVE_PLAN_CLASSES',a['blocking_reasons'])
 def test_costs_not_fabricated_from_no_trade_or_past_fee(self):
  for a in self.alternatives(self.project()):self.assertIsNone(a['transaction_cost']);self.assertIsNone(a['relative_utility']);self.assertIsNone(a['forward_return'])
 def test_realocation_two_leg_pretrade_cost_required(self):
  a=next(a for a in self.alternatives(self.project()) if a['kind']=='REALLOCATE');self.assertIn('ACTION_SPECIFIC_PRETRADE_COST_REQUIRED',a['blocking_reasons'])
 def test_shared_cash_pool_not_duplicated_as_independent_capital(self):
  rows=[a for a in self.alternatives(self.project()) if a['kind'] in ('DEPLOY_CASH','INCREASE')];self.assertEqual(len({a['shared_cash_resource_key'] for a in rows}),1)
 def test_horizon_is_explicit_not_canonical_calendar(self):
  for a in self.alternatives(self.project()):self.assertEqual((a['horizon_unit'],a['horizon_value']),('OBSERVATIONS',30))
 def test_summary_does_not_export_private_amounts_or_accounts(self):
  s=json.dumps(m.summarize(self.project()));self.assertNotIn('"account_id"',s);self.assertNotIn('"canonical_cash_observed"',s);self.assertNotIn('"capital_ceiling"',s)
 def test_input_records_not_modified(self):
  kw=self.setup();before=copy.deepcopy(kw);m.project(**kw);self.assertEqual(kw,before)
 def test_wrong_schema_cannot_enter_governed_assembler(self):
  from universal_portfolio.economic_component_set_producer_a24 import produce
  self.assertFalse(produce(self.project())['sets'])
 def test_no_authority_or_order(self):
  r=self.project()
  for k,v in m.flags().items():self.assertEqual(r[k],v)
  for a in self.alternatives(r):
   for k,v in m.flags().items():self.assertEqual(a[k],v)
 def test_uppercase_any_currency_no_fixed_brl_eur_list(self):
  kw=self.setup(registry=f.registry('JPY'));kw['cash'][0]['currency']='JPY';kw['positions'][0]['currency']='JPY';kw['plans']=[f.plan(currency='JPY')]
  kw['funding']=funding.project(cash=kw['cash'],registry=kw['registry'],budgets=[f.budget(currency='JPY')],plans=kw['plans'],candidates=kw['candidates']);self.assertEqual(m.project(**kw)['cases'][0]['currency'],'JPY')

 def test_build_reuses_seeded_position_and_preserves_files(self):
  from universal_portfolio.opening_seeded_derivation import SeededPosition
  kw=self.setup();state={'authority':'NONE','ledger_write':False,'cash':kw['cash'],'positions':[SeededPosition('account','EXPLICIT_TRANSACTION_ACCOUNT',None,I,'BRL','2',None,None)]}
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir();sentinel=root/'data/transaction_ledger.jsonl';sentinel.write_text('PRESERVE');before=(sentinel.read_bytes(),sentinel.stat().st_mtime_ns)
   with patch('universal_portfolio.canonical_runtime_read_model.build',return_value=state),patch('universal_portfolio.investment_plan_runtime._accounts',return_value=kw['registry']),patch('universal_portfolio.investment_plan_store.InvestmentPlanStore.list',return_value=kw['plans']),patch('universal_portfolio.planning_budget_store.PlanningBudgetStore.list',return_value=[f.budget()]),patch('universal_portfolio.explicit_market_bindings_a24.load',return_value={'bindings':[]}),patch('universal_portfolio.reviewed_research_identity_links_a24.load',return_value=[]):r=m.build(root,funding=kw['funding'],candidates=kw['candidates'])
   self.assertEqual(r['status'],'ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY');self.assertEqual(before,(sentinel.read_bytes(),sentinel.stat().st_mtime_ns))
 def test_build_revalidates_budget_instead_of_using_old_funding(self):
  kw=self.setup();state={'authority':'NONE','ledger_write':False,'cash':kw['cash'],'positions':kw['positions']}
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir()
   with patch('universal_portfolio.canonical_runtime_read_model.build',return_value=state),patch('universal_portfolio.investment_plan_runtime._accounts',return_value=kw['registry']),patch('universal_portfolio.investment_plan_store.InvestmentPlanStore.list',return_value=kw['plans']),patch('universal_portfolio.planning_budget_store.PlanningBudgetStore.list',return_value=[f.budget(amount='40')]),patch('universal_portfolio.explicit_market_bindings_a24.load',return_value={'bindings':[]}),patch('universal_portfolio.reviewed_research_identity_links_a24.load',return_value=[]):r=m.build(root,funding=kw['funding'],candidates=kw['candidates'])
   self.assertEqual(r['reason'],'FUNDING_PLAN_OR_BUDGET_CHANGED_RETRY_REQUIRED')
