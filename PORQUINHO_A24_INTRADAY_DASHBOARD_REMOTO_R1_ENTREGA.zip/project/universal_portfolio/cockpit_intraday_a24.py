"""Read existing intraday only. Explicit global rows and isolated legacy reference.
Current producer compatibility is not historical identity/currency attestation.
"""
import ast,csv,datetime as dt,hashlib,io,math
from collections import defaultdict,Counter
from decimal import Decimal
from .explicit_market_bindings_a24 import local,digest
SCHEMA='porquinho.cockpit-intraday-a24/1.0'
def contract(raw):
 tree=ast.parse(raw);fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fetch_intraday']
 if len(fns)!=1:return False
 request=any(isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='vs_currency' and isinstance(v,ast.Constant) and v.value=='eur' for k,v in zip(n.keys,n.values)) for n in ast.walk(fns[0]))
 cadence=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='resample' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='10min' for n in ast.walk(fns[0]))
 return request and cadence

# Pin the observed writer contract; this is compatibility, never historical attestation.
NORMAL_WRITER_SHA='e0ab60452286672621d7ff76392a32fa59ac4e6dcf7c438e3780debe63090891'
def project(rows,*,now,legacy_contract=False,normal_writer=False):
 if now.tzinfo is None:raise ValueError('AWARE_TIME_REQUIRED')
 now=now.astimezone(dt.timezone.utc)
 groups=defaultdict(list);duplicates=set();seen=set();skipped=0;reasons=Counter()
 for r in rows:
  try:
   ts=dt.datetime.fromisoformat(str(r.get('timestamp')).replace('Z','+00:00'))
   if ts.tzinfo is None:skipped+=1;reasons['NAIVE_TIMESTAMP']+=1;continue
   if not now-dt.timedelta(hours=48)<=ts<=now:skipped+=1;reasons['OUTSIDE_CURRENT_48_HOURS']+=1;continue
   ts=ts.astimezone(dt.timezone.utc)
   iid=r.get('instrument_id');q=r.get('quote_currency');provider=r.get('provider');pid=r.get('provider_id')
   if all(isinstance(x,str) and x.strip()==x and x for x in (iid,q,provider,pid)) and q.isalpha() and q.isupper():
    price=Decimal(str(r.get('price')));key=(iid,q,provider,pid,'EXPLICIT_ROW_CONTEXT');label=r.get('asset') or iid
   elif r.get('asset') and ((legacy_contract and r.get('source')=='coingecko_resampled_10m') or (normal_writer and not r.get('source') and all(k in r for k in ('promising_pct','opportunity','current_weight_pct','target_weight_pct')))):
    price=Decimal(str(r.get('price_eur')));key=(None,'EUR','coingecko',r['asset'],'CURRENT_LEGACY_CODE_COMPATIBILITY_ONLY');label=r['asset']
   else:skipped+=1;reasons['UNRECOGNIZED_SOURCE_CONTEXT']+=1;continue
   if not price.is_finite() or price<=0 or not math.isfinite(float(price)) or float(price)<=0:skipped+=1;continue
   k=key+(ts.isoformat(),)
   if k in seen:duplicates.add(key)
   seen.add(k);groups[(key,str(label))].append({'date':ts.isoformat(),'price':str(price)})
  except (ValueError,TypeError,ArithmeticError):skipped+=1;reasons['INVALID_VALUE_OR_TIMESTAMP']+=1
 series=[]
 for (key,label),points in sorted(groups.items(),key=lambda x:str(x[0])):
  if key in duplicates:skipped+=len(points);reasons['AMBIGUOUS_DUPLICATE_SERIES']+=len(points);continue
  points=sorted(points,key=lambda p:p['date'])
  gaps=sorted((dt.datetime.fromisoformat(b['date'])-dt.datetime.fromisoformat(a['date'])).total_seconds() for a,b in zip(points,points[1:]))
  series.append({'series_id':digest(list(key)),'instrument_id':key[0],'display_label':label,'quote_currency':key[1],'provider':key[2],'provider_id':key[3] if key[4]=='EXPLICIT_ROW_CONTEXT' else None,
   'scope':key[4],'historical_row_attestation':False,'financial_identity_binding_created':False,'points':points,
   'observed_cadence_seconds':gaps[len(gaps)//2] if gaps else None,'resampling_in_current_producer':key[4]=='CURRENT_LEGACY_CODE_COMPATIBILITY_ONLY'})
 return {'schema':SCHEMA,'status':'INTRADAY_INSPECTED','series':series,'series_count':len(series),'skipped_rows':skipped,
  'skipped_reason_counts':dict(reasons),'latest_point_at':max((p['date'] for s in series for p in s['points']),default=None),'observed_at':now.isoformat(),'new_collection_requested':False,'execution_authorized':False,'history_write_performed':False,'financial_mutation':False}

def build(root,*,now):
 try:
  p=local(root,'data/database/market_intraday_10m.csv');code=local(root,'tools/fetch_history.py')
  if not p.exists():return project([],now=now)
  if p.stat().st_size>32*1024*1024:raise ValueError('INTRADAY_READ_LIMIT')
  raw=p.read_bytes();producer=code.read_bytes() if code.exists() else b''
  writer=local(root,'porquinho.py');writer_raw=writer.read_bytes() if writer.exists() else b''
  result=project(list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))),now=now,legacy_contract=contract(producer) if producer else False,normal_writer=hashlib.sha256(writer_raw).hexdigest()==NORMAL_WRITER_SHA)
  if writer_raw!=(writer.read_bytes() if writer.exists() else b''):raise ValueError('WRITER_CHANGED_DURING_READ')
  result['normal_writer_contract_verified']=hashlib.sha256(writer_raw).hexdigest()==NORMAL_WRITER_SHA
  result['snapshot_pnl']=snapshot_pnl(root,now)
  if p.read_bytes()!=raw or (code.read_bytes() if code.exists() else b'')!=producer:raise ValueError('INTRADAY_CHANGED_DURING_READ')
  result['producer_sha256']=hashlib.sha256(producer).hexdigest();return result
 except Exception as exc:return {'schema':SCHEMA,'status':'INTRADAY_UNAVAILABLE','series':[],'error_type':type(exc).__name__,'execution_authorized':False,'history_write_performed':False,'financial_mutation':False}


def snapshot_pnl(root,now):
 """Stored P/L only, not hydrated holdings or wealth changes including deposits."""
 from .experience_panels_a24 import snapshot_point,number,stamp
 folder=local(root,'snapshots');groups=defaultdict(list);used=0;skipped=0
 for p in sorted(folder.glob('snapshot_*.json'),reverse=True)[:400] if folder.exists() else []:
  try:
   if p.is_symlink() or p.stat().st_size>2*1024*1024:continue
   used+=p.stat().st_size
   if used>64*1024*1024:break
   raw=p.read_bytes();obj=__import__('json').loads(raw);point=snapshot_point(obj,now=now)
   if raw!=p.read_bytes():raise ValueError('SNAPSHOT_CHANGED')
   if not point or stamp(point['date'])<now-dt.timedelta(hours=25):continue
   legacy=point['scope'].startswith('LEGACY_');value=number(obj.get('total_pnl_eur') if legacy else obj.get('total_pnl'))
   if value is None:continue
   groups[(point['currency'],point['scope'],point['account_id'])].append({'date':point['date'],'pnl':str(value),'source_sha256':hashlib.sha256(raw).hexdigest()})
  except Exception:skipped+=1
 series=[]
 for (q,scope,account),points in groups.items():
  points.sort(key=lambda p:p['date']);latest=points[-1];target=stamp(latest['date'])-dt.timedelta(minutes=10)
  candidates=[p for p in points[:-1] if abs((stamp(p['date'])-target).total_seconds())<=120]
  prior=min(candidates,key=lambda p:abs((stamp(p['date'])-target).total_seconds())) if candidates else None
  fresh=(now-stamp(latest['date'])).total_seconds()<=900
  series.append({'quote_currency':q,'scope':scope,'account_id':account,'points':points,'latest_at':latest['date'],'prior_at':prior['date'] if prior else None,'change_10m':str(number(latest['pnl'])-number(prior['pnl'])) if prior and fresh else None,'fresh':fresh,'metric':'CHANGE_IN_STORED_TOTAL_PNL_NOT_CASH_FLOW_ADJUSTED_RETURN'})
 return {'series':series,'skipped_snapshots':skipped,'history_write_performed':False}
