import unittest
from unittest.mock import patch
from tools import iphone_local_access_a24 as m
class Remote(unittest.TestCase):
 def test_private_overlay_preferred_without_exposing_service(self):
  s=m.render({'mac_private_overlay_ip':'100.65.1.2','mac_lan_ip':'192.168.1.2','mac_user':'demo'});self.assertIn('100.65.1.2',s);self.assertIn('Tailscale',s);self.assertIn('dados móveis',s);self.assertIn('127.0.0.1:8765',s);self.assertNotIn('0.0.0.0',s)
 def test_only_local_overlay_ip_queried_not_peers_or_secrets(self):
  with patch.object(m.shutil,'which',return_value='/cli'),patch.object(m.Path,'is_file',return_value=True),patch.object(m.subprocess,'check_output',return_value=b'100.65.1.2') as call:
   self.assertEqual(m.private_overlay_ip(),'100.65.1.2');self.assertEqual(call.call_args.args[0],['/cli','ip','-4'])
 def test_public_ip_not_accepted_as_overlay(self):
  with patch.object(m.shutil,'which',return_value='/cli'),patch.object(m.Path,'is_file',return_value=True),patch.object(m.subprocess,'check_output',return_value=b'8.8.8.8'):self.assertIsNone(m.private_overlay_ip())
