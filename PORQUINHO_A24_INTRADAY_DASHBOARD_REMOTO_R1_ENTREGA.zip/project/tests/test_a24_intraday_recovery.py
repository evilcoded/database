import datetime as dt,hashlib,json,tempfile,unittest
from pathlib import Path
from universal_portfolio import cockpit_intraday_a24 as m
NOW=dt.datetime(2026,10,18,12,tzinfo=dt.timezone.utc)
class Recovery(unittest.TestCase):
 def row(self,**kw):
  return dict(timestamp='2026-10-18T11:50:00+00:00',asset='ETH',price_eur='2200',promising_pct='60',opportunity='50',current_weight_pct='10',target_weight_pct='12',**kw)
 def test_observed_normal_writer_recovered_as_reference_only(self):
  r=m.project([self.row()],now=NOW,normal_writer=True);self.assertEqual(r['series_count'],1);s=r['series'][0];self.assertEqual(s['quote_currency'],'EUR');self.assertIsNone(s['instrument_id']);self.assertFalse(s['historical_row_attestation'])
 def test_no_writer_verification_no_suffix_inference(self):self.assertEqual(m.project([self.row()],now=NOW)['series_count'],0)
 def test_unknown_source_not_accepted_as_writer(self):self.assertEqual(m.project([self.row(source='unknown')],now=NOW,normal_writer=True)['series_count'],0)
 def test_reason_counters_distinguish_old_rows(self):
  r=self.row();r['timestamp']='2026-09-01T12:00:00+00:00';out=m.project([r],now=NOW,normal_writer=True);self.assertEqual(out['skipped_reason_counts'],{'OUTSIDE_CURRENT_48_HOURS':1})
 def test_no_invented_minute_points(self):
  a=self.row();b=self.row();b['timestamp']='2026-10-18T12:00:00+00:00';s=m.project([a,b],now=NOW,normal_writer=True)['series'][0];self.assertEqual(s['observed_cadence_seconds'],600);self.assertEqual(len(s['points']),2)
 def test_partial_ambiguous_duplicates_still_refused(self):self.assertEqual(m.project([self.row(),self.row()],now=NOW,normal_writer=True)['series_count'],0)
 def snapshots(self,root,old='3',new='8',q='JPY',minutes=10):
  folder=root/'snapshots';folder.mkdir()
  for i,(t,pnl) in enumerate([(NOW-dt.timedelta(minutes=minutes),old),(NOW,new)]):
   (folder/f'snapshot_20261018_12000{i}.json').write_text(json.dumps(dict(timestamp=t.isoformat(),currency=q,total_wealth='100',cash='20',portfolio_value='80',total_pnl=pnl)))
 def test_stored_pnl_change_10m_arbitrary_currency_and_no_write(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);self.snapshots(root);before={p:p.read_bytes() for p in (root/'snapshots').iterdir()};r=m.snapshot_pnl(root,NOW);self.assertEqual(r['series'][0]['change_10m'],'5');self.assertEqual(r['series'][0]['quote_currency'],'JPY');self.assertEqual(before,{p:p.read_bytes() for p in before})
 def test_missing_interval_not_fabricated(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);self.snapshots(root,minutes=25);self.assertIsNone(m.snapshot_pnl(root,NOW)['series'][0]['change_10m'])
 def test_stale_snapshot_has_no_current_pnl(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);self.snapshots(root);self.assertIsNone(m.snapshot_pnl(root,NOW+dt.timedelta(hours=1))['series'][0]['change_10m'])
 def test_wealth_change_not_used_as_pnl(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);self.snapshots(root,old=None,new=None);self.assertEqual(m.snapshot_pnl(root,NOW)['series'],[])
