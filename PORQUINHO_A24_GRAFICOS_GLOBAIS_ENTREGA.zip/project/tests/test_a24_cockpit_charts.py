import copy,unittest,datetime as dt
from unittest.mock import patch
import test_a24_global_research_lab as fixture
from universal_portfolio import cockpit_charts_a24 as m
from universal_portfolio import global_history_source_a24 as history
class Charts(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Lab();self.f.setUp();self.addCleanup(self.f.doCleanups);self.body=self.f.body();self.root=self.f.root
 def result(self,bodies=None,now=None):return m.project([self.body] if bodies is None else bodies,now=now or fixture.NOW,catalog={'instruments':[{'instrument_id':self.body['binding']['instrument_id'],'symbol':'TEST'}]})
 def test_prices_dates_preserved_not_reconstructed_portfolio(self):
  r=self.result();s=r['series'][0];self.assertEqual(len(s['points']),364);self.assertEqual(s['points'][-1]['price'],self.body['observations'][-1]['price']);self.assertFalse(r['historical_portfolio_reconstructed'])
 def test_quote_currency_provider_and_identity_explicit(self):
  s=self.result()['series'][0]
  for k in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref'):self.assertEqual(s[k],self.body['binding'][k])
 def test_account_scope_is_explicit_not_ticker(self):
  r=m.project([self.body],now=fixture.NOW,catalog={},account_contexts={self.body['series_id']:['account']});self.assertEqual(r['series'][0]['account_ids'],['account'])
 def test_future_acquisition_refused(self):
  with self.assertRaisesRegex(ValueError,'FUTURE'):self.result(now=fixture.NOW-dt.timedelta(days=1))
 def test_duplicate_series_refused(self):
  with self.assertRaisesRegex(ValueError,'DUPLICATE'):self.result([self.body,self.body])
 def test_stale_history_remains_labelled_not_current_quote(self):self.assertTrue(self.result(now=fixture.NOW+dt.timedelta(days=5))['series'][0]['stale'])
 def test_empty_sources_not_flat_zero_performance(self):self.assertEqual(self.result([])['series'],[])
 def test_no_financial_authority_or_writes(self):
  r=self.result()
  for k,v in m.flags().items():self.assertEqual(r[k],v)
 def test_source_input_unchanged(self):
  before=copy.deepcopy(self.body);self.result();self.assertEqual(before,self.body)
 def test_unmatched_catalog_name_not_guessed(self):
  r=m.project([self.body],now=fixture.NOW,catalog={'instruments':[{'instrument_id':'OTHER','symbol':'TEST'}]});self.assertIsNone(r['series'][0]['display_label'])
 def test_verified_build_reads_no_training_network_or_changes(self):
  self.f.source();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  with patch.object(history.Transport,'get_json',side_effect=AssertionError('NO_NETWORK')):
   r=m.build(self.root,self.f.demand,now=fixture.NOW,catalog={})
  self.assertEqual(r['status'],'CHART_SOURCES_INSPECTED');self.assertEqual(r['series_count'],1);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_source_modified_during_projection_refused(self):
  path,_=self.f.source();original=m.project
  def changed(*args,**kw):
   result=original(*args,**kw);path.write_bytes(b'{}');return result
  with patch.object(m,'project',side_effect=changed):
   r=m.build(self.root,self.f.demand,now=fixture.NOW,catalog={})
  self.assertEqual(r['status'],'CHART_SOURCES_UNAVAILABLE');self.assertFalse(r['series'])
