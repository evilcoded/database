/* Universal experience layer. Reads the shared monitor projection; never trades. */
'use strict';
const a24CockpitState={currency:'',account:'',query:''};
const a24CockpitOpen=new Map();
function a24UiMoney(value,currency){
 if(value===null||value===undefined||value===''||typeof value==='boolean'||!Number.isFinite(Number(value)))return 'Indisponível';
 const n=Number(value);
 try{return new Intl.NumberFormat('pt-PT',{style:'currency',currency,maximumFractionDigits:2}).format(n)}catch(_){return n.toLocaleString('pt-PT',{maximumFractionDigits:2})+' '+String(currency||'moeda não informada')}
}
function a24UiPercent(value){return value===null||value===undefined||value===''||!Number.isFinite(Number(value))?'Indisponível':Number(value).toLocaleString('pt-PT',{maximumFractionDigits:2})+'%'}
function a24UiAccount(id,q,d=a24MonitorData){
 const a=(d?.universal_portfolio?.accounts||[]).filter(x=>x.account_id===id&&x.currency===q);
 return a.length===1?[a[0].institution_name,a[0].name].filter(Boolean).join(' · ')||'Conta cadastrada':'Conta por identificar';
}
function a24UiScope(row){return (!a24CockpitState.currency||(row.currency||row.quote_currency)===a24CockpitState.currency)&&(!a24CockpitState.account||row.account_id===a24CockpitState.account)}
function a24UiSearch(row){const q=a24CockpitState.query.trim().toLocaleLowerCase();return !q||[row.display_label,row.instrument_id,row.source_display_label,row.destination_display_label,row.source_instrument_id,row.destination_instrument_id,row.provider,row.provider_id].some(x=>typeof x==='string'&&x.toLocaleLowerCase().includes(q))}
function a24UiFacts(d){const f=d?.universal_portfolio;return f?.schema==='porquinho.universal-cockpit-a24/1.0'&&f.status==='UNIVERSAL_FACTS_PROJECTED'&&f.cross_currency_aggregation===false&&f.execution_authorized===false&&Array.isArray(f.positions)&&Array.isArray(f.cash)?f:null}
function a24UiFilters(d){
 const f=a24UiFacts(d);const a=d?.reallocation_analysis;
 const currencies=[...new Set([...(f?.currency_totals||[]).map(x=>x.currency),...(d?.global_research_lab?.contexts||[]).map(x=>x.quote_currency),...(a?.rows||[]).map(x=>x.currency)])].filter(x=>typeof x==='string'&&x).sort();
 const accounts=(f?.accounts||[]).filter(x=>!a24CockpitState.currency||x.currency===a24CockpitState.currency);
 return `<div class="a24-filters"><label>Moeda<select data-a24-filter="currency"><option value="">Todas, separadas</option>${currencies.map(q=>`<option value="${esc(q)}" ${q===a24CockpitState.currency?'selected':''}>${esc(q)}</option>`).join('')}</select></label><label>Conta<select data-a24-filter="account"><option value="">Todas as contas</option>${accounts.map(a=>`<option value="${esc(a.account_id)}" ${a.account_id===a24CockpitState.account?'selected':''}>${esc(a24UiAccount(a.account_id,a.currency,d))} · ${esc(a.currency)}</option>`).join('')}</select></label><label>Ativo ou fonte<input data-a24-filter="query" value="${esc(a24CockpitState.query)}" placeholder="Pesquisar no universo acompanhado"></label><button type="button" data-a24-clear>Limpar filtros</button></div>`;
}
function a24UiHealth(d){const m=d?.monitor||{};return `<div class="a24-health" role="status"><span>${esc(a24MonitorHealthText(m))}</span><small>Snapshot: ${esc(a24MonitorTime(m.snapshot))}${a24MonitorFailed?' · Última consulta indisponível; dados anteriores exibidos.':''}</small></div>`}
function a24UiTotals(d){
 const f=a24UiFacts(d);if(!f)return '<p class="a24-empty">Dados financeiros indisponíveis nesta leitura.</p>';
 const currencies=f.currency_totals.filter(x=>!a24CockpitState.currency||x.currency===a24CockpitState.currency);
 return `<div class="a24-currency-grid">${currencies.map(t=>{
  const cs=f.cash.filter(x=>x.currency===t.currency&&a24UiScope(x));const ps=f.positions.filter(x=>x.currency===t.currency&&a24UiScope(x));
  // With account filters show rows, without summing client-side monetary amounts.
  const cash=a24CockpitState.account?(cs.length===1?cs[0].amount:null):t.cash;
  const invested=a24CockpitState.account?null:t.invested_cost;
  return `<article class="a24-currency"><header><b>${esc(t.currency)}</b><span>${ps.length} posições</span></header><small>Cash registrado</small><strong>${esc(a24UiMoney(cash,t.currency))}</strong>${a24CockpitState.account?'<small>Custos das posições na tabela abaixo</small>':`<small>Custo de aquisição registrado: ${esc(a24UiMoney(invested,t.currency))}</small>`}</article>`;
 }).join('')||'<p class="a24-empty">Nenhum registro nesta moeda.</p>'}</div><p class="a24-caption">Cada moeda mantém seus valores próprios. Custo de aquisição e cash registrado são distintos de valor de mercado.</p>`;
}
function a24UiPositionReading(p){
 const scores=(typeof lastStatus==='object'&&lastStatus?.portfolio?.scores)||[];
 const exact=scores.filter(s=>{const k=a24MonitorKey(s);return k&&k[0]===p.instrument_id&&k[1]===p.account_id&&k[2]===p.currency&&(!s.quote_currency||s.quote_currency===p.currency)});
 const reading=exact.length===1?a24OperationalReading(exact[0]):null;
 return reading?`<span class="a24-pill">${esc(reading.label)}</span><small>${esc(reading.timeSource+': '+reading.time)}</small>`:'<span class="a24-pill">Leitura por contexto pendente</span>';
}
function a24UiPositions(d){
 const f=a24UiFacts(d);if(!f)return '<p class="a24-empty">Aguardando posições do registro financeiro.</p>';
 const rows=f.positions.filter(x=>a24UiScope(x)&&a24UiSearch(x));
 return `<div class="a24-table-scroll"><table class="a24-table"><thead><tr><th>Ativo</th><th>Conta / moeda</th><th>Quantidade</th><th>Custo registrado</th><th>Valor de referência</th><th>Resultado de referência</th><th>Leitura do Brain</th></tr></thead><tbody>${rows.map(p=>{
 const quotes=p.reference_market_value===null?'<small>Cotação explícita pendente</small>':`<small>Pesquisa · ${esc(p.reference_quote_at||'data não informada')}</small>`;
 return `<tr><td><b>${esc(p.display_label||p.instrument_id||'Identidade pendente')}</b>${p.context_status!=='EXACT_REGISTERED_CONTEXT'?'<small>Revisar contexto financeiro</small>':''}</td><td>${esc(a24UiAccount(p.account_id,p.currency,d))}<small>${esc(p.currency||'Moeda pendente')}</small></td><td>${esc(p.quantity??'Indisponível')}</td><td>${esc(a24UiMoney(p.cost_basis,p.currency))}</td><td>${esc(a24UiMoney(p.reference_market_value,p.currency))}${quotes}</td><td>${esc(a24UiMoney(p.reference_pnl,p.currency))}<small>${esc(a24UiPercent(p.reference_pnl_pct))}</small></td><td>${a24UiPositionReading(p)}</td></tr>`;
 }).join('')||'<tr><td colspan="7">Nenhuma posição corresponde aos filtros.</td></tr>'}</tbody></table></div><p class="a24-caption">Cotações e resultado de referência não são preços executáveis nem lucro realizado. As leituras de referência anteriores continuam disponíveis na seção própria.</p>`;
}
const a24ReallocationDetailed=a24ReallocationPanel;
function a24UiRange(models,key,percent=true){const ns=models.map(m=>m[key]).filter(x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x))).map(Number);if(!ns.length)return 'Indisponível';const min=Math.min(...ns),max=Math.max(...ns),fmt=x=>percent?a24UiPercent(x):String(x);return min===max?fmt(min):fmt(min)+' a '+fmt(max)}
function a24UiSwapCard(r,d){
 const evidence={...d,reallocation_analysis:{...d.reallocation_analysis,rows:[r],pair_count:1,compared_pair_count:r.models.length?1:0,gross_candidate_count:r.status==='GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING'?1:0}};
 const candidate=r.status==='GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING';
 return `<article class="a24-swap ${candidate?'a24-candidate':''}"><header><div><small>${candidate?'Candidato · vantagem bruta':'Comparação de realocação'}</small><h3>${esc(r.source_display_label||r.source_instrument_id)} <span>→</span> ${esc(r.destination_display_label||r.destination_instrument_id)}</h3><p>${esc(a24UiAccount(r.account_id,r.currency,d))} · ${esc(r.currency)}</p></div><span class="a24-pill">${candidate?'Custos e valor pendentes':r.status==='NO_GROSS_ADVANTAGE_IN_AVAILABLE_MODELS'?'Sem vantagem bruta':r.status==='AWAITING_COMPARABLE_FORECASTS'?'Faltam previsões':'Evidência inconclusiva'}</span></header><div class="a24-swap-metrics"><div><small>Manter origem · estimativa</small><b>${esc(a24UiRange(r.models,'source_return_pct'))}</b></div><div><small>Destino · estimativa</small><b>${esc(a24UiRange(r.models,'destination_return_pct'))}</b></div><div><small>Capital comparado</small><b>${esc(a24UiMoney(r.reference_capital,r.currency))}</b></div></div><p class="a24-caption">Intervalos mostram a variação entre modelos, não uma probabilidade de acerto. O capital comparado não é um valor proposto para negociar.</p><details data-a24-disclosure="swap-evidence-${esc(r.alternative_id)}"><summary>Ver evidências e pendências · ${r.models.length} modelos</summary>${a24ReallocationDetailed(evidence)}</details></article>`;
}
a24ReallocationPanel=function(d){
 const a=d?.reallocation_analysis;
 if(a?.schema!=='porquinho.reallocation-analysis-a24/1.0'||a.status!=='REALLOCATION_COMPARISONS_INSPECTED'||a.execution_authorized!==false||a.recommendation_created!==false||!Array.isArray(a.rows))return '<section class="a24-section"><h2>Realocação entre ativos</h2><p class="a24-empty">Comparação indisponível nesta leitura.</p></section>';
 const rows=a.rows.filter(r=>a24UiScope(r)&&a24UiSearch(r));const compared=rows.filter(r=>r.models?.length);const candidates=compared.filter(r=>r.status==='GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING');
 const others=rows.filter(r=>!candidates.includes(r));const groups=new Map();
 for(const r of others){const key=JSON.stringify([r.source_instrument_id,r.account_id,r.currency]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r)}
 const otherHtml=[...groups].map(([key,rs])=>`<details data-a24-disclosure="source-${esc(key)}"><summary>${esc(rs[0].source_display_label||rs[0].source_instrument_id)} · ${esc(a24UiAccount(rs[0].account_id,rs[0].currency,d))} · ${esc(rs[0].currency)} · ${rs.length} destinos</summary>${rs.filter(r=>r.models?.length).map(r=>a24UiSwapCard(r,d)).join('')}${rs.some(r=>!r.models?.length)?`<details data-a24-disclosure="unavailable-${esc(key)}"><summary>${rs.filter(r=>!r.models?.length).length} destinos aguardando previsões</summary><ul>${rs.filter(r=>!r.models?.length).map(r=>`<li>${esc(r.destination_display_label||r.destination_instrument_id)} · previsões comparáveis pendentes</li>`).join('')}</ul></details>`:''}</details>`).join('');
 return `<section class="a24-section"><div class="a24-section-head"><div><h2>Realocação entre ativos</h2><p>${compared.length} pares comparados · ${candidates.length} candidatos brutos · ${rows.length-compared.length} aguardando dados</p></div></div><p class="a24-caption">Origem e destino na mesma conta e moeda. Horizonte: 30 observações. Custos e dimensionamento permanecem explícitos; esta análise não é uma ordem.</p><div class="a24-swap-grid">${candidates.map(r=>a24UiSwapCard(r,d)).join('')||'<p class="a24-empty">Nenhum candidato bruto nos filtros atuais. As demais comparações continuam nos detalhes.</p>'}</div>${others.length?`<details data-a24-disclosure="other-reallocations"><summary>Outras comparações e dados pendentes · ${others.length} pares</summary>${otherHtml}</details>`:''}</section>`;
};
function a24UiResearch(d){
 const h=d?.global_research_lab;if(h?.schema!=='porquinho.global-research-lab-a24/1.0'||h.execution_authorized!==false||!Array.isArray(h.contexts))return '<p class="a24-empty">Contextos de pesquisa indisponíveis.</p>';
 const positions=[...(a24UiFacts(d)?.positions||[]),...(a24UiFacts(d)?.research_contexts||[]).map(c=>({...c,currency:c.quote_currency}))];
 const quote=(c)=>{const oo=(a24UiFacts(d)?.market_observations||[]).filter(o=>o.instrument_id===c.instrument_id&&o.quote_currency===c.quote_currency&&String(o.provider).toLowerCase()===String(c.provider).toLowerCase()&&o.provider_id===c.provider_id);return oo.length===1?esc(a24UiMoney(oo[0].price,c.quote_currency))+'<small>'+esc(oo[0].fetched_at||'Data não informada')+'</small>':'Cotação explícita pendente'};
 const status={RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED:'Previsão de pesquisa disponível',STALE_SOURCE_NO_CURRENT_FORECAST:'Fonte desatualizada',INSUFFICIENT_HISTORY_FOR_RESEARCH_FIT:'Histórico insuficiente',AWAITING_GLOBAL_RESEARCH_PROCESSING:'Aguardando processamento',AWAITING_GLOBAL_HISTORY:'Aguardando histórico'};
 const rows=h.contexts.filter(c=>(!a24CockpitState.currency||c.quote_currency===a24CockpitState.currency)&&a24UiSearch(c)&&(!a24CockpitState.account||positions.some(p=>p.account_id===a24CockpitState.account&&p.instrument_id===c.instrument_id&&p.currency===c.quote_currency)));
 return `<section class="a24-section"><h2>Universo acompanhado</h2><p class="a24-caption">${rows.length} contextos de fonte e moeda. Pesquisa separada das posições financeiras; o filtro de conta usa posições e demandas de acompanhamento com identidade e moeda explícitas.</p><div class="a24-table-scroll"><table class="a24-table"><thead><tr><th>Ativo</th><th>Moeda</th><th>Fonte</th><th>Cotação de referência</th><th>Acompanhamento</th><th>Observações</th></tr></thead><tbody>${rows.map(c=>`<tr><td>${esc(c.display_label_evidence==='EXACT_CATALOG_METADATA'?c.display_label:c.instrument_id)}</td><td>${esc(c.quote_currency)}</td><td>${esc(c.provider)}<small>${esc(c.provider_id)}</small></td><td>${quote(c)}</td><td>${esc(status[c.status]||'Estado não confirmado')}</td><td>${esc(c.observation_count)}</td></tr>`).join('')||'<tr><td colspan="6">Nenhum contexto corresponde aos filtros.</td></tr>'}</tbody></table></div></section>`;
}
function a24UiReferenceReadings(){
 const scores=(typeof lastStatus==='object'&&lastStatus?.portfolio?.scores)||[];
 const rows=scores.filter(a24UiSearch);
 return `<details data-a24-disclosure="current-reference-readings"><summary>Leituras atuais de referência · ${rows.length} ativos</summary><p class="a24-caption">Sinais existentes do motor. Quando conta ou moeda não estão explícitas, a leitura permanece de referência e não é atribuída a uma posição financeira. Esta lista mantém seu próprio escopo e não é filtrada por conta ou moeda.</p><div class="a24-table-scroll"><table class="a24-table"><thead><tr><th>Ativo</th><th>Leitura</th><th>Contexto</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.asset||r.instrument_id||'Sem identificação')}</td><td>${a24OperationalBadge(r)}</td><td>${esc(r.currency||r.quote_currency||'Moeda não confirmada')}<small>${a24MonitorKey(r)?'Contexto declarado na linha':'Conta / identidade pendentes'}</small></td></tr>`).join('')||'<tr><td colspan="3">Nenhuma leitura corresponde à pesquisa.</td></tr>'}</tbody></table></div></details>`;
}
function a24UiDiagnostics(d){return `<details data-a24-disclosure="universal-diagnostics"><summary>Detalhes do acompanhamento e aprendizado</summary><p>${esc(a24MonitorReason(d?.canonical?.reason))}</p><p>${esc(a24EconomicSeriesMessage(d))}</p>${a24ModelEvaluationTable(d)}${a24ExistingLabTable(d)}${a24EconomicActionPlan(d)}<p>${esc(a24ObservedCostsMessage(d))}</p><p>${esc(a24ScopedEconomicMessage(d))}</p></details>`}
/* Read-only SVG plots: no chart CDN, timers, collection or monetary writes. */
const a24PlotPalette=['#32e2a4','#55b9ff','#ffc66b','#e692ff','#ff7784','#83dfdc','#b8d577','#c5baff'];
const a24PlotHidden=new Set();
Object.assign(a24CockpitState,{plotPeriod:90,plotMode:'index'});
function a24PlotNumber(x){return x!==null&&x!==undefined&&x!==''&&typeof x!=='boolean'&&Number.isFinite(Number(x))?Number(x):null}
function a24PlotPrice(value,q){const n=a24PlotNumber(value);return n===null?'Indisponível':n.toLocaleString('pt-PT',{maximumSignificantDigits:8})+' '+String(q||'Moeda pendente')}
function a24PlotSeries(d){
 const c=d?.cockpit_charts;
 if(c?.schema!=='porquinho.cockpit-charts-a24/1.0'||c.status!=='CHART_SOURCES_INSPECTED'||c.execution_authorized!==false||c.cross_currency_aggregation!==false||!Array.isArray(c.series))return [];
 return c.series.filter(s=>(!a24CockpitState.currency||s.quote_currency===a24CockpitState.currency)&&(!a24CockpitState.account||s.account_ids?.includes(a24CockpitState.account))&&a24UiSearch(s));
}
function a24PlotPoints(series,d){
 const now=Date.parse(d.cockpit_charts.observed_at);const threshold=now-Number(a24CockpitState.plotPeriod)*86400000;
 const raw=(series.points||[]).filter(p=>Date.parse(p.date)>=threshold&&Date.parse(p.date)<=now&&a24PlotNumber(p.price)>0);
 if(!raw.length)return [];
 const base=Number(raw[0].price);let peak=base;
 return raw.map(p=>{const price=Number(p.price);peak=Math.max(peak,price);return {...p,price,time:Date.parse(p.date),value:a24CockpitState.plotMode==='price'?price:a24CockpitState.plotMode==='drawdown'?(price/peak-1)*100:price/base*100}});
}
function a24PlotLine(series,d,q){
 const mode=a24CockpitState.plotMode;const active=series.filter(s=>!a24PlotHidden.has(s.series_id)).map(s=>({s,points:a24PlotPoints(s,d)})).filter(x=>x.points.length);
 if(!active.length)return '<p class="a24-empty">Nenhuma observação no período e nas séries selecionadas.</p>';
 const all=active.flatMap(x=>x.points),times=all.map(p=>p.time),ys=all.map(p=>p.value);let lo=Math.min(...ys),hi=Math.max(...ys);const start=Math.min(...times),end=Math.max(...times);
 const pad=(hi-lo||Math.abs(hi)*.02||1)*.08;lo-=pad;hi+=pad;const x=t=>58+(t-start)/(end-start||1)*560,y=v=>218-(v-lo)/(hi-lo)*190;
 const format=v=>mode==='price'?(Math.abs(v)>0&&Math.abs(v)<.01?v.toExponential(2):v.toLocaleString('pt-PT',{notation:'compact',maximumFractionDigits:2})):v.toLocaleString('pt-PT',{maximumFractionDigits:1})+(mode==='drawdown'?'%':'');
 const ticks=Array.from({length:5},(_,i)=>{const v=lo+(hi-lo)*i/4;return `<line x1="58" y1="${y(v)}" x2="618" y2="${y(v)}" class="a24-plot-grid"/><text x="52" y="${y(v)+4}" text-anchor="end">${esc(format(v))}</text>`}).join('');
 const dates=[start,(start+end)/2,end].filter((v,i,a)=>a.indexOf(v)===i).map(t=>`<text x="${x(t)}" y="244" text-anchor="middle">${esc(new Date(t).toISOString().slice(0,10))}</text>`).join('');
 const lines=active.map(({s,points})=>{const color=a24PlotPalette[series.indexOf(s)%a24PlotPalette.length];const path=points.map((p,i)=>(i?'L':'M')+x(p.time).toFixed(2)+' '+y(p.value).toFixed(2)).join(' ');return `<path d="${path}" fill="none" stroke="${color}" stroke-width="2.4"/>${points.map((p,i)=>`<circle cx="${x(p.time)}" cy="${y(p.value)}" r="${points.length===1?4:2}" fill="${color}" tabindex="${i===points.length-1?'0':'-1'}"><title>${esc(s.display_label||s.instrument_id)} · ${esc(p.date)} · ${esc(a24PlotPrice(p.price,q))} · ${esc(s.provider)} / ${esc(s.provider_id)}</title></circle>`).join('')}`}).join('');
 return `<svg class="a24-line-svg" viewBox="0 0 650 260" role="img" aria-label="${esc(mode==='price'?'Cotações em '+q:mode==='drawdown'?'Queda desde o pico no período':'Evolução com base 100 por ativo')}" preserveAspectRatio="xMidYMid meet">${ticks}${dates}${lines}</svg>`;
}
function a24PlotHistory(d){
 const series=a24PlotSeries(d);const currencies=[...new Set(series.map(s=>s.quote_currency))].sort();
 return `<section class="a24-section"><div class="a24-section-head"><div><h2>Evolução dos ativos</h2><p class="a24-caption">Histórico diário da fonte, separado por moeda. Não representa o valor histórico da carteira nem previsões emitidas no passado.</p></div><div class="a24-chart-controls"><label>Período<select data-a24-plot-period>${[30,90,365].map(n=>`<option value="${n}" ${Number(a24CockpitState.plotPeriod)===n?'selected':''}>${n} dias</option>`).join('')}</select></label><label>Visualização<select data-a24-plot-mode><option value="index" ${a24CockpitState.plotMode==='index'?'selected':''}>Evolução · base 100</option><option value="price" ${a24CockpitState.plotMode==='price'?'selected':''}>Cotação na moeda</option><option value="drawdown" ${a24CockpitState.plotMode==='drawdown'?'selected':''}>Queda desde o pico</option></select></label></div></div><div class="a24-plot-grid-cards">${currencies.map(q=>{
 const ss=series.filter(s=>s.quote_currency===q);return `<article class="a24-plot-card a24-plot-wide"><h3>${esc(q)} · histórico de cotações</h3>${a24PlotLine(ss,d,q)}<div class="a24-plot-legend">${ss.map((s,i)=>`<button type="button" data-a24-plot-series="${esc(s.series_id)}" aria-pressed="${!a24PlotHidden.has(s.series_id)}" style="--series:${a24PlotPalette[i%a24PlotPalette.length]}">${esc(s.display_label||s.instrument_id)}${s.stale?' · desatualizado':''}</button>`).join('')}</div><details data-a24-disclosure="chart-data-${esc(q)}"><summary>Fontes e dados do gráfico</summary>${ss.map(s=>`<details data-a24-disclosure="chart-source-${esc(s.series_id)}"><summary>${esc(s.display_label||s.instrument_id)} · ${esc(s.provider)} / ${esc(s.provider_id)} · ${s.points.length} observações</summary><p>Obtido em ${esc(s.source_fetched_at)}. ${s.stale?'Fonte desatualizada.':''}</p><div class="a24-chart-data"><table class="a24-table"><thead><tr><th>Data UTC</th><th>Cotação · ${esc(q)}</th></tr></thead><tbody>${a24PlotPoints(s,d).map(p=>`<tr><td>${esc(p.date)}</td><td>${esc(a24PlotPrice(p.price,q))}</td></tr>`).join('')}</tbody></table></div></details>`).join('')}</details></article>`;
 }).join('')||'<p class="a24-empty">Histórico de fonte indisponível nos filtros atuais. Nenhuma curva foi preenchida por suposição.</p>'}</div><p class="a24-caption">Base 100 parte da primeira observação de cada ativo no período; não é retorno da carteira. A queda é medida desde o pico observado no período selecionado. As linhas ligam pontos disponíveis, sem criar cotações intermediárias. Clique na legenda para mostrar ou ocultar uma série.</p></section>`;
}
function a24PlotGauge(label,value,caption,color='#32e2a4'){
 const n=a24PlotNumber(value),valid=n!==null&&n>=0&&n<=100;const theta=valid?Math.PI*(1-n/100):0;const xx=100+60*Math.cos(theta),yy=95-60*Math.sin(theta);
 return `<article class="a24-gauge"><h3>${esc(label)}</h3><svg viewBox="0 0 200 125" role="img" aria-label="${esc(label+': '+(valid?n.toFixed(1)+' de 100':'indisponível'))}"><path d="M30 95 A70 70 0 0 1 170 95" pathLength="100" fill="none" stroke="#1a4837" stroke-width="13"/>${valid?`<path d="M30 95 A70 70 0 0 1 170 95" pathLength="100" fill="none" stroke="${color}" stroke-width="13" stroke-dasharray="${n} 100"/><line x1="100" y1="95" x2="${xx}" y2="${yy}" stroke="#edfff8" stroke-width="2.5"/><circle cx="100" cy="95" r="4" fill="#edfff8"/>`:''}<text x="100" y="122" text-anchor="middle">${valid?n.toLocaleString('pt-PT',{maximumFractionDigits:1})+'/100':'Indisponível'}</text></svg><p class="a24-caption">${esc(caption)}</p></article>`;
}
function a24PlotGauges(d){
 const l=(typeof lastStatus==='object'&&lastStatus?.learning)||{};const f=a24UiFacts(d);const ps=(f?.positions||[]).filter(p=>a24UiScope(p)&&a24UiSearch(p));const valued=ps.filter(p=>a24PlotNumber(p.reference_market_value)!==null).length;
 return `<div class="a24-gauges">${a24PlotGauge('Confiança do motor',l.confidence,'Índice global de referência do motor. Não é probabilidade de lucro; não é específico dos filtros.')}${a24PlotGauge('Regime do motor',l.regime,'Índice global de referência já calculado pelo motor. Sem novo cálculo no gráfico.','#55b9ff')}${a24PlotGauge('Cobertura das posições',ps.length?valued/ps.length*100:null,valued+' de '+ps.length+' posições dos filtros possuem valor de referência com cotação explícita.','#ffc66b')}</div>`;
}
function a24PlotBars(rows,q,title,caption){
 if(!rows.length)return `<article class="a24-plot-card"><h3>${esc(title)} · ${esc(q)}</h3><p class="a24-empty">Dados indisponíveis nesta moeda e nos filtros atuais.</p><p class="a24-caption">${esc(caption)}</p></article>`;
 const min=Math.min(0,...rows.map(r=>r.value)),max=Math.max(0,...rows.map(r=>r.value));const extent=max-min||1;const scale=v=>185+(v-min)/extent*340;const height=rows.length*42+36;
 return `<article class="a24-plot-card"><h3>${esc(title)} · ${esc(q)}</h3><svg class="a24-bar-svg" viewBox="0 0 650 ${height}" role="img" aria-label="${esc(title+' em '+q)}">${rows.map((r,i)=>{const zero=scale(0),pos=scale(r.value),y=i*42+12;return `<text x="173" y="${y+17}" text-anchor="end">${esc(r.label.length>24?r.label.slice(0,23)+'…':r.label)}<title>${esc(r.label)}</title></text><rect x="${Math.min(zero,pos)}" y="${y}" width="${Math.abs(pos-zero)}" height="25" rx="3" fill="${r.value<0?'#ff7784':a24PlotPalette[i%a24PlotPalette.length]}"><title>${esc(r.label)}: ${esc(a24UiMoney(r.value,q))}</title></rect><text x="${r.value<0?Math.min(zero,pos)-5:Math.max(zero,pos)+5}" y="${y+17}" text-anchor="${r.value<0?'end':'start'}">${esc(a24UiMoney(r.value,q))}</text>`}).join('')}</svg><p class="a24-caption">${esc(caption)}</p></article>`;
}
function a24PlotDonut(rows,q,coverage){
 const positive=rows.filter(x=>x.value>0),total=positive.reduce((v,x)=>v+x.value,0);if(!total)return `<article class="a24-plot-card"><h3>Composição por custo · ${esc(q)}</h3><p class="a24-empty">Custos positivos de aquisição indisponíveis.</p></article>`;
 let offset=0;const circles=positive.map((r,i)=>{const n=r.value/total*314.159,from=offset;offset+=n;return `<circle cx="85" cy="85" r="50" fill="none" stroke="${a24PlotPalette[i%a24PlotPalette.length]}" stroke-width="24" stroke-dasharray="${n} ${314.159-n}" stroke-dashoffset="${-from}" transform="rotate(-90 85 85)"><title>${esc(r.label)} · ${esc(a24UiMoney(r.value,q))} · ${(r.value/total*100).toFixed(1)}%</title></circle>`}).join('');
 return `<article class="a24-plot-card"><h3>Composição por custo · ${esc(q)}</h3><div class="a24-donut"><svg viewBox="0 0 170 170" role="img" aria-label="Distribuição dos custos registrados em ${esc(q)}">${circles}<text x="85" y="88" text-anchor="middle">${esc(q)}</text></svg><ul>${positive.map((r,i)=>`<li><span style="color:${a24PlotPalette[i%a24PlotPalette.length]}">●</span> ${esc(r.label)} · ${(r.value/total*100).toLocaleString('pt-PT',{maximumFractionDigits:1})}%</li>`).join('')}</ul></div><p class="a24-caption">${esc(coverage)}. Distribuição dos custos conhecidos; não é composição a valor de mercado. Cash não incluído.</p></article>`;
}
function a24PlotFinancial(d){
 const f=a24UiFacts(d);if(!f)return '<p class="a24-empty">Registros financeiros indisponíveis para os gráficos.</p>';
 const ps=f.positions.filter(p=>a24UiScope(p)&&a24UiSearch(p));const cs=f.cash.filter(p=>a24UiScope(p));const qs=[...new Set([...ps,...cs].map(p=>p.currency))].filter(Boolean).sort();
 return `<section class="a24-section"><h2>Capital e resultados por moeda</h2><div class="a24-plot-grid-cards">${qs.map(q=>{
  const pp=ps.filter(p=>p.currency===q),costs=pp.filter(p=>a24PlotNumber(p.cost_basis)!==null&&p.context_status==='EXACT_REGISTERED_CONTEXT').map(p=>({label:(p.display_label||p.instrument_id)+' · '+a24UiAccount(p.account_id,q,d),value:Number(p.cost_basis)}));const pnl=pp.filter(p=>a24PlotNumber(p.reference_pnl)!==null&&p.context_status==='EXACT_REGISTERED_CONTEXT').map(p=>({label:(p.display_label||p.instrument_id)+' · '+a24UiAccount(p.account_id,q,d),value:Number(p.reference_pnl)}));
  const cash=cs.filter(p=>p.currency===q&&p.context_status==='EXACT_REGISTERED_CONTEXT'&&a24PlotNumber(p.amount)!==null).map(p=>({label:a24UiAccount(p.account_id,q,d),value:Number(p.amount)}));
  return (costs.length?a24PlotBars(costs,q,'Custo de aquisição por ativo',costs.length+' de '+pp.length+' posições com custo conhecido. Valores de aquisição, não patrimônio atual.')+a24PlotDonut(costs,q,costs.length+' de '+pp.length+' posições com custo conhecido'):`<p class="a24-empty">${esc(q)} · Custo e composição indisponíveis para ${pp.length} posições.</p>`)+(cash.length?a24PlotBars(cash,q,'Cash por conta','Cash registrado, separado da valorização dos ativos.'):'')+(pnl.length?a24PlotBars(pnl,q,'Resultado de referência',pnl.length+' de '+pp.length+' posições com resultado disponível. Variação sobre o custo registrado, não lucro realizado. Ausências não são zero.'):`<p class="a24-empty">${esc(q)} · Resultado de referência: Dados indisponíveis. 0 de ${pp.length} posições com resultado disponível. Ausências não são zero.</p>`);
 }).join('')}</div></section>`;
}
function a24PlotHeatmap(d){
 const rows=a24PlotSeries(d);if(!rows.length)return '';
 return `<section class="a24-section"><h2>Variações observadas dos ativos</h2><div class="a24-table-scroll"><table class="a24-table a24-heatmap"><thead><tr><th>Ativo / moeda</th><th>Fonte</th><th>Última observação</th><th>1 observação</th><th>7 observações</th><th>30 observações</th></tr></thead><tbody>${rows.map(s=>{const pp=s.points||[],last=pp[pp.length-1];return `<tr><td>${esc(s.display_label||s.instrument_id)} · ${esc(s.quote_currency)}</td><td>${esc(s.provider)} / ${esc(s.provider_id)}</td><td>${esc(last?.date||'Indisponível')}${s.stale?' · desatualizado':''}</td>${[1,7,30].map(n=>{const v=pp.length>n?(Number(last.price)/Number(pp[pp.length-1-n].price)-1)*100:null;return `<td class="${v===null?'':v>=0?'a24-positive':'a24-negative'}">${esc(a24UiPercent(v))}</td>`}).join('')}</tr>`}).join('')}</tbody></table></div><p class="a24-caption">Retorno das cotações da fonte por quantidade de observações disponíveis, não por dias corridos. Não inclui posição, cash, custos ou previsão de retorno futuro.</p></section>`;
}
function a24UiCharts(d,kind){return `<div class="a24-visuals">${a24PlotGauges(d)}${a24PlotHistory(d)}${kind==='market'?'':a24PlotFinancial(d)}${a24PlotHeatmap(d)}</div>`}
document.addEventListener('change',event=>{if(event.target?.hasAttribute('data-a24-plot-period')){a24CockpitState.plotPeriod=Number(event.target.value);a24UiMount()}if(event.target?.hasAttribute('data-a24-plot-mode')){a24CockpitState.plotMode=event.target.value;a24UiMount()}});
document.addEventListener('click',event=>{const button=event.target?.closest('[data-a24-plot-series]');if(!button)return;const key=button.dataset.a24PlotSeries;if(a24PlotHidden.has(key))a24PlotHidden.delete(key);else a24PlotHidden.add(key);a24UiMount()});

function a24UiRenderPage(kind,d){
 const ready=d?.schema==='porquinho.monitor-consolidation-a24/1.0';
 if(!ready)return '<div class="a24-empty">'+(a24MonitorFailed?'Não foi possível obter a leitura atual.':'Aguardando o acompanhamento do Brain…')+'</div>';
 const body=kind==='market'?a24UiResearch(d)+a24ReallocationPanel(d):kind==='opportunities'?a24ReallocationPanel(d):kind==='portfolio'?a24UiPositions(d)+a24ReallocationPanel(d):`<section class="a24-section"><h2>Posições e leituras</h2>${a24UiPositions(d)}</section>`+a24ReallocationPanel(d);
 return a24UiHealth(d)+a24UiFilters(d)+(['cockpit','portfolio'].includes(kind)?a24UiTotals(d):'')+(kind==='opportunities'?'':a24UiCharts(d,kind))+body+a24UiReferenceReadings()+a24UiDiagnostics(d);
}
function a24UiRemember(){document.querySelectorAll('.a24-space details[data-a24-disclosure]').forEach(n=>a24CockpitOpen.set(n.closest('.a24-space').id+':'+n.dataset.a24Disclosure,n.open))}
function a24UiMount(){
 a24UiRemember();
 for(const kind of ['cockpit','market','portfolio','opportunities']){
  const host=document.getElementById('a24-'+kind);if(!host||!host.closest('.experience-view')?.classList.contains('active-view'))continue;
  const focused=host.querySelector('[data-a24-filter="query"]');if(focused&&focused===document.activeElement)continue;
  host.innerHTML=a24UiRenderPage(kind,a24MonitorData);
  host.querySelectorAll('details[data-a24-disclosure]').forEach(n=>{const key=host.id+':'+n.dataset.a24Disclosure;if(a24CockpitOpen.has(key))n.open=a24CockpitOpen.get(key)});
 }
 document.querySelectorAll('[data-a24-position-context]').forEach(n=>{let key=null;try{key=JSON.parse(n.getAttribute('data-a24-position-context'))}catch(_){}n.textContent=a24MonitorRowMessage(key)});
}
// Reuse the shared GET, throttling and cadence. No new polling timer.
a24MountMonitor=a24UiMount;
const a24CockpitPreviousShow=showExperienceView;
showExperienceView=function(name,button){
 const aliases={dashboard:'cockpit',overview:'cockpit',brazil:'market',opportunities:'opportunities'};const route=aliases[name]||name;
 if(route==='cockpit'||route==='opportunities'){
  a24UiRemember();document.querySelectorAll('.experience-view').forEach(n=>n.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  document.getElementById('view-'+route)?.classList.add('active-view');document.querySelector('[data-target="'+(route==='cockpit'?'dashboard':route)+'"]')?.classList.add('active');
  try{sessionStorage.setItem('porquinho.experience.view.v1',route==='cockpit'?'dashboard':route)}catch(_){}
  a24UiMount();void a24FetchMonitor();document.querySelector('.workspace main')?.scrollTo({top:0,behavior:'instant'});window.scrollTo({top:0,behavior:'instant'});return;
 }
 a24UiRemember();const result=a24CockpitPreviousShow(route,button);a24UiMount();document.querySelector('.workspace main')?.scrollTo({top:0,behavior:'instant'});return result;
};
function a24UiInit(){
 const main=document.querySelector('main');if(!main)return;
 for(const [kind,title,desc] of [['cockpit','Cockpit universal','Posições, moedas e leituras do Brain em uma visão integrada.'],['opportunities','Oportunidades','Candidatos de realocação e suas evidências por conta e moeda.']]){
  const view=document.createElement('section');view.id='view-'+kind;view.className='experience-view';view.innerHTML=`<div class="v361-page-head"><div><span class="v361-eyebrow">PORQUINHO · UNIVERSO GLOBAL</span><h1>${title}</h1><p>${desc}</p></div><div class="v361-actions"><button type="button" onclick="showExperienceView('transactions')">Transações</button><button type="button" onclick="a24FetchMonitor(true)">Verificar acompanhamento</button></div></div><div class="a24-space" id="a24-${kind}"></div>`;main.appendChild(view);
 }
 for(const kind of ['market','portfolio']){
  const view=document.getElementById('view-'+kind);if(!view)continue;
  const legacy=document.createElement('details');legacy.className='a24-legacy';legacy.dataset.a24Disclosure='legacy-'+kind;legacy.innerHTML='<summary>'+(kind==='market'?'Leitura de referência anterior':'Controles e leitura de referência anteriores')+'</summary>';
  const header=view.firstElementChild;[...view.children].filter(x=>x!==header).forEach(x=>legacy.appendChild(x));
  const host=document.createElement('div');host.id='a24-'+kind;host.className='a24-space';view.appendChild(host);view.appendChild(legacy);
 }
 // Keep the regional dataset and controls reachable inside the universal market.
 const regional=document.getElementById('view-brazil');const market=document.getElementById('view-market');
 if(regional&&market){const details=document.createElement('details');details.className='a24-legacy';details.innerHTML='<summary>Acervo regional · Brasil e renda fixa</summary>';while(regional.firstChild)details.appendChild(regional.firstChild);market.appendChild(details);regional.remove()}
 document.querySelectorAll('[data-a24-monitor-panel]').forEach(n=>n.remove());
 const learning=document.getElementById('view-learning');if(learning){const links=document.createElement('div');links.className='a24-links';links.innerHTML='<button onclick="showExperienceView(\'analysis\')">Modelos e experimentos</button><button onclick="showExperienceView(\'analytics\')">Resultados históricos</button><button onclick="showExperienceView(\'system\')">Diagnóstico do sistema</button>';learning.insertBefore(links,learning.firstChild)}
 document.addEventListener('change',event=>{const key=event.target?.dataset?.a24Filter;if(!key)return;a24UiRemember();a24CockpitState[key]=event.target.value;if(key==='currency')a24CockpitState.account='';a24UiMount()});
 document.addEventListener('click',event=>{if(event.target?.closest('[data-a24-clear]')){a24UiRemember();Object.assign(a24CockpitState,{currency:'',account:'',query:''});a24UiMount()}});
 document.addEventListener('keydown',event=>{if(event.key==='Enter'&&event.target?.dataset?.a24Filter==='query')event.target.blur()});
 document.addEventListener('focusout',event=>{if(event.target?.dataset?.a24Filter==='query'){a24CockpitState.query=event.target.value;a24UiMount()}});
 a24UiMount();if(document.getElementById('view-dashboard')?.classList.contains('active-view'))showExperienceView('dashboard');
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',a24UiInit);else a24UiInit();
