"""Verified price history for universal charts, not historical portfolio valuations.
Reads existing provider bundles. No collection, training, FX or journal migration.
"""
import datetime as dt
from .explicit_market_bindings_a24 import digest
SCHEMA='porquinho.cockpit-charts-a24/1.0'

def flags():
 return dict(execution_authorized=False,financial_mutation=False,history_write_performed=False,
             training_requested=False,network_requests=0,cross_currency_aggregation=False,
             historical_portfolio_reconstructed=False)

def project(bodies,*,now,catalog,account_contexts=None):
 from .global_history_source_a24 import validate_bundle
 from .research_quote_acquisition_a24 import utc
 now=utc(now);rows=[];seen=set();labels={};conflicts=set()
 for row in catalog.get('instruments',[]):
  iid=row.get('instrument_id');label=row.get('symbol') or row.get('name')
  if not isinstance(iid,str) or not isinstance(label,str):continue
  if iid in labels and labels[iid]!=label:conflicts.add(iid)
  labels[iid]=label
 if len(bodies)>256:raise ValueError('CHART_SERIES_LIMIT')
 for body in bodies:
  validate_bundle(body)
  if dt.datetime.fromisoformat(body['fetched_at'])>now:raise ValueError('FUTURE_CHART_SOURCE')
  key=body['series_id']
  if key in seen:raise ValueError('DUPLICATE_CHART_SERIES')
  seen.add(key);b=body['binding'];points=body['observations'][-366:]
  if len(body['observations'])>20000:raise ValueError('CHART_SOURCE_POINT_LIMIT')
  for point in points:
   if dt.date.fromisoformat(point['observation_date'])>now.date():raise ValueError('FUTURE_CHART_POINT')
  rows.append({'series_id':key,'instrument_id':b['instrument_id'],'display_label':labels.get(b['instrument_id']) if b['instrument_id'] not in conflicts else None,
   'provider':b['provider'],'provider_id':b['provider_id'],'quote_currency':b['quote_currency'],
   'identity_source_ref':b['identity_source_ref'],'source_digest':digest(body),'source_fetched_at':body['fetched_at'],
   'account_ids':sorted(set((account_contexts or {}).get(key,[]))),
   'sampling':body['sampling'],'stale':(now.date()-dt.date.fromisoformat(points[-1]['observation_date'])).days>3 if points else True,
   'points':[{'date':p['observation_date'],'price':p['price']} for p in points],
   'meaning':'PROVIDER_PRICE_HISTORY_NOT_PORTFOLIO_PNL_OR_PAST_FORECAST_PROOF'})
 return {'schema':SCHEMA,'status':'CHART_SOURCES_INSPECTED','series':rows,'series_count':len(rows),
  'point_count':sum(len(s['points']) for s in rows),'observed_at':now.isoformat(),**flags()}

def build(root,demand,*,now,catalog,position_contexts=()):
 from brain.evolution.global_research_lab_a24 import sources
 from .global_history_source_a24 import read_sealed
 try:
  _,eligible,latest=sources(root,demand,now);contexts={}
  for key,job in eligible.items():
   b=job['binding'];aids={c[0] for c in job['funding_contexts']}
   # Reviewed aliases may scope a research graph, never value a financial holding.
   aids.update(p['account_id'] for p in position_contexts if p.get('research_instrument_id',p.get('instrument_id'))==b['instrument_id'] and p.get('currency')==b['quote_currency'] and p.get('identity_status')=='EXACT_POSITION_CONTEXT')
   contexts[key]=aids
  value=project([b for p,b in latest.values()],now=now,catalog=catalog,account_contexts=contexts)
  if any(read_sealed(p)!=b for p,b in latest.values()):raise ValueError('CHART_SOURCES_CHANGED_DURING_READ')
  return value
 except Exception as exc:
  return {'schema':SCHEMA,'status':'CHART_SOURCES_UNAVAILABLE','error_type':type(exc).__name__,
   'series':[],'series_count':None,'point_count':None,**flags()}
