#!/bin/bash
set -euo pipefail
umask 077
ROOT="${PORQUINHO_ROOT:-$HOME/Desktop/Bridge_Companion/porquinho_v33_web_foundation-2}"
PYTHON_BIN="python3"
if [ -x "$ROOT/.venv/bin/python" ]; then PYTHON_BIN="$ROOT/.venv/bin/python"; fi
"$PYTHON_BIN" -I -B "$ROOT/tools/reallocation_source_audit_v43.py" "$ROOT" "${PORQUINHO_ACTIVATOR_DIRECTORY:-$HOME/Downloads}"
