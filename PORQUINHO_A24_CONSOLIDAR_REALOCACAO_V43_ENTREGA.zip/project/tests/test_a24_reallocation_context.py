import copy,json,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import test_a24_reallocation_analysis as fixture
from universal_portfolio import reallocation_analysis_a24 as m
from tools import reallocation_source_audit_v43 as audit
class Context(unittest.TestCase):
 def setUp(self):self.f=fixture.Compare();self.f.setUp()
 def states(self,**kw):return self.f.project(**kw)['rows'][0]['valuation_state_counts']
 def test_exact_valuation_is_reported(self):self.assertEqual(self.states(),{'EXACT_FINANCIAL_REFERENCE_AVAILABLE':1})
 def test_missing_quantity_distinguished(self):
  self.f.plan['cases'][0]['quantity_upper_bound']=None;self.assertEqual(self.states(),{'POSITION_QUANTITY_REQUIRED':1})
 def test_missing_price_distinguished(self):
  self.f.prices=[];self.assertEqual(self.states(),{'EXACT_PROVIDER_ORIGIN_PRICE_REQUIRED':1})
 def test_ambiguous_price_distinguished(self):
  self.f.prices*=2;self.assertEqual(self.states(),{'EXACT_PROVIDER_ORIGIN_PRICE_AMBIGUOUS':1})
 def test_alias_not_promoted_to_financial_identity(self):
  for x in self.f.e['forecasts']+self.f.e['folds']:
   if x['instrument_id']==fixture.I:x['instrument_id']='RESEARCH:SOURCE'
  result=self.f.project(identity_links=[dict(position_instrument_id=fixture.I,research_instrument_id='RESEARCH:SOURCE',evidence_ref='review')]);r=result['rows'][0];self.assertIsNone(r['reference_capital']);self.assertEqual(r['valuation_state_counts'],{'RESEARCH_ALIAS_NOT_FINANCIAL_IDENTITY':1})
 def test_no_cost_reviews_reported_per_leg(self):
  r=m.attach_reviewed_costs(self.f.project(),[])['rows'][0];self.assertEqual(r['cost_source_diagnostics']['sell_review_count'],0);self.assertEqual(r['cost_source_diagnostics']['buy_review_count'],0)
 def test_partial_component_reported_not_assumed_zero(self):
  g=fixture.Costs();g.setUp();rr=g.reviews();rr[1]['components']['spread']['status']='UNKNOWN';r=m.attach_reviewed_costs(g.project(),rr)['rows'][0];self.assertEqual(r['cost_source_diagnostics']['unknown_component_counts'],{'spread':1});self.assertFalse(r['reviewed_two_leg_cost_scenarios'])
 def test_audit_whitelist_excludes_balances_transactions_and_nested_secrets(self):
  pair=self.f.project()['rows'][0];pair.update(cost_source_diagnostics={'sell_review_count':0,'buy_review_count':0,'total_cost':'PRIVATE_SECRET_COST','unknown_component_counts':{'spread':1,'SECRET':99}},valuation_state_counts={'POSITION_QUANTITY_REQUIRED':1,'SECRET':99},reference_capital='PRIVATE_SECRET_CAPITAL')
  report={'reallocation_analysis':{'rows':[pair]},'universal_portfolio':{'positions':[{'instrument_id':'id','quantity':'PRIVATE_SECRET_QTY','reference_price':'PRIVATE_SECRET_PRICE','cost_basis':'PRIVATE_SECRET_BASIS','account_id':'a','currency':'JPY'}]}}
  registry={'institutions':[{'institution_id':'bank','name':'Test Bank','password':'PRIVATE_SECRET_PASS'}],'accounts':[{'account_id':'a','currency':'JPY','balance':'PRIVATE_SECRET_BAL','pricing_plan':'PRIVATE_SECRET_PLAN','api_key':'PRIVATE_SECRET_TOKEN'}]}
  before=copy.deepcopy((report,registry));result=audit.project(report,registry);encoded=json.dumps(result);self.assertNotIn('PRIVATE_SECRET',encoded);self.assertNotIn('SECRET',encoded);self.assertIn('pricing_plan',encoded);self.assertEqual(before,(report,registry));self.assertTrue(result['positions'][0]['quantity_present'])
 def test_output_outside_project_and_private(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)/'project';root.mkdir();p=audit.write(Path(tmp)/'Downloads',root,audit.project({},{}));self.assertEqual(p.stat().st_mode&0o777,0o600)
   with zipfile.ZipFile(p) as z:self.assertEqual(set(z.namelist()),{'DIAGNOSTICO.json','LEIA.txt'})
   with self.assertRaises(ValueError):audit.write(root,root,{})
 def test_symlink_output_refused(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'link').symlink_to(root,target_is_directory=True)
   with self.assertRaises(ValueError):audit.write(root/'link',root/'project',{})
 def test_audit_source_change_refuses_export(self):
  with tempfile.TemporaryDirectory() as tmp:
   with patch('universal_portfolio.economic_action_plan_a24.source_versions',side_effect=[{'x':1},{'x':2}]),patch('universal_portfolio.monitor_consolidation_a24.inspect',return_value={}):
    with self.assertRaisesRegex(ValueError,'SOURCE_CHANGED'):audit.build(tmp)
 def test_audit_build_does_not_write_project(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir();p=root/'data/institution_accounts.json';p.write_text('{"institutions":[],"accounts":[]}');before=p.read_bytes()
   with patch('universal_portfolio.monitor_consolidation_a24.inspect',return_value={}):result=audit.build(root)
   self.assertEqual(p.read_bytes(),before);self.assertFalse(result['identity_binding_created']);self.assertFalse(result['financial_mutation']);self.assertEqual(set(x.name for x in root.rglob('*') if x.is_file()),{'institution_accounts.json'})

 def test_existing_binding_and_opening_identity_fields_only(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir();p=root/'data/universal_opening_state_shadow.json';p.write_text(json.dumps({'positions':[{'instrument_id':'old:id','position_id':'position','currency':'JPY','account_reference':{'value':'a'},'quantity':'SECRET_Q','cost_basis':'SECRET_COST','cash':'SECRET_CASH'}]}));before=p.read_bytes();result=audit.identity_sources(root);encoded=json.dumps(result);self.assertIn('old:id',encoded);self.assertIn('account_reference',encoded);self.assertNotIn('SECRET',encoded);self.assertEqual(p.read_bytes(),before)
 def test_unknown_binding_container_not_guessed(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir();(root/'data/canonical_position_identity_bindings.json').write_text('{"unknown":{"amount":"SECRET"}}');result=audit.identity_sources(root);self.assertEqual(result['data/canonical_position_identity_bindings.json']['status'],'UNRECOGNIZED_CONTAINER');self.assertNotIn('SECRET',json.dumps(result))
