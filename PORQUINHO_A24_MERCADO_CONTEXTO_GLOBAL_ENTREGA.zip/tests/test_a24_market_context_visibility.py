"""Display labels never alter economic identities or quote currencies."""
import copy,unittest
from universal_portfolio.monitor_consolidation_a24 import research_display_contexts
class Display(unittest.TestCase):
 def setUp(self):self.rows=[{'instrument_id':'EXACT:GLOBAL:ID','quote_currency':'JPY','status':'AWAITING_GLOBAL_HISTORY'}]
 def test_exact_catalog_label_only(self):
  out=research_display_contexts(self.rows,{'instruments':[{'instrument_id':'EXACT:GLOBAL:ID','symbol':'ASSET'}]});self.assertEqual(out[0]['display_label'],'ASSET');self.assertEqual(out[0]['instrument_id'],'EXACT:GLOBAL:ID');self.assertEqual(out[0]['quote_currency'],'JPY')
 def test_symbol_not_inferred_from_suffix(self):self.assertEqual(research_display_contexts(self.rows,{})[0]['display_label'],'EXACT:GLOBAL:ID')
 def test_other_identity_same_symbol_not_joined(self):self.assertEqual(research_display_contexts(self.rows,{'instruments':[{'instrument_id':'OTHER:GLOBAL:ID','symbol':'ASSET'}]})[0]['display_label_evidence'],'IDENTIFIER_ONLY')
 def test_conflicting_catalog_labels_not_chosen(self):
  out=research_display_contexts(self.rows,{'instruments':[{'instrument_id':'EXACT:GLOBAL:ID','symbol':'ONE'},{'instrument_id':'EXACT:GLOBAL:ID','symbol':'TWO'}]});self.assertEqual(out[0]['display_label_evidence'],'IDENTIFIER_ONLY')
 def test_no_currency_substitution_from_catalog(self):
  out=research_display_contexts(self.rows,{'instruments':[{'instrument_id':'EXACT:GLOBAL:ID','symbol':'ASSET','currency':'EUR'}]});self.assertEqual(out[0]['quote_currency'],'JPY')
 def test_original_contexts_not_mutated(self):
  before=copy.deepcopy(self.rows);research_display_contexts(self.rows,{'instruments':[{'instrument_id':'EXACT:GLOBAL:ID','symbol':'ASSET'}]});self.assertEqual(before,self.rows)
 def test_missing_metadata_collection_keeps_original_identity(self):self.assertEqual(research_display_contexts(self.rows,{'instruments':None})[0]['display_label'],'EXACT:GLOBAL:ID')
