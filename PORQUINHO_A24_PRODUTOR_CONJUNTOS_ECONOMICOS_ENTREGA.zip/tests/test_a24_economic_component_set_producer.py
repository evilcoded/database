"""Synthetic evidence only: fixtures do not certify any actual model or investment."""
import copy,json,unittest,tempfile
from pathlib import Path
from universal_portfolio import economic_component_set_producer_a24 as p
from universal_portfolio import scoped_economic_comparison_a24 as scoped
from universal_portfolio.governed_economic_input_transport_a24 import comparison_identity,collect_inputs
from universal_portfolio.governed_comparison_producer_a2 import produce_governed_comparisons
from test_a24_governed_economic_integration import envelope,public_projection,SRC,DST
import test_a24_scoped_economic_comparison as scoped_fixture

def packet(cid='synthetic-set'):
 e=envelope();alternatives=[]
 for source in e['governed_economic_alternatives']:
  scope={k:source['evidence'][k] for k in p.SCOPE}
  components={}
  for name in p.REQUIRED:
   c={**scope,'value':source['relative_utility'] if name=='relative_utility' else source['evidence'][name],
    'unit':p.UNITS.get(name,'SYNTHETIC_RISK_FRACTION'),'source_ref':'SYNTHETIC_SOURCE_ONLY','model_ref':'SYNTHETIC_MODEL_ONLY',
    'model_version':'SYNTHETIC_V1','validation_ref':'SYNTHETIC_VALIDATION_ONLY','validation_status':'VALIDATED_FOR_SHADOW_COMPARATOR','authority':'NONE'}
   if name=='risk_measure':c['comparability_ref']='SYNTHETIC_RISK_COMPARABILITY'
   if name=='relative_utility':c['policy_ref']='SYNTHETIC_UTILITY_POLICY'
   if name=='counterfactual_return':c['source_instrument_id']=SRC
   components[name]=c
  alternatives.append({k:source[k] for k in ('alternative_id','instrument_id','account_id','currency','kind','source_instrument_id','destination_instrument_id')})
  alternatives[-1].update(horizon=source['evidence']['horizon'],horizon_unit=scope['horizon_unit'],horizon_value=scope['horizon_value'],reference_capital='1000',components=components)
 item={'comparison_set_id':cid,'alternatives':alternatives,'source_refs':['SYNTHETIC_SOURCE_ONLY'],'sizing_candidates':e['governed_economic_sizing_candidates']}
 built=p.assemble_set(item);rows=produce_governed_comparisons({'governed_economic_alternatives':built['alternatives'],'governed_economic_source_refs':built['source_refs']})['comparison_rows']
 item['sizing_candidates'][0]['comparison_id']=comparison_identity(rows)
 return {'schema':p.INPUT_SCHEMA,'sets':[item]}
class Producer(unittest.TestCase):
 run_cycle=scoped_fixture.Scoped.run_cycle
 def produce(self,doc=None):return p.produce(packet() if doc is None else doc)
 def changed(self,callback):
  d=packet();callback(d['sets'][0]);return self.produce(d)
 def blocked(self,out):self.assertEqual(out['sets'],[]);self.assertGreater(len(out['diagnostic']['blocking_reason_counts']),0)
 def test_complete_components_produce_comparison_set(self):
  out=self.produce();self.assertEqual(out['diagnostic']['produced_set_count'],1);self.assertFalse(out['diagnostic']['models_certified_by_assembler']);self.assertEqual(out['sets'][0]['alternatives'][1]['relative_utility'],.08)
 def test_existing_comparison_and_sizing_accept_exact_assembled_identity(self):
  out=self.produce();data={scoped.KEY:out['sets']};sized=scoped.size(scoped.compare(data),data);self.assertEqual(scoped.summary(sized)['sets_with_matched_sizing'],1);self.assertIsNone(sized['canonical_recommendation'])
 def test_full_pipeline_assembles_sources_without_history_writes(self):
  out=self.run_cycle({p.KEY:packet()});self.assertEqual(out.economic_decision_ui_projection['economic_set_producer_diagnostic']['produced_set_count'],1);self.assertEqual(out.economic_decision_ui_projection['scoped_economic_comparison_summary']['sets_with_matched_sizing'],1)
 def test_source_packet_unchanged(self):
  d=packet();before=copy.deepcopy(d);self.produce(d);self.assertEqual(d,before)
 def test_model_provenance_preserved(self):
  d=packet();out=self.produce(d);self.assertEqual(out['sets'][0]['alternatives'][0]['evidence']['provenance']['declared_component_evidence'],d['sets'][0]['alternatives'][0]['components'])
 def test_each_missing_component_blocks_entire_set(self):
  for name in p.REQUIRED:
   self.blocked(self.changed(lambda x:x['alternatives'][0]['components'].pop(name)))
 def test_no_partial_alternative_dropped_to_pick_winner(self):
  out=self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(validation_status='NOT_VALIDATED'));self.blocked(out);self.assertEqual(out['diagnostic']['blocked_set_count'],1)
 def test_realized_return_does_not_become_expected_return(self):self.blocked(self.changed(lambda x:x['alternatives'][1]['components']['forward_return'].update(validation_status='OBSERVED')))
 def test_missing_transaction_cost_not_zero_even_for_keep(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['transaction_cost'].pop('value')))
 def test_explicit_validated_zero_cost_accepted(self):self.assertEqual(self.changed(lambda x:x['alternatives'][0]['components']['transaction_cost'].update(value=0))['diagnostic']['produced_set_count'],1)
 def test_component_scope_account_mismatch(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['risk_measure'].update(account_id='OTHER')))
 def test_component_scope_quote_mismatch(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(currency='JPY')))
 def test_component_scope_identity_mismatch(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(instrument_id='OTHER:SOURCE_A')))
 def test_component_scope_horizon_mismatch(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(horizon_unit='OBSERVATIONS')))
 def test_percent_not_silently_fraction(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(unit='PERCENT')))
 def test_risk_scales_must_share_explicit_comparability(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['risk_measure'].update(comparability_ref='OTHER_SCALE')))
 def test_utility_policies_not_implicitly_mixed(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['relative_utility'].update(policy_ref='OTHER_POLICY')))
 def test_missing_policy_not_invented(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['relative_utility'].pop('policy_ref')))
 def test_missing_model_provenance_blocks(self):
  for key in ('model_ref','model_version','validation_ref','source_ref'):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].pop(key)))
 def test_component_authority_not_promoted(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(authority='CANONICAL_RECOMMENDATION')))
 def test_numeric_boolean_refused(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(value=True)))
 def test_nonfinite_and_underflow_refused(self):
  for value in ('NaN','Infinity','1e-9999'):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(value=value)))
 def test_negative_return_preserved(self):
  out=self.changed(lambda x:x['alternatives'][0]['components']['forward_return'].update(value='-0.2'));self.assertEqual(out['sets'][0]['alternatives'][0]['evidence']['forward_return'],-.2)
 def test_negative_cost_and_risk_refused(self):
  for name in ('transaction_cost','risk_measure'):self.blocked(self.changed(lambda x:x['alternatives'][0]['components'][name].update(value=-1)))
 def test_reference_capital_not_sizing_and_basis_must_match(self):
  out=self.changed(lambda x:x['alternatives'][0].update(reference_capital='2000'));self.blocked(out)
 def test_reference_capital_precision_loss_refused(self):self.blocked(self.changed(lambda x:x['alternatives'][0].update(reference_capital='100000000000000000001')))
 def test_counterfactual_source_mismatch_refused(self):self.blocked(self.changed(lambda x:x['alternatives'][0]['components']['counterfactual_return'].update(source_instrument_id=DST)))
 def test_duplicate_sets_refused_all(self):
  d=packet();d['sets'].append(copy.deepcopy(d['sets'][0]));self.blocked(self.produce(d))
 def test_blocked_set_not_mixed_into_valid_independent_set(self):
  d=packet();bad=copy.deepcopy(d['sets'][0]);bad['comparison_set_id']='bad';bad['alternatives'][0]['components']['risk_measure']['validation_status']='NOT_VALIDATED';d['sets'].append(bad);out=self.produce(d);self.assertEqual(out['diagnostic']['produced_set_count'],1);self.assertEqual(out['diagnostic']['blocked_set_count'],1)
 def test_absent_document_explicit(self):self.assertEqual(p.produce(None)['diagnostic']['status'],'ECONOMIC_COMPONENT_SETS_NOT_SUPPLIED')
 def test_wrong_schema_not_guessed(self):self.blocked(self.produce({'sets':[]}))
 def test_size_limit_refused(self):self.blocked(self.produce({'schema':p.INPUT_SCHEMA,'sets':[{}]*65}))
 def test_transport_mixed_input_contract_refused(self):
  out=self.run_cycle({**envelope(),p.KEY:packet()});self.assertEqual(out.economic_decision_ui_projection['scoped_economic_comparison_summary']['comparison_set_count'],0)
 def test_transport_unknown_component_instrument_refused(self):
  d=packet();d['sets'][0]['alternatives'][0]['instrument_id']='UNKNOWN';out=self.run_cycle({p.KEY:d});self.assertEqual(out.economic_decision_ui_projection['economic_set_producer_diagnostic']['status'],'COMPONENT_SOURCE_REJECTED')
 def test_public_summary_redacts_models_accounts_and_values(self):
  raw=self.produce()['diagnostic'];out=public_projection({'economic_set_producer_diagnostic':raw});self.assertEqual(out['economic_set_producer_diagnostic'],raw);self.assertNotIn('TEST_ACCOUNT',json.dumps(out));self.assertNotIn('SYNTHETIC_MODEL_ONLY',json.dumps(out))
 def test_public_summary_refuses_self_approval(self):self.assertIsNone(p.public_diagnostic({**self.produce()['diagnostic'],'models_certified_by_assembler':True}))
 def test_public_summary_refuses_impossible_counts(self):self.assertIsNone(p.public_diagnostic({**self.produce()['diagnostic'],'blocked_set_count':10}))
 def test_dedicated_artifact_consumed_read_only_without_snapshot_changes(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);artifact=root/'results/governed_economic_components_a24.json';artifact.parent.mkdir();artifact.write_text(json.dumps({p.KEY:packet()}));snapshot=root/'results/latest.json';snapshot.write_text('{"unchanged":"legacy snapshot"}')
   before={f:f.read_bytes() for f in root.rglob('*') if f.is_file()};out=collect_inputs(root,observed_ids={SRC,DST});self.assertEqual(out['economic_set_producer_diagnostic']['produced_set_count'],1);self.assertTrue(out['economic_input_transport']['source_refs'][0].startswith('results/governed_economic_components_a24.json#sha256:'));self.assertEqual(before,{f:f.read_bytes() for f in root.rglob('*') if f.is_file()})
 def test_ambiguous_dedicated_and_legacy_envelopes_not_merged(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'results').mkdir();(root/'results/latest.json').write_text(json.dumps(envelope()));(root/'results/governed_economic_components_a24.json').write_text(json.dumps({p.KEY:packet()}));out=collect_inputs(root,observed_ids={SRC,DST});self.assertEqual(out['economic_set_producer_diagnostic']['status'],'COMPONENT_SOURCE_REJECTED');self.assertNotIn(scoped.KEY,out)
