"""Assemble explicit model evidence; never certify models or infer financial inputs."""
import copy,math,re,json
from decimal import Decimal
from collections.abc import Mapping
SCHEMA='porquinho.economic-component-set-producer-a24/1.0'
INPUT_SCHEMA='porquinho.economic-component-sets-a24/1.0'
KEY='governed_economic_component_sets'
UNITS={'forward_return':'RETURN_FRACTION','transaction_cost':'REFERENCE_CAPITAL_FRACTION','counterfactual_return':'RETURN_FRACTION','relative_utility':'POLICY_UTILITY'}
REQUIRED=tuple(UNITS)+('risk_measure',)
SCOPE=('instrument_id','account_id','currency','horizon_unit','horizon_value')
class ComponentError(ValueError):pass

def text(v):return isinstance(v,str) and bool(v) and v==v.strip()
def number(v):
 if isinstance(v,bool) or not isinstance(v,(int,float,str)):raise ComponentError('FINITE_COMPONENT_VALUE_REQUIRED')
 try:d=Decimal(str(v));f=float(d)
 except Exception:raise ComponentError('FINITE_COMPONENT_VALUE_REQUIRED')
 if not d.is_finite() or not math.isfinite(f) or (d!=0 and f==0):raise ComponentError('FINITE_COMPONENT_VALUE_REQUIRED')
 return f

def diagnostic(inputs=0,produced=0,reasons=None,status=None):
 return {'schema':SCHEMA,'status':status or ('COMPONENT_SETS_ASSEMBLED' if produced else 'COMPONENT_ASSEMBLY_BLOCKED'),
  'input_set_count':inputs,'produced_set_count':produced,'blocked_set_count':inputs-produced,'blocking_reason_counts':reasons or {},
  'models_certified_by_assembler':False,'canonical_publication_authorized':False,'execution_authorized':False}

def component(raw,name,scope):
 if not isinstance(raw,Mapping):raise ComponentError(name.upper()+'_COMPONENT_REQUIRED')
 if type(raw.get('horizon_value')) is not int:raise ComponentError('COMPONENT_SCOPE_MISMATCH')
 if any(raw.get(k)!=scope[k] for k in SCOPE):raise ComponentError('COMPONENT_SCOPE_MISMATCH')
 if raw.get('validation_status')!='VALIDATED_FOR_SHADOW_COMPARATOR':raise ComponentError(name.upper()+'_NOT_VALIDATED')
 if raw.get('authority')!='NONE':raise ComponentError('COMPONENT_AUTHORITY_UNEXPECTED')
 if not all(text(raw.get(k)) for k in ('source_ref','model_ref','model_version','validation_ref','unit')):raise ComponentError('COMPONENT_MODEL_PROVENANCE_REQUIRED')
 if name in UNITS and raw['unit']!=UNITS[name]:raise ComponentError('COMPONENT_UNIT_MISMATCH')
 if name=='risk_measure' and not text(raw.get('comparability_ref')):raise ComponentError('RISK_COMPARABILITY_REQUIRED')
 if name=='relative_utility' and not text(raw.get('policy_ref')):raise ComponentError('UTILITY_POLICY_REQUIRED')
 value=number(raw.get('value'))
 if name in ('transaction_cost','risk_measure') and value<0:raise ComponentError('NONNEGATIVE_COST_AND_RISK_REQUIRED')
 return value

def assemble_set(item):
 if not isinstance(item,Mapping) or not text(item.get('comparison_set_id')):raise ComponentError('EXPLICIT_COMPARISON_SET_ID_REQUIRED')
 refs=item.get('source_refs')
 if not isinstance(refs,(list,tuple)) or not refs or not all(text(v) for v in refs):raise ComponentError('SET_SOURCE_REFS_REQUIRED')
 alternatives=item.get('alternatives')
 if not isinstance(alternatives,(list,tuple)) or not 2<=len(alternatives)<=1000:raise ComponentError('COMPLETE_COMPARATIVE_ALTERNATIVES_REQUIRED')
 rows=[];identities=set();scopes=set();risk_keys=set();utility_keys=set();source_refs=set(refs)
 for alternative in alternatives:
  if not isinstance(alternative,Mapping) or not all(text(alternative.get(k)) for k in ('alternative_id','instrument_id','account_id','currency','kind','horizon_unit','horizon')):raise ComponentError('EXPLICIT_ALTERNATIVE_SCOPE_REQUIRED')
  scope={k:alternative.get(k) for k in SCOPE}
  if type(scope['horizon_value']) is not int or scope['horizon_value']<=0:raise ComponentError('EXPLICIT_HORIZON_REQUIRED')
  if not scope['currency'].isascii() or not scope['currency'].isalpha() or not scope['currency'].isupper():raise ComponentError('EXPLICIT_UPPERCASE_CURRENCY_REQUIRED')
  cap=number(alternative.get('reference_capital'))
  if cap<=0:raise ComponentError('POSITIVE_REFERENCE_CAPITAL_REQUIRED')
  if Decimal(str(cap))!=Decimal(str(alternative['reference_capital'])):raise ComponentError('REFERENCE_CAPITAL_PRECISION_LOSS')
  aid=alternative['alternative_id']
  if aid in identities:raise ComponentError('DUPLICATE_ALTERNATIVE_ID')
  identities.add(aid);scopes.add((scope['account_id'],scope['currency'],scope['horizon_unit'],scope['horizon_value'],alternative['horizon'],cap))
  components=alternative.get('components')
  if not isinstance(components,Mapping):raise ComponentError('ECONOMIC_COMPONENTS_REQUIRED')
  try:json.dumps(dict(components),allow_nan=False)
  except (TypeError,ValueError):raise ComponentError('COMPONENT_PROVENANCE_NOT_SERIALIZABLE')
  values={name:component(components.get(name),name,scope) for name in REQUIRED}
  counter=components['counterfactual_return']
  source=alternative.get('source_instrument_id')
  if source is not None and (not text(source) or counter.get('source_instrument_id')!=source):raise ComponentError('COUNTERFACTUAL_SOURCE_MISMATCH')
  if source is None and not text(counter.get('baseline_ref')):raise ComponentError('COUNTERFACTUAL_BASELINE_REQUIRED')
  risk=components['risk_measure'];utility=components['relative_utility']
  risk_keys.add((risk['unit'],risk['comparability_ref']));utility_keys.add((utility['policy_ref'],utility['model_version'],utility['unit']))
  for c in components.values():
   if isinstance(c,Mapping) and text(c.get('source_ref')):source_refs.add(c['source_ref'])
  evidence={**scope,'horizon':alternative['horizon'],'reference_capital':cap,
   **{k:values[k] for k in ('forward_return','transaction_cost','risk_measure','counterfactual_return')},
   'forward_return_validated':True,'transaction_cost_validated':True,'risk_validated':True,'counterfactual_validated':True,
   'authority':'NONE','provenance':{'assembly_schema':SCHEMA,'declared_component_evidence':copy.deepcopy(dict(components))}}
  rows.append({k:alternative[k] for k in ('alternative_id','instrument_id','account_id','currency','kind')})
  rows[-1].update(evidence=evidence,relative_utility=values['relative_utility'],relative_utility_validated=True,
   relative_utility_provenance=copy.deepcopy(dict(utility)),source_instrument_id=alternative.get('source_instrument_id'),
   destination_instrument_id=alternative.get('destination_instrument_id'),metadata=copy.deepcopy(alternative.get('metadata',{})))
 if len(scopes)!=1:raise ComponentError('COMPARISON_BASIS_MISMATCH')
 if len(risk_keys)!=1:raise ComponentError('RISK_COMPARABILITY_MISMATCH')
 if len(utility_keys)!=1:raise ComponentError('UTILITY_POLICY_MISMATCH')
 from .governed_comparison_producer_a2 import produce_governed_comparisons
 gate=produce_governed_comparisons({'governed_economic_alternatives':rows,'governed_economic_source_refs':sorted(source_refs)})
 if gate['status']!='VALIDATED_INPUTS_NOT_PROMOTED':raise ComponentError('EXISTING_COMPARISON_GATE_REJECTED')
 return {'comparison_set_id':item['comparison_set_id'],'alternatives':rows,'source_refs':sorted(source_refs),'sizing_candidates':copy.deepcopy(item.get('sizing_candidates',[]))}

def produce(document):
 if document is None:return {'sets':[],'diagnostic':diagnostic(status='ECONOMIC_COMPONENT_SETS_NOT_SUPPLIED')}
 if not isinstance(document,Mapping) or document.get('schema')!=INPUT_SCHEMA:return {'sets':[],'diagnostic':diagnostic(reasons={'COMPONENT_SOURCE_SCHEMA_REQUIRED':1})}
 items=document.get('sets')
 if not isinstance(items,(list,tuple)) or not items or len(items)>64:return {'sets':[],'diagnostic':diagnostic(reasons={'COMPONENT_SET_LIST_INVALID':1})}
 ids=[i.get('comparison_set_id') if isinstance(i,Mapping) else None for i in items]
 if any(not text(v) for v in ids) or len(ids)!=len(set(ids)):return {'sets':[],'diagnostic':diagnostic(len(items),reasons={'EXPLICIT_UNIQUE_SET_IDS_REQUIRED':len(items)})}
 out=[];reasons={}
 for item in items:
  try:out.append(assemble_set(item))
  except ComponentError as exc:
   reason=str(exc);reasons[reason]=reasons.get(reason,0)+1
 return {'sets':out,'diagnostic':diagnostic(len(items),len(out),reasons)}

def public_diagnostic(value):
 if not isinstance(value,Mapping) or value.get('schema')!=SCHEMA:return None
 fields=('input_set_count','produced_set_count','blocked_set_count')
 if any(type(value.get(k)) is not int for k in fields):return None
 n,p,b=(value[k] for k in fields)
 if not 0<=p<=n<=64 or b!=n-p:return None
 if any(value.get(k) is not False for k in ('models_certified_by_assembler','canonical_publication_authorized','execution_authorized')):return None
 if value.get('status') not in ('ECONOMIC_COMPONENT_SETS_NOT_SUPPLIED','COMPONENT_SETS_ASSEMBLED','COMPONENT_ASSEMBLY_BLOCKED','COMPONENT_SOURCE_REJECTED'):return None
 reasons=value.get('blocking_reason_counts')
 if not isinstance(reasons,Mapping) or len(reasons)>64 or any(not isinstance(k,str) or not re.fullmatch('[A-Z][A-Z0-9_]{0,119}',k) or type(v) is not int or not 0<=v<=64 for k,v in reasons.items()):return None
 return {'schema':SCHEMA,'status':value['status'],**{k:value[k] for k in fields},'blocking_reason_counts':dict(reasons),
  'models_certified_by_assembler':False,'canonical_publication_authorized':False,'execution_authorized':False}

def source_rejected(reason):
 return diagnostic(status='COMPONENT_SOURCE_REJECTED',reasons={reason:1})
