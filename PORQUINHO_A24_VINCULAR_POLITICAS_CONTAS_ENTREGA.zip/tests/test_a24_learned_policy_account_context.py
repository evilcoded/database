import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import test_a24_economic_action_plan as a
import test_a24_funded_currency_research as f
import test_a24_learned_allocation_policy as l
from universal_portfolio import learned_policy_account_context_a24 as p
from universal_portfolio.explicit_market_bindings_a24 import digest


class AccountPolicyContext(unittest.TestCase):
    def setUp(self):
        self.bindings = [{'instrument_id': iid, 'provider': 'fixture', 'provider_id': 'source-' + str(j),
            'quote_currency': 'BRL', 'effective_from': '2026-01-01', 'identity_source_ref': 'fixture'} for j, iid in enumerate((a.I, a.J))]
        self.kw = a.Plan().setup(bindings=self.bindings)
        self.action = a.m.project(**self.kw)
        self.funding = self.kw['funding']

    def body(self, k=1):
        e = l.experiment()
        for group in (e['folds'], e['forecasts']):
            for row in group:
                row['quote_currency'] = 'BRL'
                row['instrument_id'] = (a.I, a.J)[int(row['provider_id'][-1])]
        if k == 2:
            for row in e['folds']:
                if row['origin'] < '2024-08-01': row['actual_pct'] = -10 if row['instrument_id'] == a.I else 10
        return {'version': {'synthetic': True}, 'research': l.p.learn([e], now=l.NOW)}

    def run_scope(self, body=None):
        return p.project(self.action, self.funding, [body or self.body()])

    def test_exact_cash_budget_and_plan_contexts(self):
        r = self.run_scope(); s = r['scenarios'][0]
        self.assertEqual((s['account_id'], s['currency'], s['budget_id'], s['plan_id']), ('account', 'BRL', 'budget', 'plan'))
        self.assertEqual(s['budget_reference_capital'], '50')
        self.assertEqual(s['scope'], 'INCREMENTAL_CASH_BUDGET_RESEARCH_NOT_WHOLE_PORTFOLIO')

    def test_exact_held_identity_maps_increase_not_sell(self):
        s = self.run_scope()['scenarios'][0]; leg = s['legs'][0]
        self.assertEqual(leg['draft_action_kind'], 'INCREASE')
        self.assertFalse(s['zero_target_is_sell_instruction'])
        self.assertFalse(s['portfolio_target_weights_created'])
        self.assertFalse(s['reallocation_created'])

    def test_provider_mismatch_is_not_matched_by_ticker(self):
        body = self.body(); body['research']['candidates'][0]['current_research_weights'][0]['provider_id'] = 'OTHER_SOURCE'
        s = self.run_scope(body)['scenarios'][0]
        self.assertIn('EXACT_PROVIDER_QUOTE_REQUEST_REQUIRED', s['blocking_reasons'])

    def test_foreign_currency_never_uses_account_cash(self):
        body = self.body(); body['research']['quote_currency'] = 'USD'
        r = self.run_scope(body)
        self.assertEqual(r['scenarios'], [])
        self.assertEqual(r['pending_contexts'][0]['reason'], 'CURRENT_LEARNED_POLICY_CANDIDATES_REQUIRED')

    def test_mixed_quote_leg_refused(self):
        body = self.body(); body['research']['candidates'][0]['current_research_weights'][0]['quote_currency'] = 'USD'
        with self.assertRaisesRegex(ValueError, 'EXACT_UNIQUE_POLICY_WEIGHT'): self.run_scope(body)

    def test_no_model_or_publication_authority_inherited(self):
        body = self.body(); body['research']['comparison_authorized'] = True
        with self.assertRaisesRegex(ValueError, 'NONAUTHORIZING_LEARNED'): self.run_scope(body)

    def test_missing_cash_budget_does_not_create_amount(self):
        kw = a.Plan().setup(budgets=[], plans=[], bindings=self.bindings)
        r = p.project(a.m.project(**kw), kw['funding'], [self.body()])
        self.assertEqual(r['scenarios'], [])
        self.assertEqual(r['pending_contexts'][0]['reason'], 'ACTIVE_INVESTMENT_BUDGET_REQUIRED')

    def test_zero_cash_does_not_infer_realallocation(self):
        kw = a.Plan().setup(cash='0', budgets=[], bindings=self.bindings)
        r = p.project(a.m.project(**kw), kw['funding'], [self.body()])
        self.assertEqual(r['scenarios'], [])
        self.assertFalse(r['execution_authorized'])

    def test_active_plan_required_per_budget(self):
        kw = a.Plan().setup(plans=[], bindings=self.bindings)
        r = p.project(a.m.project(**kw), kw['funding'], [self.body()])
        self.assertEqual(r['scenarios'], [])
        self.assertEqual(r['pending_contexts'][0]['reason'], 'UNIQUE_ACTIVE_PLAN_FOR_BUDGET_REQUIRED')

    def test_budget_partitions_not_whole_cash_or_shared_between_plans(self):
        kw = a.Plan().setup(bindings=self.bindings,
            budgets=[f.budget(amount='20'), f.budget(budget_id='second', amount='30')],
            plans=[f.plan(), f.plan(plan_id='second-plan', planning_budget_id='second')])
        r = p.project(a.m.project(**kw), kw['funding'], [self.body()])
        self.assertEqual(sorted(x['budget_reference_capital'] for x in r['scenarios']), ['20', '30'])
        self.assertEqual(len({x['shared_cash_resource_key'] for x in r['scenarios']}), 1)
        self.assertTrue(all(x['cash_scenarios_are_mutually_exclusive'] for x in r['scenarios']))

    def test_plan_class_filters_do_not_renormalize_other_legs(self):
        kw = a.Plan().setup(bindings=self.bindings,
            budgets=[f.budget(amount='20'), f.budget(budget_id='second', amount='30')],
            plans=[f.plan(), f.plan(plan_id='second-plan', planning_budget_id='second', allowed_asset_classes=['BOND'])])
        r = p.project(a.m.project(**kw), kw['funding'], [self.body(k=2)])
        blocked = next(s for s in r['scenarios'] if s['plan_id'] == 'second-plan')
        self.assertIn('SOURCE_OUTSIDE_THIS_PLAN_REQUESTS_OR_CLASSES', blocked['blocking_reasons'])
        self.assertFalse(blocked['renormalized_after_blocked_legs'])
        self.assertTrue(all(x['fraction_denominator'] == 2 for x in blocked['legs']))

    def test_research_alias_does_not_merge_real_positions(self):
        self.kw = a.Plan().setup(positions=[{'instrument_id': 'ORIGINAL:POSITION:ID', 'account_id': 'account', 'currency': 'BRL', 'quantity': '2'}], links=[{'position_instrument_id': 'ORIGINAL:POSITION:ID', 'research_instrument_id': a.I, 'evidence_ref': 'research only'}], bindings=self.bindings)
        r = p.project(a.m.project(**self.kw), self.kw['funding'], [self.body()])
        self.assertIn('RESEARCH_LINK_NOT_FINANCIAL_IDENTITY_BINDING', r['scenarios'][0]['blocking_reasons'])
        self.assertEqual(p.summarize(r)['source_request_compatible_leg_count'], 0)

    def test_amount_and_cash_changes_require_new_context(self):
        self.action['cases'][-1]['canonical_cash_observed'] = '99'
        with self.assertRaisesRegex(ValueError, 'CASH_CONTEXT_CHANGED'): self.run_scope()

    def test_budget_ceiling_must_equal_current_partition(self):
        self.action['cases'][-1]['capital_ceiling'] = '51'
        with self.assertRaisesRegex(ValueError, 'EXACT_BUDGET_PARTITION'): self.run_scope()

    def test_horizon_mismatch_does_not_choose_alternative(self):
        for alt in self.action['cases'][-1]['alternatives']: alt['horizon_unit'] = 'DAYS'
        r = self.run_scope()
        self.assertIn('UNIQUE_EXACT_CASH_ALTERNATIVE_REQUIRED', r['scenarios'][0]['blocking_reasons'])

    def test_duplicate_alternative_not_silently_selected(self):
        alts = self.action['cases'][-1]['alternatives']; alts.append(copy.deepcopy(next(x for x in alts if x['instrument_id'] == a.I)))
        self.assertIn('UNIQUE_EXACT_CASH_ALTERNATIVE_REQUIRED', self.run_scope()['scenarios'][0]['blocking_reasons'])

    def test_existing_economic_blockers_preserved(self):
        r = self.run_scope(); s = r['scenarios'][0]
        self.assertIn('VALIDATED_SIZING_REQUIRED', s['blocking_reasons'])
        self.assertIn('ACTION_SPECIFIC_PRETRADE_COST_REQUIRED', s['blocking_reasons'])
        self.assertIn('PRETRADE_COSTS_REQUIRED', s['blocking_reasons'])

    def test_no_order_amounts_even_with_positive_budget_and_matched_source(self):
        r = self.run_scope(); s = r['scenarios'][0]
        self.assertFalse(s['budget_reference_is_order_amount'])
        self.assertFalse(s['resources_reserved'])
        self.assertTrue(all(x['scenario_amount'] is None and x['requested_amount'] is None for x in s['legs']))
        self.assertFalse(r['recommendation_created'])

    def test_summary_omits_financial_values_and_identifiers(self):
        s = json.dumps(p.summarize(self.run_scope()))
        for key in ('account_id', 'plan_id', 'budget_reference_capital', 'candidate_id', 'instrument_id'):
            self.assertNotIn('"' + key + '"', s)

    def test_duplicate_current_versions_not_selected(self):
        with self.assertRaisesRegex(ValueError, 'ONE_CURRENT_POLICY_VERSION'): p.project(self.action, self.funding, [self.body(), self.body()])

    def test_current_fingerprint_required(self):
        self.funding['contexts'][0]['context_fingerprint'] = 'OLD'
        with self.assertRaisesRegex(ValueError, 'CURRENT_FUNDING'): self.run_scope()

    def test_readonly_build_no_models_network_or_writes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'data').mkdir()
            self.action['source_version_digest'] = digest(a.m.source_versions(root))
            before = list(root.rglob('*'))
            with patch.object(p.learner, 'work', return_value=({}, [])):
                result = p.build(root, self.action, self.funding, now=l.NOW)
            self.assertEqual(result['status'], 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY')
            self.assertEqual(list(root.rglob('*')), before)

    def test_changed_financial_context_is_explicit_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'data').mkdir()
            self.action['source_version_digest'] = 'OLD'
            self.assertEqual(p.build(root, self.action, self.funding, now=l.NOW)['status'], 'LEARNED_POLICY_ACCOUNT_SCOPE_UNAVAILABLE')

    def test_financial_change_during_projection_refuses_stale_context(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'data').mkdir()
            self.action['source_version_digest'] = digest(a.m.source_versions(root))
            def changed(*args):
                (root / 'data/investment_plans.json').write_text('{}')
                return {}, []
            with patch.object(p.learner, 'work', side_effect=changed):
                result = p.build(root, self.action, self.funding, now=l.NOW)
            self.assertEqual(result['reason'], 'POLICY_OR_FINANCIAL_SOURCES_CHANGED_DURING_SCOPE')

    def test_original_learning_summary_preserved_with_real_verified_sources(self):
        existing = l.existing.Reuse(); existing.setUp(); self.addCleanup(existing.doCleanups)
        existing.runlab()
        l.p.run(existing.root, existing.demand, now=l.existing.NOW, revalidate=existing.current)
        context = existing.demand['contexts'][0]
        action = {'schema': a.m.SCHEMA, 'status': 'ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY',
            'cases': [{'resource_kind': 'CASH', 'case_id': 'fixture-cash', 'account_id': context['account_id'],
                'currency': context['currency'], 'canonical_cash_observed': '100', 'capital_ceiling': None}],
            'source_version_digest': digest(a.m.source_versions(existing.root)), **a.m.flags()}
        expected = l.p.summary(existing.root, existing.demand, now=l.existing.NOW)
        before = {x: x.read_bytes() for x in existing.root.rglob('*') if x.is_file()}
        result = p.build(existing.root, action, existing.demand, now=l.existing.NOW)
        self.assertEqual(result['status'], 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY')
        self.assertEqual(result['learning_summary'], expected)
        self.assertEqual(before, {x: x.read_bytes() for x in existing.root.rglob('*') if x.is_file()})
