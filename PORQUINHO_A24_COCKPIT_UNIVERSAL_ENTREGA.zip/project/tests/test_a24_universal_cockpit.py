import copy,unittest
from universal_portfolio.universal_cockpit_a24 import project
class Cockpit(unittest.TestCase):
 def setUp(self):
  self.positions=[dict(instrument_id='GLOBAL:ASSET:ONE',account_id='a',currency='BRL',quantity='2',cost_basis='150')]
  self.cash=[dict(account_id='a',currency='BRL',amount='20'),dict(account_id='b',currency='JPY',amount='300')]
  self.registry={'institutions':[{'institution_id':'bank','name':'Banco','country':'BR'}],'accounts':[{'account_id':'a','institution_id':'bank','name':'Principal','currency':'BRL'},{'account_id':'b','institution_id':'bank','name':'Exterior','currency':'JPY'}]}
  self.catalog={'instruments':[{'instrument_id':'GLOBAL:ASSET:ONE','symbol':'ONE'}]}
  self.quotes=[dict(instrument_id='GLOBAL:ASSET:ONE',quote_currency='BRL',price='100',fetched_at='2026-10-17T12:00:00+00:00')]
 def result(self):return project(self.positions,self.cash,self.registry,self.catalog,self.quotes,observed_at='2026-10-17T12:00:00+00:00')
 def test_any_currency_separate_totals_no_country_inference(self):
  r=self.result();self.assertEqual([v['currency'] for v in r['currency_totals']],['BRL','JPY']);self.assertFalse(r['cross_currency_aggregation'])
 def test_exact_quote_values_reference_not_execution_price(self):
  p=self.result()['positions'][0];self.assertEqual(p['reference_market_value'],'200');self.assertEqual(p['reference_pnl'],'50');self.assertIn('NOT_EXECUTION_PRICE',p['valuation_status'])
 def test_currency_mismatch_never_values_position(self):
  self.quotes[0]['quote_currency']='EUR';self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_symbol_or_research_alias_not_financial_identity(self):
  self.quotes[0]['instrument_id']='OTHER:ONE';self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_multiple_source_quotes_do_not_pick_provider(self):
  self.quotes*=2;self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_missing_cash_not_fabricated_as_zero(self):
  self.cash[0]['amount']=None;self.assertIsNone(self.result()['currency_totals'][0]['cash'])
 def test_conflicting_registered_currency_flags_context(self):
  self.registry['accounts'][0]['currency']='EUR';r=self.result();self.assertEqual(r['positions'][0]['context_status'],'CONTEXT_REVIEW_REQUIRED');self.assertIsNone(r['currency_totals'][0]['cash'])
 def test_unknown_basis_never_becomes_zero(self):
  self.positions[0]['cost_basis']=None;self.assertIsNone(self.result()['currency_totals'][0]['invested_cost'])
 def test_duplicate_account_and_position_not_silently_aggregated(self):
  self.registry['accounts']*=2;self.positions*=2;r=self.result();self.assertTrue(all(p['context_status']=='CONTEXT_REVIEW_REQUIRED' for p in r['positions']));self.assertIsNone(r['currency_totals'][0]['invested_cost'])
 def test_explicit_labels_only_not_symbol_identity_join(self):
  self.catalog['instruments'][0]['instrument_id']='OTHER:ONE';self.assertIsNone(self.result()['positions'][0]['display_label'])
 def test_zero_position_excluded_without_sell(self):
  self.positions[0]['quantity']='0';self.assertEqual(self.result()['positions'],[])
 def test_no_writes_mutation_or_authority(self):
  before=copy.deepcopy((self.positions,self.cash,self.registry,self.catalog,self.quotes));r=self.result();self.assertEqual(before,(self.positions,self.cash,self.registry,self.catalog,self.quotes))
  for k in ('execution_authorized','financial_mutation','history_write_performed'):self.assertIs(r[k],False)
