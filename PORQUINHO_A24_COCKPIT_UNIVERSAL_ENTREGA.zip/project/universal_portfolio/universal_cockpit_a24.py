"""Universal read-only UI facts. No symbol joins, default currency, FX, or orders."""
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from .monitor_consolidation_a24 import context

SCHEMA='porquinho.universal-cockpit-a24/1.0'

def number(value):
 if isinstance(value,bool) or value is None: return None
 try:
  d=Decimal(str(value))
  return d if d.is_finite() else None
 except (InvalidOperation,ValueError,TypeError):return None

def project(positions,cash,registry,catalog,observations,*,observed_at,research_requests=()):
 labels={};ambiguous=set()
 for entry in catalog.get('instruments',[]):
  iid=entry.get('instrument_id');label=entry.get('symbol') or entry.get('name')
  if not isinstance(iid,str) or not isinstance(label,str):continue
  if iid in labels and labels[iid]!=label:ambiguous.add(iid)
  labels[iid]=label
 banks={};accounts={};duplicates=set()
 for bank in registry.get('institutions',[]):
  key=bank.get('institution_id')
  if key in banks:banks[key]=None
  else:banks[key]=bank
 for account in registry.get('accounts',[]):
  aid=account.get('account_id')
  if aid in accounts:duplicates.add(aid)
  bank=banks.get(account.get('institution_id')) or {}
  accounts[aid]={'account_id':aid,'name':account.get('name'), 'currency':account.get('currency'),
   'institution_name':bank.get('name'),'country':bank.get('country')}
 out=[];seen=defaultdict(int)
 for p in positions:
  if number(p.get('quantity'))==0:continue
  key=context(p)
  if key:seen[key]+=1
 quotes=defaultdict(list)
 for obs in observations:
  quotes[(obs.get('instrument_id'),obs.get('quote_currency'))].append(obs)
 for p in positions:
  qty=number(p.get('quantity'))
  if qty==0:continue
  key=context(p);iid,aid,q=key if key else (None,None,None)
  account=accounts.get(aid)
  valid=bool(key and seen[key]==1 and aid not in duplicates and account and account['currency']==q)
  cost=number(p.get('cost_basis'));valuation=None;price=None;quote_at=None
  source=quotes[(iid,q)] if valid else []
  if len(source)==1 and qty is not None and qty>0:
   price=number(source[0].get('price'))
   if price is not None and price>0:valuation=qty*price;quote_at=source[0].get('fetched_at')
  row={'position_id':p.get('position_id'),'instrument_id':iid,'account_id':aid,'currency':q,
   'display_label':labels.get(iid) if iid not in ambiguous else None,
   'context_status':'EXACT_REGISTERED_CONTEXT' if valid else 'CONTEXT_REVIEW_REQUIRED',
   'quantity':str(qty) if qty is not None else None,'cost_basis':str(cost) if cost is not None else None,
   'reference_market_value':str(valuation) if valuation is not None else None,
   'reference_pnl':str(valuation-cost) if valuation is not None and cost is not None else None,
   'reference_pnl_pct':str((valuation-cost)/cost*100) if valuation is not None and cost is not None and cost>0 else None,
   'reference_price':str(price) if valuation is not None else None,'reference_quote_at':quote_at,
   'valuation_status':'EXACT_IDENTITY_RESEARCH_QUOTE_NOT_EXECUTION_PRICE' if valuation is not None else 'EXPLICIT_QUOTE_REQUIRED'}
  out.append(row)
 cashrows=[]
 for c in cash:
  from .funded_currency_research_a24 import field
  aid=field(c,'account_id');q=field(c,'currency');value=number(field(c,'amount'));a=accounts.get(aid)
  cashrows.append({'account_id':aid,'currency':q,'amount':str(value) if value is not None else None,
   'context_status':'EXACT_REGISTERED_CONTEXT' if a and aid not in duplicates and a['currency']==q and value is not None else 'CONTEXT_REVIEW_REQUIRED'})
 totals=[]
 for q in sorted({r['currency'] for r in out+cashrows if isinstance(r.get('currency'),str) and r['currency']}):
  ps=[p for p in out if p['currency']==q];cs=[c for c in cashrows if c['currency']==q]
  cashvalid=all(c['context_status']=='EXACT_REGISTERED_CONTEXT' for c in cs)
  positionvalid=all(p['context_status']=='EXACT_REGISTERED_CONTEXT' and p['cost_basis'] is not None for p in ps)
  totals.append({'currency':q,'position_count':len(ps),'cash':str(sum((number(c['amount']) for c in cs),Decimal(0))) if cashvalid else None,
   'invested_cost':str(sum((number(p['cost_basis']) for p in ps),Decimal(0))) if positionvalid else None,
   'reference_valued_position_count':sum(p['reference_market_value'] is not None for p in ps)})
 return {'schema':SCHEMA,'status':'UNIVERSAL_FACTS_PROJECTED','observed_at':observed_at,
  'research_contexts':[{'instrument_id':r.get('instrument_id'),'account_id':r.get('account_id'),'quote_currency':r.get('quote_currency')} for r in research_requests],
  'market_observations':[{k:o.get(k) for k in ('instrument_id','quote_currency','provider','provider_id','price','fetched_at')} for o in observations],
  'positions':out,'cash':cashrows,'currency_totals':totals,'accounts':[a for k,a in accounts.items() if k not in duplicates],
  'cross_currency_aggregation':False,'execution_authorized':False,'financial_mutation':False,'history_write_performed':False}
