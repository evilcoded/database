"""Synthetic fixtures only. No real investment evidence or authority."""
import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import scoped_economic_comparison_a24 as s
from universal_portfolio.governed_comparison_producer_a2 import produce_governed_comparisons
from universal_portfolio.governed_economic_input_transport_a24 import comparison_identity,collect_inputs
from universal_portfolio.universal_runtime_composition import compose_shadow_cycle
from test_a24_governed_economic_integration import envelope,SRC,DST,public_projection

def replace_scope(value,account,currency):
 if isinstance(value,dict):return {k:replace_scope(v,account,currency) for k,v in value.items()}
 if isinstance(value,list):return [replace_scope(v,account,currency) for v in value]
 if value=='TEST_ACCOUNT':return account
 if value=='TST':return currency
 return value

def context(cid='one',account='TEST_ACCOUNT',currency='TST'):
 e=replace_scope(envelope(),account,currency)
 comparison=comparison_identity(produce_governed_comparisons(e)['comparison_rows'])
 for candidate in e['governed_economic_sizing_candidates']:candidate['comparison_id']=comparison
 return {'comparison_set_id':cid,'alternatives':e['governed_economic_alternatives'],'source_refs':e['governed_economic_source_refs'],'sizing_candidates':e['governed_economic_sizing_candidates']}
class Scoped(unittest.TestCase):
 def evaluate(self,items):
  data={s.KEY:items};return s.size(s.compare(data),data)
 def test_independent_accounts_and_currencies(self):
  out=self.evaluate([context(),context('two','SECOND','JPY')]);self.assertEqual(s.summary(out)['sets_with_matched_sizing'],2);self.assertIsNone(out['canonical_recommendation']);self.assertFalse(out['execution_authorized'])
 def test_reallocation_retained_as_experimental(self):self.assertEqual(self.evaluate([context()])['contexts'][0]['ui_projection']['experimental_brain_proposal']['action'],'REALLOCATE')
 def test_same_currency_different_accounts_not_pooled(self):
  out=self.evaluate([context(),context('two','SECOND')]);self.assertEqual([c['account_id'] for c in out['contexts']],['TEST_ACCOUNT','SECOND'])
 def test_different_horizons_in_separate_sets_do_not_mix(self):
  other=context('two')
  for a in other['alternatives']:a['evidence'].update(horizon='60_OBSERVATIONS',horizon_unit='OBSERVATIONS',horizon_value=60)
  other['sizing_candidates']=[];out=self.evaluate([context(),other]);self.assertEqual(s.summary(out)['sets_with_accepted_comparison_inputs'],2);self.assertEqual(s.summary(out)['sets_with_matched_sizing'],1)
 def test_missing_evidence_not_filled_from_quotes(self):
  c=context();del c['alternatives'][0]['evidence']['forward_return'];out=self.evaluate([c]);self.assertEqual(s.summary(out)['sets_with_accepted_comparison_inputs'],0)
 def test_cross_account_inside_set_rejected(self):
  c=context();c['alternatives'][0]['account_id']='OTHER';self.assertEqual(s.summary(self.evaluate([c]))['sets_with_accepted_comparison_inputs'],0)
 def test_cross_currency_inside_set_rejected(self):
  c=context();c['alternatives'][0]['currency']='JPY';self.assertEqual(s.summary(self.evaluate([c]))['sets_with_accepted_comparison_inputs'],0)
 def test_mixed_horizon_inside_set_rejected(self):
  c=context();c['alternatives'][0]['evidence']['horizon_value']=60;self.assertEqual(s.summary(self.evaluate([c]))['sets_with_accepted_comparison_inputs'],0)
 def test_implicit_horizon_refused(self):
  c=context();del c['alternatives'][0]['evidence']['horizon_unit'];self.assertEqual(self.evaluate([c])['contexts'][0]['comparison_intake']['reason'],'EXPLICIT_COMPARISON_HORIZON_REQUIRED')
 def test_bad_set_does_not_promote_or_hide_other_set(self):
  c=context('bad');c['alternatives'][0]['evidence']['forward_return_validated']=False;out=self.evaluate([c,context('good')]);self.assertEqual(s.summary(out)['sets_with_accepted_comparison_inputs'],1);self.assertEqual(s.summary(out)['comparison_set_count'],2)
 def test_duplicate_set_ids_refuse_all(self):self.assertEqual(s.compare({s.KEY:[context(),context()]})['reason'],'DUPLICATE_COMPARISON_SET_ID')
 def test_duplicate_alternatives_within_set_refused(self):
  c=context();c['alternatives'][1]['alternative_id']='keep';self.assertEqual(s.summary(self.evaluate([c]))['sets_with_accepted_comparison_inputs'],0)
 def test_reused_alternative_names_between_sets_are_scoped(self):self.assertEqual(s.summary(self.evaluate([context(),context('other','SECOND')]))['sets_with_matched_sizing'],2)
 def test_wrong_sizing_scope_not_displayed(self):
  c=context();c['sizing_candidates'][0]['account_id']='OTHER';self.assertEqual(s.summary(self.evaluate([c]))['sets_with_matched_sizing'],0)
 def test_sizing_from_another_set_not_reused(self):
  c=context('second','SECOND','JPY');c['sizing_candidates']=context()['sizing_candidates'];self.assertEqual(s.summary(self.evaluate([context(),c]))['sets_with_matched_sizing'],1)
 def test_wrong_comparison_identity_not_displayed(self):
  c=context();c['sizing_candidates'][0]['comparison_id']='WRONG';self.assertEqual(s.summary(self.evaluate([c]))['sets_with_matched_sizing'],0)
 def test_missing_models_keep_comparison_without_amount(self):
  c=context();c['sizing_candidates']=[];out=self.evaluate([c]);self.assertEqual(s.summary(out)['sets_with_matched_sizing'],0);self.assertEqual(s.summary(out)['sets_with_accepted_comparison_inputs'],1)
 def test_rejected_transport_never_falls_back(self):self.assertEqual(s.compare({s.KEY:[context()],'economic_input_transport':{'status':'UNAVAILABLE','reason':'SOURCE_UNREADABLE'}})['reason'],'SCOPED_SOURCE_TRANSPORT_REJECTED')
 def test_no_sets_is_explicit(self):self.assertEqual(s.summary(s.compare({}))['reason'],'EXPLICIT_COMPARISON_SETS_NOT_SUPPLIED')
 def test_context_limit_refused(self):self.assertEqual(s.compare({s.KEY:[context(str(i)) for i in range(65)]})['reason'],'EXPLICIT_COMPARISON_SETS_INVALID')
 def test_changed_rows_between_stages_refused(self):
  data={s.KEY:[context()]};before=s.compare(data);data[s.KEY][0]['alternatives'][0]['relative_utility']=999
  with self.assertRaisesRegex(ValueError,'CHANGED'):s.size(before,data)
 def test_source_input_not_mutated(self):
  data={s.KEY:[context()]};before=copy.deepcopy(data);s.size(s.compare(data),data);self.assertEqual(data,before)
 def test_summary_redacts_private_models_and_amounts(self):
  out=s.summary(self.evaluate([context()]));self.assertNotIn('TEST_ACCOUNT',json.dumps(out));self.assertNotIn('suggested_amount',json.dumps(out));self.assertNotIn('model',json.dumps(out));self.assertIsNotNone(s.public_summary(out))
 def test_public_projection_preserves_safe_summary_idempotently(self):
  data={'scoped_economic_comparison_summary':s.summary(self.evaluate([context()]))};first=public_projection(data);second=public_projection(first);self.assertEqual(first,second);self.assertEqual(first['scoped_economic_comparison_summary']['sets_with_matched_sizing'],1);self.assertIsNone(first['experimental_brain_proposal'])
 def test_public_summary_rejects_authority_or_impossible_counts(self):
  data=s.summary(self.evaluate([context()]))
  for key,value in [('execution_authorized',True),('sets_with_matched_sizing',2),('comparison_set_count',True)]:self.assertIsNone(s.public_summary({**data,key:value}))
 def run_cycle(self,data):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp)
   def write(rel,obj):
    p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj))
   write('data/universal_instrument_catalog.json',{'instruments':[{'instrument_id':i,'asset_class':i.split(':')[2],'market':'MKT','jurisdiction':'TEST','currency':'TST'} for i in (SRC,DST)]})
   write('data/universal_positions.json',{'positions':[{'instrument_id':SRC},{'instrument_id':DST}]});write('results/latest.json',data)
   before={p:p.read_bytes() for p in root.rglob('*') if p.is_file()}
   with patch('socket.socket.connect',side_effect=AssertionError('network')):out=compose_shadow_cycle(root,observed_at='2026-10-16T00:00:00Z',started_at='2026-10-16T00:00:00Z',cycle_seed='SYNTHETIC_SCOPED_TEST')
   self.assertEqual(before,{p:p.read_bytes() for p in root.rglob('*') if p.is_file()});self.assertEqual(out.cycle.recommendation_snapshots,());self.assertFalse(out.cycle.financial_mutation)
   return out
 def test_actual_pipeline_comparison_sizing_snapshot_handoff(self):
  out=self.run_cycle({s.KEY:[context(),context('two','SECOND','JPY')]});self.assertEqual(out.economic_decision_ui_projection['scoped_economic_comparison_summary']['sets_with_matched_sizing'],2);self.assertIsNone(out.economic_decision_ui_projection['canonical_investment_recommendation'])
 def test_pipeline_unknown_instrument_refused(self):
  c=context();c['alternatives'][0]['instrument_id']='UNKNOWN';out=self.run_cycle({s.KEY:[c]});self.assertEqual(out.economic_decision_ui_projection['scoped_economic_comparison_summary']['comparison_set_count'],0)
 def test_pipeline_mixed_legacy_and_new_contract_refused(self):
  data={**envelope(),s.KEY:[context()]};out=self.run_cycle(data);self.assertIsNone(out.economic_decision_ui_projection['experimental_brain_proposal']);self.assertEqual(out.economic_decision_ui_projection['scoped_economic_comparison_summary']['comparison_set_count'],0)
 def test_pipeline_does_not_need_new_series_maturation(self):self.assertEqual(self.run_cycle({s.KEY:[context()]}).economic_decision_ui_projection['scoped_economic_comparison_summary']['sets_with_matched_sizing'],1)

 def test_transport_digest_preserved_per_context(self):
  out=s.compare({s.KEY:[context()],'economic_input_transport':{'status':'OBSERVED_NOT_CERTIFIED','source_refs':['artifact#sha256:verified']}});self.assertIn('artifact#sha256:verified',out['contexts'][0]['comparison_intake']['source_refs'])
 def test_missing_context_provenance_not_rescued_by_transport(self):
  c=context();c['source_refs']=[];out=s.compare({s.KEY:[c],'economic_input_transport':{'status':'OBSERVED_NOT_CERTIFIED','source_refs':['artifact#sha256:verified']}});self.assertEqual(s.summary(out)['sets_with_accepted_comparison_inputs'],0)
 def test_source_refs_changed_between_stages_refused(self):
  data={s.KEY:[context()]};out=s.compare(data);data[s.KEY][0]['source_refs']=['changed']
  with self.assertRaisesRegex(ValueError,'CHANGED'):s.size(out,data)
 def test_currency_not_silently_normalized(self):
  c=context(currency='jpy');self.assertEqual(s.summary(self.evaluate([c]))['sets_with_accepted_comparison_inputs'],0)
