"""Independent explicit comparison sets. No FX, global winner or canonical authority."""
from collections.abc import Mapping
SCHEMA='porquinho.scoped-economic-comparisons-a24/1.0'
KEY='governed_economic_comparison_sets'

def base(reason=None):
 return {'schema':SCHEMA,'status':'UNAVAILABLE' if reason else 'SCOPED_EVIDENCE_OBSERVED','reason':reason,
  'contexts':[],'canonical_recommendation':None,'execution_authorized':False,'financial_mutation':False,'history_write_performed':False}

def compare(intelligence):
 from .governed_comparison_producer_a2 import produce_governed_comparisons
 from .brain_economic_runtime_boundary_p32 import observe_economic_decision
 if not isinstance(intelligence,Mapping):return base('INTELLIGENCE_MAPPING_REQUIRED')
 transport=intelligence.get('economic_input_transport')
 if isinstance(transport,Mapping) and transport.get('status')=='UNAVAILABLE' and transport.get('reason')!='GOVERNED_ENVELOPE_NOT_PRODUCED':return base('SCOPED_SOURCE_TRANSPORT_REJECTED')
 sets=intelligence.get(KEY)
 if sets is None:return base('EXPLICIT_COMPARISON_SETS_NOT_SUPPLIED')
 if not isinstance(sets,(tuple,list)) or not sets or len(sets)>64:return base('EXPLICIT_COMPARISON_SETS_INVALID')
 ids=[]
 for item in sets:
  if not isinstance(item,Mapping) or not isinstance(item.get('comparison_set_id'),str) or not item['comparison_set_id'] or item['comparison_set_id']!=item['comparison_set_id'].strip():return base('EXPLICIT_COMPARISON_SET_ID_REQUIRED')
  ids.append(item['comparison_set_id'])
 if len(ids)!=len(set(ids)):return base('DUPLICATE_COMPARISON_SET_ID')
 out=base()
 for item in sets:
  payload={'governed_economic_alternatives':item.get('alternatives'),'governed_economic_source_refs':item.get('source_refs')}
  refs=payload['governed_economic_source_refs']
  if isinstance(refs,(tuple,list)) and refs and all(isinstance(r,str) and r.strip() for r in refs) and isinstance(transport,Mapping):
   transport_refs=transport.get('source_refs',())
   if isinstance(transport_refs,(tuple,list)):payload['governed_economic_source_refs']=tuple(refs)+tuple(transport_refs)
  rows=item.get('alternatives')
  # Explicit horizon identity required for the new global path.
  horizon_ok=isinstance(rows,(tuple,list)) and bool(rows) and all(isinstance(r,Mapping) and isinstance(r.get('evidence'),Mapping) and isinstance(r['evidence'].get('horizon_unit'),str) and bool(r['evidence']['horizon_unit']) and type(r['evidence'].get('horizon_value')) is int and r['evidence']['horizon_value']>0 for r in rows)
  intake=produce_governed_comparisons(payload)
  if isinstance(rows,(tuple,list)) and any(isinstance(r,Mapping) and (not isinstance(r.get('currency'),str) or not r['currency'].isascii() or not r['currency'].isalpha() or not r['currency'].isupper()) for r in rows):intake.update(status='UNAVAILABLE',reason='EXPLICIT_UPPERCASE_CURRENCY_REQUIRED',comparison_rows=(),source_refs=())
  if not horizon_ok:intake.update(status='UNAVAILABLE',reason='EXPLICIT_COMPARISON_HORIZON_REQUIRED',comparison_rows=(),source_refs=())
  compared=tuple(intake['comparison_rows']);observation=observe_economic_decision(compared)
  scope=compared[0] if compared else {}
  out['contexts'].append({'comparison_set_id':item['comparison_set_id'],'account_id':scope.get('account_id'),'currency':scope.get('currency'),
   'comparison_intake':intake,'comparison_rows':compared,'economic_observation':observation,'sizing_assessments':(),
   'ui_projection':None,'canonical_recommendation':None,'execution_authorized':False})
 return out

def size(compared,intelligence):
 from .universal_runtime_composition import _assess_supplied_governed_candidates,_economic_decision_ui_projection
 if compared.get('schema')!=SCHEMA or compared.get('execution_authorized') is not False:raise ValueError('SCOPED_COMPARISON_CONTRACT_REQUIRED')
 out=dict(compared);out['contexts']=[]
 sets=intelligence.get(KEY,()) if isinstance(intelligence,Mapping) else ()
 for context in compared['contexts']:
  c=dict(context);items=[i for i in sets if i['comparison_set_id']==c['comparison_set_id']]
  if len(items)!=1:raise ValueError('SCOPED_COMPARISON_HANDOFF_MISMATCH')
  item=items[0]
  # Reject a changed comparison set between the economic and sizing stages.
  fresh=compare({KEY:[item],'economic_input_transport':intelligence.get('economic_input_transport')})
  if not fresh['contexts'] or fresh['contexts'][0]['comparison_intake']!=c['comparison_intake']:raise ValueError('SCOPED_COMPARISON_CHANGED')
  assessments=_assess_supplied_governed_candidates({'governed_economic_sizing_candidates':item.get('sizing_candidates')}) if c['comparison_rows'] else ()
  c['sizing_assessments']=assessments
  c['ui_projection']=_economic_decision_ui_projection(c['economic_observation'],comparison_rows=c['comparison_rows'],sizing_assessments=assessments)
  out['contexts'].append(c)
 return out

def summary(value):
 """Counts only; no raw models, account identities, amounts or global proposal."""
 if not isinstance(value,Mapping) or value.get('schema')!=SCHEMA:return None
 contexts=value.get('contexts',[]);reasons={};ready=0;assessed=0
 for c in contexts:
  intake=c['comparison_intake'];reason=intake.get('reason')
  if reason:reasons[reason]=reasons.get(reason,0)+1
  ready+=bool(c['comparison_rows'])
  p=c.get('ui_projection') or {};proposal=p.get('experimental_brain_proposal') or {}
  assessed+=proposal.get('sizing_verified_for_observed_identity') is True
 return {'schema':SCHEMA,'status':value['status'],'reason':value.get('reason'),'comparison_set_count':len(contexts),
  'sets_with_accepted_comparison_inputs':ready,'sets_with_matched_sizing':assessed,'blocking_reason_counts':reasons,
  'global_winner_selected':False,'cross_currency_aggregation':False,'canonical_publication_authorized':False,'execution_authorized':False}

def public_summary(value):
 import re
 if not isinstance(value,Mapping) or value.get('schema')!=SCHEMA:return None
 keys=('comparison_set_count','sets_with_accepted_comparison_inputs','sets_with_matched_sizing')
 if any(type(value.get(k)) is not int for k in keys):return None
 total,accepted,sized=(value[k] for k in keys)
 if not 0<=sized<=accepted<=total<=64:return None
 if any(value.get(k) is not False for k in ('global_winner_selected','cross_currency_aggregation','canonical_publication_authorized','execution_authorized')):return None
 if value.get('status') not in ('UNAVAILABLE','SCOPED_EVIDENCE_OBSERVED'):return None
 reason=value.get('reason')
 if reason is not None and (not isinstance(reason,str) or not re.fullmatch('[A-Z][A-Z0-9_]{0,119}',reason)):return None
 reasons=value.get('blocking_reason_counts')
 if not isinstance(reasons,Mapping) or len(reasons)>64:return None
 if any(not isinstance(k,str) or not re.fullmatch('[A-Z][A-Z0-9_]{0,119}',k) or type(v) is not int or not 0<=v<=total for k,v in reasons.items()):return None
 return {'schema':SCHEMA,'status':value['status'],'reason':reason,**{k:value[k] for k in keys},'blocking_reason_counts':dict(reasons),
  'global_winner_selected':False,'cross_currency_aggregation':False,'canonical_publication_authorized':False,'execution_authorized':False}
