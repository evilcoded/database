"""Transport explicit evidence from existing artifacts; never certify or estimate it.

A source envelope is not an independent recommendation producer. All output stays
experimental and is rechecked by the existing comparison, edge and sizing gates.
"""
from collections.abc import Mapping
from pathlib import Path
import hashlib
import json

SOURCES = ("results/latest.json", "data/equities/decision_latest.json",
           "data/fixed_income_positions/valuation_observations.json")
KEYS = ("governed_economic_alternatives", "governed_economic_source_refs",
        "governed_economic_sizing_candidates", "governed_economic_comparison_sets")


def comparison_identity(rows):
    """Content identity, not validation or publication authority."""
    return "sha256:" + hashlib.sha256(json.dumps(
        rows, sort_keys=True, ensure_ascii=True, allow_nan=False,
        separators=(",", ":")).encode()).hexdigest()


def collect_inputs(root, *, observed_ids):
    envelopes = []
    rejected = []
    for rel in SOURCES:
        path = Path(root) / rel
        if not path.is_file():
            continue
        try:
            if path.is_symlink() or not path.resolve().is_relative_to(Path(root).resolve()):
                rejected.append("SOURCE_PATH_NOT_LOCAL"); continue
            if path.stat().st_size > 16 * 1024 * 1024:
                rejected.append("SOURCE_TOO_LARGE"); continue
            content = path.read_bytes()
            value = json.loads(content)
            if not isinstance(value, Mapping) or not any(k in value for k in KEYS):
                continue
            envelopes.append((rel, content, value))
        except (OSError, ValueError, UnicodeError):
            rejected.append("SOURCE_UNREADABLE")
    status = {"status": "UNAVAILABLE", "reason": "GOVERNED_ENVELOPE_NOT_PRODUCED",
              "source_refs": (), "canonical_recommendation": False}
    if rejected or len(envelopes) > 1:
        status["reason"] = rejected[0] if rejected else "AMBIGUOUS_GOVERNED_SOURCE_ENVELOPES"
        # An explicitly rejected governed intake must not fall back to legacy flags.
        return {KEYS[0]: (), KEYS[1]: (), "economic_input_transport": status}
    if not envelopes:
        return {"economic_input_transport": status}
    rel, content, value = envelopes[0]
    alternatives = value.get(KEYS[0])
    if isinstance(alternatives, (list, tuple)) and any(
            isinstance(row, Mapping) and row.get("instrument_id") not in observed_ids
            for row in alternatives):
        status["reason"] = "ALTERNATIVE_INSTRUMENT_NOT_OBSERVED"
        return {KEYS[0]: (), KEYS[1]: (), "economic_input_transport": status}
    if "governed_economic_comparison_sets" in value and (value.get(KEYS[0]) or value.get(KEYS[2])):
        status['reason']='MIXED_COMPARISON_CONTRACTS_REFUSED'
        return {KEYS[0]:(),KEYS[1]:(),"economic_input_transport":status}
    sets=value.get("governed_economic_comparison_sets")
    if isinstance(sets,(list,tuple)):
        for item in sets:
            alternatives=item.get('alternatives') if isinstance(item,Mapping) else None
            if isinstance(alternatives,(list,tuple)) and any(isinstance(row,Mapping) and row.get('instrument_id') not in observed_ids for row in alternatives):
                status['reason']='ALTERNATIVE_INSTRUMENT_NOT_OBSERVED'
                return {KEYS[0]:(),KEYS[1]:(),"economic_input_transport":status}
    refs = value.get(KEYS[1])
    status.update(status="OBSERVED_NOT_CERTIFIED", reason=None,
                  source_refs=(rel + "#sha256:" + hashlib.sha256(content).hexdigest(),))
    out = {k: value[k] for k in KEYS if k in value}
    # Preserve missing/invalid source refs so the existing producer rejects them.
    if isinstance(refs, (list, tuple)) and refs and all(isinstance(x, str) and x.strip() for x in refs):
        out[KEYS[1]] = tuple(refs) + status["source_refs"]
    out["economic_input_transport"] = status
    return out


def typed_candidate(item):
    """Use existing constructors for serialized models; never invent defaults."""
    from .universal_economic_edge_authority import build_edge_model, build_edge_evidence
    from .adaptive_universal_sizing_authority import build_sizing_model, build_sizing_decision
    out = dict(item)
    builders = (("edge_model", build_edge_model, "model"),
                ("edge_evidence", build_edge_evidence, "evidence"),
                ("sizing_model", build_sizing_model, "model"),
                ("sizing_decision", build_sizing_decision, "decision"))
    try:
        for field, builder, key in builders:
            if isinstance(out.get(field), Mapping):
                out[field] = builder(out[field]).get(key)
    except (ValueError, TypeError, AttributeError, KeyError):
        # The existing caller emits a typed-input abstention for malformed input.
        out["edge_model"] = None
    return out
