import copy,datetime as dt,json,unittest
from decimal import Decimal as D
from universal_portfolio import learned_reallocation_sizing_a24 as m
from universal_portfolio.explicit_market_bindings_a24 import digest
from test_a24_commission_funding import row,variant

NOW=dt.datetime(2026,10,20,tzinfo=dt.timezone.utc)
SRC=('source','Feed','source-id','ABC');DST=('dest','Feed','dest-id','ABC')
def fixture(algorithm='Model',actuals=None,predictions=None):
 r=row();r.update(alternative_id='alternative',source_research_instrument_id='source',destination_research_instrument_id='dest')
 r['source_instrument_id']='origin';r['destination_instrument_id']='destination';r['commission_funding']={'currency_quantum':'.01'}
 for l in r['documented_tariff_provisions']['legs']:l['reference_variants']=[variant('0')]
 e={'algorithm':algorithm,'cohort_digest':'cohort','horizon_unit':'OBSERVATIONS','horizon_value':30,'authority':'RESEARCH_ONLY','folds':[],'forecasts':[],**{k:False for k in ('execution_authorized','comparison_authorized','model_validation_proven','canonical_publication_authorized')}}
 for i in range(12):
  origin=dt.date(2024,1,1)+dt.timedelta(days=40*i);target=origin+dt.timedelta(days=30)
  for ident,value in [(SRC,'0'),(DST,str((actuals or [50,-30]*6)[i]))]:
   pred='0' if ident==SRC else str((predictions or [20]*12)[i])
   e['folds'].append({**dict(zip(m.KEY,ident)),'origin':origin.isoformat(),'target':target.isoformat(),'last_training_label_end':(origin-dt.timedelta(days=1)).isoformat(),'actual_pct':value,'prediction_pct':pred})
 for ident,value in [(SRC,'0'),(DST,'10')]:e['forecasts'].append({**dict(zip(m.KEY,ident)),'origin':'2026-10-19','last_training_label_end':'2026-09-01','value_pct':value})
 model={'algorithm':algorithm,'cohort_digest':'cohort','origin':'2026-10-19','source_provider':'Feed','source_provider_id':'source-id','destination_provider':'Feed','destination_provider_id':'dest-id','source_return_pct':'0','destination_return_pct':'10'}
 model['experiment_digest']=digest(e);r['models']=[model]
 return r,e

def attach(r,e):return m.attach({'rows':[r]},e if isinstance(e,list) else [e],now=NOW)['rows'][0]['brain_reallocation_sizing']
def rehash(r,e):r['models'][0]['experiment_digest']=digest(e)
class Sizing(unittest.TestCase):
 def test_fraction_learned_from_geometric_growth_not_full_position(self):
  r,e=fixture();out=attach(r,e);self.assertEqual(out['status'],'INDICATIVE_RESEARCH_SIZE_SELECTED');self.assertEqual(out['fraction_denominator'],2);self.assertEqual(D(out['suggested_source_sale_reference_amount']),50)
 def test_selected_buy_budget_contains_commission_once(self):
  r,e=fixture();out=attach(r,e);self.assertEqual(D(out['minimum_buy_debit_ceiling_provision']),50);self.assertIsNone(out['final_transfer_amount']);self.assertFalse(out['execution_authorized'])
 def test_no_legacy_models_or_history_modified(self):
  r,e=fixture();before=copy.deepcopy(e);attach(r,e);self.assertEqual(e,before)
 def test_holdout_outcomes_never_select_fraction(self):
  r,e=fixture();first=attach(copy.deepcopy(r),e)
  for f in e['folds']:
   if f['instrument_id']=='dest' and f['origin']>='2024-08-28':f['actual_pct']='-80'
  rehash(r,e);out=attach(r,e);self.assertEqual(out['fraction_denominator'],first['fraction_denominator']);self.assertEqual(out['algorithm'],first['algorithm']);self.assertEqual(out['status'],'ABSTAIN_FROZEN_POLICY_NOT_SUPPORTED_HELD_OUT')
 def test_negative_training_outcomes_choose_keep(self):
  r,e=fixture(actuals=[-20]*12);out=attach(r,e);self.assertEqual(out['action'],'KEEP');self.assertEqual(out['suggested_source_sale_reference_amount'],'0')
 def test_no_current_advantage_after_commissions_keeps_position(self):
  r,e=fixture();e['forecasts'][1]['value_pct']='-10';r['models'][0]['destination_return_pct']='-10';rehash(r,e);out=attach(r,e);self.assertEqual(out['status'],'KEEP_CURRENT_FORECAST_AFTER_COMMISSIONS');self.assertEqual(out['action'],'KEEP')
 def test_predictions_gate_historical_decision_not_future_actuals(self):
  r,e=fixture(predictions=[-5]*12);out=attach(r,e);self.assertEqual(out['action'],'KEEP');self.assertEqual(out['training']['active_period_count'],0)
 def test_source_account_mismatch_abstains(self):
  r,e=fixture();r['documented_tariff_provisions']['legs'][0]['account_id']='other';out=attach(r,e);self.assertEqual(out['action'],'ABSTAIN');self.assertIn('SCOPE',out['reason'])
 def test_currency_mismatch_abstains(self):
  r,e=fixture();r['documented_tariff_provisions']['legs'][1]['currency']='OTHER';self.assertEqual(attach(r,e)['action'],'ABSTAIN')
 def test_digest_mismatch_refused(self):
  r,e=fixture();e['algorithm']='tampered';self.assertEqual(attach(r,e)['status'],'SIZING_EVIDENCE_UNAVAILABLE')
 def test_future_training_label_refused(self):
  r,e=fixture();e['folds'][0]['last_training_label_end']=e['folds'][0]['origin'];rehash(r,e);self.assertIn('PURGED',attach(r,e)['reason'])
 def test_stale_current_forecast_refused(self):
  r,e=fixture();e['forecasts'][0]['origin']='2026-10-01';rehash(r,e);self.assertIn('CURRENT',attach(r,e)['reason'])
 def test_duplicate_fold_refused(self):
  r,e=fixture();e['folds'].append(copy.deepcopy(e['folds'][0]));rehash(r,e);self.assertIn('DUPLICATE',attach(r,e)['reason'])
 def test_missing_pair_fold_not_dropped_silently(self):
  r,e=fixture();e['folds'].pop();rehash(r,e);self.assertIn('POPULATION',attach(r,e)['reason'])
 def test_insufficient_disjoint_history_has_explicit_abstention(self):
  r,e=fixture();e['folds']=e['folds'][:6];rehash(r,e);self.assertEqual(attach(r,e)['action'],'ABSTAIN')
 def test_unknown_fee_category_not_silently_removed(self):
  r,e=fixture();r['documented_tariff_provisions']['legs'][0]['reference_variants'].append({'label':'missing-band','conditional_category':True,'bands':[{'from':'1000','until':None,'rate_pct':'1'}]});self.assertIn('FINANCED',attach(r,e)['reason'])
 def test_cross_model_same_actual_population_required(self):
  r,e=fixture('A');r2,e2=fixture('B');e2['folds'][0]['actual_pct']='1';r2['models'][0]['experiment_digest']=digest(e2);r['models']+=r2['models'];self.assertIn('POPULATION',attach(r,[e,e2])['reason'])
 def test_at_most_one_destination_per_source_selected(self):
  r,e=fixture();other=copy.deepcopy(r);other.update(alternative_id='another',destination_instrument_id='another-financial')
  # Both have explicit financial scopes; research identities remain the verified model input.
  other['documented_tariff_provisions']['legs'][1]['instrument_id']='another-financial'
  result=m.attach({'rows':[r,other]},[e],now=NOW);states=[x['brain_reallocation_sizing'] for x in result['rows']]
  self.assertEqual(sum(x['selected_for_source_resource'] for x in states),1);self.assertTrue(any(x['status']=='ANOTHER_ALTERNATIVE_SELECTED_FOR_SOURCE' for x in states))
 def test_source_resources_are_independent(self):
  r,e=fixture();other=copy.deepcopy(r);other.update(alternative_id='other-account',account_id='other')
  for l in other['documented_tariff_provisions']['legs']:l['account_id']='other'
  out=m.attach({'rows':[r,other]},[e],now=NOW);self.assertEqual(sum(x['brain_reallocation_sizing']['selected_for_source_resource'] for x in out['rows']),2)
 def test_no_extra_capital_or_zero_target_sell(self):
  r,e=fixture();out=attach(r,e);self.assertFalse(out['capital_reserved']);self.assertFalse(out['portfolio_joint_optimization_performed']);self.assertLessEqual(D(out['suggested_source_sale_reference_amount']),D(r['reference_capital']))
 def test_fraction_universe_is_data_driven(self):
  r,e=fixture();e['forecasts'].append({**dict(zip(m.KEY,('third','Feed','third-id','ABC'))),'origin':'2026-10-19','last_training_label_end':'2026-09-01','value_pct':'2'});rehash(r,e);out=attach(r,e);self.assertEqual(out['universe_count'],3)
 def test_keep_benchmark_total_loss_not_ignored(self):
  r,e=fixture();e['folds'][0]['actual_pct']='-100';rehash(r,e);self.assertIn('BENCHMARK',attach(r,e)['reason'])
 def test_no_financial_or_canonical_authority(self):
  r,e=fixture();out=attach(r,e)
  for key in ('execution_authorized','canonical_publication_authorized','financial_mutation','history_write_performed','model_fit_performed','existing_models_modified','net_performance_validated'):self.assertFalse(out[key],key)
 def test_protocol_is_time_ordered_and_disjoint(self):
  r,e=fixture();out=attach(r,e);self.assertLess(out['training_intervals'][-1][1],out['held_out_intervals'][0][0]);self.assertFalse(out['held_out_used_for_selection'])
 def test_source_commission_scenarios_conserve_cash(self):
  r,e=fixture();out=attach(r,e)
  for c in out['commission_scenarios']:self.assertEqual(sum(D(c[k]) for k in ['sell_commission','destination_reference_amount','buy_commission','cash_remainder']),D(c['source_sale_reference_amount']))
 def test_invalid_long_only_predictions_keep_sample_but_do_not_trade(self):
  r,e=fixture(predictions=[-200]*12);out=attach(r,e);self.assertEqual(out['action'],'KEEP');self.assertEqual(out['training']['period_count'],6);self.assertEqual(out['training']['active_period_count'],0)
 def test_inputs_digest_changes_with_fee_context(self):
  r,e=fixture();one=attach(copy.deepcopy(r),e)['selection_inputs_digest'];r['documented_tariff_provisions']['legs'][0]['reference_variants'][0]['label']='review changed';two=attach(r,e)['selection_inputs_digest'];self.assertNotEqual(one,two)
 def test_retrospective_optimization_is_not_certified_policy(self):
  r,e=fixture();out=attach(r,e);self.assertFalse(out['archive_point_in_time_verified']);self.assertFalse(out['historical_fees_reconstructed']);self.assertTrue(out['current_commissions_applied_counterfactually']);self.assertFalse(out['net_performance_validated'])
 def test_better_training_model_selected_without_current_forecast_chasing(self):
  r,e=fixture('A');other,e2=fixture('B',predictions=[-1]*12);e2['forecasts'][1]['value_pct']='1000';other['models'][0]['destination_return_pct']='1000';rehash(other,e2);r['models']+=other['models'];self.assertEqual(attach(r,[e,e2])['algorithm'],'A')
 def destination_fixture(self,held_loss=False):
  r,e=fixture();other=copy.deepcopy(r);other.update(alternative_id='to-third',destination_instrument_id='third-financial',destination_research_instrument_id='third')
  other['documented_tariff_provisions']['legs'][1]['instrument_id']='third-financial';other['models'][0]['destination_provider_id']='third-id';other['models'][0]['destination_return_pct']='5'
  e['forecasts'].append({**dict(zip(m.KEY,('third','Feed','third-id','ABC'))),'origin':'2026-10-19','last_training_label_end':'2026-09-01','value_pct':'5'})
  extra=[]
  for f in e['folds']:
   if f['instrument_id']=='source':extra.append({**f,'instrument_id':'third','provider_id':'third-id','prediction_pct':'10','actual_pct':'-20' if held_loss and f['origin']>='2024-08-28' else '5'})
  e['folds']+=extra;rehash(r,e);rehash(other,e);return r,other,e
 def test_destination_selection_uses_common_source_benchmark(self):
  r,other,e=self.destination_fixture();out=m.attach({'rows':[r,other]},[e],now=NOW);chosen=[x for x in out['rows'] if x['brain_reallocation_sizing']['selected_for_source_resource']];self.assertEqual(len(chosen),1);self.assertEqual(chosen[0]['alternative_id'],'to-third');self.assertEqual(chosen[0]['brain_reallocation_sizing']['action'],'REALLOCATE_INDICATIVE')
 def test_holdout_veto_does_not_select_another_destination(self):
  r,other,e=self.destination_fixture(True);out=m.attach({'rows':[r,other]},[e],now=NOW);self.assertEqual(other['brain_reallocation_sizing']['status'],'ABSTAIN_FROZEN_POLICY_NOT_SUPPORTED_HELD_OUT');self.assertEqual(r['brain_reallocation_sizing']['status'],'ANOTHER_ALTERNATIVE_SELECTED_FOR_SOURCE')
 def test_same_source_destination_refused(self):
  r,e=fixture();r['destination_instrument_id']=r['source_instrument_id'];self.assertIn('DISTINCT',attach(r,e)['reason'])
 def test_duplicate_current_model_refused(self):
  r,e=fixture();r['models']*=2;self.assertIn('UNIQUE_CURRENT',attach(r,e)['reason'])
 def test_money_and_fraction_not_exported_in_diagnostic(self):
  from tools.reallocation_source_audit_v43 import project
  r,e=fixture();attach(r,e);r['brain_reallocation_sizing']['private']='PRIVATE_SECRET';out=project({'reallocation_analysis':{'rows':[r]}},{});s=json.dumps(out);self.assertNotIn('PRIVATE_SECRET',s);self.assertNotIn('suggested_source_sale_reference_amount',s);self.assertNotIn('fraction_denominator',s);self.assertEqual(out['pairs'][0]['brain_reallocation_sizing_status_counts'],{'INDICATIVE_RESEARCH_SIZE_SELECTED':1})
 def test_failing_optional_selector_preserves_existing_readings(self):
  from unittest.mock import patch
  import test_a24_global_existing_lab as fixture_lab
  import test_a24_economic_action_plan as plan_fixture
  from universal_portfolio import reallocation_analysis_a24 as analysis,global_history_source_a24 as storage
  f=fixture_lab.Reuse();f.setUp();self.addCleanup(f.doCleanups);job,body=f.result();storage.store_once(job['path'],body)
  before={str(p):p.read_bytes() for p in f.root.rglob('*') if p.is_file()}
  def broken(projection,*args,**kwargs):
   projection['rows'][0]['brain_reallocation_sizing']={'action':'REALLOCATE_INDICATIVE','amount':'PRIVATE_PARTIAL_DECISION'}
   raise RuntimeError('new selector unavailable')
  with patch.object(m,'attach',side_effect=broken):out=analysis.build(f.root,f.demand,plan_fixture.Plan().project(),now=fixture_lab.NOW)
  self.assertEqual(out['status'],'REALLOCATION_COMPARISONS_INSPECTED');self.assertEqual(out['brain_reallocation_sizing_status'],'SIZING_UNAVAILABLE_PRIOR_READINGS_PRESERVED');self.assertNotIn('PRIVATE_PARTIAL_DECISION',json.dumps(out));self.assertEqual(before,{str(p):p.read_bytes() for p in f.root.rglob('*') if p.is_file()})
 def test_impossible_current_return_is_not_a_trade_signal(self):
  r,e=fixture();e['forecasts'][0]['value_pct']='-200';r['models'][0]['source_return_pct']='-200';rehash(r,e);self.assertEqual(attach(r,e)['action'],'ABSTAIN')
 def test_missing_position_reference_is_explicit_abstention(self):
  r,e=fixture();r['reference_capital']=None;out=attach(r,e);self.assertEqual(out['action'],'ABSTAIN');self.assertEqual(out['reason'],'CURRENT_POSITION_REFERENCE_REQUIRED');self.assertIsNone(out['suggested_source_sale_reference_amount'])
 def test_missing_forecasts_is_not_keep_or_zero_sell(self):
  r,e=fixture();r['models']=[];out=attach(r,e);self.assertEqual(out['action'],'ABSTAIN');self.assertEqual(out['reason'],'CURRENT_PAIRED_FORECASTS_REQUIRED');self.assertIsNone(out['suggested_source_sale_reference_amount'])
if __name__=='__main__':unittest.main()
