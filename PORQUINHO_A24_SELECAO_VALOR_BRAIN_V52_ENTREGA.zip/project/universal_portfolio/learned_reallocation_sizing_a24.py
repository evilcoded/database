"""Read-only, position-specific indicative sizing from existing purged experiments.
Select model, destination and fraction on training only; evaluate that frozen choice
on later disjoint intervals. Objective: geometric wealth relative to KEEP. Current
commission schedules are a constant-capital counterfactual, never historical fees.
No cash-policy weights become portfolio targets. No broker/order authority.
"""
import datetime as dt
import math
from collections import Counter,defaultdict
from decimal import Decimal,localcontext,ROUND_FLOOR
from .account_cost_evidence_a24 import number,CostError
from .commission_funding_a24 import commission,financed_buy,return_number
from .explicit_market_bindings_a24 import digest

SCHEMA='porquinho.learned-reallocation-sizing-a24/1.0'
METHOD='POSITION_RELATIVE_LOG_WEALTH_TOPK_FRACTIONS_TRAIN_ONLY_V1'
KEY=('instrument_id','provider','provider_id','quote_currency')

class SizingError(ValueError):pass

def base(status,**values):
    return {'schema':SCHEMA,'method':METHOD,'status':status,'action':'ABSTAIN',
            'selected_for_source_resource':False,'suggested_source_sale_reference_amount':None,
            'minimum_buy_debit_ceiling_provision':None,'maximum_buy_debit_ceiling_provision':None,
            'final_transfer_amount':None,'execution_authorized':False,'canonical_publication_authorized':False,
            'financial_mutation':False,'history_write_performed':False,'model_fit_performed':False,
            'existing_models_modified':False,'policy_parameter_selection_performed':False,
            'historical_fees_reconstructed':False,'archive_point_in_time_verified':False,
            'net_performance_validated':False,'portfolio_joint_optimization_performed':False,
            'same_source_cases_mutually_exclusive':True,'capital_reserved':False,
            'manual_risk_coefficient_required':False,'bank_quote_required':True,
            'cost_basis':'CURRENT_DOCUMENTED_COMMISSIONS_ONLY_CONSTANT_REFERENCE_CAPITAL',**values}

def day(value):return dt.date.fromisoformat(value)
def identity(value):
    key=tuple(value[k] for k in KEY)
    if not all(isinstance(k,str) and k and k.strip()==k for k in key):raise SizingError('EXACT_SOURCE_IDENTITY_REQUIRED')
    return key

def disjoint(keys):
    result=[];last=None
    for key in sorted(keys):
        if last is None or day(key[0])>last:result.append(key);last=day(key[1])
    return result

def paired(exp,source,destination,*,now):
    if exp.get('authority')!='RESEARCH_ONLY' or any(exp.get(k) is not False for k in ('execution_authorized','comparison_authorized','model_validation_proven','canonical_publication_authorized')):raise SizingError('SEALED_RESEARCH_EXPERIMENT_REQUIRED')
    if (exp.get('horizon_unit'),exp.get('horizon_value'))!=('OBSERVATIONS',30):raise SizingError('MATCHED_HORIZON_REQUIRED')
    rows=exp.get('folds',[])
    if len(rows)>1000:raise SizingError('BOUNDED_EVALUATION_FOLDS_REQUIRED')
    sides={source:{},destination:{}}
    for f in rows:
        key=identity(f)
        if key not in sides:continue
        origin,target=f['origin'],f['target']
        if not day(f['last_training_label_end'])<day(origin)<day(target)<now.date():raise SizingError('MATURED_PURGED_FOLD_REQUIRED')
        interval=origin,target
        if interval in sides[key]:raise SizingError('DUPLICATE_FOLD_REFUSED')
        actual=return_number(f['actual_pct']);predicted=return_number(f['prediction_pct'])
        if actual < -100:raise SizingError('LONG_ONLY_RETURN_REQUIRED')
        sides[key][interval]=(actual,predicted)
    if not sides[source] or set(sides[source])!=set(sides[destination]):raise SizingError('COMPLETE_MATCHED_PAIR_POPULATION_REQUIRED')
    return {k:(*sides[source][k],*sides[destination][k]) for k in sides[source]}

def trades(row,k,quantum):
    cap=number(row['reference_capital'],True)
    sold=(cap/Decimal(k)/quantum).to_integral_value(rounding=ROUND_FLOOR)*quantum
    if sold<=0:return []
    legs=row.get('documented_tariff_provisions',{}).get('legs',[])
    sell=[l for l in legs if l.get('side')=='SELL'];buy=[l for l in legs if l.get('side')=='BUY']
    if len(sell)!=1 or len(buy)!=1:return []
    sell,buy=sell[0],buy[0]
    for leg,iid in [(sell,row['source_instrument_id']),(buy,row['destination_instrument_id'])]:
        if leg.get('account_id')!=row['account_id'] or leg.get('currency')!=row['currency'] or leg.get('instrument_id')!=iid:raise SizingError('EXACT_ACCOUNT_CURRENCY_FINANCIAL_SCOPE_REQUIRED')
    sv,bv=sell.get('reference_variants',[]),buy.get('reference_variants',[])
    if len(sv)>16 or len(bv)>16 or len(sv)*len(bv)>128:raise SizingError('BOUNDED_COMMISSION_BRANCHES_REQUIRED')
    out=[]
    for s in sv:
        fee=commission(s,sold)
        # Missing one documented category cannot silently turn into a cheaper policy.
        if fee is None or fee>=sold:return []
        available=sold-fee;ceiling=(available/quantum).to_integral_value(rounding=ROUND_FLOOR)*quantum
        for b in bv:
            solved=financed_buy(ceiling,b,quantum) if ceiling>0 else None
            if solved is None:return []
            principal,buyfee=solved;cash=available-principal-buyfee
            if cash<0 or sold!=fee+principal+buyfee+cash:raise SizingError('FINANCED_SIZE_CONSERVATION_REQUIRED')
            out.append({'source_sale_reference_amount':str(sold),'sell_commission':str(fee),
                        'destination_reference_amount':str(principal),'buy_commission':str(buyfee),
                        'cash_remainder':str(cash),'buy_debit_ceiling_provision':str(ceiling),
                        'sale_net_proceeds_provision':str(available),'buy_total_debit_provision':str(principal+buyfee),
                        'remaining_source_reference_capital':str(cap-sold),
                        'sell_category':s['label'],'buy_category':b['label'],
                        'conditional_category':s['conditional_category'] or b['conditional_category']})
    return out

def excess(trade,rs,rd):
    sold=number(trade['source_sale_reference_amount']);principal=number(trade['destination_reference_amount']);cash=number(trade['cash_remainder'])
    return principal*(1+rd/100)+cash-sold*(1+rs/100)

def score(data,keys,cases,cap):
    values=[];turnover=Decimal(0);active_count=0
    for key in keys:
        rs,ps,rd,pd=data[key]
        keep=cap*(1+rs/100)
        if keep<=0:raise SizingError('POSITIVE_KEEP_BENCHMARK_REQUIRED')
        # The decision at an origin uses that origin's purged predictions only.
        active=bool(cases) and min(ps,pd)>=-100 and min(excess(t,ps,pd) for t in cases)>0
        delta=min(excess(t,rs,rd) for t in cases) if active else Decimal(0)
        wealth=keep+delta
        if wealth<=0:return {'feasible':False,'geometric_excess_log_mean':None,'period_count':len(keys),'active_period_count':active_count,'turnover_reference_amount':str(turnover)}
        value=math.log(float(wealth/keep))
        if not math.isfinite(value):raise SizingError('FINITE_LOG_WEALTH_REQUIRED')
        values.append(value)
        if active:
            turnover+=number(cases[0]['source_sale_reference_amount']);active_count+=1
    return {'feasible':True,'geometric_excess_log_mean':math.fsum(values)/len(values),
            'geometric_excess_relative_to_keep_pct':math.expm1(math.fsum(values)/len(values))*100,
            'period_count':len(values),'active_period_count':active_count,
            'turnover_reference_amount':str(turnover)}

def candidates(row,experiments,*,now):
    with localcontext() as ctx:
        ctx.prec=100
        cap=number(row['reference_capital'],True)
        quantum=number(row.get('commission_funding',{}).get('currency_quantum'),True)
        if row['source_instrument_id']==row['destination_instrument_id'] or row['source_research_instrument_id']==row['destination_research_instrument_id']:raise SizingError('DISTINCT_SOURCE_AND_DESTINATION_REQUIRED')
        model_rows=row.get('models',[])
        if not model_rows or len(model_rows)>10:raise SizingError('BOUNDED_CURRENT_MODELS_REQUIRED')
        indexes={}
        for e in experiments:
            key=e['algorithm'],e['cohort_digest']
            if key in indexes:raise SizingError('UNIQUE_EXPERIMENT_REQUIRED')
            indexes[key]=e
        prepared=[];population=None;universe=None;seen_models=set()
        for m in model_rows:
            model_key=m['algorithm'],m['cohort_digest']
            if model_key in seen_models:raise SizingError('UNIQUE_CURRENT_MODEL_REQUIRED')
            seen_models.add(model_key)
            exp=indexes[(m['algorithm'],m['cohort_digest'])]
            if digest(exp)!=m['experiment_digest']:raise SizingError('EXACT_EXPERIMENT_DIGEST_REQUIRED')
            src=(row['source_research_instrument_id'],m['source_provider'],m['source_provider_id'],row['currency'])
            dst=(row['destination_research_instrument_id'],m['destination_provider'],m['destination_provider_id'],row['currency'])
            fs=exp.get('forecasts',[])
            keys=[identity(f) for f in fs]
            if len(keys)>100 or len(keys)!=len(set(keys)) or any(k[-1]!=row['currency'] for k in keys):raise SizingError('ONE_CURRENCY_FORECAST_UNIVERSE_REQUIRED')
            current={identity(f):f for f in fs}
            if src not in current or dst not in current:raise SizingError('EXACT_CURRENT_PAIR_REQUIRED')
            for key,field in ((src,'source_return_pct'),(dst,'destination_return_pct')):
                f=current[key]
                if f['origin']!=m['origin'] or not day(f['last_training_label_end'])<day(f['origin'])<=now.date() or not 0<=(now.date()-day(f['origin'])).days<=3:raise SizingError('CURRENT_PURGED_FORECAST_REQUIRED')
                if return_number(f['value_pct'])!=return_number(m[field]):raise SizingError('CURRENT_MODEL_VALUES_MISMATCH')
                if return_number(f['value_pct']) < -100:raise SizingError('VALID_LONG_ONLY_CURRENT_FORECAST_REQUIRED')
            if universe is not None and set(keys)!=universe:raise SizingError('MATCHED_FORECAST_UNIVERSE_REQUIRED')
            universe=set(keys)
            data=paired(exp,src,dst,now=now)
            actual={k:(v[0],v[2]) for k,v in data.items()}
            if population is not None and actual!=population:raise SizingError('MATCHED_REALIZED_POPULATION_REQUIRED')
            population=actual;prepared.append((m,data))
        intervals=sorted(population)
        if len(intervals)<4:raise SizingError('INSUFFICIENT_POLICY_PERIODS')
        boundary=intervals[len(intervals)//2][0]
        training=disjoint([k for k in intervals if day(k[1])<day(boundary)])
        held=disjoint([k for k in intervals if day(k[0])>=day(boundary)])
        if min(len(training),len(held))<2:raise SizingError('INSUFFICIENT_DISJOINT_POLICY_PERIODS')
        cache={k:trades(row,k,quantum) for k in range(1,len(universe)+1)}
        if not any(cache.values()):raise SizingError('DOCUMENTED_FINANCED_FRACTION_REQUIRED')
        out=[]
        for m,data in prepared:
            for k,cases in cache.items():
                if not cases:continue
                metric=score(data,training,cases,cap)
                if not metric['feasible']:continue
                out.append({'algorithm':m['algorithm'],'cohort_digest':m['cohort_digest'],'experiment_digest':m['experiment_digest'],
                            'fraction_numerator':1,'fraction_denominator':k,'cases':cases,
                            'training':metric,'_data':data,'_held':held,'_model':m,'_cap':cap})
        protocol={'training_intervals':[list(k) for k in training],'held_out_intervals':[list(k) for k in held],
                  'protocol_digest':digest({'intervals':sorted(population),'source_actual':{str(k):str(population[k][0]) for k in sorted(population)},'reference_capital':str(cap),'training':training,'held':held}),
                  'candidate_family':'KEEP_OR_1_OVER_K_WITH_K_FROM_CURRENT_UNIVERSE',
                  'universe_count':len(universe),'selection_objective':'MAX_TRAINING_GEOMETRIC_WEALTH_RELATIVE_TO_KEEP',
                  'held_out_used_for_selection':False,'repeated_searches_are_independent_evidence':False,'current_commissions_applied_counterfactually':True,
                  'selection_inputs_digest':digest({'models':model_rows,'account_id':row['account_id'],'currency':row['currency'],'source':row['source_instrument_id'],'destination':row['destination_instrument_id'],'reference_capital':str(cap),'tariff_context':row.get('documented_tariff_provisions'),'currency_quantum':str(quantum)})}
        return out,protocol

def attach(result,experiments,*,now):
    groups=defaultdict(list);rows=result.get('rows',[])
    for row in rows:
        key=row['account_id'],row['currency'],row['source_instrument_id']
        try:
            if row.get('reference_capital') is None or not row.get('models'):
                row['brain_reallocation_sizing']=base('SIZING_EVIDENCE_UNAVAILABLE',reason='CURRENT_POSITION_REFERENCE_REQUIRED' if row.get('reference_capital') is None else 'CURRENT_PAIRED_FORECASTS_REQUIRED')
                continue
            cs,protocol=candidates(row,experiments,now=now)
            for c in cs:groups[key].append((row,c,protocol))
            row['brain_reallocation_sizing']=base('AWAITING_SOURCE_RESOURCE_SELECTION',policy_parameter_selection_performed=True,**protocol)
        except Exception as exc:
            row['brain_reallocation_sizing']=base('SIZING_EVIDENCE_UNAVAILABLE',reason=str(exc) if isinstance(exc,(SizingError,CostError)) else type(exc).__name__)
    for key,options in groups.items():
        # Select one mutually exclusive destination/model/fraction per source resource.
        # Outcomes on the held-out intervals never break a training tie.
        try:
            if len({p['protocol_digest'] for _,_,p in options})!=1:raise SizingError('COMMON_DESTINATION_EVALUATION_POPULATION_REQUIRED')
            selected=min(options,key=lambda item:(-item[1]['training']['geometric_excess_log_mean'],number(item[1]['training']['turnover_reference_amount']),-item[1]['fraction_denominator'],item[1]['algorithm'],item[0]['destination_instrument_id']))
            chosen,c,protocol=selected
            for row,_,_ in options:
                row['brain_reallocation_sizing']=base('ANOTHER_ALTERNATIVE_SELECTED_FOR_SOURCE',selected_alternative_id=chosen['alternative_id'],policy_parameter_selection_performed=True,**protocol)
            common={**protocol,'algorithm':c['algorithm'],'cohort_digest':c['cohort_digest'],'experiment_digest':c['experiment_digest'],
                    'fraction_numerator':1,'fraction_denominator':c['fraction_denominator'],'training':c['training'],
                    'selected_for_source_resource':True,'policy_parameter_selection_performed':True,
                    'selected_alternative_id':chosen['alternative_id']}
            if c['training']['geometric_excess_log_mean']<=0:
                chosen['brain_reallocation_sizing']=base('KEEP_NOT_OUTPERFORMED_IN_TRAINING',action='KEEP',suggested_source_sale_reference_amount='0',**common);continue
            with localcontext() as ctx:
                ctx.prec=100
                held=score(c['_data'],c['_held'],c['cases'],c['_cap'])
                if not held['feasible'] or held['geometric_excess_log_mean']<=0:
                    chosen['brain_reallocation_sizing']=base('ABSTAIN_FROZEN_POLICY_NOT_SUPPORTED_HELD_OUT',held_out=held,**common);continue
                m=c['_model'];ps,pd=return_number(m['source_return_pct']),return_number(m['destination_return_pct'])
                if min(excess(t,ps,pd) for t in c['cases'])<=0:
                    chosen['brain_reallocation_sizing']=base('KEEP_CURRENT_FORECAST_AFTER_COMMISSIONS',action='KEEP',held_out=held,suggested_source_sale_reference_amount='0',**common);continue
                caps=[number(t['buy_debit_ceiling_provision']) for t in c['cases']]
                chosen['brain_reallocation_sizing']=base('INDICATIVE_RESEARCH_SIZE_SELECTED',action='REALLOCATE_INDICATIVE',held_out=held,
                    suggested_source_sale_reference_amount=c['cases'][0]['source_sale_reference_amount'],
                    minimum_buy_debit_ceiling_provision=str(min(caps)),maximum_buy_debit_ceiling_provision=str(max(caps)),
                    commission_scenarios=c['cases'],**common)
        except Exception as exc:
            for row,_,_ in options:row['brain_reallocation_sizing']=base('SOURCE_RESOURCE_SELECTION_UNAVAILABLE',reason=str(exc) if isinstance(exc,(SizingError,CostError)) else type(exc).__name__)
    result['brain_reallocation_sizing_status_counts']=dict(Counter(r.get('brain_reallocation_sizing',{}).get('status','PAIR_EVIDENCE_REQUIRED') for r in rows))
    result['brain_reallocation_sizing_method']=METHOD
    result['brain_reallocation_sizing_final_amount_published']=False
    return result
