"""Regression for recovered account projection omitting institution name."""
import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from decimal import Decimal
from universal_portfolio.account_cost_evidence_a24 import accounts,CostError
from universal_portfolio import research_tariff_context_a24 as tariffs

class InstitutionProjection(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.path=self.root/'data/institution_accounts.json';self.path.parent.mkdir()
  self.registry={'schema':'porquinho.institution-account-registry/1.0','institutions':[{'institution_id':'bank','name':'Example Institution','country':'ZZ'}],'accounts':[{'account_id':'account','institution_id':'bank','currency':'ABC','pricing_plan':'Example Plan'}]}
  self.write()
  source=json.loads((Path(__file__).resolve().parents[1]/tariffs.CATALOG).read_text())['policies'][0]
  self.policy=copy.deepcopy(source);self.policy['scope'].update(institution_name='Example Institution',registry_country='ZZ',source_jurisdiction='ZZ',currency='ABC',pricing_plan='Example Plan')
  self.policy['variants']=self.policy['variants'][:1];self.policy['variants'][0].update(provider='Demo',provider_ids=['one'])
  self.now=tariffs.timestamp(self.policy['source']['observed_at'])+dt.timedelta(seconds=1)
 def write(self):self.path.write_text(json.dumps(self.registry))
 def leg(self):
  registered,_=accounts(self.root)
  return tariffs.leg([self.policy],registered['account'],'financial-one','ABC','CRYPTO',{('Demo','one')},Decimal('100'),'BUY',now=self.now)
 def test_registered_institution_metadata_enables_exact_tariff(self):
  row=accounts(self.root)[0]['account'];self.assertEqual(row['_institution_name'],'Example Institution');self.assertEqual(row['_institution_country'],'ZZ');result=self.leg();self.assertTrue(result['estimates']);self.assertIsNone(result['total_cost']);self.assertFalse(result['execution_quote'])
 def test_no_bank_or_currency_branch_required(self):
  self.registry['institutions'][0].update(name='Second Institution',country='XY');self.registry['accounts'][0].update(currency='QRS',pricing_plan='Second Plan');self.write()
  self.policy['scope'].update(institution_name='Second Institution',registry_country='XY',source_jurisdiction='XY',currency='QRS',pricing_plan='Second Plan')
  row=accounts(self.root)[0]['account'];result=tariffs.leg([self.policy],row,'another-id','QRS','CRYPTO',{('Demo','one')},Decimal('42'),'SELL',now=self.now);self.assertTrue(result['estimates'])
 def test_missing_plan_never_defaults(self):
  del self.registry['accounts'][0]['pricing_plan'];self.write();self.assertFalse(self.leg()['estimates'])
 def test_changed_institution_cannot_reuse_previous_policy(self):
  self.registry['institutions'][0]['name']='Different Institution';self.write();self.assertFalse(self.leg()['estimates'])
 def test_duplicate_institution_refused(self):
  self.registry['institutions']*=2;self.write()
  with self.assertRaises(CostError):accounts(self.root)
 def test_registry_and_learning_not_modified(self):
  p=self.root/'data/model.bin';p.write_bytes(b'preserved');before=self.path.read_bytes();self.leg();self.assertEqual(self.path.read_bytes(),before);self.assertEqual(p.read_bytes(),b'preserved')
