"""Export identifiers and lineage only, never financial values or inferred bindings."""
import csv,hashlib,json,math,os,sys
from pathlib import Path
from datetime import date

MAX_JSON=32*1024*1024

def text(v):return isinstance(v,str) and bool(v) and len(v)<=512 and v==v.strip()
def scalar(v):return v if text(v) else None

def inspect(root):
 root=Path(root).resolve(strict=True);tracked={}
 def local(rel):
  p=root/rel
  if p.is_symlink() or any(a.is_symlink() for a in p.parents if a!=root.parent):raise ValueError('SOURCE_SYMLINK_REFUSED')
  if not p.resolve().is_relative_to(root):raise ValueError('SOURCE_OUTSIDE_PROJECT')
  return p
 def sig(p):
  if not p.exists():return None
  s=p.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
 def read(rel):
  p=local(rel);tracked[p]=sig(p)
  if tracked[p] is None:return None
  if tracked[p][2]>MAX_JSON:raise ValueError('JSON_SIZE_LIMIT')
  return json.loads(p.read_text(encoding='utf-8'))
 lab=read('results/prediction_lab.json')
 if not isinstance(lab,dict):raise ValueError('PREDICTION_LAB_MISSING_OR_INVALID')
 fields=('asset','instrument_id','provider','provider_id','quote_currency','price_unit_status')
 cases={};group_counts={};invalid=0
 for group in ('predictions','ensemble_predictions'):
  rows=lab.get(group) or []
  if not isinstance(rows,list) or len(rows)>10000:raise ValueError('PREDICTION_ROWS_INVALID')
  group_counts[group]=len(rows)
  for row in rows:
   if not isinstance(row,dict) or not text(row.get('asset')):invalid+=1;continue
   selected={k:scalar(row.get(k)) for k in fields};key=tuple(selected[k] for k in fields)
   if key not in cases:cases[key]={**selected,'groups':[],'observation_dates':[]}
   item=cases[key];item['groups'].append(group) if group not in item['groups'] else None
   try:d=date.fromisoformat(row.get('date','')).isoformat()
   except (ValueError,TypeError):d=None
   if d and d not in item['observation_dates']:item['observation_dates'].append(d)
 out={'validation':'A24_BRAIN_UNIVERSE_REVIEW_READ_ONLY','status':'COLLECTED_IDENTIFIERS_NOT_VALIDATED',
      'prediction_group_counts':group_counts,'unique_prediction_context_count':len(cases),
      'invalid_prediction_row_count':invalid,'trained_at':scalar(lab.get('trained_at')),
      'cases':list(cases.values()),'catalog_identity_references':[],
      'identity_binding_created':False,'financial_values_exported':False,'canonical_publication_authorized':False}
 latest=read('results/latest.json')
 score_rows=latest.get('scores',[]) if isinstance(latest,dict) else []
 if not isinstance(score_rows,list) or len(score_rows)>10000:raise ValueError('SCORE_ROWS_INVALID')
 out['latest_score_observations']=[{k:scalar(row.get(k)) for k in ('asset','instrument_id','provider','provider_id','quote_currency')} for row in score_rows if isinstance(row,dict) and text(row.get('asset'))]
 out['scope']='PERSISTED_LAB_PREDICTIONS_AND_LATEST_SCORES; NOT_ALL_IN_MEMORY_SHADOW_CANDIDATES'
 labels={v['asset'] for v in cases.values()}
 histories={};bound={};market=local('data/database/market_daily.csv');tracked[market]=sig(market)
 if tracked[market] is not None:
  if tracked[market][2]>512*1024*1024:raise ValueError('MARKET_SIZE_LIMIT')
  with market.open(newline='',encoding='utf-8') as f:
   for n,row in enumerate(csv.DictReader(f),1):
    if n>2000000:raise ValueError('MARKET_ROW_LIMIT')
    label=scalar(row.get('asset'))
    if label not in labels:continue
    h=histories.setdefault(label,{'rows':0,'rows_with_explicit_identity_origin':0,'first_date':None,'latest_date':None})
    h['rows']+=1
    complete=all(text(row.get(k)) for k in ('instrument_id','provider','provider_id','quote_currency'))
    if complete:h['rows_with_explicit_identity_origin']+=1
    try:day=date.fromisoformat(row.get('date','')).isoformat()
    except (TypeError,ValueError):continue
    h['first_date']=min(h['first_date'],day) if h['first_date'] else day
    h['latest_date']=max(h['latest_date'],day) if h['latest_date'] else day
    if complete:
     key=(row['instrument_id'],row['provider'].lower(),row['provider_id'],row['quote_currency'],day)
     bound[key]=bound.get(key,0)+1
 references={}
 for rel in ('data/universal_instrument_catalog.json','data/instruments/manual_instruments.json'):
  obj=read(rel)
  if obj is None:continue
  if not isinstance(obj,dict) or not isinstance(obj.get('instruments',[]),list):raise ValueError('CATALOG_SCHEMA_INVALID')
  for row in obj.get('instruments',[]):
   if not isinstance(row,dict) or not text(row.get('instrument_id')):continue
   selected={k:scalar(row.get(k)) for k in ('instrument_id','symbol','asset_class','market','jurisdiction')}
   selected['source']=rel;references[(row['instrument_id'],rel)]=selected
 out['catalog_identity_references']=list(references.values())
 for item in out['cases']:
  item['history_by_exact_presentation_label']=histories.get(item['asset'])
  item['label_history_is_not_canonical_identity_proof']=True
  complete=all(text(item.get(k)) for k in ('instrument_id','provider','provider_id','quote_currency'))
  item['review_status']='EXPLICIT_METADATA_REQUIRES_REVIEW' if complete else 'MISSING_EXPLICIT_IDENTITY_OR_ORIGIN'
  item['exact_start_observation_counts']=({d:bound.get((item['instrument_id'],item['provider'].lower(),item['provider_id'],item['quote_currency'],d),0) for d in item['observation_dates']} if complete else None)
 changed=[str(p.relative_to(root)) for p,before in tracked.items() if sig(p)!=before]
 out['source_files_stable_during_read']=not changed
 if changed:
  out['status']='SOURCE_CHANGED_DURING_READ_RETRY_REQUIRED';out['cases']=[];out['catalog_identity_references']=[]
 return out


def canonical_held(root):
 """Guarded call to the application's actual verified runtime read model."""
 from decimal import Decimal
 from universal_portfolio.canonical_runtime_read_model import build
 value=build(root);ids=set();unavailable=0
 for position in value['positions']:
  quantity=position.quantity
  if quantity is None:unavailable+=1;continue
  q=Decimal(str(quantity))
  if not q.is_finite():unavailable+=1;continue
  if q==0:continue
  iid=position.instrument_id
  if text(iid):ids.add(iid)
  else:unavailable+=1
 return {'status':'VERIFIED_RUNTIME_READ_MODEL_IDENTITIES_ONLY','active_instrument_ids':sorted(ids),
         'unavailable_position_identity_or_quantity_count':unavailable,
         'financial_values_exported':False,'ownership_inferred_from_catalog':False}


def main(expected_read_model_hash):
 root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root));opened={}
 def signature(p):
  try:s=p.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
  except OSError:return None
 def guard(event,args):
  if event=='open':
   mode,flags=args[1:3]
   if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
   if isinstance(args[0],(str,bytes,os.PathLike)):
    p=Path(os.fsdecode(args[0]))
    if p.is_absolute() and (p.is_relative_to(root/'data') or p.is_relative_to(root/'results')):opened.setdefault(p,signature(p))
  if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
 sys.addaudithook(guard)
 try:
  out=inspect(root)
  readmodel=root/'universal_portfolio/canonical_runtime_read_model.py'
  if not readmodel.is_file():
   out['portfolio']={'status':'UNAVAILABLE_NO_LEGACY_FALLBACK','error':'ReadModelSourceMissing','active_instrument_ids':None}
  elif readmodel.is_symlink() or hashlib.sha256(readmodel.read_bytes()).hexdigest()!=expected_read_model_hash:
   out['portfolio']={'status':'READ_MODEL_SOURCE_HASH_MISMATCH','active_instrument_ids':None}
  else:
   try:out['portfolio']=canonical_held(root)
   except Exception as exc:out['portfolio']={'status':'UNAVAILABLE_NO_LEGACY_FALLBACK','error':type(exc).__name__,'active_instrument_ids':None}
  changed=any(signature(p)!=old for p,old in opened.items())
  if changed:
   out['portfolio']={'status':'SOURCE_CHANGED_DURING_READ_RETRY_REQUIRED','active_instrument_ids':None}
   out['source_files_stable_during_read']=False;out['status']='SOURCE_CHANGED_DURING_READ_RETRY_REQUIRED'
   out['cases']=[];out['catalog_identity_references']=[]
  known=out['portfolio'].get('active_instrument_ids')
  for item in out['cases']:
   item['portfolio_exact_identity_match']=(item['instrument_id'] in known if item['instrument_id'] and known is not None else None)
  out['portfolio_symbol_or_suffix_matching_performed']=False
 except Exception as exc:out={'validation':'A24_BRAIN_UNIVERSE_REVIEW_READ_ONLY','status':'FAILED_CLOSED','error':type(exc).__name__}
 print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':main('18a840442c8efe742b1fdfb2084491eb6425d800fb11a4b26fc33a7524bccdbd')
