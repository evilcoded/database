import importlib.util,json,csv,hashlib,os,subprocess,sys,tempfile,unittest,zipfile,types
from unittest.mock import patch
from pathlib import Path
spec=importlib.util.spec_from_file_location('collector',Path(__file__).parent/'PORQUINHO_A24_MAPEAR_UNIVERSO_BRAIN.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Mapping(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'project';self.root.mkdir()
 def put(self,rel,obj):
  p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj));return p
 def lab(self,rows,ensemble=None):return self.put('results/prediction_lab.json',{'predictions':rows,'ensemble_predictions':ensemble or [],'trained_at':'2026-10-15T12:00:00+00:00','cash':999999})
 def row(self,**extra):return dict({'asset':'SAME','date':'2026-10-15','prediction_30d_pct':777777},**extra)
 def test_deduplicates_shared_champion_and_ensemble_context(self):
  r=self.row();self.lab([r],[r]);out=m.inspect(self.root);self.assertEqual(out['unique_prediction_context_count'],1);self.assertEqual(out['cases'][0]['groups'],['predictions','ensemble_predictions'])
 def test_same_label_different_origins_stay_separate(self):
  self.lab([self.row(provider_id='A'),self.row(provider_id='B')]);self.assertEqual(m.inspect(self.root)['unique_prediction_context_count'],2)
 def test_no_numeric_prediction_or_cash_exported(self):
  self.lab([self.row()]);out=json.dumps(m.inspect(self.root));self.assertNotIn('777777',out);self.assertNotIn('999999',out);self.assertNotIn('prediction_30d_pct',out)
 def test_catalog_is_not_joined_by_symbol(self):
  self.lab([self.row()]);self.put('data/universal_instrument_catalog.json',{'instruments':[{'instrument_id':'GLOBAL:OTHER:SAME','symbol':'SAME'}]})
  out=m.inspect(self.root);self.assertIsNone(out['cases'][0]['instrument_id']);self.assertEqual(out['cases'][0]['review_status'],'MISSING_EXPLICIT_IDENTITY_OR_ORIGIN')
 def test_literal_ids_are_preserved(self):
  iid='A:B:C:D:E';self.lab([self.row(instrument_id=iid)]);self.assertEqual(m.inspect(self.root)['cases'][0]['instrument_id'],iid)
 def test_exact_source_date_duplicate_is_reported(self):
  fields={'instrument_id':'A:B:C:D','provider':'Provider','provider_id':'source','quote_currency':'USD'}
  self.lab([self.row(**fields)]);p=self.root/'data/database/market_daily.csv';p.parent.mkdir(parents=True)
  rows=[dict(fields,asset='SAME',date='2026-10-15',price=123456)]*2
  with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
  out=m.inspect(self.root);self.assertEqual(out['cases'][0]['exact_start_observation_counts'],{'2026-10-15':2});self.assertNotIn('123456',json.dumps(out))
 def test_missing_explicit_identity_not_reported_as_zero_exact_matches(self):
  self.lab([self.row()]);self.assertIsNone(m.inspect(self.root)['cases'][0]['exact_start_observation_counts'])
 def test_score_observations_are_distinct_from_predictions(self):
  self.lab([self.row()]);self.put('results/latest.json',{'scores':[{'asset':'OTHER','quantity':123456,'account_id':'SECRET'}]})
  out=m.inspect(self.root);self.assertEqual(out['latest_score_observations'][0]['asset'],'OTHER');self.assertEqual(len(out['cases']),1);self.assertNotIn('SECRET',json.dumps(out))
 def test_symlinks_rejected(self):
  p=self.root/'results/prediction_lab.json';p.parent.mkdir();p.symlink_to('/etc/passwd')
  with self.assertRaisesRegex(ValueError,'SYMLINK'):m.inspect(self.root)
 def test_project_bytes_unchanged(self):
  self.lab([self.row()]);before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};m.inspect(self.root);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_audit_guard_blocks_write(self):
  self.lab([self.row()]);source=(Path(__file__).parent/'PORQUINHO_A24_MAPEAR_UNIVERSO_BRAIN.py').read_text()+"\n(root if False else Path(sys.argv[1])).joinpath('blocked').write_text('bad')\n"
  r=subprocess.run([sys.executable,'-I','-B','-c',source,str(self.root)],capture_output=True,text=True);self.assertNotEqual(r.returncode,0);self.assertIn('READ_ONLY_WRITE_REFUSED',r.stderr);self.assertFalse((self.root/'blocked').exists())
 def test_wrapper_exports_only_review_zip_even_if_read_model_unavailable(self):
  self.lab([self.row()]);destination=Path(self.tmp.name)/'review';destination.mkdir()
  script=Path(__file__).parent/'PORQUINHO_A24_MAPEAR_UNIVERSO_BRAIN.command'
  before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  r=subprocess.run(['/bin/bash',str(script)],env=dict(os.environ,PORQUINHO_ROOT=str(self.root),PORQUINHO_REVIEW_DIR=str(destination)),capture_output=True,text=True,check=True)
  package=next(destination.glob('*.zip'))
  with zipfile.ZipFile(package) as z:
   report=json.loads(z.read('BRAIN_UNIVERSE_REVIEW.json'));manifest=json.loads(z.read('MANIFEST.json'))
   self.assertEqual(hashlib.sha256(z.read('BRAIN_UNIVERSE_REVIEW.json')).hexdigest(),manifest['report_sha256'])
   self.assertEqual(report['portfolio']['status'],'UNAVAILABLE_NO_LEGACY_FALLBACK');self.assertIsNone(report['cases'][0]['portfolio_exact_identity_match']);self.assertNotIn('777777',z.read('BRAIN_UNIVERSE_REVIEW.json').decode())
  self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()});self.assertIn('ZIP_PARA_COMPARTILHAR=',r.stdout)
 def test_runtime_projection_exports_ids_without_account_or_quantity(self):
  positions=[types.SimpleNamespace(instrument_id='A:B:C:D',quantity=123456,account_id='SECRET'),types.SimpleNamespace(instrument_id='A:B:C:D:E',quantity=-99,account_id='SECRET'),types.SimpleNamespace(instrument_id='ZERO',quantity=0)]
  fake=types.SimpleNamespace(build=lambda root:{'positions':positions})
  with patch.dict(sys.modules,{'universal_portfolio.canonical_runtime_read_model':fake}):out=m.canonical_held(self.root)
  self.assertEqual(out['active_instrument_ids'],['A:B:C:D','A:B:C:D:E']);self.assertNotIn('SECRET',json.dumps(out));self.assertNotIn('123456',json.dumps(out));self.assertNotIn('-99',json.dumps(out))
 def test_unknown_position_not_claimed_absent_or_held(self):
  fake=types.SimpleNamespace(build=lambda root:{'positions':[types.SimpleNamespace(instrument_id='UNKNOWN',quantity=None)]})
  with patch.dict(sys.modules,{'universal_portfolio.canonical_runtime_read_model':fake}):out=m.canonical_held(self.root)
  self.assertEqual(out['unavailable_position_identity_or_quantity_count'],1);self.assertEqual(out['active_instrument_ids'],[])
if __name__=='__main__':unittest.main()
