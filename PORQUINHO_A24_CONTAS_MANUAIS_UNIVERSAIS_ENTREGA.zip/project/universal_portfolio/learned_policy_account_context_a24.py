"""Scope learned cash-distribution research to existing budgets and action drafts.
Never turn source weights into portfolio targets, orders, or execution authority.
"""
import datetime as dt
import math
from collections import Counter
from pathlib import Path
from . import economic_action_plan_a24 as actions
from .funded_currency_research_a24 import amount, fingerprint
from .explicit_market_bindings_a24 import digest
from .research_quote_acquisition_a24 import utc
from .global_history_source_a24 import read_sealed
from brain.evolution import learned_allocation_policy_a24 as learner

SCHEMA = 'porquinho.learned-policy-account-context-a24/1.0'


class ContextError(ValueError):
    pass


def flags():
    return {**actions.flags(), 'policy_validation_proven': False,
            'canonical_publication_authorized': False,
            'portfolio_target_weights_created': False, 'research_alias_used_as_financial_binding': False,
            'cash_scenarios_are_mutually_exclusive': True, 'resources_reserved': False}


def project(action_plan, funding, policies):
    if action_plan.get('schema') != actions.SCHEMA or action_plan.get('status') != 'ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY' or any(action_plan.get(k) != v for k, v in actions.flags().items()):
        raise ContextError('CURRENT_NONAUTHORIZING_ACTION_CONTEXTS_REQUIRED')
    if funding.get('schema') != 'porquinho.funded-currency-research-a24/1.0' or funding.get('status') != 'OBSERVATION_DEMAND_PROJECTED' or funding.get('financial_mutation') is not False or funding.get('automatic_execution_authorized') is not False:
        raise ContextError('CURRENT_NONAUTHORIZING_FUNDING_REQUIRED')
    contexts = {}
    for c in funding['contexts']:
        key = c['account_id'], c['currency']
        if key in contexts or c.get('context_fingerprint') != fingerprint({k: v for k, v in c.items() if k != 'context_fingerprint'}):
            raise ContextError('UNIQUE_CURRENT_FUNDING_CONTEXT_REQUIRED')
        contexts[key] = c
    requests = {}
    for r in funding['research_requests']:
        key = r['account_id'], r['quote_currency'], r['instrument_id']
        if key in requests or (key[0], key[1]) not in contexts or r.get('context_fingerprint') != contexts[key[:2]]['context_fingerprint']:
            raise ContextError('UNIQUE_CURRENT_RESEARCH_REQUEST_REQUIRED')
        requests[key] = r
    by_currency = {}
    for body in policies:
        r = body['research']
        if any(r.get(k) != v for k, v in learner.flags().items()):
            raise ContextError('NONAUTHORIZING_LEARNED_RESEARCH_REQUIRED')
        if r.get('status') != 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY':
            continue
        q = r['quote_currency']
        if q in by_currency:
            raise ContextError('ONE_CURRENT_POLICY_VERSION_PER_CURRENCY_REQUIRED')
        by_currency[q] = body
    cases = {}
    for case in action_plan['cases']:
        if case['resource_kind'] != 'CASH':
            continue
        key = case['account_id'], case['currency']
        if key in cases:
            raise ContextError('UNIQUE_CASH_RESOURCE_REQUIRED')
        cases[key] = case
    rows = []
    pending = []
    for key, case in sorted(cases.items()):
        context = contexts.get(key)
        if context is None or amount(case['canonical_cash_observed']) != amount(context['canonical_cash_observed']):
            raise ContextError('CASH_CONTEXT_CHANGED')
        if context.get('capital_status') != 'ACTIVE_INVESTMENT_BUDGET' or context.get('research_enabled') is not True or case.get('capital_ceiling') is None:
            pending.append({'case_id': case['case_id'], 'reason': 'ACTIVE_INVESTMENT_BUDGET_REQUIRED'})
            continue
        cap = amount(case['capital_ceiling'])
        budgets = context.get('planning_budget_intents', [])
        if len({b['budget_id'] for b in budgets}) != len(budgets) or sum((amount(b['amount']) for b in budgets), amount('0')) != cap or cap != amount(context['investment_budget_amount']) or not 0 < cap <= amount(case['canonical_cash_observed']):
            raise ContextError('EXACT_BUDGET_PARTITION_WITHIN_CASH_REQUIRED')
        body = by_currency.get(key[1])
        if body is None:
            pending.append({'case_id': case['case_id'], 'reason': 'CURRENT_LEARNED_POLICY_CANDIDATES_REQUIRED'})
            continue
        research = body['research']
        if research['horizon_unit'] != 'OBSERVATIONS' or research['horizon_value'] != 30:
            raise ContextError('POLICY_HORIZON_INVALID')
        for budget in budgets:
            value = amount(budget['amount'])
            if value <= 0:
                raise ContextError('POSITIVE_ACTIVE_BUDGET_REQUIRED')
            plans = [p for p in context['active_plan_contexts'] if p['planning_budget_id'] == budget['budget_id'] and p['plan_id'] in context['active_plan_ids']]
            if len(plans) != 1:
                pending.append({'case_id': case['case_id'], 'reason': 'UNIQUE_ACTIVE_PLAN_FOR_BUDGET_REQUIRED'})
                continue
            plan = plans[0]
            classes = plan.get('allowed_asset_classes')
            if not isinstance(classes, (list, tuple)) or not classes or not all(isinstance(c, str) and c.strip() for c in classes):
                raise ContextError('EXPLICIT_PLAN_CLASSES_REQUIRED')
            for candidate in research['candidates']:
                k = candidate['maximum_selected_sources']
                if type(k) is not int or k < 1 or k > 1000:
                    raise ContextError('EXPLICIT_LEARNED_SOURCE_COUNT_REQUIRED')
                weights = candidate['current_research_weights']
                if len(weights) > k:
                    raise ContextError('POLICY_WEIGHT_COUNT_EXCEEDS_SLEEVES')
                seen = set(); legs = []; blocking = ['LIQUIDITY_EVIDENCE_REQUIRED' if reason == 'LIQUIDITY_AND_BROKER_ELIGIBILITY_REQUIRED' else reason for reason in research['blocking_reasons']]
                for w in weights:
                    iid, provider, provider_id, q = learner.identity(w)
                    if iid in seen or q != key[1] or isinstance(w['weight'], bool) or not math.isclose(learner.number(w['weight']), 1 / k, rel_tol=1e-12, abs_tol=1e-12):
                        raise ContextError('EXACT_UNIQUE_POLICY_WEIGHT_REQUIRED')
                    seen.add(iid)
                    request = requests.get((*key, iid))
                    matches = [a for a in case['alternatives'] if a['instrument_id'] == iid and a['account_id'] == key[0] and a['currency'] == key[1] and a['kind'] in ('DEPLOY_CASH', 'INCREASE') and a['horizon_unit'] == research['horizon_unit'] and a['horizon_value'] == research['horizon_value']]
                    reasons = []
                    if request is None or request.get('candidate_asset_class') not in classes:
                        reasons.append('SOURCE_OUTSIDE_THIS_PLAN_REQUESTS_OR_CLASSES')
                    if request is None or not any(s.get('provider', '').lower() == provider.lower() and s.get('provider_id') == provider_id and s.get('quote_currency') == q for s in request.get('source_candidates', [])):
                        reasons.append('EXACT_PROVIDER_QUOTE_REQUEST_REQUIRED')
                    if len(matches) != 1:
                        reasons.append('UNIQUE_EXACT_CASH_ALTERNATIVE_REQUIRED')
                    else:
                        a = matches[0]
                        if a.get('planning_context_fingerprint') != context['context_fingerprint']:
                            reasons.append('ACTION_FUNDING_CONTEXT_MISMATCH')
                        # Keep all existing economic blockers, especially identity,
                        # pretrade costs, eligibility and validated sizing.
                        reasons.extend(a['blocking_reasons'])
                    blocking.extend(reasons)
                    legs.append({**dict(zip(learner.KEY, (iid, provider, provider_id, q))),
                        'alternative_id': matches[0]['alternative_id'] if len(matches) == 1 else None,
                        'draft_action_kind': matches[0]['kind'] if len(matches) == 1 else None,
                        'manual_account_asset_scope': dict(matches[0]['manual_account_asset_scope']) if len(matches) == 1 and isinstance(matches[0].get('manual_account_asset_scope'), dict) else None,
                        'fraction_numerator': 1, 'fraction_denominator': k,
                        'scenario_amount': None, 'requested_amount': None,
                        'blocking_reasons': sorted(set(reasons))})
                row = {'case_id': case['case_id'], 'account_id': key[0], 'currency': key[1],
                    'budget_id': budget['budget_id'], 'plan_id': plan['plan_id'],
                    'budget_reference_capital': str(value),
                    'budget_reference_is_order_amount': False,
                    'shared_cash_resource_key': fingerprint(['CASH', *key]),
                    'candidate_id': candidate['candidate_id'],
                    'policy_version_digest': digest(body['version']),
                    'funding_context_fingerprint': context['context_fingerprint'],
                    'action_case_digest': digest(case),
                    'scope': 'INCREMENTAL_CASH_BUDGET_RESEARCH_NOT_WHOLE_PORTFOLIO',
                    'horizon_unit': research['horizon_unit'], 'horizon_value': research['horizon_value'],
                    'legs': legs, 'cash_fraction_numerator': k - len(weights), 'cash_fraction_denominator': k,
                    'renormalized_after_blocked_legs': False, 'scenario_amounts_created': False,
                    'zero_target_is_sell_instruction': False, 'reallocation_created': False,
                    'blocking_reasons': sorted(set(blocking)), **flags()}
                rows.append(row)
                if len(rows) > 20000:
                    raise ContextError('SCOPED_POLICY_CASE_LIMIT')
    return {'schema': SCHEMA, 'status': 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY',
            'scenarios': rows, 'pending_contexts': pending, **flags()}


def summarize(value):
    if value.get('schema') != SCHEMA:
        raise ContextError('SCOPED_POLICY_SCHEMA_REQUIRED')
    if value.get('status') != 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY':
        return {k: v for k, v in value.items() if k not in ('scenarios', 'learning_summary')}
    rows = value['scenarios']
    return {'schema': SCHEMA, 'status': value['status'], 'scenario_count': len(rows),
            'budget_plan_context_count': len({(r['account_id'], r['currency'], r['budget_id'], r['plan_id']) for r in rows}),
            'exact_alternative_leg_count': sum(l['alternative_id'] is not None for r in rows for l in r['legs']),
            'source_request_compatible_leg_count': sum(not any(x in l['blocking_reasons'] for x in ('SOURCE_OUTSIDE_THIS_PLAN_REQUESTS_OR_CLASSES', 'EXACT_PROVIDER_QUOTE_REQUEST_REQUIRED', 'UNIQUE_EXACT_CASH_ALTERNATIVE_REQUIRED', 'ACTION_FUNDING_CONTEXT_MISMATCH', 'RESEARCH_LINK_NOT_FINANCIAL_IDENTITY_BINDING')) for r in rows for l in r['legs']),
            'blocking_reason_counts': dict(Counter(x for r in rows for x in r['blocking_reasons'])),
            'pending_context_reason_counts': dict(Counter(x['reason'] for x in value['pending_contexts'])),
            'scenario_amounts_created': False, 'scope': 'INCREMENTAL_CASH_BUDGET_RESEARCH_NOT_WHOLE_PORTFOLIO', **flags()}


def build(root, action_plan, funding, *, now=None, action_evidence=None):
    root = Path(root).resolve(strict=True); now = utc(now or dt.datetime.now(dt.timezone.utc))
    learning = {'schema': learner.SCHEMA, 'status': 'LEARNED_POLICY_RESEARCH_INSPECTED', 'contexts': [], **learner.flags()}
    try:
        if action_plan.get('source_version_digest') != digest(actions.source_versions(root)):
            raise ContextError('FINANCIAL_CONTEXT_CHANGED_BEFORE_POLICY_SCOPE')
        _, planned = learner.lab.jobs(root, funding, now)
        directories = {root / learner.lab.STORE / 'experiments', *(j['path'].parent for j in planned)}
        def directory_versions():
            return {str(p): (p.stat().st_ino, p.stat().st_mtime_ns) if p.exists() else None for p in directories}
        before_directories = directory_versions()
        _, jobs = learner.work(root, funding, now)
        policies = []; source_bodies = {}
        for job in jobs:
            for experiment_job, experiment in job['pairs']:
                source_bodies[experiment_job['path']] = experiment
                for path, body in experiment_job['pairs']: source_bodies[path] = body
            row = {'quote_currency': job['pairs'][0][1]['quote_currency'], 'status': 'AWAITING_POLICY_LEARNING'}
            if job['path'].exists():
                body = learner.check_stored(read_sealed(job['path']), job, now); policies.append(body); source_bodies[job['path']] = body
                r = body['research']
                row.update(status=r['status'], algorithm_count=r['algorithm_count'], searched_candidate_count=r.get('searched_candidate_count', 0),
                    retained_candidate_count=len(r['candidates']), training_period_count=len(r.get('training_intervals', [])),
                    held_out_period_count=len(r.get('held_out_intervals', [])), blocking_reasons=r['blocking_reasons'])
            learning['contexts'].append(row)
        learning['candidate_count'] = sum(r.get('retained_candidate_count', 0) for r in learning['contexts'])
        result = project(action_plan, funding, policies)
        from .learned_policy_economic_basis_a24 import project as economic_project, SCHEMA as ECONOMIC_SCHEMA, BasisError
        experiments = {str(j['path'].relative_to(root)): r for job in jobs for j, r in job['pairs']}
        try:
            result['economic_basis'] = economic_project(result, policies, experiments)
            from .learned_policy_cost_context_a24 import attach
            attach(root, result['economic_basis'], result, now=now, action_evidence=action_evidence)
        except Exception as exc:
            result['economic_basis'] = {'schema': ECONOMIC_SCHEMA, 'status': 'LEARNED_ECONOMIC_BASIS_UNAVAILABLE', 'reason': str(exc) if isinstance(exc, BasisError) else type(exc).__name__}
        # Jobs and source hashes rechecked; a disappearing binding, forecast or
        # newly changed financial context must not leave a stale projection.
        if before_directories != directory_versions() or any(read_sealed(path) != body for path, body in source_bodies.items()) or action_plan['source_version_digest'] != digest(actions.source_versions(root)):
            raise ContextError('POLICY_OR_FINANCIAL_SOURCES_CHANGED_DURING_SCOPE')
        result['learning_summary'] = learning
        return result
    except Exception as exc:
        return {'schema': SCHEMA, 'status': 'LEARNED_POLICY_ACCOUNT_SCOPE_UNAVAILABLE',
                'reason': str(exc) if isinstance(exc, ContextError) else type(exc).__name__,
                'learning_summary': {**learning, 'status': 'LEARNED_POLICY_RESEARCH_UNAVAILABLE', 'error_type': type(exc).__name__}, **flags()}
