"""Read-only financial action context construction, not economic validation or sizing.
Uses existing positions, canonical cash, budgets/plans; never creates instruments or FX.
"""
from collections import Counter,defaultdict
from decimal import Decimal
from pathlib import Path
from .funded_currency_research_a24 import amount,currency,field,fingerprint,text
SCHEMA='porquinho.economic-action-plan-a24/1.0'
KEY='economic_action_plan'
class ActionPlanError(ValueError):pass

def flags():return {'authority':'NONE','recommendation_created':False,'comparison_authorized':False,'sizing_created':False,'execution_authorized':False,'automatic_execution_authorized':False,'financial_mutation':False,'history_write_performed':False,'cross_currency_aggregation':False,'account_transfer_created':False}
COMMON=('VALIDATED_FORWARD_RETURN_REQUIRED','VALIDATED_FORWARD_RISK_REQUIRED','ACTION_SPECIFIC_COUNTERFACTUAL_REQUIRED','EXPLICIT_UTILITY_POLICY_REQUIRED','COMMON_REFERENCE_CAPITAL_REQUIRED','VALIDATED_SIZING_REQUIRED')

def position_key(row):
 iid=row.get('canonical_instrument_id') or row.get('instrument_id');aid=row.get('account_id');ref=row.get('account_reference');nested=ref.get('value') if isinstance(ref,dict) else None
 if aid and nested and aid!=nested:raise ActionPlanError('POSITION_ACCOUNT_CONFLICT')
 aid=aid or nested
 if not text(iid) or not text(aid):raise ActionPlanError('EXPLICIT_POSITION_CONTEXT_REQUIRED')
 if row.get('canonical_instrument_id') and row.get('instrument_id') and row['canonical_instrument_id']!=row['instrument_id']:raise ActionPlanError('POSITION_IDENTITY_CONFLICT')
 return iid,aid,currency(row.get('currency'))

def project(*,positions,cash,registry,funding,identity_links=(),candidates=(),plans=(),bindings=(),horizon_unit="OBSERVATIONS",horizon_value=30):
 if horizon_unit not in ('OBSERVATIONS','DAYS') or type(horizon_value) is not int or horizon_value<=0:raise ActionPlanError('EXPLICIT_COMPARISON_HORIZON_REQUIRED')
 if funding.get('schema')!='porquinho.funded-currency-research-a24/1.0' or funding.get('status')!='OBSERVATION_DEMAND_PROJECTED':raise ActionPlanError('CURRENT_FUNDING_PROJECTION_REQUIRED')
 if funding.get('financial_mutation') is not False or funding.get('automatic_execution_authorized') is not False:raise ActionPlanError('NONAUTHORIZING_FUNDING_REQUIRED')
 accounts={}
 for a in registry.get('accounts',[]):
  aid=a.get('account_id')
  if not text(aid) or aid in accounts:raise ActionPlanError('UNIQUE_ACCOUNT_REGISTRY_REQUIRED')
  accounts[aid]=a
 balances=defaultdict(lambda:Decimal('0'))
 for row in cash:
  aid=field(row,'account_id');q=currency(field(row,'currency'));value=amount(field(row,'amount'))
  if not text(aid) or aid not in accounts or accounts[aid].get('currency')!=q:raise ActionPlanError('CANONICAL_CASH_ACCOUNT_CURRENCY_REQUIRED')
  balances[(aid,q)]+=value
 contexts={}
 for c in funding.get('contexts',[]):
  key=(c['account_id'],currency(c['currency']))
  if key in contexts or key not in balances or balances[key]!=amount(c['canonical_cash_observed']):raise ActionPlanError('FUNDING_CASH_REVALIDATION_REQUIRED')
  if c.get('context_fingerprint')!=fingerprint({k:v for k,v in c.items() if k!='context_fingerprint'}):raise ActionPlanError('FUNDING_CONTEXT_FINGERPRINT_REQUIRED')
  contexts[key]=c
 held={};excluded=0
 for p in positions:
  if p.get('quantity') is not None:
   qty=amount(p['quantity'])
   if qty==0:excluded+=1;continue
   if qty<0:raise ActionPlanError('SHORT_POSITION_NOT_SUPPORTED')
  else:qty=None
  key=position_key(p);iid,aid,q=key
  if aid not in accounts or accounts[aid].get('currency')!=q:raise ActionPlanError('POSITION_ACCOUNT_CURRENCY_REQUIRED')
  if key in held:raise ActionPlanError('DUPLICATE_POSITION_CONTEXT')
  basis=amount(p['cost_basis']) if p.get('cost_basis') is not None else None
  if basis is not None and basis<0:raise ActionPlanError('NONNEGATIVE_ACQUISITION_BASIS_REQUIRED')
  held[key]={'quantity_upper_bound':str(qty) if qty is not None else None,'historical_cost_basis':str(basis) if basis is not None else None}
 catalog={}
 for candidate in candidates:
  iid=candidate.get('instrument_id');cls=candidate.get('asset_class')
  if not text(iid) or not text(cls) or iid in catalog:raise ActionPlanError('UNIQUE_CANDIDATE_IDENTITY_CLASS_REQUIRED')
  catalog[iid]=candidate
 plan_contexts=defaultdict(list);plan_ids=set()
 for p in plans:
  if p.get('status')!='ACTIVE':continue
  aid=p.get('source_account_id');q=currency(p.get('currency'));pid=p.get('plan_id');classes=p.get('allowed_asset_classes')
  if not text(pid) or pid in plan_ids or aid not in accounts or accounts[aid].get('currency')!=q:raise ActionPlanError('ACTIVE_PLAN_SCOPE_REQUIRED')
  if p.get('authority')!='NONE' or p.get('automatic_execution_authorized') is not False or p.get('execution_mode')!='MANUAL':raise ActionPlanError('MANUAL_PLAN_AUTHORITY_REQUIRED')
  if not isinstance(classes,(list,tuple)) or not classes or not all(text(x) for x in classes):raise ActionPlanError('ACTIVE_PLAN_ASSET_CLASSES_REQUIRED')
  plan_ids.add(pid);plan_contexts[(aid,q)].append(p)
 requests=defaultdict(dict)
 for r in funding.get('research_requests',[]):
  key=(r.get('account_id'),currency(r.get('quote_currency')));c=contexts.get(key);iid=r.get('instrument_id')
  if c is None or r.get('context_fingerprint')!=c['context_fingerprint'] or not text(iid):raise ActionPlanError('REQUEST_FUNDING_CONTEXT_REQUIRED')
  if iid in requests[key]:raise ActionPlanError('DUPLICATE_REQUEST_CONTEXT')
  requests[key][iid]=r
 # Research aliases never choose financial identity or action equivalence.
 aliases={}
 for link in identity_links:
  a=link.get('position_instrument_id');b=link.get('research_instrument_id')
  if not text(a) or not text(b) or a in aliases:raise ActionPlanError('UNIQUE_REVIEWED_RESEARCH_LINK_REQUIRED')
  aliases[a]=b
 if len(held)+len(contexts)>256 or len(catalog)>1000 or sum(len(v) for v in requests.values())>20000:raise ActionPlanError('ACTION_CASE_LIMIT')
 cases=[]
 def planning(c,needs_cash=True):
  if needs_cash and (not c or c.get('capital_status')!='ACTIVE_INVESTMENT_BUDGET' or c.get('research_enabled') is not True):return ['ACTIVE_INVESTMENT_BUDGET_REQUIRED']
  if not c or not c.get('active_plan_ids'):return ['ACTIVE_MANUAL_INVESTMENT_PLAN_REQUIRED']
  return []
 def alt(case_id,kind,iid,aid,q,*,source=None,request=None,context=None,extra=()):
  blockers=list(COMMON)+list(extra)
  legs=0 if kind in ('KEEP','NO_ALLOCATION') else 2 if kind=='REALLOCATE' else 1
  if legs:blockers.append('ACTION_SPECIFIC_PRETRADE_COST_REQUIRED')
  if kind in ('DEPLOY_CASH','INCREASE','REALLOCATE'):
   blockers+=planning(context,needs_cash=kind!='REALLOCATE')
   if kind=='REALLOCATE':
    candidate=catalog.get(iid);classes={v for p in plan_contexts[(aid,q)] for v in p['allowed_asset_classes']}
    if not candidate or candidate['asset_class'] not in classes:blockers.append('DESTINATION_OUTSIDE_ACTIVE_PLAN_CLASSES')
   if (not request or request.get('status')!='READY_FOR_SOURCE_REVIEW') and not any(b.get('instrument_id')==iid and b.get('quote_currency')==q for b in bindings):blockers.append('EXPLICIT_PROVIDER_QUOTE_BINDING_REQUIRED')
  if kind in ('DEPLOY_CASH','INCREASE') and balances[(aid,q)]<=0:blockers.append('POSITIVE_CANONICAL_CASH_REQUIRED')
  collisions=[pid for pid,a,cur in held if a==aid and cur==q and pid!=iid and aliases.get(pid)==iid]
  if collisions:blockers.append('RESEARCH_LINK_NOT_FINANCIAL_IDENTITY_BINDING')
  if source and (source,aid,q) not in held:raise ActionPlanError('REALLOCATION_SOURCE_NOT_HELD')
  if kind=='REALLOCATE' and (source==iid or not text(source)):raise ActionPlanError('DISTINCT_REALLOCATION_LEGS_REQUIRED')
  return {'alternative_id':fingerprint([case_id,kind,iid,source]),'kind':kind,'instrument_id':iid,'account_id':aid,'currency':q,
   'source_instrument_id':source,'destination_instrument_id':iid if kind=='REALLOCATE' else None,
   'horizon_unit':horizon_unit,'horizon_value':horizon_value,'shared_cash_resource_key':fingerprint(['CASH',aid,q]) if kind in ('DEPLOY_CASH','INCREASE') else None,
   'source_position_resource_key':fingerprint(['POSITION',source or iid,aid,q]) if kind in ('KEEP','REDUCE','SELL','REALLOCATE') else None,
   'manual_account_asset_scope':{'schema':'porquinho.manual-account-asset-scope-a24/1.0','status':'COMPATIBLE_DECLARED_ACCOUNT_CURRENCY','mode':'MANUAL','asset_scope':'ANY_EXPLICIT_INSTRUMENT','account_currency':accounts[aid]['currency'],'transaction_currency':q,'account_currency_matches':True,'institution_asset_restriction_applied':False,'country_used_to_infer_currency':False,'manual_confirmation_required':bool(legs),'broker_execution_supported':None,'automatic_execution_authorized':False,'future_costs_assumed':False},
   'resources_reserved':False,'trade_leg_count':legs,'planning_context_fingerprint':context.get('context_fingerprint') if context else None,
   'requested_amount':None,'requested_quantity':None,'reference_capital':None,'forward_return':None,'risk_measure':None,
   'transaction_cost':None,'relative_utility':None,'status':'DRAFT_NOT_COMPARATOR_READY',
   'blocking_reasons':sorted(set(blockers)),**flags()}
 for (iid,aid,q),position in sorted(held.items()):
  cid=fingerprint(['POSITION',iid,aid,q]);ctx=contexts.get((aid,q));r=requests[(aid,q)].get(iid)
  if not ctx:ctx={'active_plan_ids':[p['plan_id'] for p in plan_contexts[(aid,q)]]}
  extra=[] if position['quantity_upper_bound'] is not None else ['EXPLICIT_POSITION_QUANTITY_REQUIRED']
  alternatives=[alt(cid,'KEEP',iid,aid,q,context=ctx),alt(cid,'REDUCE',iid,aid,q,context=ctx,extra=extra),alt(cid,'SELL',iid,aid,q,context=ctx,extra=extra)]
  if balances[(aid,q)]>0:alternatives.append(alt(cid,'INCREASE',iid,aid,q,request=r,context=ctx))
  for dest in sorted(set(catalog)|set(requests[(aid,q)])):
   request=requests[(aid,q)].get(dest)
   if dest!=iid:alternatives.append(alt(cid,'REALLOCATE',dest,aid,q,source=iid,request=request,context=ctx,extra=extra))
  cases.append({'case_id':cid,'resource_kind':'POSITION','instrument_id':iid,'account_id':aid,'currency':q,
   'quantity_upper_bound':position['quantity_upper_bound'],'historical_cost_basis':position['historical_cost_basis'],'capital_ceiling':None,'alternatives_mutually_exclusive':True,'alternatives':alternatives})
 for (aid,q),ctx in sorted(contexts.items()):
  if balances[(aid,q)]<=0:continue
  cid=fingerprint(['CASH',aid,q]);ceiling=None
  if ctx.get('capital_status')=='ACTIVE_INVESTMENT_BUDGET':
   cap=amount(ctx.get('investment_budget_amount'))
   if cap<=0 or cap>balances[(aid,q)]:raise ActionPlanError('PLANNING_CAPITAL_EXCEEDS_CANONICAL_CASH')
   ceiling=str(cap)
  alternatives=[alt(cid,'NO_ALLOCATION',None,aid,q,context=ctx)]
  for iid,request in sorted(requests[(aid,q)].items()):
   kind='INCREASE' if (iid,aid,q) in held else 'DEPLOY_CASH'
   alternatives.append(alt(cid,kind,iid,aid,q,request=request,context=ctx))
  cases.append({'case_id':cid,'resource_kind':'CASH','instrument_id':None,'account_id':aid,'currency':q,
   'canonical_cash_observed':str(balances[(aid,q)]),'capital_ceiling':ceiling,'alternatives_mutually_exclusive':True,'quantity_upper_bound':None,'alternatives':alternatives})
 if len(cases)>256 or sum(len(c['alternatives']) for c in cases)>20000:raise ActionPlanError('ACTION_CASE_LIMIT')
 return {'schema':SCHEMA,'status':'ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY','cases':cases,'excluded_zero_position_count':excluded,
  'capital_ceiling_is_order_size':False,'historical_fees_used_as_future_tariff':False,'research_alias_used_as_financial_binding':False,'sizing_policy_created':False,**flags()}

def summarize(value):
 if value.get('schema')!=SCHEMA:raise ActionPlanError('ACTION_PLAN_SCHEMA_REQUIRED')
 if value.get('status')!='ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY':return {k:v for k,v in value.items() if k!='cases'}
 rows=[a for c in value['cases'] for a in c['alternatives']]
 return {'schema':SCHEMA,'status':value['status'],'case_count':len(value['cases']),'position_case_count':sum(c['resource_kind']=='POSITION' for c in value['cases']),
  'cash_case_count':sum(c['resource_kind']=='CASH' for c in value['cases']),'alternative_count':len(rows),
  'manual_currency_compatible_alternative_count':sum(a.get('manual_account_asset_scope',{}).get('status')=='COMPATIBLE_DECLARED_ACCOUNT_CURRENCY' for a in rows),'institution_asset_restriction_applied':False,'automatic_broker_capability_inferred':False,
  'action_counts':dict(Counter(a['kind'] for a in rows)),'blocking_reason_counts':dict(Counter(r for a in rows for r in a['blocking_reasons'])),
  'funded_case_with_capital_ceiling_count':sum(c['resource_kind']=='CASH' and c['capital_ceiling'] is not None for c in value['cases']),
  'excluded_zero_position_count':value['excluded_zero_position_count'],'capital_ceiling_is_order_size':False,'historical_fees_used_as_future_tariff':False,
  'research_alias_used_as_financial_binding':False,**flags()}

def source_versions(root):
 from .explicit_market_bindings_a24 import local
 root=Path(root).resolve(strict=True)
 names=('transaction_ledger.jsonl','universal_opening_state_shadow.json','prospective_cutover_declaration_shadow.json','institution_accounts.json','planning_budgets.json','investment_plans.json','instruments/market_provider_bindings_a24.json','opening_position_identity_bindings.json','canonical_position_identity_bindings.json','portfolio_registry.json','opening_cash_identity_bindings.json','instruments/research_identity_links_a24.json')
 paths=[local(root,'data/'+v) for v in names]+list(local(root,'data').glob('*institution*account*.json'))
 return {str(p.relative_to(root)):(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) if p.exists() else None for p in paths}

def build(root,*,funding,candidates=()):
 try:
  from .canonical_runtime_read_model import build as runtime
  from .investment_plan_runtime import _accounts
  from .investment_plan_store import InvestmentPlanStore
  from .planning_budget_store import PlanningBudgetStore
  from .explicit_market_bindings_a24 import load as load_bindings
  from .funded_currency_research_a24 import project as project_funding
  from .monitor_consolidation_a24 import position_records,projected_account_records
  from .reviewed_research_identity_links_a24 import load
  from .explicit_market_bindings_a24 import local
  root=Path(root).resolve(strict=True)
  def versions():return source_versions(root)
  before=versions();state=runtime(root);registry=_accounts(root)
  if state.get('authority')!='NONE' or state.get('ledger_write') is not False:raise ActionPlanError('READ_ONLY_CANONICAL_RUNTIME_REQUIRED')
  positions=projected_account_records(position_records(state['positions']),registry)
  plans=InvestmentPlanStore(root/'data/investment_plans.json').list();bindings=load_bindings(root)['bindings']
  fresh=project_funding(cash=state['cash'],registry=registry,budgets=PlanningBudgetStore(root/'data/planning_budgets.json').list(),plans=plans,candidates=candidates,bindings=bindings)
  if fresh!=funding:raise ActionPlanError('FUNDING_PLAN_OR_BUDGET_CHANGED_RETRY_REQUIRED')
  result=project(positions=positions,cash=state['cash'],registry=registry,funding=fresh,identity_links=load(root),candidates=candidates,plans=plans,bindings=bindings)
  if before!=versions():raise ActionPlanError('ACTION_SOURCES_CHANGED_DURING_READ')
  result['source_version_digest']=fingerprint(before)
  return result
 except Exception as exc:return {'schema':SCHEMA,'status':'ACTION_CONTEXT_PROJECTION_UNAVAILABLE','reason':str(exc) if isinstance(exc,ActionPlanError) else type(exc).__name__,'cases':[],**flags()}
