import copy
import unittest
import test_a24_economic_action_plan as fixture

class ManualScope(unittest.TestCase):
    def setUp(self):
        self.args=fixture.Plan().setup()
    def alternatives(self):return [a for c in fixture.m.project(**self.args)['cases'] for a in c['alternatives']]
    def test_manual_scope_applies_to_every_action_without_broker_claim(self):
        rows=self.alternatives();self.assertTrue(rows)
        for row in rows:
            scope=row['manual_account_asset_scope'];self.assertEqual(scope['status'],'COMPATIBLE_DECLARED_ACCOUNT_CURRENCY');self.assertTrue(scope['account_currency_matches']);self.assertIsNone(scope['broker_execution_supported']);self.assertFalse(scope['automatic_execution_authorized']);self.assertFalse(scope['future_costs_assumed']);self.assertNotIn('INSTRUMENT_VENUE_ELIGIBILITY_REQUIRED',row['blocking_reasons'])
    def test_economic_cost_and_model_blockers_remain(self):
        for row in self.alternatives():
            self.assertIn('VALIDATED_FORWARD_RETURN_REQUIRED',row['blocking_reasons']);self.assertIn('VALIDATED_SIZING_REQUIRED',row['blocking_reasons']);self.assertFalse(row['execution_authorized']);self.assertFalse(row['comparison_authorized'])
    def test_currency_mismatch_still_refused(self):
        self.args['cash'][0]['currency']='JPY'
        with self.assertRaises(ValueError):fixture.m.project(**self.args)
    def test_bank_country_does_not_relabel_existing_currencies(self):
        before=copy.deepcopy(self.args)
        for i in self.args['registry'].get('institutions',[]):i['country']='JP'
        rows=self.alternatives()
        for row in rows:self.assertEqual(row['currency'],'BRL');self.assertFalse(row['manual_account_asset_scope']['country_used_to_infer_currency'])
        self.assertEqual(self.args['cash'],before['cash'])
    def test_no_bank_asset_class_whitelist(self):
        self.args['candidates'][0]['asset_class']='GLOBAL_CUSTOM_ASSET_TYPE'
        rows=self.alternatives();self.assertTrue(rows)
        for row in rows:self.assertFalse(row['manual_account_asset_scope']['institution_asset_restriction_applied'])
    def test_reallocation_keeps_same_account_currency_and_distinct_legs(self):
        rows=[a for a in self.alternatives() if a['kind']=='REALLOCATE'];self.assertTrue(rows)
        for row in rows:self.assertNotEqual(row['source_instrument_id'],row['destination_instrument_id']);self.assertEqual(row['trade_leg_count'],2);self.assertTrue(row['manual_account_asset_scope']['manual_confirmation_required'])
    def test_readonly_projection_and_summary(self):
        before=copy.deepcopy(self.args);result=fixture.m.project(**self.args);summary=fixture.m.summarize(result)
        self.assertEqual(self.args,before);self.assertEqual(summary['manual_currency_compatible_alternative_count'],summary['alternative_count']);self.assertFalse(summary['automatic_broker_capability_inferred'])
