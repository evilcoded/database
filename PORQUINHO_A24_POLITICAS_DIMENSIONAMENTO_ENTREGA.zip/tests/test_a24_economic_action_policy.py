import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
import test_a24_economic_action_plan as actions
from universal_portfolio import economic_action_policy_a24 as p
from universal_portfolio.explicit_market_bindings_a24 import digest

from types import SimpleNamespace
from universal_portfolio.universal_risk_evidence_authority import build_risk_evidence
from universal_portfolio.universal_liquidity_evidence_authority import build_liquidity_evidence

def _base_policy():
 return {'policy_id':'TEST_POLICY','policy_version':'TEST_V1','source':'GOVERNED_POLICY','authority':'TEST_GOVERNANCE','account_id':'TEST_ACCOUNT','currency':'TST','effective_from':'TEST_TIME','provenance':'TEST_SOURCE','evaluator_id':'THRESHOLD_EVALUATOR','evaluator_version':'TEST_V1','operator':'MAX','validated':True,'validation_ref':'TEST_VALIDATION','calibration_required':False}
def _risk_policy():return p.risk.build_policy({**_base_policy(),'threshold':.5,'metric_semantics':'TEST_SEMANTICS','scale':'TEST_SCALE','unit':'TEST_UNIT','horizon':'OBSERVATIONS:30'})
def _risk_evidence(horizon='OBSERVATIONS:30'):
 return build_risk_evidence({'instrument_id':'TEST_ID','asset_class':'EQUITY','metric_name':'TEST_RISK','metric_semantics':'TEST_SEMANTICS','value':.4,'scale':'TEST_SCALE','unit':'TEST_UNIT','horizon':horizon,'model_name':'TEST_MODEL','model_version':'TEST_V1','observed_at':'TEST_TIME','provenance':'TEST_SOURCE','maturity':'VALIDATED','validation_ref':'TEST_VALIDATION'})['evidence']
def _liquidity_policy():return p.liquidity.build_policy({**_base_policy(),'threshold':15,'metric_family':'SPREAD','metric_semantics':'TEST_SPREAD','unit':'TEST_BPS','observation_window':'TEST_WINDOW','requested_amount_context_supported':False})
def _liquidity_evidence():
 return build_liquidity_evidence({'instrument_id':'TEST_ID','asset_class':'EQUITY','metric_name':'TEST_LIQUIDITY','metric_family':'SPREAD','metric_semantics':'TEST_SPREAD','value':10,'unit':'TEST_BPS','observation_window':'TEST_WINDOW','model_name':'TEST_MODEL','model_version':'TEST_V1','observed_at':'TEST_TIME','provenance':'TEST_SOURCE','maturity':'VALIDATED','validation_ref':'TEST_VALIDATION'})['evidence']
def _concentration_policy():return {'policy_id':'TEST_POLICY','version':'TEST_V1','source':'GOVERNED_POLICY','authority':'TEST_AUTHORITY','account_id':'ACC','currency':'TST','effective_from':'TEST_TIME','validated':True,'provenance':'TEST_SOURCE','constraints':[{'metric':'LARGEST_POSITION_WEIGHT','operator':'MAX','threshold':.7}]}
rf=SimpleNamespace(policy=_risk_policy,evidence=_risk_evidence)
lf=SimpleNamespace(policy=_liquidity_policy,evidence=_liquidity_evidence)
cf=SimpleNamespace(policy=_concentration_policy,exposure=lambda account,currency:{'account_id':account,'currency':currency,'concentration_hhi':.5,'largest_position_weight':.6})
NOW=dt.datetime(2026,10,17,tzinfo=dt.timezone.utc)
class Policies(unittest.TestCase):
 def setUp(self):
  self.kw=actions.Plan().setup();self.action=actions.m.project(**self.kw);self.a={**self.action['cases'][0]['alternatives'][0],'case_id':self.action['cases'][0]['case_id']}
 def item(self):
  scope={k:self.a.get(k) for k in p.SCOPE};times={'effective_from':(NOW-dt.timedelta(hours=1)).isoformat(),'account_id':'account','currency':'BRL'}
  rp=rf.policy()['policy'].payload();rp.update(times,horizon='OBSERVATIONS:30');re=rf.evidence(horizon='OBSERVATIONS:30').payload();re.update(instrument_id=actions.I,observed_at=NOW.isoformat())
  lp=lf.policy()['policy'].payload();lp.update(times);le=lf.evidence().payload();le.update(instrument_id=actions.I,observed_at=NOW.isoformat())
  cp=cf.policy();cp.update(times);ex={**cf.exposure(account='account',currency='BRL'),'instrument_id':actions.I,'observed_at':NOW.isoformat(),'metric_unit':'FRACTION','validation_status':'VALIDATED_FOR_SHADOW_POLICY_ASSESSMENT','source_ref':'fixture','validation_ref':'fixture'}
  end=(NOW+dt.timedelta(hours=1)).isoformat()
  return {**scope,'action_context_digest':digest(self.a),'as_of':NOW.isoformat(),'effective_until':end,'risk_policy':rp,'risk_evidence':re,'risk_effective_until':end,'liquidity_policy':lp,'liquidity_evidence':le,'liquidity_horizon':'OBSERVATIONS:30','liquidity_effective_until':end,'concentration_policy':cp,'concentration_effective_until':end,'concentration_horizon':'OBSERVATIONS:30','current_exposure':ex,'counterfactual_exposure':{**ex,'counterfactual':True,'scenario_reference_amount':'10'},'scenario_reference_amount':'10'}
 def run_policy(self,item=None):
  document={'schema':p.INPUT_SCHEMA,'execution_authorized':False,'comparison_authorized':False,'assessments':[item or self.item()]}
  return p.project(self.action,document,now=NOW,active_plans=self.kw['plans'])
 def dimension(self,result,name):return result['assessments'][0]['dimensions'][name]
 def test_no_inputs_unknown_not_blocked_or_passed(self):
  r=p.project(self.action,now=NOW);s=p.summarize(r);self.assertIsNone(r['assessments'][0]['scenario_guardrails_acceptable']);self.assertIsNone(r['assessments'][0]['sizing_guardrail_context']['risk_policy_acceptable'])
  for d in p.DIMENSIONS:self.assertEqual(s['dimensions'][d]['acceptable_count'],0);self.assertEqual(s['dimensions'][d]['blocked_count'],0);self.assertEqual(s['dimensions'][d]['unavailable_count'],s['alternative_count'])
 def test_three_existing_evaluators_accept_explicit_fixture(self):
  r=self.run_policy()
  for d in p.DIMENSIONS:self.assertIs(self.dimension(r,d)['acceptable'],True)
 def test_risk_blocked_is_false_not_unavailable(self):
  x=self.item();x['risk_policy']['threshold']=.1;self.assertIs(self.dimension(self.run_policy(x),'risk')['acceptable'],False)
 def test_liquidity_blocked(self):
  x=self.item();x['liquidity_policy']['threshold']=1;self.assertIs(self.dimension(self.run_policy(x),'liquidity')['acceptable'],False)
 def test_concentration_blocked(self):
  x=self.item();x['concentration_policy']['constraints'][0]['threshold']=.1;self.assertIs(self.dimension(self.run_policy(x),'concentration')['acceptable'],False)
 def test_absent_threshold_not_default(self):
  x=self.item();x['risk_policy'].pop('threshold');self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_unvalidated_risk_remains_unavailable(self):
  x=self.item();x['risk_evidence']['maturity']='OBSERVED';self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_future_policy_rejected(self):
  x=self.item();x['risk_policy']['effective_from']=(NOW+dt.timedelta(days=1)).isoformat();self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_expired_input_refused(self):
  x=self.item();x['effective_until']=NOW.isoformat()
  with self.assertRaises(ValueError):self.run_policy(x)
 def test_policy_expiry_is_dimension_specific(self):
  x=self.item();x['risk_effective_until']=NOW.isoformat();r=self.run_policy(x);self.assertIsNone(self.dimension(r,'risk')['acceptable']);self.assertIs(self.dimension(r,'liquidity')['acceptable'],True)
 def test_different_account_rejected(self):
  x=self.item();x['risk_policy']['account_id']='other';self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_currency_and_identity_not_guessed(self):
  x=self.item();x['liquidity_policy']['currency']='EUR';x['risk_evidence']['instrument_id']='OTHER';r=self.run_policy(x);self.assertIsNone(self.dimension(r,'risk')['acceptable']);self.assertIsNone(self.dimension(r,'liquidity')['acceptable'])
 def test_days_never_interchanged_with_observations(self):
  x=self.item();x['risk_policy']['horizon']='DAYS:30';self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_bool_is_not_threshold(self):
  x=self.item();x['risk_policy']['threshold']=True;self.assertIsNone(self.dimension(self.run_policy(x),'risk')['acceptable'])
 def test_concentration_requires_scenario_amount(self):
  x=self.item();x.pop('scenario_reference_amount');self.assertIsNone(self.dimension(self.run_policy(x),'concentration')['acceptable'])
 def test_concentration_requires_matching_after_amount(self):
  x=self.item();x['counterfactual_exposure']['scenario_reference_amount']='20';self.assertIsNone(self.dimension(self.run_policy(x),'concentration')['acceptable'])
 def test_accepted_guards_do_not_size_authorize_or_remove_blockers(self):
  r=self.run_policy()['assessments'][0];self.assertIs(r['sizing_guardrail_context']['risk_policy_acceptable'],True);self.assertIsNone(r['sizing_guardrail_context']['suggested_amount']);self.assertTrue(r['scenario_guardrails_acceptable']);self.assertIsNone(r['suggested_amount']);self.assertFalse(r['sizing_authorized_by_guardrails']);self.assertFalse(r['execution_authorized']);self.assertEqual(r['remaining_economic_blockers'],self.a['blocking_reasons'])
 def test_context_digest_prevents_stale_input(self):
  x=self.item();x['action_context_digest']='old'
  with self.assertRaises(ValueError):self.run_policy(x)
 def test_summary_exports_no_amounts_accounts_or_thresholds(self):
  s=json.dumps(p.summarize(self.run_policy()));self.assertNotIn('"account_id"',s);self.assertNotIn('"scenario_reference_amount"',s);self.assertNotIn('"threshold"',s)
 def test_build_readonly_absent_document(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data').mkdir();self.action['source_version_digest']=digest(actions.m.source_versions(root));before=list(root.rglob('*'));r=p.build(root,self.action,now=NOW);self.assertEqual(r['input_count'],0);self.assertEqual(before,list(root.rglob('*')));buy=next(x for x in r['assessments'] if x['kind']=='INCREASE');sell=next(x for x in r['assessments'] if x['kind']=='SELL');self.assertEqual(buy['sizing_guardrail_context']['financial_capacity'],'50');self.assertEqual(sell['sizing_guardrail_context']['available_quantity_upper_bound'],'2');self.assertIsNone(sell['sizing_guardrail_context']['financial_capacity'])
