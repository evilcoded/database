import copy,unittest
from decimal import Decimal
import test_a24_reallocation_analysis as fixture
from universal_portfolio import reallocation_analysis_a24 as m
class NetSizing(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Compare();self.f.setUp()
 def quote(self,i,side,amount,fee='1',**kw):
  return dict(account_id='account',currency='BRL',instrument_id=i,side=side,reference_amount=amount,evidence_id=side+amount,execution_venue_id='venue',components={k:{'status':'KNOWN' if k=='brokerage' else 'NOT_APPLICABLE','amount':fee if k=='brokerage' else None} for k in fixture.costs.COMPONENTS},**kw)
 def assess(self,amount='100',buy='98',fee='1',quotes=None):
  return m.attach_reviewed_costs(self.f.project(),quotes if quotes is not None else [self.quote(fixture.I,'SELL',amount,fee),self.quote(fixture.J,'BUY',buy,fee)])
 def scenario(self,**kw):return self.assess(**kw)['rows'][0]['reviewed_two_leg_cost_scenarios'][0]
 def test_partial_amount_preserves_remaining_position_and_no_cash(self):
  x=self.scenario();self.assertEqual(x['source_sale_reference_amount'],'100');self.assertEqual(x['remaining_source_reference_capital'],'100');self.assertEqual(x['reference_source_fraction'],'0.5');self.assertEqual(x['additional_cash_required'],'0')
 def test_partial_net_accounts_for_lost_destination_growth_of_fees(self):
  self.assertEqual(Decimal(self.scenario()['models'][0]['execution_cost_adjusted_uplift_amount']),Decimal('.90'))
 def test_fee_changes_can_reverse_sign_without_changing_model(self):
  x=self.scenario(fee='2',buy='96');self.assertLess(Decimal(x['models'][0]['execution_cost_adjusted_uplift_amount']),0);self.assertFalse(x['positive_in_all_available_models'])
 def test_above_position_capital_rejected(self):self.assertFalse(self.assess(amount='201',buy='199')['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_unfunded_buy_or_unexplained_remainder_rejected(self):
  for buy in ('99','97'):self.assertFalse(self.assess(buy=buy)['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_cross_currency_cannot_fund(self):
  rr=[self.quote(fixture.I,'SELL','100'),self.quote(fixture.J,'BUY','98')];rr[1]['currency']='USD';self.assertFalse(self.assess(quotes=rr)['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_cross_account_cannot_fund(self):
  rr=[self.quote(fixture.I,'SELL','100'),self.quote(fixture.J,'BUY','98')];rr[1]['account_id']='other';self.assertFalse(self.assess(quotes=rr)['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_missing_spread_not_assumed_zero(self):
  rr=[self.quote(fixture.I,'SELL','100'),self.quote(fixture.J,'BUY','98')];rr[1]['components']['spread']['status']='UNKNOWN';self.assertFalse(self.assess(quotes=rr)['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_quote_fees_not_scaled_to_half_position(self):
  x=self.scenario();self.assertEqual(x['sell_cost'],'1');self.assertEqual(x['buy_cost'],'1')
 def test_no_quotes_still_computes_model_break_even_not_actual_cost(self):
  r=self.assess(quotes=[]);c=r['rows'][0]['execution_cost_capacity_models'][0];self.assertLess(abs(Decimal(c['maximum_upfront_two_leg_cost'])-Decimal(40)/7),Decimal('1e-24'));self.assertFalse(r['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_break_even_is_discounted_not_gross_cash_delta(self):
  self.assertLess(Decimal(self.assess(quotes=[])['rows'][0]['execution_cost_capacity_models'][0]['maximum_upfront_two_leg_cost']),6)
 def test_arbitrary_currency_and_no_fx(self):
  r=self.f.project();r['rows'][0]['currency']='JPY';rr=[self.quote(fixture.I,'SELL','100'),self.quote(fixture.J,'BUY','98')]
  for q in rr:q['currency']='JPY'
  self.assertEqual(m.attach_reviewed_costs(r,rr)['partial_quote_scenario_count'],1)
 def test_alias_cannot_size_financial_position(self):
  r=self.f.project();r['rows'][0]['research_alias_used']=True;m.attach_reviewed_costs(r,[]);self.assertFalse(r['rows'][0]['execution_cost_capacity_models'])
 def test_multiple_amounts_remain_candidates_never_selected(self):
  rr=[self.quote(fixture.I,'SELL','100'),self.quote(fixture.J,'BUY','98'),self.quote(fixture.I,'SELL','200'),self.quote(fixture.J,'BUY','198')];before=copy.deepcopy(rr);r=self.assess(quotes=rr);self.assertEqual(rr,before);self.assertEqual(r['reviewed_cost_scenario_count'],2);self.assertEqual(r['partial_quote_scenario_count'],1);self.assertTrue(all(not x['selected'] for x in r['rows'][0]['reviewed_two_leg_cost_scenarios']))
 def test_partial_quote_does_not_cover_full_position_costs(self):
  row=self.assess()['rows'][0];self.assertIn('TWO_LEG_CURRENT_COSTS_REQUIRED',row['missing_reasons']);self.assertIn('COSTS_AVAILABLE_ONLY_FOR_QUOTED_PARTIAL_AMOUNTS',row['missing_reasons'])
 def test_no_authority_order_or_validated_sizing_added(self):
  r=self.assess();row=r['rows'][0];self.assertIsNone(row['requested_amount']);self.assertIsNone(row['requested_quantity']);self.assertFalse(r['net_returns_validated']);self.assertFalse(r['quote_amounts_are_selected_sizing']);self.assertFalse(row['sizing_created']);self.assertFalse(row['execution_authorized'])
