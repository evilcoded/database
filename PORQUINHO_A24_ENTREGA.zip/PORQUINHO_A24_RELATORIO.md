# Porquinho — entrega A24

Estado: integração offline implementada e testada com fixtures sintéticas. A publicação canônica e recomendações com dados reais NÃO foram demonstradas.

## Reconciliação da entrada

ZIP íntegro: 2.277 entradas, aproximadamente 43 MB descompactados. Os hashes dos sete arquivos-alvo originais foram conferidos contra o manifesto enviado. A composição recebida corresponde exatamente ao resultado do A23: a reversão da substituição feita pelo patch A23 reproduz o SHA-256 A22 esperado pelo próprio patch. Isso confirma o conteúdo desse arquivo, não o estado de um processo no Mac.

## Falha funcional corrigida

`universal_cycle_orchestrator.run_offline_cycle` passa `result.payload` à etapa seguinte. O A23 tentava ler novamente `sizing_payload['payload']` em `snapshot_adapter`, descartando a entrada real. Reproduzido na composição A23 original: `ValueError: A2_SIZING_STAGE_PAYLOAD_REQUIRED`, inclusive em raiz vazia. O A24 usa o conteúdo já desembrulhado e percorre as cinco etapas do orquestrador existente.

## Alterações

- Ponte de observação transporta exclusivamente envelopes econômicos explícitos dos artefatos já lidos pelo projeto: `results/latest.json`, `data/equities/decision_latest.json`, `data/fixed_income_positions/valuation_observations.json`. Não cria um motor econômico, fontes de previsão ou arquivos de dados.
- Os nomes de entrada reutilizam o contrato existente: `governed_economic_alternatives`, `governed_economic_source_refs`, `governed_economic_sizing_candidates`. Fatos de mercado comuns não são convertidos em alternativas validadas. Múltiplas fontes concorrentes, instrumentos não observados, escopos e horizontes incompatíveis são rejeitados sem selecionar um subconjunto conveniente.
- Usa os construtores existentes de modelos/evidências de edge e sizing para dados serializados; não inventa modelos, montantes, custos ou retornos.
- Vincula sizing a alternativa, conteúdo completo da comparação (SHA-256), conta, moeda, instrumentos, ação e horizonte. O produtor de sizing precisa fornecer `alternative_id` e `comparison_id` correspondentes; o transporte não inventa esse vínculo. O hash identifica conteúdo, não certifica qualidade econômica ou autoridade.
- Preserva metadado `destination_is_held` para manter a distinção DEPLOY_CASH/INCREASE do comparador existente.
- Zero fornecido por modelo válido aparece como NO_ALLOCATION; ausência de evidência não vira zero.
- A projeção pública e as funções da UI apresentam propostas com asterisco e abstenção explícita, sem recomendações canônicas ou autorização. Nenhuma tela nova. Preserva as etiquetas das oito ações pedidas.

## Validação executada no cloud/Linux

- 122 testes Python aprovados: 100 regressões existentes e 22 testes novos, com cenários adicionais em subtestes. Sem skips ou falhas esperadas.
- 14 verificações JavaScript aprovadas, executando as funções reais de projeção, correspondência de identidade e renderização extraídas de `static/app.js` no Node.
- Sintaxe Bash e JavaScript válida.
- Instalador executado em cópia A23: aplicação aprovada, hashes finais corretos, backups originais conferidos, sentinela financeira intacta.
- Segunda execução: ALREADY_APPLIED, sem nova escrita ou backup duplicado.
- Alteração posterior simulada: recusa antes de mutação, preservando todos os arquivos-alvo.
- Cada ciclo funcional confirma cinco etapas, zero snapshots canônicos, ausência de escrita de histórico/execução e hashes inalterados nos arquivos financeiros e de observação da fixture.

Os testes não iniciam `webapp.server`, não fazem requests de investimento nem importam inicializadores do aplicativo. A função real de projeção pública é extraída via AST para evitar efeitos colaterais de importação. Portanto, não demonstram funcionamento HTTP completo, navegação em browser, integração Bridge, atividade de learning ou operação real no Mac.

## Bloqueios concretos que permanecem

1. `governed_forward_return_estimator.estimate` sempre acrescenta `RESEARCH_LAB_NOT_YET_PROSPECTIVELY_VALIDATED_FOR_COMPARATOR` e mantém NOT_VALIDATED. Não é possível tratar seus números como previsões economicamente aprovadas sem evidência prospectiva e um contrato de promoção verificável.
2. Nas fontes recebidas, os adaptadores ativos não produzem o conjunto completo de alternativas econômicas governadas, modelos de sizing e vínculo à mesma comparação. O A24 transporta envelopes completos caso um produtor legítimo os forneça; não preenche essas lacunas com flags ou fixtures de produção. Na ausência desses produtores, o resultado legítimo é ABSTAIN com motivos.
3. `_verified_canonical_producer_boundary` permanece bloqueado: não há raiz de confiança independente verificada. Nenhuma proposta experimental foi promovida. O campo canônico continua nulo.
4. O ZIP exclui dados reais, modelos, memória e aprendizagem intencionalmente. Não foi demonstrada a integridade desses artefatos nem a execução do runtime do Mac. O instalador não deve ser confundido com essa validação.

Esses pontos impedem declarar o A24 integralmente concluído segundo o critério de recomendações reais. A entrega resolve a falha do ciclo, integra o transporte explícito e demonstra o percurso completo com entradas sintéticas identificadas, sem simular evidência ou autoridade financeira.

## Execução no Mac

Baixe o arquivo `.command` para Downloads e execute:

```bash
cd ~/Downloads
chmod +x PORQUINHO_A24_GOVERNED_ECONOMIC_INTEGRATION.command
./PORQUINHO_A24_GOVERNED_ECONOMIC_INTEGRATION.command
```

Requer Python 3.10+ (prefere o Python da `.venv` existente) e Node.js para executar as regressões JavaScript. Não instala dependências automaticamente. O caminho padrão é `~/Desktop/Bridge_Companion/porquinho_v33_web_foundation-2`. Para outra localização, use `PORQUINHO_ROOT="/caminho/do/projeto" ./PORQUINHO_A24_GOVERNED_ECONOMIC_INTEGRATION.command`.

Antes de escrever, verifica os hashes dos alvos e testes existentes e executa as regressões em cópia temporária contendo somente fontes. Recusa diferenças posteriores ao ZIP. Aplica sete arquivos existentes e adiciona um módulo de transporte e dois arquivos de teste. Guarda backup dos originais em `.porquinho_a24_backup_<data>` na raiz do projeto. Em erro de aplicação tenta rollback; se detectar edição externa, preserva-a e exige revisão. Como qualquer atualização de vários arquivos, a troca não é uma transação atômica contra desligamento abrupto do computador.

Não reinicia serviços, não executa ordens e não altera dados financeiros, modelos, memória ou histórico. A atualização do código em processos já abertos exige uma ativação planejada pelo usuário; o instalador não a executa. Não restaurar a pasta inteira sobre dados atuais. Preserve o backup e envie a saída do Terminal para confirmar a execução no Mac.
