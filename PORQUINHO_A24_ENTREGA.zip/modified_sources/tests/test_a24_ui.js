// SYNTHETIC FIXTURES ONLY. Execute the actual UI projection/rendering functions.
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('static/app.js','utf8');
const start=source.indexOf('function a8Projection(){'),end=source.indexOf('function a8Mount(host)',start);
assert(start>=0&&end>start);
const c={lastStatus:{},esc:s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')};
vm.createContext(c);vm.runInContext(source.slice(start,end),c);
const labels={KEEP:'MANTER',DEPLOY_CASH:'APLICAR SALDO',INCREASE:'AUMENTAR',REDUCE:'REDUZIR',SELL:'VENDER',REALLOCATE:'REALOCAR',ABSTAIN:'ABSTER-SE',NO_ALLOCATION:'NÃO ALOCAR'};
let count=0;
function check(name,fn){fn();count++;console.log('PASS '+name)}
function set(action){c.lastStatus={economic_decision_ui_projection:{schema:'porquinho.a6-shadow-ui-transport/1.0',status:'EXPERIMENTAL_DECISION_AVAILABLE',canonical_decision_available:false,canonical_investment_recommendation:null,execution_authorized:false,experimental_brain_proposal:{action,instrument_id:'TEST:MKT:OTHER:A',account_id:'ACCOUNT',currency:'TST',alternative_id:'ALT',comparison_id:'HASH',horizon_unit:'DAY',horizon_value:30,asterisk_required:true,canonical_recommendation:false,authority_status:'EXPERIMENTAL_NOT_CANONICAL'}}};return c.lastStatus.economic_decision_ui_projection}
const row={instrument_id:'TEST:MKT:OTHER:A',account_id:'ACCOUNT',currency:'TST'};
for(const [action,label]of Object.entries(labels))check('label '+action,()=>{set(action);assert(c.a8ExperimentalBadge(row).includes(label+' *'));assert(c.a8EvidencePanel().includes(label+' *'))});
check('wrong account/currency/instrument has no badge',()=>{set('REALLOCATE');for(const field of ['account_id','currency','instrument_id'])assert.strictEqual(c.a8ExperimentalBadge({...row,[field]:'OTHER'}),'')});
check('canonical promotion refused',()=>{const x=set('SELL');x.experimental_brain_proposal.canonical_recommendation=true;assert.strictEqual(c.a8ExperimentalBadge(row),'')});
check('execution authority refused',()=>{const x=set('SELL');x.execution_authorized=true;assert.strictEqual(c.a8ExperimentalBadge(row),'')});
check('matched sizing displayed; other comparison rejected',()=>{const x=set('REALLOCATE'),p=x.experimental_brain_proposal;p.sizing_verified_for_observed_identity=true;p.governed_sizing_evidence={account_id:'ACCOUNT',currency:'TST',action:'REALLOCATE',alternative_id:'ALT',comparison_id:'HASH',horizon_unit:'DAY',horizon_value:30,suggested_amount:850};assert(!c.a8EvidencePanel().includes('sem valor dimensionado'));p.governed_sizing_evidence.comparison_id='OTHER';assert(c.a8EvidencePanel().includes('sem valor dimensionado'))});
check('abstention rendered without recommendation',()=>{const x=set('ABSTAIN');x.status='UNAVAILABLE';x.experimental_brain_proposal=null;x.economic_abstention={action:'ABSTAIN',authority:'NONE',execution_authorized:false,reasons:['GOVERNED_ALTERNATIVES_NOT_SUPPLIED']};assert(c.a8EvidencePanel().includes('Brain — ABSTER-SE'));assert(c.a8EvidencePanel().includes('Ainda não há alternativas'))});
check('no projection has no fabricated badge/panel',()=>{c.lastStatus={};assert.strictEqual(c.a8EvidencePanel(),'');assert.strictEqual(c.a8ExperimentalBadge(row),'')});
console.log('UI_TESTS_PASSED='+count);
