"""SYNTHETIC TEST FIXTURES ONLY: no investment evidence or financial authority."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from universal_portfolio.universal_runtime_composition import compose_shadow_cycle
from universal_portfolio.governed_comparison_producer_a2 import produce_governed_comparisons
from universal_portfolio.governed_economic_input_transport_a24 import comparison_identity
from test_universal_economic_edge_authority_r21386ly9k import model as edge_model, evidence as edge_evidence
from test_adaptive_universal_sizing_authority_r21386ly9l import model as sizing_model, decision as sizing_decision

ROOT = Path(__file__).resolve().parents[1]
SRC = 'TEST:MKT:EQUITY:SOURCE_A'
DST = 'TEST:MKT:LISTED_FUND:DESTINATION_B'


def envelope(kind='ROTATE_POSITION', amount=850.0):
    rows = []
    for aid, iid, row_kind, utility in [('keep', SRC, 'KEEP_POSITION', .01),
                                        ('move', DST, kind, .08)]:
        evidence = dict(instrument_id=iid, account_id='TEST_ACCOUNT', currency='TST',
                        horizon='TEST_30_DAYS', horizon_unit='DAY', horizon_value=30,
                        forward_return=.08, transaction_cost=.01, risk_measure=.03,
                        counterfactual_return=.04, reference_capital=1000.,
                        forward_return_validated=True, transaction_cost_validated=True,
                        risk_validated=True, counterfactual_validated=True,
                        provenance={'source': 'SYNTHETIC_TEST_FIXTURE_ONLY'})
        row = dict(alternative_id=aid, instrument_id=iid, account_id='TEST_ACCOUNT',
                   currency='TST', kind=row_kind, evidence=evidence,
                   relative_utility=utility, relative_utility_validated=True,
                   relative_utility_provenance={'source': 'SYNTHETIC_TEST_FIXTURE_ONLY'},
                   source_instrument_id=SRC,
                   destination_instrument_id=DST if aid == 'move' else None)
        rows.append(row)
    data = dict(governed_economic_alternatives=rows,
                governed_economic_source_refs=['SYNTHETIC_TEST_FIXTURE_ONLY'])
    identity = comparison_identity(produce_governed_comparisons(data)['comparison_rows'])
    data['governed_economic_sizing_candidates'] = [dict(
        edge_model=edge_model()['model'].payload(),
        edge_evidence=edge_evidence()['evidence'].payload(),
        sizing_model=sizing_model()['model'].payload(),
        sizing_decision=sizing_decision(amount=amount)['decision'].payload(),
        alternative_id='move', comparison_id=identity, account_id='TEST_ACCOUNT',
        currency='TST', horizon_unit='DAY', horizon_value=30,
        financial_capacity=5000., liquidity_capacity=2800.,
        risk_policy_acceptable=True, liquidity_policy_acceptable=True,
        concentration_policy_acceptable=True)]
    return data


def public_projection(value):
    # Execute the actual server function without importing the live application's
    # startup, schedulers, financial stores or network integrations.
    module = ast.parse((ROOT/'webapp/server.py').read_text())
    fn = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == '_a6_safe_projection')
    ns = {}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), 'webapp/server.py', 'exec'), ns)
    return ns['_a6_safe_projection'](value)


class Integration(unittest.TestCase):
    def run_cycle(self, data=None, source='results/latest.json', second=False):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            def write(rel, value):
                p=root/rel; p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(json.dumps(value))
            write('data/universal_positions.json', {'positions':[{'instrument_id':SRC},{'instrument_id':DST}]})
            write('data/universal_instrument_catalog.json', {'instruments':[
                dict(instrument_id=i, asset_class=i.split(':')[2], market='MKT',
                     jurisdiction='TEST', currency='TST') for i in (SRC,DST)]})
            write('data/ledger.json', {'sentinel': 'MUST_NOT_CHANGE'})
            if data is not None:
                write(source, data)
                if second: write('data/equities/decision_latest.json', data)
            before={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in root.rglob('*') if p.is_file()}
            out=compose_shadow_cycle(root, observed_at='2026-10-15T00:00:00Z',
                                     started_at='2026-10-15T00:00:00Z', cycle_seed='SYNTHETIC_A24_TEST')
            after={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in root.rglob('*') if p.is_file()}
            self.assertEqual(before,after, 'Financial/observation files must not change')
            self.assertIsNone(out.economic_decision_ui_projection['canonical_investment_recommendation'])
            self.assertFalse(out.economic_decision_ui_projection['execution_authorized'])
            self.assertEqual(len(out.bridge.candidates), 2)
            self.assertEqual(out.cycle.recommendation_snapshots, ())
            self.assertFalse(out.cycle.financial_mutation)
            self.assertFalse(out.cycle.history_write_performed)
            self.assertFalse(out.cycle.execution_performed)
            self.assertEqual([stage.stage for stage in out.cycle.stages],
                             ['UNIVERSE','SPECIALIZED_INTELLIGENCE','ECONOMIC_DECISION',
                              'SIZING','RECOMMENDATION_SNAPSHOT'])
            return out

    def proposal(self, data):
        return self.run_cycle(data).economic_decision_ui_projection['experimental_brain_proposal']

    def test_real_bridge_to_comparison_sizing_public_transport(self):
        out=self.run_cycle(envelope())
        p=out.economic_decision_ui_projection['experimental_brain_proposal']
        self.assertEqual(p['action'],'REALLOCATE')
        self.assertEqual(p['action_label_pt'],'REALOCAR *')
        self.assertTrue(p['sizing_verified_for_observed_identity'])
        self.assertEqual(p['governed_sizing_evidence']['suggested_amount'],850.)
        public=public_projection(out.economic_decision_ui_projection)
        self.assertEqual(public['experimental_brain_proposal']['governed_sizing_evidence']['suggested_amount'],850.)
        self.assertNotIn('edge_model',json.dumps(public))
        self.assertIsNone(public['canonical_investment_recommendation'])
        self.assertFalse(public['execution_authorized'])

    def test_no_producer_returns_explicit_abstention(self):
        out=self.run_cycle()
        p=public_projection(out.economic_decision_ui_projection)
        self.assertEqual(p['economic_abstention']['action'],'ABSTAIN')
        self.assertIn('GOVERNED_ALTERNATIVES_NOT_SUPPLIED',p['economic_abstention']['reasons'])

    def test_each_existing_artifact_transports_same_contract(self):
        for path in ('results/latest.json','data/equities/decision_latest.json',
                     'data/fixed_income_positions/valuation_observations.json'):
            with self.subTest(path=path):
                self.assertIsNotNone(self.run_cycle(envelope(),source=path).economic_decision_ui_projection['experimental_brain_proposal'])

    def test_research_forecast_is_not_governed_evidence(self):
        data={'status':'OK','predictions':[{'instrument_id':DST,'prediction_30d_pct':99}]}
        out=self.run_cycle(data,source='results/prediction_lab.json')
        self.assertIsNone(out.economic_decision_ui_projection['experimental_brain_proposal'])
        self.assertEqual(out.economic_decision_ui_projection['economic_abstention']['action'],'ABSTAIN')

    def test_research_authority_rejected(self):
        d=envelope();d['governed_economic_alternatives'][1]['evidence']['authority']='RESEARCH_ONLY'
        self.assertIsNone(self.proposal(d))

    def test_missing_and_contradictory_evidence(self):
        for field,value in [('forward_return',None),('forward_return_validated',False),
                            ('instrument_id',SRC),('account_id','OTHER'),('currency','OTHER'),
                            ('risk_measure',float('nan'))]:
            with self.subTest(field=field):
                d=envelope();d['governed_economic_alternatives'][1]['evidence'][field]=value
                self.assertIsNone(self.proposal(d))

    def test_cross_account_and_currency_rejected(self):
        for field in ('account_id','currency'):
            with self.subTest(field=field):
                d=envelope(); row=d['governed_economic_alternatives'][1]
                row[field]='OTHER'; row['evidence'][field]='OTHER'
                self.assertIsNone(self.proposal(d))

    def test_horizon_contradiction_rejected(self):
        for field,value in [('horizon','OTHER'),('horizon_value',60),('horizon_value',True)]:
            d=envelope();d['governed_economic_alternatives'][1]['evidence'][field]=value
            self.assertIsNone(self.proposal(d))

    def test_missing_source_refs_rejected(self):
        d=envelope();del d['governed_economic_source_refs']
        self.assertIsNone(self.proposal(d))

    def test_ambiguous_sources_rejected(self):
        p=self.run_cycle(envelope(),second=True).economic_decision_ui_projection
        self.assertIsNone(p['experimental_brain_proposal'])
        self.assertEqual(p['economic_comparison_intake_reason'],'AMBIGUOUS_GOVERNED_SOURCE_ENVELOPES')

    def test_unobserved_instrument_rejected(self):
        d=envelope();d['governed_economic_alternatives'][1]['instrument_id']='TEST:MKT:OTHER:NOT_OBSERVED'
        self.assertIsNone(self.proposal(d))

    def test_mismatched_decision_sizing_does_not_clear_gate(self):
        for field,value in [('alternative_id','other'),('comparison_id','sha256:other'),
                            ('account_id','other'),('currency','OTHER'),('horizon_value',60)]:
            with self.subTest(field=field):
                d=envelope();d['governed_economic_sizing_candidates'][0][field]=value
                p=self.proposal(d)
                self.assertFalse(p['sizing_verified_for_observed_identity'])

    def test_invalid_sizing_or_capacity_keeps_decision_without_amount(self):
        for amount in (6000., -1., None):
            d=envelope();d['governed_economic_sizing_candidates'][0]['sizing_decision']['model_amount']=amount
            p=self.proposal(d)
            self.assertEqual(p['action'],'REALLOCATE')
            self.assertIsNone(p['governed_sizing_evidence'])

    def test_unvalidated_models_cannot_supply_sizing(self):
        for field in ('edge_model','sizing_model'):
            d=envelope();d['governed_economic_sizing_candidates'][0][field]['validated']=False
            self.assertFalse(self.proposal(d)['sizing_verified_for_observed_identity'])

    def test_duplicate_sizing_is_ambiguous(self):
        d=envelope();d['governed_economic_sizing_candidates']*=2
        self.assertFalse(self.proposal(d)['sizing_verified_for_observed_identity'])

    def test_zero_model_amount_preserves_no_allocation(self):
        p=self.proposal(envelope(amount=0.))
        self.assertEqual(p['action'],'NO_ALLOCATION')
        self.assertEqual(p['action_label_pt'],'NÃO ALOCAR *')
        self.assertEqual(p['economic_comparison_action'],'REALLOCATE')
        self.assertEqual(p['governed_sizing_evidence']['suggested_amount'],0.)
        self.assertTrue(p['sizing_verified_for_observed_identity'])
        out=public_projection({'experimental_brain_proposal':p})
        self.assertEqual(out['experimental_brain_proposal']['action'],'NO_ALLOCATION')

    def test_increase_metadata_survives_comparison(self):
        d=envelope(kind='DEPLOY_CASH')
        d['governed_economic_alternatives'][1]['metadata']={'destination_is_held':True}
        self.assertEqual(self.proposal(d)['action'],'INCREASE')

    def test_keep_is_visible_without_invented_sizing(self):
        d=envelope();d['governed_economic_alternatives'][0]['relative_utility']=1.
        p=self.proposal(d)
        self.assertEqual(p['action'],'KEEP')
        self.assertEqual(p['instrument_id'],SRC)
        self.assertIsNone(p['governed_sizing_evidence'])

    def test_independent_scopes_preserve_original_currencies(self):
        for currency in ('AAA','BBB'):
            d=envelope()
            for row in d['governed_economic_alternatives']:
                row['currency']=currency;row['evidence']['currency']=currency
            p=self.proposal(d)
            self.assertEqual(p['currency'],currency)
            self.assertIsNone(p['governed_sizing_evidence'])

    def test_public_projection_rejects_sizing_for_other_comparison(self):
        p=self.proposal(envelope())
        p['governed_sizing_evidence']['comparison_id']='other'
        out=public_projection({'experimental_brain_proposal':p})
        self.assertFalse(out['experimental_brain_proposal']['sizing_verified_for_observed_identity'])
        self.assertNotIn('governed_sizing_evidence',out['experimental_brain_proposal'])

    def test_public_projection_refuses_self_promoted_canonical_flag(self):
        p=self.proposal(envelope());p['canonical_recommendation']=True
        self.assertIsNone(public_projection({'experimental_brain_proposal':p})['experimental_brain_proposal'])

    def test_status_projection_roundtrip_keeps_abstention(self):
        first=public_projection(self.run_cycle().economic_decision_ui_projection)
        self.assertEqual(first,public_projection(first))

if __name__=='__main__': unittest.main()
