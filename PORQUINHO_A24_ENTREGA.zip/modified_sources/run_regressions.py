"""Run only the selected offline regressions from a source-only staging root."""
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'tests'))
patterns = [
 'test_universal_runtime_composition_r21386ly11d1.py',
 'test_universal_observation_bridge_r21386ly11c.py',
 'test_universal_economic_decision_r21386ly9.py',
 'test_universal_real_economic_evidence_bridge_r21386ly9a.py',
 'test_universal_economic_edge_authority_r21386ly9k.py',
 'test_adaptive_universal_sizing_authority_r21386ly9l.py',
 'test_capital_economic_evidence_assembly_r21386ij.py',
 'test_capital_relative_utility_r21386ih.py',
 'test_a24_governed_economic_integration.py',
]
suite=unittest.TestSuite()
for pattern in patterns:
 suite.addTests(unittest.defaultTestLoader.discover(str(ROOT/'tests'), pattern=pattern))
result=unittest.TextTestRunner(verbosity=1).run(suite)
if result.testsRun != 122 or result.skipped or result.expectedFailures:
 raise SystemExit('FAIL_CLOSED: expected exactly 122 tests, no skipped/expected-failure tests')
if not result.wasSuccessful(): raise SystemExit(1)
print('PYTHON_REGRESSION_OK=122')
