"""A2 read-only composition of existing economic-edge and sizing authorities.

This module DOES NOT promote observations to canonical recommendations, authorize
trades, write recommendation history, or perform any financial mutation.
"""
from __future__ import annotations
from typing import Any

from .universal_economic_edge_authority import (
    EconomicEdgeModel, EconomicEdgeEvidence, evaluate_edge, EDGE_SUPPORTED,
)
from .adaptive_universal_sizing_authority import (
    AdaptiveSizingModel, AdaptiveSizingDecision, evaluate_sizing,
    SIZING_READY, NO_ALLOCATION,
)


def assess_candidate(
    *,
    edge_model: EconomicEdgeModel | None,
    edge_evidence: EconomicEdgeEvidence | None,
    sizing_model: AdaptiveSizingModel | None,
    sizing_decision: AdaptiveSizingDecision | None,
    account_id: str,
    currency: str,
    horizon_unit: str,
    horizon_value: int,
    financial_capacity: Any,
    liquidity_capacity: Any,
    risk_policy_acceptable: bool,
    liquidity_policy_acceptable: bool,
    concentration_policy_acceptable: bool,
) -> dict[str, Any]:
    """Evaluate already-provided, model-governed evidence; never invent sizing."""
    unavailable = {
        "status": "A2_CANDIDATE_UNAVAILABLE",
        "canonical_recommendation": False,
        "execution_authorized": False,
        "financial_mutation": False,
        "suggested_amount": None,
        "action": None,
    }
    # Enforce scope before invoking the existing evaluators. Their own checks
    # remain authoritative and can reject additional mismatches.
    if not account_id or not currency or not horizon_unit or type(horizon_value) is not int or horizon_value <= 0:
        return {**unavailable, "reasons": ("SCOPE_REQUIRED",)}
    if edge_model is None or edge_evidence is None:
        return {**unavailable, "reasons": ("ECONOMIC_EDGE_EVIDENCE_REQUIRED",)}
    try:
        edge = evaluate_edge(
            edge_model, edge_evidence, account_id=account_id,
            currency=currency, horizon_unit=horizon_unit,
            horizon_value=horizon_value,
        )
    except (TypeError, ValueError, AttributeError, KeyError):
        return {**unavailable, "reasons": ("ECONOMIC_EDGE_CONTRACT_MISMATCH",)}
    if edge.get("status") != EDGE_SUPPORTED or edge.get("edge_supported") is not True:
        return {**unavailable, "reasons": ("ECONOMIC_EDGE_NOT_SUPPORTED",),
                "edge_status": edge.get("status")}
    if sizing_model is None or sizing_decision is None:
        return {**unavailable, "reasons": ("SIZING_AUTHORITY_REQUIRED",),
                "edge_status": EDGE_SUPPORTED}
    if sizing_decision.destination_instrument_id != edge_evidence.destination_instrument_id or sizing_decision.source_instrument_id != edge_evidence.source_instrument_id:
        return {**unavailable, "reasons": ("ECONOMIC_SIZING_IDENTITY_MISMATCH",),
                "edge_status": EDGE_SUPPORTED}
    try:
        sizing = evaluate_sizing(
            sizing_model, sizing_decision, account_id=account_id,
            currency=currency, horizon_unit=horizon_unit,
            horizon_value=horizon_value,
            financial_capacity=financial_capacity,
            liquidity_capacity=liquidity_capacity,
            economic_edge_status=edge["status"],
            risk_policy_acceptable=risk_policy_acceptable,
            liquidity_policy_acceptable=liquidity_policy_acceptable,
            concentration_policy_acceptable=concentration_policy_acceptable,
        )
    except (TypeError, ValueError, AttributeError, KeyError):
        return {**unavailable, "reasons": ("SIZING_CONTRACT_MISMATCH",),
                "edge_status": EDGE_SUPPORTED}
    if sizing.get("status") not in (SIZING_READY, NO_ALLOCATION):
        return {**unavailable, "reasons": tuple(sizing.get("reasons") or ("SIZING_UNAVAILABLE",)),
                "edge_status": EDGE_SUPPORTED, "sizing_status": sizing.get("status")}
    return {
        "status": "A2_ECONOMIC_SIZING_ASSESSED_NOT_PROMOTED",
        "canonical_recommendation": False,
        "execution_authorized": False,
        "financial_mutation": False,
        "edge_status": edge["status"],
        "sizing_status": sizing["status"],
        "sizing_input_action": sizing_decision.action,
        "action": sizing.get("action") if sizing["status"] == SIZING_READY else "NO_ALLOCATION",
        "suggested_amount": sizing["suggested_amount"],
        "source_instrument_id": sizing.get("source_instrument_id"),
        "destination_instrument_id": sizing.get("destination_instrument_id"),
        "account_id": account_id,
        "currency": currency.upper(),
        "horizon_unit": horizon_unit.upper(),
        "horizon_value": horizon_value,
        "reasons": ("CANONICAL_PROMOTION_NOT_PROVEN",),
    }
