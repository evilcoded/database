from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from .universal_cycle_orchestrator import new_cycle_context, run_offline_cycle
from .universal_observation_bridge import build_read_only_bridge

@dataclass(frozen=True)
class UniversalRuntimeCompositionResult:
    cycle: Any
    bridge: Any
    mode: str = "SHADOW_OFFLINE_NO_HISTORY_WRITE"
    economic_comparison_rows: tuple | None = None
    economic_sizing_assessments: tuple = ()
    economic_decision_observation: dict | None = None
    economic_decision_ui_projection: dict | None = None
    economic_comparison_intake: dict | None = None

def _env(status: str, source_refs, payload):
    refs=tuple(str(x).strip() for x in (source_refs or ()) if str(x).strip())
    if not refs:
        raise ValueError("STAGE_SOURCE_REFS_REQUIRED")
    return {
        "status": status,
        "source_refs": refs,
        "payload": payload,
        "execution_performed": False,
        "financial_mutation": False,
        "history_write_performed": False,
    }

def _validated_economic_rows(intelligence):
    # Explicit validated economic alternatives only; no inference from signals.
    from collections.abc import Mapping
    if not isinstance(intelligence,Mapping): return None
    if intelligence.get("economic_comparison_status")!="VALIDATED": return None
    refs=intelligence.get("economic_comparison_source_refs")
    if not isinstance(refs,(tuple,list)) or not refs or not all(isinstance(x,str) and x.strip() for x in refs): return None
    rows=intelligence.get("economic_comparison_rows")
    if not isinstance(rows,(tuple,list)) or not rows or not all(isinstance(x,Mapping) for x in rows): return None
    return tuple(dict(x) for x in rows)


def _candidate_forward_return_observations(root,candidates):
    from .candidate_forward_return_observations_a2 import candidate_forward_return_observations
    return candidate_forward_return_observations(root,candidates)


def _economic_evidence_source_status(root):
    from .economic_evidence_source_status_a2 import evidence_source_status
    return evidence_source_status(root)


def _economic_comparison_intake(intelligence):
    # Consume only explicitly validated, provenance-bearing alternatives.
    # The boundary remains the sole decision evaluator; this is not promotion.
    from .governed_comparison_producer_a2 import produce_governed_comparisons
    result = produce_governed_comparisons(intelligence)
    transport = intelligence.get("economic_input_transport") if isinstance(intelligence, dict) else None
    if isinstance(transport, dict) and transport.get("status") == "UNAVAILABLE" and transport.get("reason") != "GOVERNED_ENVELOPE_NOT_PRODUCED":
        result.update(status="UNAVAILABLE", reason=transport["reason"], comparison_rows=(), source_refs=())
    return result



def _selected_economic_comparisons(intelligence):
    """One governed producer decision per intake; no legacy fallback on rejection."""
    from collections.abc import Mapping
    intake = _economic_comparison_intake(intelligence)
    if not isinstance(intelligence, Mapping):
        return (), (), intake
    # A governed submission must be assessed by its actual producer. A rejected
    # submission cannot be rescued by an unrelated legacy VALIDATED flag.
    if "governed_economic_alternatives" in intelligence:
        return (tuple(intake["comparison_rows"]), tuple(intake["source_refs"]), intake)
    legacy = _validated_economic_rows(intelligence)
    if legacy is not None:
        return (legacy, tuple(intelligence["economic_comparison_source_refs"]), intake)
    return (), (), intake


def _assess_supplied_governed_candidates(intelligence):
    """Only already-typed, explicitly governed candidate inputs; no inference."""
    from collections.abc import Mapping
    from .a2_economic_sizing_bridge import assess_candidate
    from .universal_economic_edge_authority import EconomicEdgeModel, EconomicEdgeEvidence
    from .adaptive_universal_sizing_authority import AdaptiveSizingModel, AdaptiveSizingDecision
    if not isinstance(intelligence, Mapping):
        return ()
    candidates = intelligence.get("governed_economic_sizing_candidates")
    if not isinstance(candidates, (tuple, list)):
        return ()
    outcomes = []
    for item in candidates:
        if not isinstance(item, Mapping):
            continue
        from .governed_economic_input_transport_a24 import typed_candidate
        item = typed_candidate(item)
        if not (isinstance(item.get("edge_model"), EconomicEdgeModel)
                and isinstance(item.get("edge_evidence"), EconomicEdgeEvidence)
                and isinstance(item.get("sizing_model"), AdaptiveSizingModel)
                and isinstance(item.get("sizing_decision"), AdaptiveSizingDecision)):
            outcomes.append({"status": "A2_CANDIDATE_UNAVAILABLE",
                             "reasons": ("TYPED_GOVERNED_INPUTS_REQUIRED",),
                             "canonical_recommendation": False,
                             "execution_authorized": False,
                             "financial_mutation": False,
                             "suggested_amount": None,
                             "action": None})
            continue
        required = ("account_id", "currency", "horizon_unit", "horizon_value",
                    "financial_capacity", "liquidity_capacity",
                    "risk_policy_acceptable", "liquidity_policy_acceptable",
                    "concentration_policy_acceptable")
        if any(key not in item for key in required):
            outcomes.append({"status": "A2_CANDIDATE_UNAVAILABLE",
                             "reasons": ("EXPLICIT_CAPACITY_AND_POLICY_REQUIRED",),
                             "canonical_recommendation": False,
                             "execution_authorized": False,
                             "financial_mutation": False,
                             "suggested_amount": None,
                             "action": None})
            continue
        outcome = assess_candidate(**{key: item[key] for key in required},
                                   edge_model=item["edge_model"],
                                   edge_evidence=item["edge_evidence"],
                                   sizing_model=item["sizing_model"],
                                   sizing_decision=item["sizing_decision"])
        outcome.update(alternative_id=item.get("alternative_id"),
                       comparison_id=item.get("comparison_id"))
        outcomes.append(outcome)
    return tuple(outcomes)


def _economic_decision_ui_projection(observation, *, comparison_rows, sizing_assessments):
    """Read-only logical output for existing UI consumers; never canonical promotion."""
    from collections.abc import Mapping
    obs = observation if isinstance(observation, Mapping) else {}
    publication = obs.get("publication")
    publication = publication if isinstance(publication, Mapping) else {}
    evidence = publication.get("decision")
    evidence = evidence if isinstance(evidence, Mapping) else None
    comparisons_present = bool(comparison_rows)
    if not comparisons_present:
        reason = "COMPARISON_PRODUCER_OR_VALIDATED_EVIDENCE_UNAVAILABLE"
    elif publication.get("status") != "ECONOMIC_DECISION_OBSERVED":
        reason = str(obs.get("reason") or publication.get("status") or "ECONOMIC_DECISION_NOT_READY")
    elif not sizing_assessments:
        reason = "GOVERNED_SIZING_NOT_PROVEN"
    else:
        reason = "CANONICAL_RECOMMENDATION_AUTHORITY_NOT_PROVEN"
    # Evidence-only decisions must never be rendered as canonical investment actions.
    experimental = None
    if evidence and publication.get("status") == "ECONOMIC_DECISION_OBSERVED":
        experimental = {
            "action": evidence.get("action"),
            "account_id": evidence.get("account_id"),
            "currency": evidence.get("currency"),
            "alternative_id": evidence.get("alternative_id"),
            "instrument_id": evidence.get("instrument_id"),
            "comparison_id": evidence.get("comparison_id"),
            "horizon_unit": evidence.get("horizon_unit"),
            "horizon_value": evidence.get("horizon_value"),
            "source_instrument_id": evidence.get("source_instrument_id"),
            "destination_instrument_id": evidence.get("destination_instrument_id"),
            "source": "BRAIN_ECONOMIC_EVIDENCE_ONLY",
            "asterisk_required": True,
            "canonical_recommendation": False,
        }
    # Match governed sizing to the observed decision by full economic identity.
    # Never infer a size from an unrelated account, currency or instrument.
    governed_sizing = None
    if experimental:
        matching = []
        for assessment in sizing_assessments or ():
            if not isinstance(assessment, Mapping):
                continue
            if assessment.get("status") != "A2_ECONOMIC_SIZING_ASSESSED_NOT_PROMOTED":
                continue
            if assessment.get("sizing_status") not in ("SIZING_READY", "NO_ALLOCATION"):
                continue
            if any(assessment.get(field) != experimental.get(field) for field in
                   ("account_id", "currency", "source_instrument_id", "destination_instrument_id",
                    "alternative_id", "comparison_id", "horizon_unit", "horizon_value")):
                continue
            if not experimental.get("comparison_id") or not experimental.get("alternative_id"):
                continue
            if (not isinstance(experimental.get("horizon_unit"), str)
                    or type(experimental.get("horizon_value")) is not int
                    or experimental["horizon_value"] <= 0):
                continue
            if assessment.get("sizing_input_action", assessment.get("action")) != experimental.get("action"):
                continue
            matching.append(assessment)
        # Ambiguous independent sizing evidence is not safe to project.
        if len(matching) == 1:
            a = matching[0]
            governed_sizing = {
                "status": a["sizing_status"],
                "action": a["action"],
                "observed_action": experimental["action"],
                "alternative_id": a["alternative_id"],
                "comparison_id": a["comparison_id"],
                "suggested_amount": a.get("suggested_amount"),
                "currency": a["currency"],
                "account_id": a["account_id"],
                "horizon_unit": a["horizon_unit"],
                "horizon_value": a["horizon_value"],
                "canonical_recommendation": False,
                "execution_authorized": False,
            }
    # A5: universal, read-only action labels for experimental proposals only.
    labels = {"KEEP":"MANTER", "DEPLOY_CASH":"APLICAR SALDO", "INCREASE":"AUMENTAR", "REDUCE":"REDUZIR", "SELL":"VENDER", "REALLOCATE":"REALOCAR", "ABSTAIN":"ABSTER-SE", "NO_ALLOCATION":"NÃO ALOCAR"}
    if experimental is not None:
        action = experimental.get("action")
        # Experimental identity must be explicit; never attach unscoped
        # economic evidence to an account, currency or instrument UI row.
        account = experimental.get("account_id")
        currency = experimental.get("currency")
        if (action not in labels or not isinstance(account, str) or not account.strip()
                or not isinstance(currency, str) or not currency.strip()):
            experimental = None
        else:
            experimental["action_label_pt"] = labels[action] + " *"
            experimental["authority_status"] = "EXPERIMENTAL_NOT_CANONICAL"
            experimental["publication_ready"] = False
    if experimental is not None and governed_sizing is not None and governed_sizing["status"] == "NO_ALLOCATION":
        experimental["economic_comparison_action"] = experimental["action"]
        experimental["action"] = "NO_ALLOCATION"
        experimental["action_label_pt"] = labels["NO_ALLOCATION"] + " *"
    if experimental is not None:
        experimental["governed_sizing_evidence"] = governed_sizing
        experimental["sizing_verified_for_observed_identity"] = governed_sizing is not None
    # A9: make the missing canonical producer contract observable, without
    # mistaking model-governed evidence for an authorized publisher.
    producer_gate = {
        "status": "BLOCKED_UNTIL_VERIFIED_PRODUCER",
        "economic_decision_observed": bool(experimental),
        "governed_sizing_identity_matched": governed_sizing is not None,
        "verified_recommendation_producer": False,
        "canonical_publication_authorized": False,
        "reason": ("VERIFIED_RECOMMENDATION_PRODUCER_REQUIRED"
                   if governed_sizing is not None else
                   "GOVERNED_SIZING_AND_PRODUCER_REQUIRED"),
    }
    # Preserve research-only economic comparison visibility by account/currency.
    # No FX aggregation, no ranking, no inferred canonical authority.
    groups={}
    for item in comparison_rows or ():
        if not isinstance(item, Mapping):
            continue
        account=item.get("account_id")
        currency=item.get("currency")
        if not isinstance(account,str) or not account.strip():
            continue
        if not isinstance(currency,str) or not currency.strip():
            continue
        key=(account.strip(),currency.strip().upper())
        groups[key]=groups.get(key,0)+1
    research_groups=[{"account_id":account,"currency":currency,
                      "comparison_row_count":count,
                      "canonical_recommendation":False}
                     for (account,currency),count in sorted(groups.items())]
    return {
        "schema": "porquinho.a2-economic-decision-ui-projection/1.0",
        "status": "EXPERIMENTAL_DECISION_AVAILABLE" if experimental else "UNAVAILABLE",
        "reason": None if experimental else reason,
        "experimental_brain_proposal": experimental,
        "canonical_investment_recommendation": None,
        "governed_sizing_evidence": governed_sizing,
        "canonical_promotion_status": "BLOCKED_UNTIL_VERIFIED_PRODUCER",
        "canonical_producer_gate": producer_gate,
        "comparison_rows_received": len(comparison_rows or ()),
        "research_comparison_groups_by_currency": research_groups,
        "canonical_decision_available": False,
        "sizing_assessments_received": len(sizing_assessments or ()),
        "execution_authorized": False,
        "financial_mutation": False,
        "legacy_action_promotion": False,
        "cross_currency_aggregation": False,
    }


def _verified_canonical_producer_boundary(*, producer, observed_decision, sizing_evidence):
    """Independent producer entry point; shadow runtime never authorizes itself.

    Only a locally injected, separately audited callable may supply a result.
    User-controlled market/sizing payloads cannot serve as producer authority.
    This boundary intentionally refuses publication until an audited producer
    is integrated with explicit provenance and independent authorization.
    """
    from collections.abc import Mapping
    if producer is None:
        return {"status": "BLOCKED_UNTIL_VERIFIED_PRODUCER",
                "canonical_recommendation": None, "execution_authorized": False,
                "reason": "INDEPENDENT_PRODUCER_NOT_WIRED"}
    if not callable(producer):
        raise ValueError("CANONICAL_PRODUCER_MUST_BE_CALLABLE")
    if not isinstance(observed_decision, Mapping) or not isinstance(sizing_evidence, Mapping):
        raise ValueError("CANONICAL_EVIDENCE_INVALID")
    # Fail closed even for injected callbacks until their trust root is audited.
    return {"status": "BLOCKED_UNTIL_VERIFIED_PRODUCER",
            "canonical_recommendation": None, "execution_authorized": False,
            "reason": "INDEPENDENT_PRODUCER_TRUST_ROOT_NOT_VERIFIED"}


def compose_shadow_cycle(root, *, observed_at: str, started_at: str, top_n: int=30,
                         universe_version: str="LY11C6A_TOP30_PER_CATEGORY",
                         cycle_seed: str|None=None):
    bridge=build_read_only_bridge(root,top_n=top_n)
    bridge_refs=tuple(getattr(bridge,"source_refs",()) or ())
    if not bridge_refs:
        bridge_refs=("LY11C6A_UNIVERSAL_OBSERVATION_BRIDGE",)

    context=new_cycle_context(
        observed_at=observed_at,
        started_at=started_at,
        universe_version=universe_version,
        source_refs=bridge_refs,
        provenance={
            "mode":"SHADOW_OFFLINE_NO_HISTORY_WRITE",
            "observation_bridge":"LY11c6a",
            "adapter_first_no_reset":True,
        },
        model_refs=(),
        policy_refs=(),
        cycle_seed=cycle_seed,
    )

    def universe_adapter(ctx, seed):
        return _env(
            "UNIVERSE_OBSERVED",
            bridge_refs,
            {"candidates":tuple(bridge.candidates),
             "domain_statuses":bridge.domain_statuses},
        )

    def specialized_adapter(ctx, universe_payload):
        return _env(
            "SPECIALIZED_INTELLIGENCE_TRANSPORTED",
            bridge_refs+("LY8_SPECIALIZED_INTELLIGENCE_CONTRACT",),
            bridge.intelligence,
        )

    def economic_adapter(ctx, intelligence_payload):
        # Transport only source-validated comparison rows; never infer decisions
        # from raw signals or treat comparison validation as promotion authority.
        from collections.abc import Mapping
        payload = intelligence_payload.get("payload") if isinstance(intelligence_payload, Mapping) else None
        if not isinstance(payload, Mapping):
            payload = intelligence_payload if isinstance(intelligence_payload, Mapping) else {}
        rows, refs, intake = _selected_economic_comparisons(payload)
        observations = tuple(payload.get("observations") or ())
        # Reuse the existing P3.2 boundary with the actual validated rows.
        # The boundary itself enforces complete evidence, account/currency
        # compatibility and abstention. It cannot grant canonical authority.
        from .brain_economic_runtime_boundary_p32 import observe_economic_decision
        economic_observation = observe_economic_decision(rows)
        economic_decision_observation_cache.append(economic_observation)
        return _env(
            "ECONOMIC_COMPARISONS_OBSERVED_NOT_PROMOTED" if rows else "ECONOMIC_DECISION_NOT_PROMOTED",
            bridge_refs+("LY9_ECONOMIC_DECISION_BOUNDARY",)+refs,
            {
                "state":"ECONOMIC_COMPARISONS_VALIDATED_NOT_PROMOTED" if rows else "ECONOMIC_DECISION_NOT_PROMOTED_IN_SHADOW_COMPOSITION",
                "observations":observations,
                "validated_comparison_rows":rows,
                "validated_comparison_source_refs":refs,
                "economic_decision_observation":economic_observation,
                "recommendations":(),
                "reason":"comparison evidence does not grant recommendation or sizing authority",
            },
        )

    economic_decision_observation_cache = []

    sizing_assessments_cache = []

    def sizing_adapter(ctx, economic_payload):
        # Governed inputs only: compare via existing authorities in the actual
        # sizing stage, not after the orchestrated cycle has already finished.
        # The outcome remains evidence-only and never enters canonical snapshots.
        assessments = _assess_supplied_governed_candidates(getattr(bridge, "intelligence", None))
        # Validated comparisons are NOT typed, governed economic/sizing models.
        # Make the missing authority observable inside the actual sizing stage
        # rather than silently losing every comparison when candidates are zero.
        comparison_rows, _, _ = _selected_economic_comparisons(getattr(bridge, "intelligence", None))
        if not assessments and comparison_rows:
            assessments = tuple({
                "status": "A2_COMPARISON_AWAITING_GOVERNED_MODELS",
                "reasons": ("ECONOMIC_EDGE_MODEL_AND_SIZING_DECISION_NOT_PROVEN",),
                "canonical_recommendation": False,
                "comparison_index": index,
            } for index, _ in enumerate(comparison_rows))
        sizing_assessments_cache.append(assessments)
        return _env(
            "GOVERNED_ECONOMIC_SIZING_ASSESSED_NOT_PROMOTED" if assessments else "SIZING_NOT_REQUESTED",
            ("LY9L_ADAPTIVE_SIZING_BOUNDARY",),
            {
                "state": "GOVERNED_SIZING_EVIDENCE_ONLY" if assessments else "SIZING_NOT_REQUESTED_WITHOUT_GOVERNED_CANDIDATES",
                "economic": economic_payload,
                "economic_sizing_assessments": assessments,
                # Carry actual governed assessments across the orchestrator stage.
                # Assessments are evidence, NOT executable sizing decisions.
                "sizing_evidence": tuple(assessments),
                "sizing_decisions": (),
                "recommendations": (),
            },
        )

    def snapshot_adapter(ctx, sizing_payload):
        # Validate the actual sizing-stage handoff, rather than relying on a
        # separate post-cycle cache. No candidate may self-promote to canonical.
        from collections.abc import Mapping
        # The orchestrator already unwraps every stage envelope (result.payload).
        stage = sizing_payload if isinstance(sizing_payload, Mapping) else None
        if not isinstance(stage, Mapping):
            raise ValueError("A2_SIZING_STAGE_PAYLOAD_REQUIRED")
        evidence = stage.get("sizing_evidence", ())
        if not isinstance(evidence, (tuple, list)) or any(not isinstance(x, Mapping) for x in evidence):
            raise ValueError("A2_SIZING_EVIDENCE_INVALID")
        if stage.get("recommendations") or stage.get("sizing_decisions"):
            raise ValueError("A2_UNAUTHORIZED_CANONICAL_PROMOTION")
        # A4: the handoff may transport evidence only if the authoritative
        # assessment list is identical, in order, to the stage evidence.
        # A shadow candidate cannot inject additional sizing or promotion.
        assessments = stage.get("economic_sizing_assessments", ())
        if not isinstance(assessments, (tuple, list)) or any(not isinstance(x, Mapping) for x in assessments):
            raise ValueError("A4_ASSESSMENTS_INVALID")
        if list(evidence) != list(assessments):
            raise ValueError("A4_SIZING_HANDOFF_DIVERGENCE")
        for assessment in evidence:
            status = assessment.get("status")
            if status == "A2_COMPARISON_AWAITING_GOVERNED_MODELS":
                # An observed comparison without governed models is a valid
                # research-only stage outcome, not a sizing authorization.
                if (assessment.get("canonical_recommendation") is not False
                        or assessment.get("sizing_status") is not None
                        or assessment.get("suggested_amount") is not None
                        or assessment.get("execution_authorized") not in (None, False)
                        or not isinstance(assessment.get("comparison_index"), int)
                        or isinstance(assessment.get("comparison_index"), bool)
                        or assessment["comparison_index"] < 0):
                    raise ValueError("A12_UNGOVERNED_COMPARISON_AUTHORITY_INVALID")
                continue
            if status == "A2_CANDIDATE_UNAVAILABLE":
                # An independently evaluated governed candidate may legitimately
                # be unavailable. Preserve the abstention without aborting cycle.
                if (assessment.get("canonical_recommendation") is not False
                        or assessment.get("execution_authorized") not in (None, False)
                        or assessment.get("suggested_amount") is not None
                        or assessment.get("sizing_status") == "SIZING_READY"
                        or not isinstance(assessment.get("reasons"), (tuple, list))
                        or not assessment.get("reasons")):
                    raise ValueError("A13_UNAVAILABLE_CANDIDATE_AUTHORITY_INVALID")
                continue
            if assessment.get("canonical_recommendation") is not False or assessment.get("execution_authorized") is not False:
                raise ValueError("A4_SIZING_EVIDENCE_AUTHORITY_INVALID")
            if status != "A2_ECONOMIC_SIZING_ASSESSED_NOT_PROMOTED":
                raise ValueError("A4_SIZING_EVIDENCE_STATUS_INVALID")
        # Important: orchestrator interprets final payload as snapshots.
        # Return an empty tuple, not a wrapper object, so zero canonical
        # recommendation snapshots are emitted in shadow mode.
        return _env(
            "NO_CANONICAL_RECOMMENDATION_SNAPSHOT",
            ("LY10A_RECOMMENDATION_SNAPSHOT_BOUNDARY",),
            (),
        )

    cycle=run_offline_cycle(
        context=context,
        seed_payload={"bridge_contract":"LY11c6a"},
        universe_adapter=universe_adapter,
        specialized_intelligence_adapter=specialized_adapter,
        economic_decision_adapter=economic_adapter,
        sizing_adapter=sizing_adapter,
        recommendation_snapshot_adapter=snapshot_adapter,
    )
    economic_rows, _, intake_diagnostic = _selected_economic_comparisons(getattr(bridge,"intelligence",None))
    assessments=sizing_assessments_cache[-1] if sizing_assessments_cache else ()
    decision_observation=(economic_decision_observation_cache[-1] if economic_decision_observation_cache else None)
    evidence_source_diagnostic=_economic_evidence_source_status(root)
    candidate_return_diagnostic=_candidate_forward_return_observations(root,bridge.candidates)
    ui_projection=_economic_decision_ui_projection(decision_observation, comparison_rows=economic_rows, sizing_assessments=assessments)
    # Preserve the exact gate reason for existing UI consumers without turning
    # observations into recommendations or leaking private evidence values.
    ui_projection=dict(ui_projection)
    ui_projection["economic_comparison_intake_status"]=intake_diagnostic["status"]
    ui_projection["economic_comparison_intake_reason"]=intake_diagnostic["reason"]
    ui_projection["economic_comparison_input_count"]=intake_diagnostic["input_count"]
    ui_projection["economic_evidence_source_status"]=evidence_source_diagnostic
    ui_projection["candidate_forward_return_observations"]=candidate_return_diagnostic
    # Report the real missing producer inputs in the existing projection.
    # Observation-only market data cannot certify a forward-return model,
    # validated relative utility, account capacity, or independent authority.
    intelligence=getattr(bridge,"intelligence",None)
    from collections.abc import Mapping
    intelligence=intelligence if isinstance(intelligence,Mapping) else {}
    governed_alternatives=intelligence.get("governed_economic_alternatives")
    governed_sizing=intelligence.get("governed_economic_sizing_candidates")
    missing=[]
    if not isinstance(governed_alternatives,(tuple,list)) or not governed_alternatives:
        missing.append("GOVERNED_ECONOMIC_ALTERNATIVES_NOT_PRODUCED")
    if not isinstance(governed_sizing,(tuple,list)) or not governed_sizing:
        missing.append("GOVERNED_ECONOMIC_SIZING_MODELS_NOT_PRODUCED")
    if not economic_rows:
        missing.append("VALIDATED_COMPARISON_NOT_AVAILABLE")
    # A ready assessment for another account, currency or instrument must not
    # clear the gate for the decision actually observed by the Brain.
    experimental=ui_projection.get("experimental_brain_proposal")
    experimental=experimental if isinstance(experimental,Mapping) else {}
    matched=experimental.get("governed_sizing_evidence")
    if not (isinstance(matched,Mapping) and matched.get("status") in ("SIZING_READY", "NO_ALLOCATION")):
        missing.append("READY_GOVERNED_SIZING_NOT_AVAILABLE_FOR_OBSERVED_DECISION")
    missing.append("INDEPENDENT_CANONICAL_RECOMMENDATION_PRODUCER_NOT_WIRED")
    ui_projection["canonical_production_missing_inputs"]=tuple(missing)
    ui_projection["canonical_production_readiness"]="BLOCKED_BY_UNPROVEN_INPUTS"
    # A24: abstention is a first-class outcome, with exact missing dependencies.
    ui_projection["economic_abstention"] = None if experimental else {
        "action": "ABSTAIN", "action_label_pt": "ABSTER-SE",
        "reasons": tuple(dict.fromkeys(
            [intake_diagnostic.get("reason") or "ECONOMIC_DECISION_NOT_READY"] + missing)),
        "observed_instrument_count": len(bridge.candidates),
        "authority": "NONE", "execution_authorized": False,
    }
    return UniversalRuntimeCompositionResult(
        cycle=cycle,bridge=bridge,economic_comparison_rows=economic_rows,
        economic_sizing_assessments=assessments,
        economic_decision_observation=decision_observation,
        economic_decision_ui_projection=ui_projection,
        economic_comparison_intake={"status":intake_diagnostic["status"],
                                    "reason":intake_diagnostic["reason"],
                                    "input_count":intake_diagnostic["input_count"]},
    )

def contract_payload():
    return {
        "mode":"SHADOW_OFFLINE_NO_HISTORY_WRITE",
        "runtime_wiring":False,
        "history_writer_enabled":False,
        "financial_mutation":False,
        "execution":False,
        "legacy_action_promotion":False,
        "partial_evidence_promotion":False,
        "pending_evidence_promotion":False,
        "second_scheduler":False,
        "adapter_first_no_reset":True,
        "canonical_recommendation_snapshots_expected":0,
    }
