"""A2 governed comparison intake: transport validated evidence, never infer it.

This module does not estimate returns, costs, risk, or utility. It refuses
research-only evidence and keeps the original source references intact.
"""
from __future__ import annotations
from collections.abc import Mapping
import math

REQUIRED_EVIDENCE = ("forward_return", "transaction_cost", "risk_measure", "counterfactual_return")
REQUIRED_FLAGS = ("forward_return_validated", "transaction_cost_validated", "risk_validated", "counterfactual_validated")

def produce_governed_comparisons(intelligence):
    def blocked(reason, count=0):
        return {"status": "UNAVAILABLE", "reason": reason, "comparison_rows": (),
                "source_refs": (), "input_count": count, "authority": "NONE",
                "execution_authorized": False, "canonical_recommendation": False}
    if not isinstance(intelligence, Mapping):
        return blocked("INTELLIGENCE_MAPPING_REQUIRED")
    supplied = intelligence.get("governed_economic_alternatives")
    if not isinstance(supplied, (list, tuple)) or not supplied:
        return blocked("GOVERNED_ALTERNATIVES_NOT_SUPPLIED")
    refs = intelligence.get("governed_economic_source_refs")
    if not isinstance(refs, (list, tuple)) or not refs or not all(isinstance(x, str) and x.strip() for x in refs):
        return blocked("GOVERNED_SOURCE_REFS_REQUIRED", len(supplied))
    rows=[]; scope=set(); horizons=set(); seen=set(); explicit_horizons=set()
    for item in supplied:
        if not isinstance(item, Mapping): return blocked("ALTERNATIVE_NOT_MAPPING",len(supplied))
        for field in ("alternative_id", "instrument_id", "account_id", "currency", "kind"):
            if not isinstance(item.get(field), str) or not item[field].strip():
                return blocked("CANONICAL_ALTERNATIVE_IDENTITY_REQUIRED",len(supplied))
        if item["alternative_id"] in seen: return blocked("DUPLICATE_ALTERNATIVE_ID",len(supplied))
        seen.add(item["alternative_id"])
        ev=item.get("evidence")
        if not isinstance(ev, Mapping): return blocked("ECONOMIC_EVIDENCE_REQUIRED",len(supplied))
        if any(k in ev and ev[k] != item[k] for k in ("account_id", "currency")):
            return blocked("EVIDENCE_SCOPE_MISMATCH",len(supplied))
        if ev.get("instrument_id")!=item["instrument_id"]:
            return blocked("EVIDENCE_IDENTITY_MISMATCH",len(supplied))
        if not isinstance(ev.get("horizon"),str) or not ev["horizon"].strip():
            return blocked("HORIZON_REQUIRED",len(supplied))
        if not all(ev.get(flag) is True for flag in REQUIRED_FLAGS):
            return blocked("EVIDENCE_NOT_VALIDATED",len(supplied))
        if not all(isinstance(ev.get(k),(int,float)) and not isinstance(ev[k],bool) and math.isfinite(ev[k]) for k in REQUIRED_EVIDENCE):
            return blocked("ECONOMIC_VALUES_REQUIRED",len(supplied))
        if not isinstance(ev.get("provenance"),Mapping) or not ev["provenance"]:
            return blocked("EVIDENCE_PROVENANCE_REQUIRED",len(supplied))
        if ev.get("authority") in ("RESEARCH_ONLY", "EXPERIMENTAL"):
            return blocked("RESEARCH_ONLY_EVIDENCE",len(supplied))
        utility=item.get("relative_utility")
        if not isinstance(utility,(int,float)) or isinstance(utility,bool) or not math.isfinite(utility):
            return blocked("PRECOMPUTED_VALIDATED_UTILITY_REQUIRED",len(supplied))
        if item.get("relative_utility_validated") is not True or not isinstance(item.get("relative_utility_provenance"),Mapping) or not item["relative_utility_provenance"]:
            return blocked("RELATIVE_UTILITY_NOT_VALIDATED",len(supplied))
        scope.add((item["account_id"],item["currency"].upper()))
        horizons.add(ev["horizon"].strip().upper())
        hu, hv = ev.get("horizon_unit"), ev.get("horizon_value")
        if hu is not None or hv is not None:
            if not isinstance(hu, str) or not hu.strip() or type(hv) is not int or hv <= 0:
                return blocked("EXPLICIT_HORIZON_INVALID",len(supplied))
            explicit_horizons.add((hu, hv))
        else:
            explicit_horizons.add((None, None))
        rows.append({k:item[k] for k in ("alternative_id","instrument_id","account_id","currency","kind","relative_utility")})
        rows[-1].update(evidence=dict(ev),source_instrument_id=item.get("source_instrument_id"),
                        destination_instrument_id=item.get("destination_instrument_id"),
                        metadata={"relative_utility_provenance":dict(item["relative_utility_provenance"]),
                                  "destination_is_held": (item.get("metadata") or {}).get("destination_is_held") is True
                                  if isinstance(item.get("metadata"), Mapping) else False})
    if len(scope)!=1: return blocked("CROSS_ACCOUNT_OR_CURRENCY_COMPARISON",len(supplied))
    if len(explicit_horizons)!=1: return blocked("COMPARISON_HORIZON_MISMATCH",len(supplied))
    if len(horizons)!=1: return blocked("COMPARISON_HORIZON_MISMATCH",len(supplied))
    if len(rows)<2: return blocked("COMPARATIVE_ALTERNATIVES_REQUIRED",len(supplied))
    return {"status":"VALIDATED_INPUTS_NOT_PROMOTED", "reason":None,
            "comparison_rows":tuple(rows), "source_refs":tuple(refs),
            "input_count":len(supplied), "authority":"NONE", "execution_authorized":False,
            "canonical_recommendation":False}
