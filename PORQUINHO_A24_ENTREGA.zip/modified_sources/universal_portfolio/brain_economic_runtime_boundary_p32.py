"""P3.2: explicit read-only economic decision integration boundary.

Caller supplies genuine, already validated economic evidence and relative utility.
No inference from ticker, score, price, signal, or unvalidated return.
Not attached to scheduled runtime or HTTP; no financial writes.
"""
from __future__ import annotations
from collections.abc import Mapping, Sequence
from universal_portfolio.universal_real_economic_evidence_bridge import (
    bind_identity_evidence, to_ly9_alternative,
)
from universal_portfolio.universal_economic_decision import decide
from universal_portfolio.brain_decision_publication_contract_p3 import project_decision

SCHEMA = "porquinho.brain-economic-runtime-boundary/1.0"

def observe_economic_decision(rows: Sequence[Mapping] | None) -> dict:
    """Evaluate a complete, single-account, single-currency comparison set.

    Rows must contain instrument_id, account_id, currency, evidence,
    alternative_id, kind, relative_utility, and relevant source/destination IDs.
    The evidence bridge and economic decision engine remain the sole authorities.
    """
    def blocked(reason):
        return {"schema": SCHEMA, "status": "UNAVAILABLE", "reason": reason,
                "publication": project_decision(None), "runtime_wiring": False,
                "execution_authorized": False}
    if not isinstance(rows, (list, tuple)) or not rows:
        return blocked("COMPARISON_SET_REQUIRED")
    alternatives = []
    seen_alternatives = set()
    comparison_horizons = set()
    try:
        for row in rows:
            if not isinstance(row, Mapping):
                return blocked("ALTERNATIVE_NOT_MAPPING")
            mandatory = ("instrument_id", "account_id", "currency", "alternative_id", "kind")
            if any(not isinstance(row.get(k), str) or not row[k].strip() for k in mandatory):
                return blocked("CANONICAL_IDENTITY_OR_KIND_MISSING")
            if row["alternative_id"] in seen_alternatives:
                return blocked("DUPLICATE_ALTERNATIVE_ID")
            seen_alternatives.add(row["alternative_id"])
            if not isinstance(row.get("evidence"), Mapping):
                return blocked("REAL_EVIDENCE_REQUIRED")
            # A comparison of unlike horizons is not an economic comparison.
            # Missing horizons cannot be silently assumed equivalent.
            horizon = row["evidence"].get("horizon")
            if not isinstance(horizon, str) or not horizon.strip():
                return blocked("EVIDENCE_HORIZON_REQUIRED")
            comparison_horizons.add(horizon.strip().upper())
            if len(comparison_horizons) != 1:
                return blocked("COMPARISON_HORIZON_MISMATCH")
            if "relative_utility" not in row:
                return blocked("PRECOMPUTED_UTILITY_REQUIRED")
            bound = bind_identity_evidence(
                row["instrument_id"], row["account_id"], row["currency"], row["evidence"]
            )
            alt = to_ly9_alternative(
                alternative_id=row["alternative_id"], kind=row["kind"], bound=bound,
                source_instrument_id=row.get("source_instrument_id"),
                destination_instrument_id=row.get("destination_instrument_id"),
                relative_utility=row["relative_utility"], metadata=row.get("metadata"),
            )
            alternatives.append(alt)
        # Preserve the complete comparison set. Never discard blocked alternatives
        # or promote partial evidence into an actionable recommendation.
        readiness = tuple({
            "alternative_id": a["alternative_id"],
            "account_id": a["account_id"],
            "currency": a["currency"],
            "comparator_ready": a["comparator_ready"],
            "reasons": tuple(a["readiness_reasons"]),
        } for a in alternatives)
        # The existing decision engine rejects cross-account/currency comparisons
        # and abstains if ANY alternative is not ready.
        result = decide(alternatives).payload()
        publication = project_decision(result)
        if publication.get("decision") is not None:
            selected = next(row for row in rows if row["alternative_id"] == result["alternative_id"])
            from .governed_economic_input_transport_a24 import comparison_identity
            publication["decision"].update(
                instrument_id=selected["instrument_id"],
                comparison_id=comparison_identity(rows),
                horizon=selected["evidence"]["horizon"],
                horizon_unit=selected["evidence"].get("horizon_unit"),
                horizon_value=selected["evidence"].get("horizon_value"),
            )
        return {"schema": SCHEMA,
                "status": publication["status"],
                "decision_action": result["action"],
                "decision_ready": result["decision_ready"],
                "publication": publication,
                "comparison_readiness": readiness,
                "comparison_count": len(readiness),
                "blocked_comparison_count": sum(not a["comparator_ready"] for a in readiness),
                "runtime_wiring": False,
                "execution_authorized": False}
    except (ValueError, TypeError, KeyError, AttributeError) as exc:
        return blocked("INVALID_COMPARISON:" + type(exc).__name__)
