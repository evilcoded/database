"""Compare held-versus-destination forecasts. Read only; never an order or tariff learner.

All available comparable estimators are shown. No majority vote/model selection,
manual risk coefficient, retrospective certification, or portfolio resizing.
"""
import datetime as dt
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from .explicit_market_bindings_a24 import digest

SCHEMA = 'porquinho.reallocation-analysis-a24/1.0'


class ReallocationError(ValueError):
    pass


def flags():
    return dict(authority='RESEARCH_ONLY', execution_authorized=False,
                automatic_execution_authorized=False, canonical_publication_authorized=False,
                financial_mutation=False, history_write_performed=False,
                training_requested=False, recommendation_created=False,
                sizing_created=False, historical_fees_used_as_future_tariff=False)


def number(value):
    if isinstance(value, bool) or value is None:
        raise ReallocationError('FINITE_NUMBER_REQUIRED')
    try:
        result = Decimal(str(value))
    except Exception as exc:
        raise ReallocationError('FINITE_NUMBER_REQUIRED') from exc
    if not result.is_finite() or abs(result) > Decimal('1e30'):
        raise ReallocationError('FINITE_NUMBER_REQUIRED')
    return result


def date(value):
    try:
        return dt.date.fromisoformat(value)
    except Exception as exc:
        raise ReallocationError('EXPLICIT_OBSERVATION_DATE_REQUIRED') from exc


def project(plan, experiments, *, identity_links=(), reference_links=(), now, prices=()):
    """Pure projection of verified inputs; price notional is a full-position scenario,
    never a chosen trade size. Research aliases alone cannot value financial holdings.
    """
    from .economic_action_plan_a24 import SCHEMA as PLAN_SCHEMA
    from .reviewed_research_identity_links_a24 import index
    if now.tzinfo is None or now.utcoffset() is None:
        raise ReallocationError('AWARE_TIME_REQUIRED')
    if (plan.get('schema') != PLAN_SCHEMA or
            plan.get('status') != 'ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY' or
            plan.get('execution_authorized') is not False):
        raise ReallocationError('READ_ONLY_ACTION_PLAN_REQUIRED')
    links = index(identity_links)
    from .position_reference_reconciliation_a24 import index as reference_index
    references = reference_index(reference_links)
    def research(iid):
        return links.get(iid, {}).get('research_instrument_id', iid)
    models = {}; quotes = defaultdict(list)
    for p in prices:
        quotes[tuple(p[k] for k in ('instrument_id', 'provider', 'provider_id', 'quote_currency', 'origin'))].append(p)
    for e in experiments:
        if (e.get('horizon_unit'), e.get('horizon_value')) != ('OBSERVATIONS', 30):
            raise ReallocationError('COMMON_EXPLICIT_HORIZON_REQUIRED')
        if e.get('execution_authorized') is not False or e.get('model_validation_proven') is not False:
            raise ReallocationError('RESEARCH_EXPERIMENT_REQUIRED')
        stamp = dt.datetime.fromisoformat(e['computed_at'])
        if stamp.tzinfo is None or stamp > now:
            raise ReallocationError('EXPERIMENT_TIME_INVALID')
        key = e['quote_currency'], e['algorithm'], e['cohort_digest']
        if key in models:
            raise ReallocationError('DUPLICATE_EXPERIMENT_CONTEXT')
        forecasts = defaultdict(list)
        for f in e['forecasts']:
            if f['quote_currency'] != e['quote_currency']:
                raise ReallocationError('FORECAST_CURRENCY_CONFLICT')
            forecasts[f['instrument_id']].append(f)
        models[key] = (e, forecasts)
    rows = []
    for case in plan.get('cases', []):
        if case.get('resource_kind') != 'POSITION':
            continue
        for alt in case['alternatives']:
            if alt['kind'] != 'REALLOCATE':
                continue
            src, dst = alt['source_instrument_id'], alt['destination_instrument_id']
            aid, q = case['account_id'], case['currency']
            if (src != case['instrument_id'] or src == dst or
                    (alt['account_id'], alt['currency']) != (aid, q)):
                raise ReallocationError('DISTINCT_SAME_ACCOUNT_CURRENCY_REQUIRED')
            scope = alt.get('manual_account_asset_scope', {})
            if (scope.get('account_currency') != q or scope.get('transaction_currency') != q or
                    scope.get('account_currency_matches') is not True):
                raise ReallocationError('DECLARED_ACCOUNT_CURRENCY_REQUIRED')
            if research(src) == research(dst):
                continue
            if (alt.get('horizon_unit'), alt.get('horizon_value')) != ('OBSERVATIONS', 30):
                raise ReallocationError('COMMON_EXPLICIT_HORIZON_REQUIRED')
            row = dict(alternative_id=alt['alternative_id'], account_id=aid, currency=q,
                       source_instrument_id=src, destination_instrument_id=dst,
                       source_research_instrument_id=research(src), destination_research_instrument_id=research(dst),
                       research_alias_used=research(src) != src or research(dst) != dst,
                       horizon_unit='OBSERVATIONS', horizon_value=30,
                       models=[], missing_reasons=[], requested_amount=None,
                       requested_quantity=None, reference_capital=None,
                       capital_semantics='FULL_SOURCE_POSITION_SCENARIO_NOT_TRADE_SIZE',
                       net_advantage_amount=None, transaction_cost=None,
                       status='AWAITING_COMPARABLE_FORECASTS', **flags())
            for (cur, algorithm, cohort), (e, fs) in sorted(models.items()):
                if cur != q:
                    continue
                a, b = fs.get(research(src), []), fs.get(research(dst), [])
                if len(a) != 1 or len(b) != 1:
                    row['missing_reasons'].append('SOURCE_OR_DESTINATION_FORECAST_MISSING_OR_AMBIGUOUS')
                    continue
                a, b = a[0], b[0]
                origin = a['origin']
                if origin != b['origin']:
                    row['missing_reasons'].append('COMMON_FORECAST_ORIGIN_REQUIRED'); continue
                age = (now.date() - date(origin)).days
                if age < 0 or age > 3:
                    row['missing_reasons'].append('CURRENT_FORECAST_REQUIRED'); continue
                if not (date(a['last_training_label_end']) < date(origin) and date(b['last_training_label_end']) < date(origin)):
                    raise ReallocationError('PURGED_FORECAST_REQUIRED')
                source, destination = number(a['value_pct']), number(b['value_pct'])
                if min(source, destination) < -100:
                    row['missing_reasons'].append('INVALID_LONG_ONLY_RETURN_FORECAST'); continue
                af, bf = {}, {}
                for f in e['folds']:
                    exact = tuple(f[k] for k in ('instrument_id', 'provider', 'provider_id', 'quote_currency'))
                    left = tuple(a[k] for k in ('instrument_id', 'provider', 'provider_id', 'quote_currency'))
                    right = tuple(b[k] for k in ('instrument_id', 'provider', 'provider_id', 'quote_currency'))
                    if exact not in (left, right): continue
                    if not date(f['last_training_label_end']) < date(f['origin']) < date(f['target']):
                        raise ReallocationError('PURGED_FOLD_REQUIRED')
                    if date(f['target']) > date(origin): continue
                    k = f['origin'], f['target']
                    target = af if exact == left else bf
                    if k in target: raise ReallocationError('DUPLICATE_EVALUATION_CONTEXT')
                    target[k] = number(f['actual_pct'])
                common = sorted(set(af) & set(bf))
                sr = (sum((min(af[k], Decimal(0)) ** 2 for k in common), Decimal(0))/len(common)).sqrt() if common else None
                dr = (sum((min(bf[k], Decimal(0)) ** 2 for k in common), Decimal(0))/len(common)).sqrt() if common else None
                delta = destination-source
                classification = ('GROSS_UPLIFT_NO_GREATER_OBSERVED_DOWNSIDE' if delta > 0 and sr is not None and dr <= sr else
                                  'GROSS_UPLIFT_RISK_UNAVAILABLE' if delta > 0 and sr is None else 'GROSS_UPLIFT_RISK_TRADEOFF' if delta > 0 else 'NO_GROSS_UPLIFT')
                capital = None
                valuation_state='EXACT_FINANCIAL_REFERENCE_AVAILABLE'
                price_key = tuple(a[k] for k in ('instrument_id','provider','provider_id','quote_currency','origin'))
                pp = quotes[price_key]
                # Diagnose the actual missing input; research compatibility is not financial identity.
                reference = references.get((aid, q, src, research(src), a['provider'], a['provider_id']))
                if reference and date(reference['effective_from']) > date(origin): reference = None
                if research(src)!=src and reference is None:valuation_state='RESEARCH_ALIAS_NOT_FINANCIAL_IDENTITY'
                elif case.get('quantity_upper_bound') is None:valuation_state='POSITION_QUANTITY_REQUIRED'
                elif not pp:valuation_state='EXACT_PROVIDER_ORIGIN_PRICE_REQUIRED'
                elif len(pp)!=1:valuation_state='EXACT_PROVIDER_ORIGIN_PRICE_AMBIGUOUS'
                else:
                    qty=number(case['quantity_upper_bound']);price=number(pp[0]['price'])
                    if qty>0 and price>0:
                        capital=qty*price
                        if reference:valuation_state='REGISTERED_POSITION_REVIEWED_SOURCE_REFERENCE'
                    else:valuation_state='POSITIVE_QUANTITY_AND_PRICE_REQUIRED'
                row['models'].append(dict(algorithm=algorithm, cohort_digest=cohort,
                    experiment_digest=digest(e), origin=origin, computed_at=e['computed_at'],
                    source_provider=a['provider'], source_provider_id=a['provider_id'],
                    destination_provider=b['provider'], destination_provider_id=b['provider_id'],
                    source_return_pct=str(source), destination_return_pct=str(destination), gross_uplift_pp=str(delta),
                    paired_matured_fold_count=len(common), evaluation_windows_may_overlap=True,
                    source_historical_downside_rms_pct=str(sr) if sr is not None else None,
                    destination_historical_downside_rms_pct=str(dr) if dr is not None else None,
                    historical_risk_is_forward_risk=False, classification=classification,
                    reference_capital=str(capital) if capital is not None else None,
                    valuation_state=valuation_state,
                    reference_identity_chain=reference if capital is not None and reference else None,
                    reference_is_execution_quote=False,
                    gross_uplift_amount=str(capital*delta/100) if capital is not None else None,
                    # Maximum two-leg cost difference before gross advantage disappears;
                    # not an estimate of actual fees or a guarantee of net profitability.
                    break_even_extra_cost_amount=str(capital*delta/100) if capital is not None and delta>0 else None))
            mm = row['models']
            row['valuation_state_counts']=dict(Counter(m['valuation_state'] for m in mm))
            row['source_reference_reconciled']=bool(mm) and all(m['valuation_state']=='REGISTERED_POSITION_REVIEWED_SOURCE_REFERENCE' for m in mm)
            row['financial_identifiers_rewritten']=False
            if mm:
                kinds = {m['classification'] for m in mm}
                if len({m['origin'] for m in mm}) != 1:
                    kinds.add('DIFFERENT_MODEL_ORIGINS')
                    row['missing_reasons'].append('COMMON_MODEL_ORIGIN_REQUIRED')
                row['status'] = ('GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING' if kinds == {'GROSS_UPLIFT_NO_GREATER_OBSERVED_DOWNSIDE'} else
                                 'NO_GROSS_ADVANTAGE_IN_AVAILABLE_MODELS' if kinds == {'NO_GROSS_UPLIFT'} else
                                 'HISTORICAL_RISK_UNAVAILABLE' if kinds == {'GROSS_UPLIFT_RISK_UNAVAILABLE'} else
                                 'MODEL_DISAGREEMENT_OR_RISK_TRADEOFF')
                row['missing_reasons'] += ['TWO_LEG_CURRENT_COSTS_REQUIRED', 'ACTION_SPECIFIC_SIZING_NOT_PRODUCED']
                if any(m['paired_matured_fold_count'] == 0 for m in mm): row['missing_reasons'].append('PAIRED_HISTORICAL_RISK_UNAVAILABLE')
                caps = {m['reference_capital'] for m in mm}
                if len(caps) == 1: row['reference_capital'] = next(iter(caps))
            if row['reference_capital'] is None: row['missing_reasons'].append('EXACT_CURRENT_FINANCIAL_VALUATION_REQUIRED')
            row['missing_reasons'] += [v for v in alt.get('blocking_reasons', []) if v in ('ACTIVE_MANUAL_INVESTMENT_PLAN_REQUIRED','DESTINATION_OUTSIDE_ACTIVE_PLAN_CLASSES','EXPLICIT_POSITION_QUANTITY_REQUIRED')]
            row['missing_reasons'] = sorted(set(row['missing_reasons']))
            rows.append(row)
    counts = Counter(r['status'] for r in rows)
    return dict(schema=SCHEMA, status='REALLOCATION_COMPARISONS_INSPECTED', rows=rows,
                pair_count=len(rows), compared_pair_count=sum(bool(r['models']) for r in rows),
                gross_candidate_count=counts['GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING'],
                status_counts=dict(counts), model_outputs_are_independent_votes=False,
                selected_winner=None, history_horizon_is_calendar_days=False,
                observed_at=now.isoformat(), **flags())


def attach_reviewed_costs(result, reviews):
    with localcontext() as ctx:
        ctx.prec=200
        return _attach_reviewed_costs(result,reviews)


def _attach_reviewed_costs(result, reviews):
    """Enumerate reviewed, complete two-leg routes; never select a venue or scale fees. Partial quotes are enumerated
    within the original source reference capital; untraded source cancels from
    the same-horizon comparison and remains invested in the origin.
    BUY notional plus its quoted fees must exactly equal available SELL proceeds.
    This is execution-cost-adjusted research, not all-in utility or an order size.
    """
    from .account_cost_evidence_a24 import COMPONENTS
    complete = []
    for review in reviews:
        if any(review['components'][k]['status'] == 'UNKNOWN' for k in COMPONENTS): continue
        total = sum((number(review['components'][k]['amount']) for k in COMPONENTS
                     if review['components'][k]['status'] == 'KNOWN'), Decimal(0))
        if total < 0: raise ReallocationError('NONNEGATIVE_COST_REQUIRED')
        complete.append((review, total))
    scoped=defaultdict(list)
    for review,total in complete:
        scoped[(review['account_id'],review['currency'],review['instrument_id'],review['side'])].append((review,total))
    for row in result.get('rows', []):
        row['reviewed_two_leg_cost_scenarios'] = []
        row['execution_cost_capacity_models'] = []
        row['sizing_semantics'] = 'REVIEWED_QUOTE_AMOUNT_FEASIBILITY_NOT_SELECTED_TRADE'
        row['requested_amount'] = None
        row['requested_quantity'] = None
        relevant=[r for r in reviews if r['account_id']==row['account_id'] and r['currency']==row['currency'] and ((r['instrument_id']==row['source_instrument_id'] and r['side']=='SELL') or (r['instrument_id']==row['destination_instrument_id'] and r['side']=='BUY'))]
        row['cost_source_diagnostics']={'sell_review_count':sum(r['side']=='SELL' for r in relevant),
            'buy_review_count':sum(r['side']=='BUY' for r in relevant),
            'unknown_component_counts':dict(Counter(k for r in relevant for k in COMPONENTS if r['components'][k]['status']=='UNKNOWN')),
            'historical_fees_used_as_tariffs':False}
        if row['research_alias_used'] and (not row.get('source_reference_reconciled') or row['destination_instrument_id']!=row['destination_research_instrument_id']): continue
        cap = row['reference_capital']
        if cap is None: continue
        cap = number(cap)
        if cap <= 0: continue
        for model in row['models']:
            source = number(model['source_return_pct']); destination = number(model['destination_return_pct'])
            if min(source,destination)<-100: raise ReallocationError('LONG_ONLY_RETURN_REQUIRED')
            with localcontext() as ctx:
                ctx.prec=60
                capacity=cap*(destination-source)/(100+destination) if destination>source and destination>-100 else Decimal(0)
            row['execution_cost_capacity_models'].append({'algorithm':model['algorithm'],'cohort_digest':model['cohort_digest'],
                'reference_source_capital':str(cap),'maximum_upfront_two_leg_cost':str(capacity),
                'semantics':'HYPOTHETICAL_BREAK_EVEN_ALL_COSTS_PAID_UPFRONT_NOT_QUOTE_OR_AUTHORIZATION'})
        for sell, sc in scoped[(row['account_id'],row['currency'],row['source_instrument_id'],'SELL')]:
            if (sell['account_id'], sell['currency'], sell['instrument_id'], sell['side']) != (row['account_id'],row['currency'],row['source_instrument_id'],'SELL'): continue
            sold=number(sell['reference_amount'])
            if sold <= 0 or sold > cap or sc >= sold: continue
            for buy, bc in scoped[(row['account_id'],row['currency'],row['destination_instrument_id'],'BUY')]:
                if (buy['account_id'], buy['currency'], buy['instrument_id'], buy['side']) != (row['account_id'],row['currency'],row['destination_instrument_id'],'BUY'): continue
                buy_cap = number(buy['reference_amount'])
                if buy_cap <= 0 or buy_cap+bc != sold-sc: continue
                scenarios=[]
                for m in row['models']:
                    with localcontext() as ctx:
                        ctx.prec=60
                        delta=buy_cap*(1+number(m['destination_return_pct'])/100)-sold*(1+number(m['source_return_pct'])/100)
                    scenarios.append({'algorithm':m['algorithm'],'cohort_digest':m['cohort_digest'],
                        'execution_cost_adjusted_uplift_amount':str(delta)})
                row['reviewed_two_leg_cost_scenarios'].append({'sell_evidence_id':sell['evidence_id'],
                    'buy_evidence_id':buy['evidence_id'],'sell_execution_venue_id':sell['execution_venue_id'],
                    'buy_execution_venue_id':buy['execution_venue_id'],'sell_cost':str(sc),'buy_cost':str(bc),
                    'source_sale_reference_amount':str(sold),'destination_notional':str(buy_cap),
                    'remaining_source_reference_capital':str(cap-sold),
                    'reference_source_fraction':str(sold/cap),'additional_cash_required':'0',
                    'sizing_status':'QUOTE_AMOUNTS_BALANCED_WITHIN_SOURCE_REFERENCE_CAPITAL',
                    'positive_in_all_available_models':bool(scenarios) and all(number(m['execution_cost_adjusted_uplift_amount'])>0 for m in scenarios),
                    'lot_constraints_verified':False,'models':scenarios,'selected':False,
                    'ongoing_costs_and_liquidity_verified':False})
        if row['reviewed_two_leg_cost_scenarios']:
            if any(number(c['source_sale_reference_amount'])==cap for c in row['reviewed_two_leg_cost_scenarios']):
                row['missing_reasons']=[v for v in row['missing_reasons'] if v!='TWO_LEG_CURRENT_COSTS_REQUIRED']
            else:
                row['missing_reasons'].append('COSTS_AVAILABLE_ONLY_FOR_QUOTED_PARTIAL_AMOUNTS')
            row['missing_reasons'] += ['EXECUTION_ROUTE_SELECTION_REQUIRED','ONGOING_COSTS_AND_LIQUIDITY_REQUIRED']
    candidates=[c for r in result.get('rows',[]) for c in r['reviewed_two_leg_cost_scenarios']]
    result['reviewed_cost_scenario_count']=len(candidates)
    result['partial_quote_scenario_count']=sum(number(c['remaining_source_reference_capital'])>0 for c in candidates)
    result['execution_cost_positive_scenario_count']=sum(c['positive_in_all_available_models'] for c in candidates)
    result['pairs_with_cost_capacity_count']=sum(bool(r['execution_cost_capacity_models']) for r in result.get('rows',[]))
    result['quote_amounts_are_selected_sizing']=False
    result['net_returns_validated']=False
    return result


def build(root, demand, plan, *, now):
    """Uses only sealed, current experiments and their original source bundles.
    Does not call fit, train, quote providers, or any trading endpoint.
    """
    from brain.evolution import global_existing_lab_a24 as lab
    from . import global_history_source_a24 as storage
    from . import economic_action_plan_a24 as actions
    from .reviewed_research_identity_links_a24 import load
    try:
        before = actions.source_versions(root)
        if plan.get('source_version_digest') and plan['source_version_digest'] != digest(before):
            raise ReallocationError('ACTION_PLAN_SOURCES_CHANGED_RETRY_REQUIRED')
        _, jobs = lab.jobs(root, demand, now)
        experiments = []; prices = []; frames = {}; files = {}
        for job in jobs:
            path = job['path']
            if not path.exists(): continue
            cohort = job['metadata']['cohort_digest']
            if cohort not in frames:
                frames[cohort] = lab.input_frame([b for p,b in job['pairs']])
                for p,body in job['pairs']:
                    files[p] = digest(storage.read_sealed(p))
                    last = body['observations'][-1]
                    prices.append({**body['binding'], 'origin':last['observation_date'], 'price':last['price']})
            body = storage.read_sealed(path); files[path] = digest(body)
            experiments.append(lab.validate(body, job, now, frame=frames[cohort]))
        from .position_reference_reconciliation_a24 import load as reference_load
        reference_links = reference_load(root, now=now)
        result = project(plan, experiments, identity_links=load(root), reference_links=reference_links, now=now, prices=prices)
        from . import account_cost_evidence_a24 as costs
        reviews = costs.load(root, now=now)
        if reviews:
            accounts, _ = costs.accounts(root)
            for review in reviews.values(): costs.current_scope(review, accounts)
            active = [v for v in reviews.values() if costs.timestamp(v['effective_from']) <= now < costs.timestamp(v['effective_until'])]
            attach_reviewed_costs(result, active)
            if costs.load(root, now=now) != reviews: raise ReallocationError('COSTS_CHANGED_DURING_READ')
        else: attach_reviewed_costs(result, [])
        if before != actions.source_versions(root) or any(digest(storage.read_sealed(p)) != sha for p,sha in files.items()):
            raise ReallocationError('REALLOCATION_SOURCES_CHANGED_DURING_READ')
        return result
    except Exception as exc:
        return dict(schema=SCHEMA, status='REALLOCATION_ANALYSIS_UNAVAILABLE',
                    error_type=type(exc).__name__, rows=[], **flags())


def summarize(value):
    return {k:v for k,v in value.items() if k not in ('rows',)}
