"""Read-only reconciliation of registered position IDs with reviewed price sources.

Associations are current analytical reference compatibility, never a rewrite,
financial identity merger, broker eligibility, execution quote or trading authority.
"""
import datetime as dt
import json
from .explicit_market_bindings_a24 import local, text
SCHEMA = 'porquinho.position-reference-reconciliation-a24/1.0'
FIELDS = ('account_id', 'currency', 'position_instrument_id', 'research_instrument_id',
          'provider', 'provider_id', 'canonical_binding_id', 'canonical_confirmation_digest',
          'research_evidence_ref', 'quote_binding_ref', 'portfolio_id', 'effective_from')


def index(rows):
    if not isinstance(rows, (list, tuple)) or len(rows)>10000: raise ValueError('BOUNDED_REFERENCE_CHAIN_REQUIRED')
    out = {}
    for row in rows:
        if not isinstance(row, dict) or row.get('schema') != SCHEMA or any(not text(row.get(k)) for k in FIELDS):
            raise ValueError('EXPLICIT_REGISTERED_REFERENCE_CHAIN_REQUIRED')
        dt.date.fromisoformat(row['effective_from'])
        if row['position_instrument_id'] == row['research_instrument_id']:
            raise ValueError('REFERENCE_CHAIN_REQUIRES_DISTINCT_IDENTIFIERS')
        key = tuple(row[k] for k in ('account_id', 'currency', 'position_instrument_id', 'research_instrument_id', 'provider', 'provider_id'))
        if key in out:
            raise ValueError('AMBIGUOUS_REGISTERED_REFERENCE_CHAIN')
        out[key] = dict(row)
    return out


def assemble(*, canonical, research_links, quote_bindings, accounts, portfolio_ids, now):
    from .reviewed_research_identity_links_a24 import index as research_index
    from .account_cost_evidence_a24 import timestamp
    aliases = research_index(research_links)
    seen = set(); positions = set(); output = []
    for row in canonical:
        required = ('binding_id', 'position_domain', 'position_id', 'account_id', 'portfolio_id',
                    'instrument_id', 'confirmation_digest', 'confirmed_by', 'confirmed_at')
        if not isinstance(row, dict) or any(not text(row.get(k)) for k in required):
            raise ValueError('CONFIRMED_CANONICAL_POSITION_BINDING_REQUIRED')
        key = row['account_id'], row['instrument_id']
        position_key = row['position_domain'], row['position_id']
        if key in seen or position_key in positions:
            raise ValueError('AMBIGUOUS_CANONICAL_POSITION_BINDING')
        seen.add(key); positions.add(position_key)
        account = accounts.get(row['account_id'])
        if account is None or row['portfolio_id'] not in portfolio_ids:
            raise ValueError('CURRENT_REGISTERED_ACCOUNT_AND_PORTFOLIO_REQUIRED')
        if timestamp(row['confirmed_at']) > now:
            raise ValueError('FUTURE_POSITION_CONFIRMATION_REFUSED')
        alias = aliases.get(row['instrument_id'])
        if alias is None: continue
        for binding in quote_bindings:
            if (binding['instrument_id'], binding['quote_currency']) != (alias['research_instrument_id'], account['currency']):
                continue
            if timestamp(binding['confirmed_at']) > now:
                raise ValueError('FUTURE_QUOTE_CONFIRMATION_REFUSED')
            if binding['effective_from'] > now.date().isoformat(): continue
            output.append(dict(schema=SCHEMA, account_id=row['account_id'], currency=account['currency'],
                position_instrument_id=row['instrument_id'], research_instrument_id=alias['research_instrument_id'],
                provider=binding['provider'], provider_id=binding['provider_id'],
                canonical_binding_id=row['binding_id'], canonical_confirmation_digest=row['confirmation_digest'],
                research_evidence_ref=alias['evidence_ref'], quote_binding_ref=binding['identity_source_ref'],
                portfolio_id=row['portfolio_id'], effective_from=binding['effective_from']))
    return list(index(output).values())


def load(root, *, now):
    from .account_cost_evidence_a24 import accounts
    from .explicit_market_bindings_a24 import load as quote_load
    from .reviewed_research_identity_links_a24 import load as research_load
    from .portfolio_registry import PortfolioRegistry
    from .economic_action_plan_a24 import source_versions
    path = local(root, 'data/canonical_position_identity_bindings.json')
    if not path.exists(): return []
    before = source_versions(root)
    if path.stat().st_size > 4 * 1024 * 1024: raise ValueError('POSITION_BINDING_READ_LIMIT')
    raw = path.read_bytes(); document = json.loads(raw)
    if document.get('schema') != 'porquinho.canonical-position-identity-binding/1.0' or not isinstance(document.get('bindings'), list):
        raise ValueError('CANONICAL_POSITION_BINDING_SCHEMA_REQUIRED')
    registered, _ = accounts(root)
    portfolios = PortfolioRegistry(local(root, 'data/portfolio_registry.json')).list_portfolios()
    result = assemble(canonical=document['bindings'], research_links=research_load(root),
                      quote_bindings=quote_load(root)['bindings'], accounts=registered,
                      portfolio_ids={p.portfolio_id for p in portfolios}, now=now)
    if source_versions(root) != before or path.read_bytes() != raw:
        raise ValueError('REFERENCE_CHAIN_CHANGED_DURING_READ')
    return result
