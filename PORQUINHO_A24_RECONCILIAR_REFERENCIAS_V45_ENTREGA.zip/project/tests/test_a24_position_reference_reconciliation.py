import copy
import datetime as dt
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import test_a24_reallocation_analysis as base
from universal_portfolio import position_reference_reconciliation_a24 as m
from universal_portfolio import reallocation_analysis_a24 as analysis

NOW=base.NOW
class ReferenceTests(unittest.TestCase):
    def setUp(self):
        self.case=base.Compare();self.case.setUp()
        self.source=base.I;self.target='REVIEWED:UNIVERSAL:IDENTITY'
        self.account=self.case.plan['cases'][0]['account_id']
        self.alias=dict(position_instrument_id=self.source,research_instrument_id=self.target,evidence_ref='reviewed-alias-fixture')
        for f in self.case.e['forecasts']+self.case.e['folds']:
            if f['instrument_id']==self.source:f['instrument_id']=self.target
        self.case.prices=[{**self.case.e['forecasts'][0],'price':'100'}]
        self.canonical=dict(binding_id='binding-fixture',position_domain='arbitrary-domain',position_id='position-fixture',account_id=self.account,portfolio_id='portfolio-fixture',instrument_id=self.source,confirmation_digest='confirmation-fixture',confirmed_by='fixture-reviewer',confirmed_at='2026-10-15T00:00:00+00:00')
        self.quote=dict(instrument_id=self.target,provider='CoinGecko',provider_id='source',quote_currency='BRL',identity_source_ref='quote-fixture',confirmed_at='2026-10-15T00:00:00+00:00',effective_from='2026-10-15')
        self.args=dict(canonical=[self.canonical],research_links=[self.alias],quote_bindings=[self.quote],accounts={self.account:{'currency':'BRL'}},portfolio_ids={'portfolio-fixture'},now=NOW)
    def chain(self):return m.assemble(**self.args)
    def result(self,chains=None):return self.case.project(identity_links=[self.alias],reference_links=self.chain() if chains is None else chains)
    def row(self,**kw):return self.result(**kw)['rows'][0]
    def test_complete_chain_references_real_quantity_without_rewriting(self):
        before=copy.deepcopy((self.args,self.case.plan,self.case.e,self.case.prices));r=self.row()
        self.assertEqual(r['reference_capital'],'200');self.assertEqual(r['source_instrument_id'],self.source);self.assertTrue(r['source_reference_reconciled'])
        self.assertFalse(r['financial_identifiers_rewritten']);self.assertIsNone(r['requested_amount'])
        self.assertEqual(r['models'][0]['reference_identity_chain']['canonical_binding_id'],'binding-fixture')
        self.assertEqual(before,(self.args,self.case.plan,self.case.e,self.case.prices))
    def test_alias_alone_stays_unvalued(self):self.assertIsNone(self.row(chains=[])['reference_capital'])
    def test_wrong_account_not_reused(self):
        rows=self.chain();rows[0]['account_id']='other';self.assertIsNone(self.row(chains=rows)['reference_capital'])
    def test_wrong_currency_not_reused(self):
        rows=self.chain();rows[0]['currency']='USD';self.assertIsNone(self.row(chains=rows)['reference_capital'])
    def test_wrong_provider_and_provider_id_not_reused(self):
        for key in ('provider','provider_id'):
            rows=self.chain();rows[0][key]='other';self.assertIsNone(self.row(chains=rows)['reference_capital'])
    def test_wrong_exact_instrument_not_reused(self):
        for key in ('position_instrument_id','research_instrument_id'):
            rows=self.chain();rows[0][key]='same-symbol-other-identity';self.assertIsNone(self.row(chains=rows)['reference_capital'])
    def test_unknown_quantity_still_blocked(self):
        self.case.plan['cases'][0]['quantity_upper_bound']=None;self.assertIsNone(self.row()['reference_capital'])
    def test_missing_and_duplicate_prices_still_blocked(self):
        self.case.prices=[];self.assertIsNone(self.row()['reference_capital'])
        self.case.prices=[{**self.case.e['forecasts'][0],'price':'100'}]*2;self.assertIsNone(self.row()['reference_capital'])
    def test_reference_cannot_predate_binding_effect(self):
        rows=self.chain();rows[0]['effective_from']='2026-10-18';self.assertIsNone(self.row(chains=rows)['reference_capital'])
    def test_future_effect_does_not_assemble(self):
        self.quote['effective_from']='2026-10-18';self.assertEqual(self.chain(),[])
    def test_no_confirmation_no_chain(self):
        del self.canonical['confirmation_digest']
        with self.assertRaisesRegex(ValueError,'CONFIRMED_CANONICAL'):self.chain()
    def test_future_confirmation_refused(self):
        self.canonical['confirmed_at']='2026-10-18T00:00:00+00:00'
        with self.assertRaisesRegex(ValueError,'FUTURE'):self.chain()
    def test_unknown_account_or_portfolio_refused(self):
        for key,value in [('account_id','other'),('portfolio_id','other')]:
            old=self.canonical[key];self.canonical[key]=value
            with self.assertRaisesRegex(ValueError,'CURRENT_REGISTERED'):self.chain()
            self.canonical[key]=old
    def test_duplicate_source_binding_refused(self):
        self.args['canonical']*=2
        with self.assertRaisesRegex(ValueError,'AMBIGUOUS'):self.chain()
    def test_duplicate_reference_chain_refused(self):
        rows=self.chain()
        with self.assertRaisesRegex(ValueError,'AMBIGUOUS'):m.index(rows*2)
    def test_nonmatching_quote_creates_no_chain(self):
        self.quote['quote_currency']='EUR';self.assertEqual(self.chain(),[])
    def test_current_chain_does_not_manufacture_costs(self):
        r=self.result();analysis.attach_reviewed_costs(r,[]);row=r['rows'][0]
        self.assertTrue(row['execution_cost_capacity_models']);self.assertEqual(row['reviewed_two_leg_cost_scenarios'],[])
        self.assertIn('TWO_LEG_CURRENT_COSTS_REQUIRED',row['missing_reasons']);self.assertFalse(row['execution_authorized'])
    def test_costs_remain_scoped_to_original_financial_identity(self):
        r=self.result();old=self.source
        reviews=base.Costs().reviews()
        analysis.attach_reviewed_costs(r,reviews)
        self.assertEqual(len(r['rows'][0]['reviewed_two_leg_cost_scenarios']),1)
        self.assertIsNone(r['rows'][0]['requested_amount'])
    def test_loader_is_read_only_and_detects_source_race(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=root/'data/canonical_position_identity_bindings.json';p.parent.mkdir();raw=json.dumps({'schema':'porquinho.canonical-position-identity-binding/1.0','bindings':[self.canonical]}).encode();p.write_bytes(raw)
            with patch('universal_portfolio.account_cost_evidence_a24.accounts',return_value=(self.args['accounts'],'hash')),patch('universal_portfolio.reviewed_research_identity_links_a24.load',return_value=[self.alias]),patch('universal_portfolio.explicit_market_bindings_a24.load',return_value={'bindings':[self.quote]}),patch('universal_portfolio.portfolio_registry.PortfolioRegistry.list_portfolios',return_value=[SimpleNamespace(portfolio_id='portfolio-fixture')]):
                self.assertEqual(m.load(root,now=NOW),self.chain());self.assertEqual(p.read_bytes(),raw)
                with patch('universal_portfolio.economic_action_plan_a24.source_versions',side_effect=[{'version':1},{'version':2}]):
                    with self.assertRaisesRegex(ValueError,'CHANGED_DURING_READ'):m.load(root,now=NOW)
    def test_absent_canonical_source_does_not_guess(self):
        with tempfile.TemporaryDirectory() as root:self.assertEqual(m.load(root,now=NOW),[])
if __name__=='__main__':unittest.main()
