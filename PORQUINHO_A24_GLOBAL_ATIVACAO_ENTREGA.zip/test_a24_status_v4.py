from pathlib import Path
import unittest,importlib.util,json,io,time
spec=importlib.util.spec_from_file_location('a24status',str(Path(__file__).resolve().parent/'PORQUINHO_A24_ATIVAR_GLOBAL_V4.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Fragmented(io.BytesIO):
 def read(self,n=-1):return super().read(min(n,3))
class LargeStream:
 def __init__(self):
  self.parts=[b'{"history":{"blob":"', 34*1024*1024,b'"},"jobs":[{"status":"running","result":{"secret":"OMIT"}}],"snapshot":{"timestamp":"NOW","private":"OMIT"}}'];self.index=0
 def read(self,n):
  if self.index>=len(self.parts):return b''
  value=self.parts[self.index]
  if isinstance(value,int):
   out=b'x'*min(n,value);value-=len(out);self.parts[self.index]=value
   if not value:self.index+=1
   return out
  self.index+=1;return value
class Streaming(unittest.TestCase):
 def read(self,v):return m.StatusReader(io.BytesIO(json.dumps(v,ensure_ascii=False).encode())).read()
 def test_extract_only_required_data(self):
  v={'jobs':[{'status':'running','result':{'private':'NEVER_RETURN'}}],'snapshot':{'timestamp':'NOW','cash':123456},'history':{'secret':'VALUE'}}
  self.assertEqual(self.read(v),{'jobs':[{'status':'running'}],'snapshot':{'timestamp':'NOW'}})
 def test_larger_than_32_mib_without_buffering_snapshot(self):
  started=time.monotonic();r=m.StatusReader(LargeStream());v=r.read()
  self.assertGreater(r.total,32*1024*1024);self.assertLessEqual(len(r.buffer),65536)
  self.assertTrue(m.busy(v));print('34 MiB parsed in %.2fs; selected fields only'%(time.monotonic()-started))
 def test_fragmented_utf8_and_escapes(self):
  raw=json.dumps({'snapshot':{'timestamp':'ação " \\ ☀'},'jobs':[]},ensure_ascii=False).encode()
  self.assertEqual(m.StatusReader(Fragmented(raw)).read()['snapshot']['timestamp'],'ação " \\ ☀')
 def test_job_results_can_contain_status_decoys(self):
  self.assertFalse(m.busy(self.read({'jobs':[{'status':'done','result':{'status':'running'}}],'snapshot':{}})))
 def test_missing_job_status_refuses(self):
  with self.assertRaises(RuntimeError):self.read({'jobs':[{'result':{'status':'done'}}],'snapshot':{}})
 def test_unknown_status_refuses(self):
  with self.assertRaises(RuntimeError):self.read({'jobs':[{'status':'unknown'}],'snapshot':{}})
 def test_missing_contract_refuses(self):
  with self.assertRaises(RuntimeError):self.read({'jobs':[]})
 def test_duplicate_root_key_refuses(self):
  with self.assertRaises(RuntimeError):m.StatusReader(io.BytesIO(b'{"jobs":[],"jobs":[],"snapshot":{}}')).read()
 def test_truncated_document_refuses(self):
  with self.assertRaises(RuntimeError):m.StatusReader(io.BytesIO(b'{"jobs":[],"snapshot":{')).read()
 def test_invalid_skipped_json_refuses(self):
  with self.assertRaises((RuntimeError,ValueError)):m.StatusReader(io.BytesIO(b'{"secret":INVALID,"jobs":[],"snapshot":{}}')).read()
 def test_trailing_data_refuses(self):
  with self.assertRaises(RuntimeError):m.StatusReader(io.BytesIO(b'{"jobs":[],"snapshot":{}}SECRET')).read()
 def test_oversized_selected_string_refuses(self):
  with self.assertRaises(RuntimeError):self.read({'jobs':[],'snapshot':{'timestamp':'x'*20000}})
if __name__=='__main__':unittest.main(verbosity=2)
