"""Aggregate-only, read-only diagnostics. Does not resolve or assign identities."""
import csv,datetime as dt,hashlib,json,math
from pathlib import Path

UNIT='EXPLICIT_QUOTE_NEUTRAL_VALUES_SOURCE_UNATTESTED'

def text(v):return isinstance(v,str) and bool(v) and v==v.strip()
def finite(v):
    try:return not isinstance(v,bool) and math.isfinite(float(v))
    except (ValueError,TypeError,OverflowError):return False

def classification(row,forecast=False):
    origin=[row.get(k) for k in ('provider','provider_id','quote_currency')]
    iid=row.get('instrument_id')
    if not text(iid):return 'MISSING_INSTRUMENT_ID'
    if not all(text(v) for v in origin):return 'MISSING_OR_INVALID_PROVIDER_QUOTE'
    q=origin[-1]
    if not q.isascii() or not q.isalpha() or not q.isupper():return 'INVALID_QUOTE_CODE'
    if forecast:
        if row.get('price_unit_status')!=UNIT:return 'UNVERIFIED_PRICE_UNIT'
        if not finite(row.get('prediction_30d_pct',row.get('prediction_pct'))):return 'INVALID_PREDICTION'
    elif not finite(row.get('price')) or float(row['price'])<=0:return 'MISSING_OR_INVALID_NEUTRAL_PRICE'
    return 'EXPLICIT_BINDING_UNATTESTED'


def binding_diagnostics(root,checkpoint=None):
    root=Path(root);out={}
    def add(counts,key):counts[key]=counts.get(key,0)+1
    def missing(counts,row):
        for key in ('instrument_id','provider','provider_id','quote_currency'):
            if not text(row.get(key)):add(counts,key)
    def signature(path):
        s=path.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)
    market=root/'data/database/market_daily.csv'
    if not market.is_file():out['market']={'status':'MISSING'}
    else:
        before=signature(market);counts={};latest_counts={};missing_counts={};latest_missing={};latest=None;n=0
        with market.open(newline='',encoding='utf-8') as f:
            reader=csv.DictReader(f)
            for row in reader:
                n+=1
                if n>2000000:raise ValueError('MARKET_ROW_LIMIT')
                state=classification(row);add(counts,state);missing(missing_counts,row)
                try:day=dt.date.fromisoformat(row.get('date',''))
                except (ValueError,TypeError):continue
                if latest is None or day>latest:latest=day;latest_counts={};latest_missing={}
                if day==latest:add(latest_counts,state);missing(latest_missing,row)
        stable=before==signature(market)
        out['market']={'status':'READ_ONLY_COUNTS' if stable else 'CHANGED_DURING_READ',
                       'rows':n if stable else None,'counts':counts if stable else {},
                       'latest_date':latest.isoformat() if latest and stable else None,
                       'latest_date_counts':latest_counts if stable else {},
                       'missing_fields':missing_counts if stable else {},'latest_date_missing_fields':latest_missing if stable else {}}
    lab=root/'results/prediction_lab.json'
    if not lab.is_file():out['prediction_lab']={'status':'MISSING'}
    else:
        before=signature(lab)
        if before[2]>32*1024*1024:raise ValueError('LAB_SIZE_LIMIT')
        value=json.loads(lab.read_text());groups={}
        if not isinstance(value,dict):raise ValueError('LAB_SCHEMA_INVALID')
        for key in ('predictions','ensemble_predictions'):
            rows=value.get(key) or []
            if not isinstance(rows,list) or any(not isinstance(r,dict) for r in rows):raise ValueError('LAB_ROWS_INVALID')
            counts={};missing_counts={}
            for row in rows:
                add(counts,classification(row,forecast=True));missing(missing_counts,row)
            groups[key]={'rows':len(rows),'counts':counts,'missing_fields':missing_counts}
        stable=before==signature(lab)
        trained=value.get('trained_at')
        out['prediction_lab']={'status':'READ_ONLY_COUNTS' if stable else 'CHANGED_DURING_READ',
                               'trained_at':trained if isinstance(trained,str) and len(trained)<=80 and stable else None,
                               'groups':groups if stable else {}}
    journal=root/'results/p35e_research_forecast_issuance.jsonl'
    if not journal.is_file():out['issuance']={'status':'MISSING','records':0}
    else:
        before=signature(journal);previous='GENESIS';counts={};missing_counts={};n=0;prefix=None;seen=set()
        if checkpoint and checkpoint.get('records')==0:prefix='GENESIS'
        with journal.open(encoding='utf-8') as f:
            for line in f:
                if len(line)>1024*1024 or not line.endswith('\n'):raise ValueError('JOURNAL_LINE_INVALID')
                item=json.loads(line);body=item['body']
                encoded=json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
                digest=hashlib.sha256((previous+'|'+encoded).encode()).hexdigest()
                if item.get('previous_hash')!=previous or item.get('hash')!=digest:raise ValueError('JOURNAL_CHAIN_INVALID')
                fid=body.get('forecast_id')
                if not text(fid) or fid in seen:raise ValueError('JOURNAL_ID_INVALID_OR_DUPLICATE')
                seen.add(fid);previous=digest;n+=1
                if n>2000000:raise ValueError('JOURNAL_ROW_LIMIT')
                add(counts,classification(body,forecast=True));missing(missing_counts,body)
                if checkpoint and n==checkpoint.get('records'):prefix=digest
        stable=before==signature(journal)
        out['issuance']={'status':'VERIFIED_LOCAL_CHAIN_UNATTESTED' if stable else 'CHANGED_DURING_READ',
                         'records':n if stable else None,'counts':counts if stable else {},'missing_fields':missing_counts if stable else {},
                         '_tail_hash':previous if stable else None,'_prior_prefix_hash':prefix if stable else None}
    return out


def public_diagnostics(value):
    return {key:{k:v for k,v in block.items() if not k.startswith('_')} for key,block in value.items()}
