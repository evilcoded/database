import csv,hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('diag',str(Path(__file__).resolve().parent/'a24_global_binding_diagnostics.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Diagnostics(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  (self.root/'data/database').mkdir(parents=True);(self.root/'results').mkdir()
 def csv(self,rows):
  with (self.root/'data/database/market_daily.csv').open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=sorted(set().union(*(set(r) for r in rows))));w.writeheader();w.writerows(rows)
 def bound(self,**extra):
  return dict(instrument_id='PRIVATE-ID',provider='PRIVATE-PROVIDER',provider_id='PRIVATE-SOURCE',quote_currency='USD',price=10,date='2026-10-15',**extra)
 def append(self,body,previous='GENESIS'):
  digest=hashlib.sha256((previous+'|'+json.dumps(body,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)).encode()).hexdigest()
  with (self.root/'results/p35e_research_forecast_issuance.jsonl').open('a') as f:f.write(json.dumps({'body':body,'previous_hash':previous,'hash':digest})+'\n')
  return digest
 def test_missing_is_explicit(self):
  d=m.binding_diagnostics(self.root);self.assertEqual(d['market']['status'],'MISSING');self.assertEqual(d['issuance']['records'],0)
 def test_partial_metadata_counts_each_missing_field(self):
  self.csv([{'asset':'SECRET','date':'2026-10-15','price_eur':10}])
  d=m.binding_diagnostics(self.root)['market'];self.assertEqual(d['counts'],{'MISSING_INSTRUMENT_ID':1});self.assertEqual(d['missing_fields'],dict.fromkeys(['instrument_id','provider','provider_id','quote_currency'],1))
 def test_latest_counts_do_not_retroactively_upgrade_history(self):
  self.csv([self.bound(),{'asset':'SECRET','date':'2026-10-14','price_eur':10}])
  d=m.binding_diagnostics(self.root)['market'];self.assertEqual(d['counts'],{'EXPLICIT_BINDING_UNATTESTED':1,'MISSING_INSTRUMENT_ID':1});self.assertEqual(d['latest_date_counts'],{'EXPLICIT_BINDING_UNATTESTED':1})
 def test_neutral_price_is_required(self):
  row=self.bound();row.pop('price');row['price_eur']=10;self.csv([row]);self.assertEqual(m.binding_diagnostics(self.root)['market']['counts'],{'MISSING_OR_INVALID_NEUTRAL_PRICE':1})
 def test_bad_quote_is_not_valid_binding(self):
  row=self.bound();row['quote_currency']='usd';self.assertEqual(m.classification(row),'INVALID_QUOTE_CODE')
 def test_lab_groups_preserve_missing_fields(self):
  row=self.bound(prediction_30d_pct=1,price_unit_status=m.UNIT)
  (self.root/'results/prediction_lab.json').write_text(json.dumps({'trained_at':'2026-10-15T00:00:00+00:00','predictions':[row],'ensemble_predictions':[{'asset':'SECRET'}]}))
  d=m.binding_diagnostics(self.root)['prediction_lab']['groups'];self.assertEqual(d['predictions']['counts'],{'EXPLICIT_BINDING_UNATTESTED':1});self.assertEqual(d['ensemble_predictions']['missing_fields']['instrument_id'],1)
 def test_unit_status_required_for_forecast(self):
  row=self.bound(prediction_30d_pct=1);self.assertEqual(m.classification(row,forecast=True),'UNVERIFIED_PRICE_UNIT')
 def test_verified_prefix_preserved_when_append(self):
  tail=self.append({'forecast_id':'FIRST'});before=m.binding_diagnostics(self.root)['issuance']
  self.append({'forecast_id':'SECOND'},tail);after=m.binding_diagnostics(self.root,checkpoint=before)['issuance'];self.assertEqual(after['_prior_prefix_hash'],tail);self.assertEqual(after['records'],2)
 def test_rewritten_valid_chain_is_not_same_prefix(self):
  self.append({'forecast_id':'FIRST'});before=m.binding_diagnostics(self.root)['issuance']
  (self.root/'results/p35e_research_forecast_issuance.jsonl').unlink();self.append({'forecast_id':'DIFFERENT'})
  after=m.binding_diagnostics(self.root,checkpoint=before)['issuance'];self.assertNotEqual(after['_prior_prefix_hash'],before['_tail_hash'])
 def test_corrupted_chain_rejected(self):
  self.append({'forecast_id':'FIRST'});p=self.root/'results/p35e_research_forecast_issuance.jsonl';p.write_text(p.read_text().replace('FIRST','OTHER'))
  with self.assertRaisesRegex(ValueError,'CHAIN'):m.binding_diagnostics(self.root)
 def test_duplicate_id_rejected(self):
  tail=self.append({'forecast_id':'FIRST'});self.append({'forecast_id':'FIRST'},tail)
  with self.assertRaisesRegex(ValueError,'DUPLICATE'):m.binding_diagnostics(self.root)
 def test_no_individual_values_or_hashes_in_public_report(self):
  row=self.bound(prediction_pct=1,price_unit_status=m.UNIT,forecast_id='PRIVATE-FORECAST');self.csv([row]);self.append(row)
  output=json.dumps(m.public_diagnostics(m.binding_diagnostics(self.root)))
  self.assertNotIn('PRIVATE-',output);self.assertNotIn('_tail_hash',output)
 def test_reading_preserves_all_files(self):
  self.csv([self.bound()]);self.append({'forecast_id':'FIRST'})
  before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};m.binding_diagnostics(self.root)
  self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
if __name__=='__main__':unittest.main(verbosity=1)
