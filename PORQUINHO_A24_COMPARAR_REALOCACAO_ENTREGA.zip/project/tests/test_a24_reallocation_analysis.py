import copy,datetime as dt,json,unittest
from decimal import Decimal
from unittest.mock import patch
import test_a24_economic_action_plan as fixture
from universal_portfolio import reallocation_analysis_a24 as m
from universal_portfolio import account_cost_evidence_a24 as costs
NOW=dt.datetime(2026,10,17,12,tzinfo=dt.timezone.utc)
I,J=fixture.I,fixture.J

def forecast(i,value,provider_id):
 return dict(instrument_id=i,provider='CoinGecko',provider_id=provider_id,quote_currency='BRL',origin='2026-10-17',last_training_label_end='2026-10-16',value_pct=value)
def experiment(algorithm='Ridge',source=2,destination=5):
 fs=[forecast(I,source,'source'),forecast(J,destination,'destination')]
 folds=[]
 for f,values in zip(fs,[[-8,4],[-4,6]]):
  for origin,target,value in [('2026-08-01','2026-08-31',values[0]),('2026-09-01','2026-10-01',values[1])]:
   folds.append({**f,'origin':origin,'target':target,'last_training_label_end':'2026-07-31','actual_pct':value})
 return dict(quote_currency='BRL',algorithm=algorithm,cohort_digest='cohort',computed_at=NOW.isoformat(),horizon_unit='OBSERVATIONS',horizon_value=30,execution_authorized=False,model_validation_proven=False,forecasts=fs,folds=folds)

class Compare(unittest.TestCase):
 def setUp(self):
  self.plan=fixture.Plan().project();self.e=experiment()
  self.prices=[{**self.e['forecasts'][0],'price':'100'}]
 def project(self,experiments=None,**kw):return m.project(self.plan,[self.e] if experiments is None else experiments,now=NOW,prices=self.prices,**kw)
 def row(self,**kw):return self.project(**kw)['rows'][0]
 def test_compares_existing_realocation_not_cash_only(self):
  r=self.row();self.assertEqual(r['source_instrument_id'],I);self.assertEqual(r['destination_instrument_id'],J)
  self.assertEqual(r['status'],'GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING')
 def test_common_capital_gross_difference_is_not_trade_size(self):
  r=self.row();self.assertEqual(Decimal(r['reference_capital']),200);self.assertEqual(Decimal(r['models'][0]['gross_uplift_amount']),6)
  self.assertIsNone(r['requested_amount']);self.assertIsNone(r['requested_quantity']);self.assertFalse(r['sizing_created'])
 def test_risk_uses_same_matured_windows(self):
  x=self.row()['models'][0];self.assertEqual(x['paired_matured_fold_count'],2)
  self.assertLess(Decimal(x['destination_historical_downside_rms_pct']),Decimal(x['source_historical_downside_rms_pct']))
 def test_negative_forecast_can_still_be_relative_advantage(self):
  self.e=experiment(source=-10,destination=-5);self.assertEqual(Decimal(self.row()['models'][0]['gross_uplift_pp']),5)
 def test_lower_destination_forecast_keeps_origin_advantage(self):
  self.e=experiment(source=5,destination=2);self.assertEqual(self.row()['status'],'NO_GROSS_ADVANTAGE_IN_AVAILABLE_MODELS')
 def test_model_disagreement_is_not_majority_vote(self):
  r=self.project(experiments=[self.e,experiment('Other',source=8,destination=3)])
  self.assertEqual(r['rows'][0]['status'],'MODEL_DISAGREEMENT_OR_RISK_TRADEOFF');self.assertIsNone(r['selected_winner'])
 def test_higher_downside_not_silently_risk_adjusted(self):
  self.e['folds'][2]['actual_pct']=-20;self.assertEqual(self.row()['status'],'MODEL_DISAGREEMENT_OR_RISK_TRADEOFF')
 def test_no_folds_never_implies_zero_risk(self):
  self.e['folds']=[];r=self.row();self.assertIsNone(r['models'][0]['source_historical_downside_rms_pct']);self.assertNotEqual(r['status'],'GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING')
 def test_future_targets_not_used_for_historical_risk(self):
  for f in self.e['folds']:f['target']='2026-10-18'
  self.assertEqual(self.row()['models'][0]['paired_matured_fold_count'],0)
 def test_no_cross_currency_match(self):
  self.e['quote_currency']='EUR'
  for f in self.e['forecasts']:f['quote_currency']='EUR'
  self.assertEqual(self.project()['compared_pair_count'],0)
 def test_same_symbol_cannot_supply_missing_identity(self):
  self.e['forecasts'][1]['instrument_id']='OTHER:ID';self.e['forecasts'][1]['asset']='TEST'
  self.assertEqual(self.project()['compared_pair_count'],0)
 def test_ambiguous_provider_not_chosen(self):
  self.e['forecasts'].append({**self.e['forecasts'][1],'provider_id':'alternative'})
  self.assertEqual(self.project()['compared_pair_count'],0)
 def test_no_common_origin_no_compare(self):
  self.e['forecasts'][1]['origin']='2026-10-16';self.assertEqual(self.project()['compared_pair_count'],0)
 def test_stale_forecast_no_compare(self):
  for f in self.e['forecasts']:f['origin']='2026-10-12'
  self.assertEqual(self.project()['compared_pair_count'],0)
 def test_future_forecast_no_compare(self):
  for f in self.e['forecasts']:f['origin']='2026-10-18'
  self.assertEqual(self.project()['compared_pair_count'],0)
 def test_no_inferred_eur_or_fixed_currency_list(self):
  for c in self.plan['cases']:
   c['currency']='JPY'
   for a in c['alternatives']:
    a['currency']='JPY';a['manual_account_asset_scope'].update(account_currency='JPY',transaction_currency='JPY')
  self.e['quote_currency']='JPY'
  for f in self.e['forecasts']+self.e['folds']:f['quote_currency']='JPY'
  self.assertEqual(self.row()['currency'],'JPY')
 def test_reviewed_alias_allows_research_not_valuation_or_order(self):
  for f in self.e['forecasts']+self.e['folds']:
   if f['instrument_id']==I:f['instrument_id']='RESEARCH:SOURCE'
  links=[dict(position_instrument_id=I,research_instrument_id='RESEARCH:SOURCE',evidence_ref='review')]
  r=self.row(identity_links=links);self.assertTrue(r['models']);self.assertIsNone(r['reference_capital']);self.assertTrue(r['research_alias_used'])
 def test_alias_to_same_asset_not_realocation(self):
  links=[dict(position_instrument_id=I,research_instrument_id=J,evidence_ref='review')]
  self.assertEqual(self.project(identity_links=links)['pair_count'],0)
 def test_unknown_quantity_no_fabricated_capital(self):
  self.plan['cases'][0]['quantity_upper_bound']=None;self.assertIsNone(self.row()['reference_capital'])
 def test_duplicate_price_no_valuation(self):
  self.prices*=2;self.assertIsNone(self.row()['reference_capital'])
 def test_duplicate_experiments_refused(self):
  with self.assertRaisesRegex(ValueError,'DUPLICATE_EXPERIMENT'):self.project(experiments=[self.e,self.e])
 def test_mixed_horizon_refused(self):
  self.e['horizon_unit']='DAYS'
  with self.assertRaisesRegex(ValueError,'HORIZON'):self.project()
 def test_different_account_alt_refused(self):
  self.plan['cases'][0]['alternatives'][-1]['account_id']='other'
  with self.assertRaisesRegex(ValueError,'SAME_ACCOUNT'):self.project()
 def test_nonfinite_model_refused(self):
  self.e['forecasts'][1]['value_pct']='NaN'
  with self.assertRaisesRegex(ValueError,'FINITE'):self.project()
 def test_inputs_and_history_unchanged(self):
  before=copy.deepcopy((self.plan,self.e,self.prices));self.project();self.assertEqual(before,(self.plan,self.e,self.prices))
 def test_no_cost_assumption_or_canonical_wait(self):
  r=self.row();self.assertIsNone(r['net_advantage_amount']);self.assertIsNone(r['transaction_cost'])
  self.assertIn('TWO_LEG_CURRENT_COSTS_REQUIRED',r['missing_reasons']);self.assertNotIn('PROSPECTIVE_POLICY_VALIDATION_REQUIRED',r['missing_reasons'])
 def test_no_execution_or_promotion(self):
  r=self.project()
  for row in [r]+r['rows']:
   for k,v in m.flags().items():self.assertEqual(row[k],v)

class Costs(unittest.TestCase):
 setUp=Compare.setUp
 project=Compare.project
 def reviews(self,fee='1'):
  def row(i,side,cap):return dict(account_id='account',currency='BRL',instrument_id=i,side=side,reference_amount=cap,evidence_id=side,execution_venue_id='venue',components={k:{'status':'KNOWN' if k=='brokerage' else 'NOT_APPLICABLE','amount':fee if k=='brokerage' else None} for k in costs.COMPONENTS})
  return [row(I,'SELL','200'),row(J,'BUY',str(Decimal(200)-2*Decimal(fee)))]
 def test_exact_two_leg_costs_can_reverse_gross_advantage(self):
  r=m.attach_reviewed_costs(self.project(),self.reviews('5'))['rows'][0]
  self.assertLess(Decimal(r['reviewed_two_leg_cost_scenarios'][0]['models'][0]['execution_cost_adjusted_uplift_amount']),0)
  self.assertFalse(r['recommendation_created']);self.assertIsNone(r['requested_amount'])
 def test_cost_other_account_never_spread(self):
  rr=self.reviews();rr[1]['account_id']='other';r=m.attach_reviewed_costs(self.project(),rr)
  self.assertFalse(r['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_partial_costs_not_zero(self):
  rr=self.reviews();rr[1]['components']['spread']['status']='UNKNOWN';r=m.attach_reviewed_costs(self.project(),rr)
  self.assertFalse(r['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_no_tariff_scaling(self):
  rr=self.reviews();rr[0]['reference_amount']='100';self.assertFalse(m.attach_reviewed_costs(self.project(),rr)['rows'][0]['reviewed_two_leg_cost_scenarios'])
 def test_both_cost_legs_reduce_invested_capital(self):
  r=m.attach_reviewed_costs(self.project(),self.reviews())['rows'][0];c=r['reviewed_two_leg_cost_scenarios'][0]
  self.assertEqual(Decimal(c['destination_notional']),198);self.assertEqual(Decimal(c['models'][0]['execution_cost_adjusted_uplift_amount']),Decimal('3.90'))

class Build(unittest.TestCase):
 def test_verified_experiment_read_no_fit_network_or_writes(self):
  import test_a24_global_existing_lab as fixture_lab
  from brain.evolution import global_existing_lab_a24 as lab
  from universal_portfolio import global_history_source_a24 as storage
  f=fixture_lab.Reuse();f.setUp();self.addCleanup(f.doCleanups)
  job,body=f.result();storage.store_once(job['path'],body)
  before={str(p):p.read_bytes() for p in f.root.rglob('*') if p.is_file()}
  with patch.object(lab,'model_for',side_effect=AssertionError('NO_TRAINING')):
   result=m.build(f.root,f.demand,fixture.Plan().project(),now=fixture_lab.NOW)
  self.assertEqual(result['status'],'REALLOCATION_COMPARISONS_INSPECTED')
  self.assertEqual(before,{str(p):p.read_bytes() for p in f.root.rglob('*') if p.is_file()})
 def test_corrupt_experiment_reports_unavailable(self):
  import test_a24_global_existing_lab as fixture_lab
  from universal_portfolio import global_history_source_a24 as storage
  f=fixture_lab.Reuse();f.setUp();self.addCleanup(f.doCleanups)
  job,body=f.result();body['horizon_unit']='DAYS';storage.store_once(job['path'],body)
  self.assertEqual(m.build(f.root,f.demand,fixture.Plan().project(),now=fixture_lab.NOW)['status'],'REALLOCATION_ANALYSIS_UNAVAILABLE')
