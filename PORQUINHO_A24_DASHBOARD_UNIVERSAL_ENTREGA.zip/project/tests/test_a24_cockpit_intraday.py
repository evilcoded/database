import datetime as dt,unittest,tempfile
from pathlib import Path
from universal_portfolio import cockpit_intraday_a24 as m
NOW=dt.datetime(2026,10,17,12,tzinfo=dt.timezone.utc)
class Intraday(unittest.TestCase):
 def row(self,**kw):return dict(timestamp='2026-10-17T11:00:00+00:00',asset='ETH',source='coingecko_resampled_10m',price_eur='2000',**kw)
 def project(self,rows,legacy=True):return m.project(rows,now=NOW,legacy_contract=legacy)
 def test_legacy_contract_is_reference_not_identity_or_attestation(self):
  s=self.project([self.row()])['series'][0];self.assertEqual(s['quote_currency'],'EUR');self.assertIsNone(s['instrument_id']);self.assertIsNone(s['provider_id']);self.assertFalse(s['historical_row_attestation'])
 def test_suffix_alone_cannot_establish_currency(self):self.assertFalse(self.project([self.row()],legacy=False)['series'])
 def test_explicit_global_brl_not_forced_to_eur(self):
  r=self.row(instrument_id='ID:ETH',quote_currency='BRL',provider='Source',provider_id='ethereum',price='10000');s=self.project([r],legacy=False)['series'][0];self.assertEqual(s['quote_currency'],'BRL');self.assertEqual(s['scope'],'EXPLICIT_ROW_CONTEXT')
 def test_arbitrary_currency_supported(self):
  r=self.row(instrument_id='ID:ASSET',quote_currency='JPY',provider='Source',provider_id='x',price='2');self.assertEqual(self.project([r])['series'][0]['quote_currency'],'JPY')
 def test_naive_timestamp_not_assumed_utc(self):
  r=self.row();r['timestamp']='2026-10-17T11:00:00';self.assertFalse(self.project([r])['series'])
 def test_future_timestamp_excluded(self):
  r=self.row();r['timestamp']='2026-10-18T11:00:00+00:00';self.assertFalse(self.project([r])['series'])
 def test_duplicate_instants_in_different_offsets_not_chosen(self):
  a=self.row();b=self.row();b['timestamp']='2026-10-17T12:00:00+01:00';self.assertFalse(self.project([a,b])['series'])
 def test_observed_cadence_not_fabricated_minute_data(self):
  a=self.row();b=self.row();b['timestamp']='2026-10-17T11:10:00+00:00';s=self.project([a,b])['series'][0];self.assertEqual(s['observed_cadence_seconds'],600);self.assertEqual(len(s['points']),2)
 def test_nonfinite_prices_not_plotted(self):
  r=self.row();r['price_eur']='NaN';self.assertFalse(self.project([r])['series'])
 def test_unknown_source_not_inferred_from_label(self):
  r=self.row();r['source']='other';self.assertFalse(self.project([r])['series'])
 def test_contract_inspects_request_and_cadence(self):
  self.assertTrue(m.contract("def fetch_intraday():\n x={'vs_currency':'eur'}\n y=x.resample('10min')\n"));self.assertFalse(m.contract("def fetch_intraday():\n x={'vs_currency':'usd'}\n y=x.resample('10min')\n"))
 def test_reader_preserves_files_and_no_collection(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data/database').mkdir(parents=True);p=root/'data/database/market_intraday_10m.csv';p.write_text('timestamp,asset,source,price_eur\n2026-10-17T11:00:00+00:00,ETH,coingecko_resampled_10m,2000\n');before=p.read_bytes();r=m.build(root,now=NOW);self.assertEqual(p.read_bytes(),before);self.assertFalse(r['new_collection_requested']);self.assertFalse(r['history_write_performed'])
