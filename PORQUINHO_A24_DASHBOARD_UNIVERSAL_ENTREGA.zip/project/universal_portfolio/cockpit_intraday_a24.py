"""Read existing intraday only. Explicit global rows and isolated legacy reference.
Current producer compatibility is not historical identity/currency attestation.
"""
import ast,csv,datetime as dt,hashlib,io,math
from collections import defaultdict
from decimal import Decimal
from .explicit_market_bindings_a24 import local,digest
SCHEMA='porquinho.cockpit-intraday-a24/1.0'
def contract(raw):
 tree=ast.parse(raw);fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fetch_intraday']
 if len(fns)!=1:return False
 request=any(isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='vs_currency' and isinstance(v,ast.Constant) and v.value=='eur' for k,v in zip(n.keys,n.values)) for n in ast.walk(fns[0]))
 cadence=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='resample' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='10min' for n in ast.walk(fns[0]))
 return request and cadence

def project(rows,*,now,legacy_contract=False):
 if now.tzinfo is None:raise ValueError('AWARE_TIME_REQUIRED')
 now=now.astimezone(dt.timezone.utc)
 groups=defaultdict(list);duplicates=set();seen=set();skipped=0
 for r in rows:
  try:
   ts=dt.datetime.fromisoformat(str(r.get('timestamp')).replace('Z','+00:00'))
   if ts.tzinfo is None or not now-dt.timedelta(hours=48)<=ts<=now:skipped+=1;continue
   ts=ts.astimezone(dt.timezone.utc)
   iid=r.get('instrument_id');q=r.get('quote_currency');provider=r.get('provider');pid=r.get('provider_id')
   if all(isinstance(x,str) and x.strip()==x and x for x in (iid,q,provider,pid)) and q.isalpha() and q.isupper():
    price=Decimal(str(r.get('price')));key=(iid,q,provider,pid,'EXPLICIT_ROW_CONTEXT');label=r.get('asset') or iid
   elif legacy_contract and r.get('source')=='coingecko_resampled_10m' and r.get('asset'):
    price=Decimal(str(r.get('price_eur')));key=(None,'EUR','coingecko',r['asset'],'CURRENT_LEGACY_CODE_COMPATIBILITY_ONLY');label=r['asset']
   else:skipped+=1;continue
   if not price.is_finite() or price<=0 or not math.isfinite(float(price)) or float(price)<=0:skipped+=1;continue
   k=key+(ts.isoformat(),)
   if k in seen:duplicates.add(key)
   seen.add(k);groups[(key,str(label))].append({'date':ts.isoformat(),'price':str(price)})
  except (ValueError,TypeError,ArithmeticError):skipped+=1
 series=[]
 for (key,label),points in sorted(groups.items(),key=lambda x:str(x[0])):
  if key in duplicates:skipped+=len(points);continue
  points=sorted(points,key=lambda p:p['date'])
  gaps=sorted((dt.datetime.fromisoformat(b['date'])-dt.datetime.fromisoformat(a['date'])).total_seconds() for a,b in zip(points,points[1:]))
  series.append({'series_id':digest(list(key)),'instrument_id':key[0],'display_label':label,'quote_currency':key[1],'provider':key[2],'provider_id':key[3] if key[4]=='EXPLICIT_ROW_CONTEXT' else None,
   'scope':key[4],'historical_row_attestation':False,'financial_identity_binding_created':False,'points':points,
   'observed_cadence_seconds':gaps[len(gaps)//2] if gaps else None,'resampling_in_current_producer':key[4]=='CURRENT_LEGACY_CODE_COMPATIBILITY_ONLY'})
 return {'schema':SCHEMA,'status':'INTRADAY_INSPECTED','series':series,'series_count':len(series),'skipped_rows':skipped,
  'observed_at':now.isoformat(),'new_collection_requested':False,'execution_authorized':False,'history_write_performed':False,'financial_mutation':False}

def build(root,*,now):
 try:
  p=local(root,'data/database/market_intraday_10m.csv');code=local(root,'tools/fetch_history.py')
  if not p.exists():return project([],now=now)
  if p.stat().st_size>32*1024*1024:raise ValueError('INTRADAY_READ_LIMIT')
  raw=p.read_bytes();producer=code.read_bytes() if code.exists() else b''
  result=project(list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))),now=now,legacy_contract=contract(producer) if producer else False)
  if p.read_bytes()!=raw or (code.read_bytes() if code.exists() else b'')!=producer:raise ValueError('INTRADAY_CHANGED_DURING_READ')
  result['producer_sha256']=hashlib.sha256(producer).hexdigest();return result
 except Exception as exc:return {'schema':SCHEMA,'status':'INTRADAY_UNAVAILABLE','series':[],'error_type':type(exc).__name__,'execution_authorized':False,'history_write_performed':False,'financial_mutation':False}
