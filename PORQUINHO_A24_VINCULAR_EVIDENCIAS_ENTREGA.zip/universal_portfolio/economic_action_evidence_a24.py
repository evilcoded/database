"""Attach existing scoped historical and planning facts to draft economic actions.
No tariff inference, utility policy creation, model promotion, sizing or trade.
"""
import copy
import datetime as dt
from collections import Counter
from pathlib import Path
from . import economic_action_plan_a24 as plan
from . import observed_trade_costs_a24 as observed
from . import account_cost_evidence_a24 as costs
from .explicit_market_bindings_a24 import digest
SCHEMA='porquinho.economic-action-evidence-a24/1.0'
class EvidenceError(ValueError):pass

def project(action_plan,observed_costs,*,plans=(),reviews=(),now):
 if action_plan.get('schema')!=plan.SCHEMA or action_plan.get('status')!='ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY':raise EvidenceError('CURRENT_ACTION_CONTEXTS_REQUIRED')
 if any(action_plan.get(k)!=v for k,v in plan.flags().items()):raise EvidenceError('NONAUTHORIZING_ACTION_PLAN_REQUIRED')
 if observed_costs.get('schema')!=observed.SCHEMA or observed_costs.get('status') not in ('EXISTING_TRADE_COSTS_OBSERVED','EXISTING_LEDGER_NOT_PRESENT'):raise EvidenceError('VERIFIED_EXISTING_COST_OBSERVATIONS_REQUIRED')
 if any(observed_costs.get(k)!=v for k,v in observed.flags().items()):raise EvidenceError('HISTORICAL_COST_AUTHORITY_REQUIRED')
 if observed_costs.get('status')=='EXISTING_TRADE_COSTS_OBSERVED' and (observed_costs.get('ledger_local_chain_verified') is not True or observed_costs.get('source_files_stable_during_read') is not True):raise EvidenceError('VERIFIED_STABLE_HISTORICAL_SOURCE_REQUIRED')
 history={}
 for row in observed_costs.get('observations',[]):
  if row.get('status')!='EXECUTED_TRADE_AND_FEE_OBSERVED' or row.get('economic_role')!='REALIZED_TRADE_COST_NOT_PRETRADE_TARIFF':raise EvidenceError('OBSERVED_COST_SEMANTICS_REQUIRED')
  if any(row.get(k)!=v for k,v in observed.flags().items()):raise EvidenceError('OBSERVED_COST_NONAUTHORIZING_REQUIRED')
  key=row.get('trade_event_id')
  if not isinstance(key,str) or not key or key in history:raise EvidenceError('UNIQUE_HISTORICAL_TRADE_REQUIRED')
  stamp=observed.instant(row.get('executed_at'))
  if stamp is None or stamp>now:raise EvidenceError('HISTORICAL_TRADE_TIME_REQUIRED')
  history[key]=row
 active_plans=[]
 for p in plans:
  if p.get('status')!='ACTIVE':continue
  if p.get('authority')!='NONE' or p.get('automatic_execution_authorized') is not False or p.get('execution_mode')!='MANUAL':raise EvidenceError('ACTIVE_MANUAL_PLANNING_ONLY')
  active_plans.append(p)
 if len({p['plan_id'] for p in active_plans})!=len(active_plans):raise EvidenceError('UNIQUE_ACTIVE_PLAN_REQUIRED')
 current_reviews=[]
 for row in reviews:
  costs.validate(row,now=now)
  if costs.timestamp(row['effective_from'])<=now<costs.timestamp(row['effective_until']):current_reviews.append(row)
 output=[]
 for case in action_plan['cases']:
  aid=case['account_id'];currency=case['currency'];ap=[p for p in active_plans if p.get('source_account_id')==aid and p.get('currency')==currency]
  planning={'active_plan_refs':[{'plan_id':p['plan_id'],'source_ref':'data/investment_plans.json','record_digest':digest(p),
    'strategy':copy.deepcopy(p.get('strategy')),'period':copy.deepcopy(p.get('period')),'allowed_asset_classes':list(p.get('allowed_asset_classes') or [])} for p in ap],
   'capital_ceiling':case.get('capital_ceiling'),'capital_ceiling_is_order_size':False,
   'utility_policy_inferred_from_strategy':False,'utility_policy':None}
  for alternative in case['alternatives']:
   kind=alternative['kind'];iid=alternative['instrument_id'];source=alternative.get('source_instrument_id')
   legs=[]
   if kind=='REALLOCATE':specs=[('SELL',source),('BUY',iid)]
   elif kind in ('SELL','REDUCE'):specs=[('SELL',iid)]
   elif kind in ('INCREASE','DEPLOY_CASH'):specs=[('BUY',iid)]
   elif kind in ('KEEP','NO_ALLOCATION'):specs=[]
   else:raise EvidenceError('SUPPORTED_ACTION_KIND_REQUIRED')
   if len(specs)!=alternative['trade_leg_count']:raise EvidenceError('ACTION_LEG_COUNT_MISMATCH')
   identities={x for side,x in specs}
   if iid:identities.add(iid)
   historical=[r for r in history.values() if r.get('instrument_id') in identities and r.get('account_id')==aid and r.get('currency')==currency]
   for side,target in specs:
    exact=[r for r in historical if r['instrument_id']==target and r['side']==side]
    scenarios=[r for r in current_reviews if (r['instrument_id'],r['account_id'],r['currency'],r['side'])==(target,aid,currency,side)]
    legs.append({'side':side,'instrument_id':target,'account_id':aid,'currency':currency,
     'past_same_side_trade_refs':[{'event_id':r['trade_event_id'],'event_hash':r['trade_event_hash']} for r in exact],
     'reviewed_cost_scenario_refs':[{'evidence_id':r['evidence_id'],'record_digest':digest(r),'execution_venue_id':r['execution_venue_id'],
       'reference_amount':r['reference_amount'],'complete_component_declarations':all(r['components'][name]['status']!='UNKNOWN' for name in costs.COMPONENTS)} for r in scenarios],
     'status':'CURRENT_ORDER_CONTEXT_REQUIRED' if scenarios else 'CURRENT_PRETRADE_COST_EVIDENCE_REQUIRED',
     'selected_cost_evidence_id':None,'execution_venue_selected':None,'reference_amount_selected':None,'future_cost_estimate':None,
     'historical_rate_used':False,'comparison_authorized':False})
   no_trade=not specs
   output.append({'case_id':case['case_id'],'alternative_id':alternative['alternative_id'],'kind':kind,
    'instrument_id':iid,'account_id':aid,'currency':currency,'horizon_unit':alternative['horizon_unit'],'horizon_value':alternative['horizon_value'],
    'planning':planning,'quantity_upper_bound':case.get('quantity_upper_bound'),'historical_cost_basis':case.get('historical_cost_basis'),
    'cost_basis_role':'ACQUISITION_BOOK_BASIS_NOT_MARKET_VALUE_OR_CERTIFIED_TAX_LOTS',
    'historical_trade_refs':[{'event_id':r['trade_event_id'],'event_hash':r['trade_event_hash'],'side':r['side'],'fee_event_ids':list(r['fee_event_ids'])} for r in historical],
    'legs':legs,'execution_transaction_cost':{'status':'NOT_APPLICABLE_NO_TRANSACTION_LEGS' if no_trade else 'CURRENT_LEG_CONTEXT_REQUIRED',
      'value':'0' if no_trade else None,'unit':'CURRENCY_AMOUNT','currency':currency,'scope':'EXECUTION_LEGS_ONLY_NOT_ONGOING_HOLDING_COSTS',
      'validation_status':'STRUCTURAL_COST_APPLICABILITY_NOT_COMPARATOR_VALIDATION'},
    'remaining_comparison_blockers':list(alternative['blocking_reasons']),
    'status':'EXISTING_FACTS_ATTACHED_NOT_COMPARATOR_READY',**plan.flags()})
 return {'schema':SCHEMA,'status':'ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY','alternatives':output,
  'historical_trade_population_count':len(history),'historical_fees_used_as_future_tariff':False,
  'utility_policy_inferred_from_strategy':False,'historical_basis_used_as_available_capital':False,**plan.flags()}

def summarize(value):
 if value.get('schema')!=SCHEMA:raise EvidenceError('ACTION_EVIDENCE_SCHEMA_REQUIRED')
 if value.get('status')!='ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY':return {k:v for k,v in value.items() if k!='alternatives'}
 rows=value['alternatives'];legs=[leg for r in rows for leg in r['legs']]
 return {'schema':SCHEMA,'status':value['status'],'alternative_count':len(rows),'leg_count':len(legs),
  'alternatives_with_historical_trade_count':sum(bool(r['historical_trade_refs']) for r in rows),
  'distinct_historical_trades_reused':len({ref['event_id'] for r in rows for ref in r['historical_trade_refs']}),
  'cases_with_book_cost_basis':len({r['case_id'] for r in rows if r.get('historical_cost_basis') is not None}),
  'cases_with_active_plan':len({r['case_id'] for r in rows if r['planning']['active_plan_refs']}),
  'no_transaction_leg_alternative_count':sum(not r['legs'] for r in rows),
  'legs_with_reviewed_cost_scenarios':sum(bool(leg['reviewed_cost_scenario_refs']) for leg in legs),
  'future_cost_estimates_created':0,'utility_policies_created':0,'historical_fees_used_as_future_tariff':False,
  'remaining_blocker_counts':dict(Counter(reason for r in rows for reason in r['remaining_comparison_blockers'])),**plan.flags()}

def build(root,action_plan,observed_costs,*,now=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 try:
  from .investment_plan_store import InvestmentPlanStore
  root=Path(root).resolve(strict=True)
  if action_plan.get('source_version_digest')!=digest(plan.source_versions(root)):raise EvidenceError('ACTION_SOURCES_CHANGED_BEFORE_EVIDENCE')
  registered,_=costs.accounts(root);reviews=[]
  for row in costs.load(root,now=now).values():
   try:costs.current_scope(row,registered)
   except costs.CostError:continue
   reviews.append(row)
  result=project(action_plan,observed_costs,plans=InvestmentPlanStore(root/'data/investment_plans.json').list(),reviews=reviews,now=now)
  if action_plan['source_version_digest']!=digest(plan.source_versions(root)):raise EvidenceError('ACTION_SOURCES_CHANGED_DURING_EVIDENCE')
  return result
 except Exception as exc:return {'schema':SCHEMA,'status':'ACTION_EVIDENCE_UNAVAILABLE','reason':str(exc) if isinstance(exc,EvidenceError) else type(exc).__name__,'alternatives':[],**plan.flags()}
