import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
import test_a24_economic_action_plan as fixture
import test_a24_account_cost_evidence as review_fixture
from universal_portfolio import economic_action_evidence_a24 as e,observed_trade_costs_a24 as o
NOW=review_fixture.NOW
class Evidence(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Plan();self.kw=self.f.setup();self.kw['positions'][0]['cost_basis']='10';self.p=fixture.m.project(**self.kw)
  self.row={'instrument_id':fixture.I,'account_id':'account','currency':'BRL','side':'BUY','executed_at':(NOW-dt.timedelta(hours=1)).isoformat(),'trade_event_id':'trade','trade_event_hash':'hash','fee_event_ids':['fee'],'status':'EXECUTED_TRADE_AND_FEE_OBSERVED','economic_role':'REALIZED_TRADE_COST_NOT_PRETRADE_TARIFF',**o.flags()}
  self.history={'schema':o.SCHEMA,'status':'EXISTING_TRADE_COSTS_OBSERVED','observations':[self.row],'ledger_local_chain_verified':True,'source_files_stable_during_read':True,**o.flags()}
 def result(self,**kw):return e.project(self.p,self.history,plans=self.kw['plans'],now=NOW,**kw)
 def test_exact_history_reused(self):self.assertEqual(e.summarize(self.result())['distinct_historical_trades_reused'],1)
 def test_account_mismatch_no_reuse(self):self.row['account_id']='other';self.assertEqual(e.summarize(self.result())['distinct_historical_trades_reused'],0)
 def test_currency_mismatch_no_reuse(self):self.row['currency']='EUR';self.assertEqual(e.summarize(self.result())['distinct_historical_trades_reused'],0)
 def test_identity_not_matched_by_symbol_or_research_alias(self):self.row['instrument_id']='OTHER:ID';self.row['symbol']='TEST';self.assertEqual(e.summarize(self.result())['distinct_historical_trades_reused'],0)
 def test_realocation_two_correct_scoped_legs(self):
  r=next(r for r in self.result()['alternatives'] if r['kind']=='REALLOCATE');self.assertEqual([(x['side'],x['instrument_id']) for x in r['legs']],[('SELL',fixture.I),('BUY',fixture.J)])
 def test_entry_fee_not_a_sell_fee(self):
  r=next(r for r in self.result()['alternatives'] if r['kind']=='SELL');self.assertTrue(r['historical_trade_refs']);self.assertFalse(r['legs'][0]['past_same_side_trade_refs']);self.assertIsNone(r['legs'][0]['future_cost_estimate'])
 def test_no_trade_execution_cost_is_not_holding_cost(self):
  r=next(r for r in self.result()['alternatives'] if r['kind']=='KEEP');self.assertEqual(r['execution_transaction_cost']['value'],'0');self.assertEqual(r['execution_transaction_cost']['scope'],'EXECUTION_LEGS_ONLY_NOT_ONGOING_HOLDING_COSTS')
 def test_trade_cost_unknown_not_zero(self):
  r=next(r for r in self.result()['alternatives'] if r['kind']=='SELL');self.assertIsNone(r['execution_transaction_cost']['value'])
 def test_zero_book_basis_preserved_as_known(self):
  self.kw['positions'][0]['cost_basis']='0';self.p=fixture.m.project(**self.kw);r=self.result();self.assertEqual(e.summarize(r)['cases_with_book_cost_basis'],1);self.assertEqual(next(x for x in r['alternatives'] if x['kind']=='KEEP')['historical_cost_basis'],'0')
 def test_strategy_not_converted_to_utility(self):
  self.kw['plans'][0]['strategy']='BALANCED';r=self.result();self.assertTrue(r['alternatives'][0]['planning']['active_plan_refs']);self.assertIsNone(r['alternatives'][0]['planning']['utility_policy']);self.assertFalse(r['utility_policy_inferred_from_strategy'])
 def test_other_account_plan_not_reused(self):
  self.kw['plans'][0]['source_account_id']='other';self.assertEqual(e.summarize(self.result())['cases_with_active_plan'],0)
 def test_future_trade_refused(self):
  self.row['executed_at']=(NOW+dt.timedelta(seconds=1)).isoformat()
  with self.assertRaises(ValueError):self.result()
 def test_unverified_history_refused(self):
  self.history['ledger_local_chain_verified']=False
  with self.assertRaises(ValueError):self.result()
 def test_authority_leak_refused(self):
  self.p['execution_authorized']=True
  with self.assertRaises(ValueError):self.result()
 def test_reviewed_quote_does_not_choose_venue_or_amount(self):
  row=review_fixture.Cost().row(account_id='account',instrument_id=fixture.I);r=self.result(reviews=[row]);legs=[x for a in r['alternatives'] for x in a['legs'] if x['side']=='BUY' and x['instrument_id']==fixture.I]
  self.assertTrue(legs[0]['reviewed_cost_scenario_refs']);self.assertIsNone(legs[0]['selected_cost_evidence_id']);self.assertIsNone(legs[0]['reference_amount_selected']);self.assertIsNone(legs[0]['execution_venue_selected']);self.assertIsNone(legs[0]['future_cost_estimate'])
 def test_expired_quote_not_linked_as_current(self):
  row=review_fixture.Cost().row(account_id='account',instrument_id=fixture.I,effective_until=(NOW-dt.timedelta(seconds=1)).isoformat());self.assertEqual(e.summarize(self.result(reviews=[row]))['legs_with_reviewed_cost_scenarios'],0)
 def test_inputs_not_mutated_and_output_not_aliasing_history(self):
  before=copy.deepcopy((self.p,self.history,self.kw['plans']));r=self.result();self.assertEqual(before,(self.p,self.history,self.kw['plans']));next(x for x in r['alternatives'] if x['historical_trade_refs'])['historical_trade_refs'][0]['fee_event_ids'].append('other');self.assertEqual(self.row['fee_event_ids'],['fee'])
 def test_summary_contains_no_accounts_amounts_or_event_ids(self):
  s=json.dumps(e.summarize(self.result()));self.assertNotIn('"account_id"',s);self.assertNotIn('"capital_ceiling"',s);self.assertNotIn('"historical_cost_basis"',s);self.assertNotIn('"event_id"',s)
 def test_stale_action_snapshot_refused_before_reading_more(self):
  with tempfile.TemporaryDirectory() as tmp:
   (Path(tmp)/'data').mkdir();r=e.build(tmp,self.p,self.history,now=NOW);self.assertEqual(r['reason'],'ACTION_SOURCES_CHANGED_BEFORE_EVIDENCE')
 def test_existing_comparison_blockers_and_authority_preserved(self):
  r=self.result();original={a['alternative_id']:a for c in self.p['cases'] for a in c['alternatives']}
  for row in r['alternatives']:
   self.assertEqual(row['remaining_comparison_blockers'],original[row['alternative_id']]['blocking_reasons'])
   for k,v in fixture.m.flags().items():self.assertEqual(row[k],v)
