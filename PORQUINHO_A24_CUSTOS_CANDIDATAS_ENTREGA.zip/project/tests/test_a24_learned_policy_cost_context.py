import copy
import unittest
from unittest.mock import patch
from universal_portfolio import learned_policy_cost_context_a24 as p
from universal_portfolio import learned_policy_economic_basis_a24 as economic
from universal_portfolio import learned_policy_account_context_a24 as scoped

class Costs(unittest.TestCase):
    def setUp(self):
        self.scenario = dict(account_id='A', currency='BRL', budget_reference_capital='100',candidate_id='C',policy_version_digest='V',budget_id='B',plan_id='P')
        self.leg = dict(instrument_id='I',quote_currency='BRL',fraction_numerator=1,fraction_denominator=3)
        self.review = dict(account_id='A',instrument_id='I',currency='BRL',side='BUY',reference_amount='33.33',institution_id='BANK',institution_country='BR',execution_venue_id='VENUE',evidence_id='Q')
        self.history = dict(self.review,trade_event_id='T',trade_event_hash='H',fee_event_ids=['F'],fee_event_hashes=['FH'],executed_at='2026-10-16T00:00:00Z',observed_fee_amount='1',observed_fee_to_gross_fraction='0.01')

    def match(self, history=None, reviews=None):
        with patch.object(p.quotes,'current_scope'):
            return p.match_leg(self.scenario,self.leg,history or [],reviews or {},{},lambda q:dict(status='REVIEWED_PRETRADE_COST_ESTIMATE_NOT_VALIDATED',total_cost='1'))

    def test_exact_historical_link_does_not_make_tariff(self):
        x=self.match([self.history]);self.assertEqual(x['historical_trade_count'],1);self.assertIsNone(x['future_cost_estimate']);self.assertFalse(x['future_tariff_inferred'])

    def test_history_cannot_cross_account_currency_identity_or_side(self):
        for k,v in [('account_id','OTHER'),('currency','EUR'),('instrument_id','OTHER'),('side','SELL')]:
            with self.subTest(k=k):
                h=dict(self.history,**{k:v});self.assertEqual(self.match([h])['historical_trade_count'],0)

    def test_rounded_third_does_not_match_exact_fraction(self):
        self.assertFalse(self.match(reviews={'Q':self.review})['reviewed_quote_candidates'])

    def test_exact_fraction_matches_without_order_or_venue_selection(self):
        self.leg['fraction_denominator']=4;self.review['reference_amount']='25.00'
        x=self.match(reviews={'Q':self.review});self.assertEqual(len(x['reviewed_quote_candidates']),1);self.assertFalse(x['execution_venue_selected']);self.assertFalse(x['order_notional_created']);self.assertEqual(x['total_cost_status'],'UNKNOWN')

    def test_multiple_venues_remain_candidates(self):
        self.leg['fraction_denominator']=4;self.review['reference_amount']='25'
        other=dict(self.review,evidence_id='Q2',execution_venue_id='OTHER')
        self.assertEqual(len(self.match(reviews={'Q':self.review,'Q2':other})['reviewed_quote_candidates']),2)

    def test_quote_cannot_cross_scope(self):
        self.leg['fraction_denominator']=4;self.review['reference_amount']='25'
        for k,v in [('account_id','OTHER'),('currency','EUR'),('instrument_id','OTHER'),('side','SELL')]:
            with self.subTest(k=k):self.assertFalse(self.match(reviews={'Q':dict(self.review,**{k:v})})['reviewed_quote_candidates'])

    def test_currency_mismatch_refused(self):
        self.leg['quote_currency']='EUR'
        with self.assertRaises(ValueError):self.match()

    def test_fraction_bounds_refused(self):
        for n,d in [(0,3),(-1,3),(4,3)]:
            self.leg.update(fraction_numerator=n,fraction_denominator=d)
            with self.assertRaises(ValueError):self.match()

    def fixture(self):
        scope=dict(schema=scoped.SCHEMA,scenarios=[dict(self.scenario,legs=[self.leg])])
        basis=dict(schema=economic.SCHEMA,rows=[copy.deepcopy(self.scenario)],**economic.flags())
        return scope,basis

    def test_source_change_prevents_partial_attachment(self):
        scope,basis=self.fixture()
        with patch.object(p.observed,'read',side_effect=[dict(status='EXISTING_TRADE_COSTS_OBSERVED',observations=[]),dict(status='EXISTING_TRADE_COSTS_OBSERVED',observations=[self.history])]),patch.object(p.quotes,'load',return_value={}),patch.object(p.quotes,'accounts',return_value=({},'D')):
            p.attach('.',basis,scope,now=None)
        self.assertEqual(basis['cost_context_summary']['status'],'CANDIDATE_COST_CONTEXT_UNAVAILABLE');self.assertNotIn('cost_context',basis['rows'][0])

    def test_success_summary_has_no_identifiers_or_amounts(self):
        scope,basis=self.fixture()
        with patch.object(p.observed,'read',return_value=dict(status='EXISTING_TRADE_COSTS_OBSERVED',observations=[self.history])),patch.object(p.quotes,'load',return_value={}),patch.object(p.quotes,'accounts',return_value=({},'D')):
            p.attach('.',basis,scope,now=None)
        s=basis['cost_context_summary'];self.assertEqual(s['legs_with_realized_fee_evidence'],1);self.assertEqual(s['future_cost_complete_scenario_count'],0);self.assertNotIn('account_id',s);self.assertNotIn('observed_fee_amount',s)

    def test_missing_source_preserves_existing_basis(self):
        scope,basis=self.fixture();before=copy.deepcopy(basis['rows'])
        with patch.object(p.observed,'read',side_effect=ValueError):p.attach('.',basis,scope,now=None)
        self.assertEqual(basis['rows'],before)

    def test_different_scenario_refused(self):
        scope,basis=self.fixture();basis['rows'][0]['candidate_id']='OTHER'
        with patch.object(p.observed,'read',return_value=dict(status='EXISTING_TRADE_COSTS_OBSERVED',observations=[])),patch.object(p.quotes,'load',return_value={}),patch.object(p.quotes,'accounts',return_value=({},'D')):p.attach('.',basis,scope,now=None)
        self.assertEqual(basis['cost_context_summary']['status'],'CANDIDATE_COST_CONTEXT_UNAVAILABLE')
