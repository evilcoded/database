"""Common research units and observed behavior groups; no net utility invented."""
import datetime as dt
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
from fractions import Fraction
from . import learned_policy_account_context_a24 as scoped
from . import capital_relative_utility as utility
from .explicit_market_bindings_a24 import digest
from brain.evolution import learned_allocation_policy_a24 as learner

SCHEMA = 'porquinho.learned-policy-economic-basis-a24/1.0'


class BasisError(ValueError):
    pass


def flags():
    return {**scoped.flags(), 'gross_projection_is_validated_forward_return': False,
            'observed_behavior_groups_are_independent_evidence': False,
            'grouping_selects_winner': False, 'historical_fees_used_as_future_tariff': False,
            'net_utility_created': False, 'ranking_created': False}


def weights(rows, k):
    return [[*key, str(Fraction(1, k))] for key in sorted(learner.allocation(rows, k))]


def candidate_data(policies, experiments):
    out = {}
    for body in policies:
        version = body['version']; refs = version['input_experiments']
        if not isinstance(refs, dict) or not refs or len(refs) > 10:
            raise BasisError('BOUNDED_POLICY_EXPERIMENT_REFERENCES_REQUIRED')
        source = []
        for path, expected in refs.items():
            value = experiments.get(path)
            if value is None or digest(value) != expected:
                raise BasisError('EXACT_POLICY_SOURCE_EXPERIMENT_REQUIRED')
            source.append(value)
        now = dt.datetime.fromisoformat(body['computed_at'])
        if now.tzinfo is None or now.utcoffset() is None:
            raise BasisError('AWARE_POLICY_COMPUTATION_TIME_REQUIRED')
        research = learner.learn(source, now=now)
        if body['research'] != research:
            raise BasisError('LEARNED_RESEARCH_RECONSTRUCTION_MISMATCH')
        if research['status'] != 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY':
            continue
        by_algorithm = {e['algorithm']: e for e in source}
        vid = digest(version)
        for candidate in research['candidates']:
            key = vid, candidate['candidate_id']
            if key in out:
                raise BasisError('DUPLICATE_LEARNED_CANDIDATE_REFERENCE')
            exp = by_algorithm[candidate['algorithm']]; k = candidate['maximum_selected_sources']
            groups = defaultdict(list)
            for row in exp['folds']: groups[(row['origin'], row['target'])].append(row)
            path = []
            for phase in ('training_intervals', 'held_out_intervals'):
                for origin, target in research[phase]:
                    rows = groups.get((origin, target))
                    if not rows:
                        raise BasisError('EXACT_POLICY_EVALUATION_PATH_REQUIRED')
                    path.append({'phase': phase, 'origin': origin, 'target': target,
                                 'weights': weights(rows, k),
                                 'cash': str(Fraction(k - len(learner.allocation(rows, k)), k))})
            current = [{**row, 'prediction_pct': row['value_pct']} for row in exp['forecasts']]
            current_weights = weights(current, k)
            current_cash = Fraction(k - len(current_weights), k)
            with localcontext() as ctx:
                ctx.prec = 50
                selected = learner.allocation(current, k)
                gross = sum((Decimal(str(row['value_pct'])) / Decimal(k) for row in current if learner.identity(row) in selected), Decimal(0))
            distribution = {'currency': research['quote_currency'], 'origin': candidate['current_forecast_origin'],
                            'source_weights': current_weights, 'nominal_cash_fraction': str(current_cash)}
            out[key] = {'candidate': candidate, 'research': research,
                        'nominal_cash_zero_return_projection_pct': str(gross),
                        'current_distribution_digest': digest(distribution),
                        'observed_behavior_digest': digest({'policy_version': vid, 'path': path, 'current': distribution}),
                        'current_cash_fraction': str(current_cash)}
    return out


def project(value, policies, experiments):
    if value.get('schema') != scoped.SCHEMA or value.get('status') != 'LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY' or any(value.get(k) != v for k, v in scoped.flags().items()):
        raise BasisError('NONAUTHORIZING_CURRENT_POLICY_SCOPE_REQUIRED')
    sources = candidate_data(policies, experiments)
    rows = []
    for scenario in value['scenarios']:
        source = sources.get((scenario['policy_version_digest'], scenario['candidate_id']))
        if source is None:
            raise BasisError('SCENARIO_POLICY_REFERENCE_NOT_RESOLVED')
        candidate = source['candidate']; research = source['research']
        if scenario['currency'] != research['quote_currency'] or (scenario['horizon_unit'], scenario['horizon_value']) != (research['horizon_unit'], research['horizon_value']):
            raise BasisError('SCENARIO_POLICY_COMMON_UNIT_MISMATCH')
        # Scope and source weights must remain identical; grouping may not trim
        # a blocked leg, redistribute a sleeve, or invent a cost notional.
        expected = sorted([*learner.identity(w), str(Fraction(1, candidate['maximum_selected_sources']))] for w in candidate['current_research_weights'])
        actual = sorted([*learner.identity(w), str(Fraction(w['fraction_numerator'], w['fraction_denominator']))] for w in scenario['legs'])
        if expected != actual or Fraction(scenario['cash_fraction_numerator'], scenario['cash_fraction_denominator']) != Fraction(source['current_cash_fraction']):
            raise BasisError('SCOPED_DISTRIBUTION_CHANGED')
        cap = scenario['budget_reference_capital']
        # UNKNOWN is intentional, including cash-only candidates. Execution fees
        # may be inapplicable there, but account yield/carrying costs are unknown.
        with localcontext() as ctx:
            ctx.prec = 50
            common = utility.build(action='RESEARCH_INCREMENTAL_CASH_DISTRIBUTION',
                currency=scenario['currency'], reference_capital=cap,
                horizon_unit=scenario['horizon_unit'], horizon_value=scenario['horizon_value'],
                expected_return_pct=source['nominal_cash_zero_return_projection_pct'],
                transaction_cost_status='UNKNOWN', risk_measure=None).payload()
        basis = {k: scenario[k] for k in ('account_id', 'currency', 'budget_id', 'plan_id', 'horizon_unit', 'horizon_value')}
        basis.update(reference_capital=common['reference_capital'],
                     forecast_origin=candidate['current_forecast_origin'])
        gaps = sorted(set(scenario['blocking_reasons']) | {
            'GROSS_RESEARCH_FORECAST_NOT_VALIDATED', 'FORWARD_RISK_MODEL_REQUIRED',
            'CARRYING_COST_MODEL_REQUIRED',
            'RISK_RETURN_UTILITY_MODEL_REQUIRED'})
        if scenario['legs']: gaps = sorted(set(gaps) | {'CURRENT_PRETRADE_VENUE_AND_NOTIONAL_REQUIRED'})
        if Fraction(source['current_cash_fraction']) > 0: gaps = sorted(set(gaps) | {'CASH_YIELD_MODEL_REQUIRED'})
        rows.append({**basis, 'basis_group_digest': digest(basis),
            'candidate_id': scenario['candidate_id'], 'policy_version_digest': scenario['policy_version_digest'],
            'current_distribution_group_digest': source['current_distribution_digest'],
            'observed_behavior_group_digest': source['observed_behavior_digest'],
            'common_research_unit': common,
            'gross_projection_semantics': 'MODEL_RESEARCH_WITH_NOMINAL_CASH_PRICE_RETURN_ZERO_NOT_ACCOUNT_NET_RETURN',
            'current_cash_fraction': source['current_cash_fraction'],
            'training_observed_risk': candidate['training'],
            'held_out_observed_results': candidate['held_out'],
            'observed_risk_is_forward_risk': False,
            'execution_transaction_cost_status': 'NOT_APPLICABLE_NO_TRADE_LEGS' if not scenario['legs'] else 'CURRENT_QUOTE_REQUIRED',
            'total_cost_status': 'UNKNOWN', 'expected_net_change': None, 'utility_score': None,
            'execution_venue_selected': False, 'order_notional_created': False,
            'comparability_gaps': gaps, **flags()})
        if len(rows) > 20000:
            raise BasisError('ECONOMIC_RESEARCH_ROW_LIMIT')
    return {'schema': SCHEMA, 'status': 'COMMON_RESEARCH_BASIS_ASSESSED_NOT_ECONOMICALLY_VALIDATED',
            'rows': rows, 'discarded_candidate_count': 0, **flags()}


def summarize(value):
    if value.get('schema') != SCHEMA:
        raise BasisError('ECONOMIC_RESEARCH_SCHEMA_REQUIRED')
    if value.get('status') != 'COMMON_RESEARCH_BASIS_ASSESSED_NOT_ECONOMICALLY_VALIDATED':
        return {k: v for k, v in value.items() if k != 'rows'}
    groups = defaultdict(list)
    for row in value['rows']: groups[row['basis_group_digest']].append(row)
    return {'schema': SCHEMA, 'status': value['status'], 'cost_context_summary': value.get('cost_context_summary'), 'scenario_count': len(value['rows']),
            'common_basis_group_count': len(groups),
            'current_distribution_group_count': sum(len({r['current_distribution_group_digest'] for r in rows}) for rows in groups.values()),
            'observed_behavior_group_count': sum(len({r['observed_behavior_group_digest'] for r in rows}) for rows in groups.values()),
            'net_comparable_scenario_count': 0, 'discarded_candidate_count': 0,
            'comparability_gap_counts': dict(Counter(g for r in value['rows'] for g in r['comparability_gaps'])),
            'grouping_semantics': 'SAME_OBSERVED_ALLOCATIONS_NOT_EQUIVALENCE_ON_UNSEEN_DATA_OR_INDEPENDENT_EVIDENCE',
            **flags()}
