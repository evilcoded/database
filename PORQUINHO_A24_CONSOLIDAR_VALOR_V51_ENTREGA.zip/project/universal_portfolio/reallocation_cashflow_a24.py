"""Consolidate commission scenarios into planning debit ceilings; never select size.
BUY debit includes its commission. Documentary sale proceeds remain provisional.
"""
from decimal import Decimal,localcontext,ROUND_FLOOR
from collections import defaultdict,Counter
from .account_cost_evidence_a24 import number,CostError

def assess(row,precision):
    base={'schema':'porquinho.reallocation-cashflow-a24/1.0','status':'EXPLICIT_CURRENCY_PRECISION_REQUIRED',
          'scenarios':[],'budget_groups':[],'selected_amount':None,'recommended_amount':None,
          'execution_authorized':False,'financial_mutation':False,'history_write_performed':False,
          'actual_bank_quote_proven':False,'net_performance_validated':False,
          'value_semantics':'PLANNING_BUY_DEBIT_CEILING_NOT_SELECTED_TRADE'}
    if type(precision) is not int or not 0<=precision<=18:return base
    with localcontext() as ctx:
        ctx.prec=200;quantum=Decimal(1).scaleb(-precision);scenarios=[];groups=defaultdict(list)
        cap=number(row['reference_capital'],True)
        hs=row.get('commission_funding',{}).get('scenarios',[])
        if len(hs)>128:raise CostError('CASHFLOW_SCENARIO_LIMIT')
        for h in hs:
            sold=number(h['source_sale_reference_amount'],True);sellfee=number(h['sell_commission'])
            principal=number(h['destination_reference_amount'],True);buyfee=number(h['buy_commission'])
            cash=number(h['cash_remainder']);left=number(h['remaining_source_reference_capital'])
            if sold+left!=cap or sold!=sellfee+principal+buyfee+cash:raise CostError('EXACT_CASHFLOW_CONSERVATION_REQUIRED')
            net=sold-sellfee;debit=principal+buyfee
            ceiling=(net/quantum).to_integral_value(rounding=ROUND_FLOOR)*quantum
            if ceiling<=0:continue
            state='PROVISIONAL_CASHFLOW_CONSOLIDATED' if debit<=ceiling and debit%quantum==0 else 'BANK_QUANTIZATION_OR_REQUOTE_REQUIRED'
            scenario={'status':state,'source_sale_reference_amount':str(sold),'sell_commission_provision':str(sellfee),
                      'sale_net_proceeds_provision':str(net),'buy_total_debit_provision':str(debit),
                      'buy_asset_principal_provision':str(principal),'buy_commission_included':str(buyfee),
                      'buy_debit_ceiling_provision':str(ceiling),'cash_remainder_provision':str(cash),
                      'remaining_source_reference_capital':str(left),'sell_category':h['sell_category'],'buy_category':h['buy_category'],
                      'conditional_category':h['conditional_category'],'buy_fee_is_already_in_total_debit':True,
                      'bank_quote_required':True,'selected':False,'execution_authorized':False}
            scenarios.append(scenario);groups[sold].append(scenario)
        summaries=[]
        for sold,items in sorted(groups.items()):
            ceilings=[number(i['buy_debit_ceiling_provision']) for i in items]
            summaries.append({'source_sale_reference_amount':str(sold),'minimum_buy_debit_ceiling_provision':str(min(ceilings)),
                              'maximum_buy_debit_ceiling_provision':str(max(ceilings)),
                              'single_ceiling_across_documented_categories':min(ceilings)==max(ceilings),
                              'scenario_count':len(items),'all_cashflows_at_registered_precision':all(i['status']=='PROVISIONAL_CASHFLOW_CONSOLIDATED' for i in items),
                              'bank_quote_required':True,'selected':False})
        return {**base,'status':'PROVISIONAL_BUY_BUDGETS_CONSOLIDATED' if scenarios else 'COMMISSION_FUNDED_HYPOTHESIS_REQUIRED',
                'scenarios':scenarios,'budget_groups':summaries,'status_counts':dict(Counter(s['status'] for s in scenarios))}
