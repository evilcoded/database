import copy,json,tempfile,unittest
from decimal import Decimal as D
from pathlib import Path
from universal_portfolio import reallocation_cashflow_a24 as m
from universal_portfolio.account_cost_evidence_a24 import CostError
from test_a24_commission_funding import row,variant,assess as fund

def fixture(cap='100'):
 v=variant(rounding_quantum='.01',rounding_mode='CEILING',rounding_stage='AFTER_CLAMP');r=row(cap,sell=v,buy=v);r['commission_funding']=fund(r,2);return r
class Cashflow(unittest.TestCase):
 def setUp(self):self.r=fixture()
 def get(self,r=None,p=2):return m.assess(r or self.r,p)
 def test_total_buy_debit_already_includes_fee(self):
  c=self.get()['scenarios'][0];self.assertEqual(D(c['buy_total_debit_provision']),D('97.50'));self.assertEqual(D(c['buy_asset_principal_provision']),D('95.12'));self.assertEqual(D(c['buy_commission_included']),D('2.38'))
 def test_sell_net_matches_buy_total_plus_cash(self):
  c=self.get()['scenarios'][0];self.assertEqual(D(c['sale_net_proceeds_provision']),D(c['buy_total_debit_provision'])+D(c['cash_remainder_provision']))
 def test_full_cashflow_conservation(self):
  c=self.get()['scenarios'][0];self.assertEqual(D(c['source_sale_reference_amount']),D(c['sell_commission_provision'])+D(c['buy_total_debit_provision'])+D(c['cash_remainder_provision']))
 def test_never_add_buy_fee_twice(self):
  c=self.get()['scenarios'][0];self.assertNotEqual(D(c['buy_total_debit_provision']),D('97.50')+D('2.38'));self.assertTrue(c['buy_fee_is_already_in_total_debit'])
 def test_same_sale_fee_different_buy_categories_preserve_budget(self):
  r=fixture();h=copy.deepcopy(r['commission_funding']['scenarios'][0]);h.update(destination_reference_amount='94.20',buy_commission='3.30',buy_category='conditional',conditional_category=True);r['commission_funding']['scenarios'].append(h)
  g=self.get(r)['budget_groups'][0];self.assertTrue(g['single_ceiling_across_documented_categories']);self.assertEqual(g['scenario_count'],2)
 def test_different_sell_category_retains_range(self):
  r=fixture();h=copy.deepcopy(r['commission_funding']['scenarios'][0]);h.update(sell_commission='3.50',destination_reference_amount='94.12',buy_commission='2.38',sell_category='conditional',conditional_category=True);r['commission_funding']['scenarios'].append(h)
  g=self.get(r)['budget_groups'][0];self.assertFalse(g['single_ceiling_across_documented_categories']);self.assertEqual(D(g['minimum_buy_debit_ceiling_provision']),D('96.50'));self.assertEqual(D(g['maximum_buy_debit_ceiling_provision']),D('97.50'))
 def test_partial_and_full_capitals_not_selected(self):
  r=fixture('200');v=variant(rounding_quantum='.01',rounding_mode='CEILING',rounding_stage='AFTER_CLAMP');r=row('200',sell=v,buy=v);r['commission_funding']=fund(r,2,notionals=['100']);out=self.get(r);self.assertEqual(len(out['budget_groups']),2);self.assertTrue(all(g['selected'] is False for g in out['budget_groups']))
 def test_unsold_fraction_preserved(self):
  c=self.get(fixture('100.009'))['scenarios'][0];self.assertEqual(D(c['remaining_source_reference_capital']),D('.009'))
 def test_currency_precision_is_explicit(self):self.assertEqual(self.get(p=None)['status'],'EXPLICIT_CURRENCY_PRECISION_REQUIRED')
 def test_boolean_precision_not_integer(self):self.assertFalse(self.get(p=True)['scenarios'])
 def test_arbitrary_currency_no_fx(self):
  r=fixture();r['currency']='XYZ';self.assertEqual(self.get(r)['status'],'PROVISIONAL_BUY_BUDGETS_CONSOLIDATED')
 def test_three_decimal_budget(self):
  r=row();r['commission_funding']=fund(r,3);g=self.get(r,3)['budget_groups'][0];self.assertEqual(D(g['maximum_buy_debit_ceiling_provision']),D('97.500'))
 def test_integer_budget_never_rounds_up(self):
  r=row();r['commission_funding']=fund(r,0);g=self.get(r,0)['budget_groups'][0];self.assertEqual(D(g['maximum_buy_debit_ceiling_provision']),D('97'))
 def test_unknown_bank_rounding_not_certified_by_currency_precision(self):
  r=row();r['commission_funding']=fund(r,2);self.assertEqual(self.get(r)['scenarios'][0]['status'],'BANK_QUANTIZATION_OR_REQUOTE_REQUIRED')
 def test_corrupt_cashflow_refused(self):
  self.r['commission_funding']['scenarios'][0]['cash_remainder']='1'
  with self.assertRaises(CostError):self.get()
 def test_capital_mismatch_refused(self):
  self.r['reference_capital']='99'
  with self.assertRaises(CostError):self.get()
 def test_negative_component_refused(self):
  self.r['commission_funding']['scenarios'][0]['buy_commission']='-1'
  with self.assertRaises(CostError):self.get()
 def test_scenario_limit(self):
  self.r['commission_funding']['scenarios']*=129
  with self.assertRaises(CostError):self.get()
 def test_no_scenarios_no_amount_invented(self):
  self.r['commission_funding']['scenarios']=[];self.assertEqual(self.get()['status'],'COMMISSION_FUNDED_HYPOTHESIS_REQUIRED')
 def test_no_order_selection_or_return_certification(self):
  out=self.get();self.assertIsNone(out['selected_amount']);self.assertIsNone(out['recommended_amount']);self.assertFalse(out['execution_authorized']);self.assertFalse(out['actual_bank_quote_proven']);self.assertFalse(out['net_performance_validated'])
 def test_inputs_preserved(self):
  old=copy.deepcopy(self.r);self.get();self.assertEqual(self.r,old)
 def test_audit_does_not_export_monetary_values(self):
  from tools.reallocation_source_audit_v43 import project
  self.r['reallocation_cashflow']={'status_counts':{'PROVISIONAL_CASHFLOW_CONSOLIDATED':1,'SECRET':2},'scenarios':[{'buy_total_debit_provision':'PRIVATE_VALUE'}]}
  out=project({'reallocation_analysis':{'rows':[self.r]}},{});self.assertNotIn('PRIVATE',json.dumps(out));self.assertNotIn('SECRET',json.dumps(out));self.assertEqual(out['pairs'][0]['reallocation_cashflow_status_counts'],{'PROVISIONAL_CASHFLOW_CONSOLIDATED':1})
 def test_pipeline_produces_cashflows_without_writes(self):
  import test_a24_research_tariff_context as f
  from universal_portfolio.research_tariff_context_a24 import build
  with tempfile.TemporaryDirectory() as root:
   h=f.TariffContext();h.setUp();r=h.build_fixture(root);p=Path(root)/'data/currency_registry.json';p.write_text(json.dumps({'schema':'porquinho.currency-registry/1.0','currencies':[{'currency_code':'EUR','active':True,'precision':2}]}));before={p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()};out=build(root,r,now=h.now)
   self.assertEqual(out['reallocation_cashflow_status_counts'],{'PROVISIONAL_BUY_BUDGETS_CONSOLIDATED':1});self.assertNotIn('reallocation_cashflow',r['rows'][0]);self.assertEqual(before,{p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()})
if __name__=='__main__':unittest.main()
