import copy,datetime as dt,json,tempfile,unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import research_tariff_context_a24 as m
from universal_portfolio.account_cost_evidence_a24 import CostError
import test_a24_reallocation_analysis as fixture

class TariffContext(unittest.TestCase):
 def setUp(self):
  self.policies=json.loads((Path(__file__).resolve().parents[1]/m.CATALOG).read_text())['policies']
  self.now=m.timestamp(self.policies[0]['source']['observed_at'])+dt.timedelta(seconds=1)
  self.account=dict(account_id='account',institution_id='institution',currency='EUR',pricing_plan='Standard',_institution_name='N26',_institution_country='DE')
 def leg(self,identity='binancecoin',amount='123.45',**kw):return m.leg(self.policies,self.account,'financial-original','EUR','CRYPTO',{('CoinGecko',identity)},Decimal(amount),'SELL',now=kw.get('now',self.now))
 def test_published_rates_are_data_not_bank_branches(self):
  self.policies[0]['scope'].update(institution_name='Other Institution',registry_country='ZZ',source_jurisdiction='ZZ',currency='JPY');self.account.update(_institution_name='Other Institution',_institution_country='ZZ',currency='JPY')
  r=m.leg(self.policies,self.account,'arbitrary-id','JPY','CRYPTO',{('CoinGecko','binancecoin')},Decimal('100'),'BUY',now=self.now);self.assertEqual(len(r['estimates']),2)
 def test_documented_rounding_and_conditional_categories(self):
  r=self.leg();self.assertEqual([e['commission_reference_amount'] for e in r['estimates']],['3.09','4.33']);self.assertTrue(all(e['conditional_category'] for e in r['estimates']));self.assertIsNone(r['total_cost'])
 def test_app_explanation_confirms_only_solana_standard_scope(self):
  r=self.leg('solana','100');self.assertEqual(len(r['estimates']),1);self.assertEqual(r['estimates'][0]['rate_pct'],'2.5');self.assertFalse(r['estimates'][0]['conditional_category']);self.assertEqual(r['estimates'][0]['classification_evidence']['kind'],'REVIEWED_APP_FEE_EXPLANATION');self.assertEqual(len(self.leg('ethereum','100')['estimates']),2)
 def test_exact_bitcoin_identity_selects_documented_category(self):
  r=self.leg('bitcoin','100');self.assertEqual([e['commission_reference_amount'] for e in r['estimates']],['1.5']);self.assertFalse(r['estimates'][0]['conditional_category'])
 def test_plan_change_refuses_previous_policy(self):
  self.account['pricing_plan']='Other';self.assertFalse(self.leg()['estimates'])
 def test_no_plan_does_not_default_standard(self):
  del self.account['pricing_plan'];self.assertFalse(self.leg()['estimates'])
 def test_country_currency_and_asset_class_scope(self):
  for key,value in [('_institution_country','PT'),('currency','BRL')]:
   previous=self.account[key];self.account[key]=value;self.assertFalse(self.leg()['estimates']);self.account[key]=previous
  self.assertFalse(m.leg(self.policies,self.account,'id','EUR','EQUITY',{('CoinGecko','solana')},Decimal('100'),'SELL',now=self.now)['estimates'])
 def test_unknown_identity_not_selected_by_ticker(self):self.assertFalse(self.leg('SOL')['estimates'])
 def test_multiple_provider_contexts_are_not_arbitrarily_selected(self):
  r=m.leg(self.policies,self.account,'id','EUR','CRYPTO',{('CoinGecko','solana'),('Other','solana')},Decimal('100'),'SELL',now=self.now);self.assertEqual(r['status'],'EXACT_PROVIDER_IDENTITY_REQUIRED')
 def test_expired_review_is_not_renewed_silently(self):
  r=self.leg(now=m.timestamp(self.policies[0]['source']['review_until']));self.assertEqual(r['status'],'TARIFF_SOURCE_RECHECK_REQUIRED');self.assertFalse(r['estimates'])
 def test_duplicate_policy_is_ambiguous(self):
  self.policies.append(copy.deepcopy(self.policies[0]));self.assertEqual(self.leg()['status'],'AMBIGUOUS_TARIFF_POLICY_REVIEW_REQUIRED')
 def revolut(self):self.account.update(_institution_name='Revolut',_institution_country='LT');self.now=m.timestamp(self.policies[1]['source']['observed_at'])+dt.timedelta(seconds=1)
 def test_lithuanian_minimum_not_percentage_alone(self):
  self.revolut();r=self.leg('hyperliquid','40');self.assertEqual(r['estimates'][0]['commission_reference_amount'],'1.99');self.assertIn('fair_usage',r['unresolved_components']);self.assertEqual(r['source_jurisdiction'],'LT')
 def test_revolut_band_boundaries(self):
  self.revolut()
  for a,c in [('1','0.5'),('2','0.99'),('5','1.49'),('25','1.99'),('100','2.49'),('150','2.99'),('201','2.9949')]:self.assertEqual(self.leg('hyperliquid',a)['estimates'][0]['commission_reference_amount'],c)
 def test_exact_ambiguous_boundary_is_pending(self):
  self.revolut();self.assertEqual(self.leg('hyperliquid','200')['status'],'ASSET_OR_TARIFF_BRACKET_REVIEW_REQUIRED')
 def test_stablecoin_explicit_fee_waiver_not_zero_total_cost(self):
  self.revolut();r=self.leg('usd-coin','100');self.assertEqual(r['estimates'][0]['commission_reference_amount'],'0');self.assertIsNone(r['total_cost']);self.assertIn('taxes',r['unresolved_components']);self.assertIn('fair_usage',r['unresolved_components'])
 def test_unknown_stablecoin_not_given_waiver(self):
  self.revolut();self.assertFalse(self.leg('unknown-coin')['estimates'])
 def test_attach_does_not_create_funded_route_or_selected_size(self):
  f=fixture.Compare();f.setUp();r=f.project();before=copy.deepcopy(r);a={**self.account,'currency':'BRL'}
  policies=copy.deepcopy(self.policies);policies[0]['scope']['currency']='BRL';policies[0]['variants'][0]['provider_ids']=['source','destination']
  m.attach(r,policies,{'account':a},{fixture.I:'CRYPTO',fixture.J:'CRYPTO'},now=self.now)
  row=r['rows'][0];self.assertTrue(row['documented_tariff_provisions']['legs'][0]['estimates']);self.assertIsNone(row['documented_tariff_provisions']['total_cost']);self.assertIsNone(row['requested_amount']);self.assertFalse(row['execution_authorized']);self.assertEqual(row['missing_reasons'],before['rows'][0]['missing_reasons'])
 def test_build_missing_catalog_preserves_existing_readings(self):
  with tempfile.TemporaryDirectory() as root:
   r={'rows':[],'existing':'unchanged'};out=m.build(root,r,now=self.now);self.assertEqual(out['existing'],'unchanged');self.assertEqual(out['documented_tariff_catalog_status'],'CATALOG_NOT_CONFIGURED');self.assertEqual(r,{'rows':[],'existing':'unchanged'})
 def test_corrupt_catalog_does_not_hide_existing_readings(self):
  with tempfile.TemporaryDirectory() as root:
   p=Path(root)/m.CATALOG;p.parent.mkdir();p.write_text('{');out=m.build(root,{'rows':[],'existing':'kept'},now=self.now);self.assertEqual(out['existing'],'kept');self.assertEqual(out['documented_tariff_catalog_status'],'TARIFF_PROVISIONS_UNAVAILABLE')
 def test_negative_reference_rejected(self):
  with self.assertRaises(CostError):self.leg(amount='-1')
 def test_inputs_are_preserved(self):
  before=copy.deepcopy((self.policies,self.account));self.leg();self.assertEqual(before,(self.policies,self.account))
 def build_fixture(self,root):
  f=fixture.Compare();f.setUp();result=f.project();row=result['rows'][0];row['currency']='EUR'
  for model in row['models']:model.update(source_provider='CoinGecko',source_provider_id='solana',destination_provider='CoinGecko',destination_provider_id='hyperliquid')
  documents={m.CATALOG:{'schema':m.SCHEMA,'policies':self.policies},'data/institution_accounts.json':{'schema':'porquinho.institution-account-registry/1.0','institutions':[{'institution_id':'institution','name':'N26','country':'DE'}],'accounts':[{'account_id':'account','institution_id':'institution','currency':'EUR','pricing_plan':'Standard'}]},'data/universal_instrument_catalog.json':{'instruments':[{'instrument_id':fixture.I,'asset_class':'CRYPTO'},{'instrument_id':fixture.J,'asset_class':'CRYPTO'}]}}
  for rel,doc in documents.items():p=Path(root)/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(doc))
  return result
 def test_actual_registry_and_catalog_read_produces_partial_references_without_writes(self):
  with tempfile.TemporaryDirectory() as root:
   result=self.build_fixture(root);before={p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()};out=m.build(root,result,now=self.now)
   self.assertEqual(out['documented_tariff_catalog_status'],'DOCUMENTED_SOURCES_PROJECTED_NOT_COST_QUOTES');self.assertEqual(out['documented_tariff_leg_status_counts'],{'DOCUMENTED_COMMISSION_REFERENCE_PARTIAL':2});self.assertNotIn('documented_tariff_provisions',result['rows'][0]);self.assertTrue(all(p.read_bytes()==b for p,b in before.items()));self.assertEqual(len(before),len([p for p in Path(root).rglob('*') if p.is_file()]))
 def test_registry_change_during_read_refuses_new_provisions_but_keeps_readings(self):
  with tempfile.TemporaryDirectory() as root:
   result=self.build_fixture(root);registered,version=m.accounts(root)
   with patch.object(m,'accounts',side_effect=[(registered,version),(registered,'changed')]):out=m.build(root,result,now=self.now)
   self.assertEqual(out['documented_tariff_catalog_status'],'TARIFF_PROVISIONS_UNAVAILABLE');self.assertEqual(out['rows'],result['rows'])
