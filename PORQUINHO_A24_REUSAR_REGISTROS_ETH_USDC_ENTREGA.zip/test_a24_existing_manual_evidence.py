import unittest,sys,importlib.util,tempfile,json,copy
from pathlib import Path
ROOT=Path('/workspace/porquinho-a24/project');sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('preflight',str(Path(__file__).parent/'PORQUINHO_A24_REUSO_TRANSACOES_READ_ONLY.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
from universal_portfolio.ledger import TransactionLedger
class Evidence(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();(self.root/'data').mkdir();self.ledger=TransactionLedger(self.root/'data/transaction_ledger.jsonl')
  self.trade={'event_type':'BUY','asset_id':'EXPLICIT:IDENTITY:1','account_id':'PRIVATE_ACCOUNT','currency':'JPY','quantity':'2','unit_price':'50','gross_amount':'100','executed_at':'2026-10-16T01:00:00Z','external_id':'TRADE1','source_ref':'TEST','provenance':{'source':'TEST'},'identity_fingerprint_v2':'trade-fp'}
  self.fee={'event_type':'FEE','account_id':'PRIVATE_ACCOUNT','currency':'JPY','gross_amount':'1','executed_at':'2026-10-16T01:00:00Z','external_id':'FEE1','identity_fingerprint_v2':'fee-fp','provenance':{'parent_external_id':'TRADE1'}}
  (self.root/'data/universal_instrument_catalog.json').write_text(json.dumps({'instruments':[{'instrument_id':self.trade['asset_id'],'symbol':'ETH'}]}))
 def seed(self):self.ledger.append(self.trade);self.ledger.append(self.fee)
 def test_explicit_parent_links_assetless_fee(self):
  self.seed();r=m.inspect(self.root);self.assertEqual(r['targets']['ETH']['contexts_with_trade_and_linked_fee'],1);self.assertEqual(r['latest_trade_contexts'][0]['fee_assetless_but_explicitly_linked_count'],1)
 def test_account_mismatch_not_joined(self):
  self.fee['account_id']='OTHER';self.seed();self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['existing_trade_fee_economics_available'])
 def test_currency_mismatch_not_joined(self):
  self.fee['currency']='USD';self.seed();self.assertEqual(m.inspect(self.root)['latest_trade_contexts'][0]['linked_fee_event_count'],0)
 def test_no_link_from_symbol_amount_or_time(self):
  self.fee['provenance']={};self.fee['asset_id']=self.trade['asset_id'];self.seed();self.assertEqual(m.inspect(self.root)['latest_trade_contexts'][0]['linked_fee_event_count'],0)
 def test_duplicate_external_trade_id_not_joined(self):
  self.seed();other={**self.trade,'external_id':'TRADE1','executed_at':'2026-10-16T02:00:00Z'};self.ledger.append(other);self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['existing_trade_fee_economics_available'])
 def test_same_timestamp_trades_ambiguous(self):
  self.seed();self.ledger.append({**self.trade,'external_id':'TRADE2'});r=m.inspect(self.root);self.assertTrue(all(not t['existing_trade_fee_economics_available'] for t in r['latest_trade_contexts']))
 def test_missing_fee_not_zero(self):
  self.ledger.append(self.trade);row=m.inspect(self.root)['latest_trade_contexts'][0];self.assertFalse(row['zero_fee_inferred_from_absence']);self.assertFalse(row['existing_trade_fee_economics_available'])
 def test_invalid_fee_amount_not_available(self):
  self.fee['gross_amount']='NaN';self.seed();self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['linked_fee_amounts_valid'])
 def test_no_amount_or_account_id_export(self):
  self.seed();r=m.inspect(self.root);s=json.dumps(r);self.assertNotIn('PRIVATE_ACCOUNT',s);self.assertNotIn('"gross_amount"',s);self.assertFalse(r['financial_amounts_exported'])
 def test_sources_unchanged(self):
  self.seed();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};m.inspect(self.root);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_catalog_label_not_rebind_history(self):
  self.seed();p=self.root/'data/universal_instrument_catalog.json';p.write_text(json.dumps({'instruments':[{'instrument_id':'DIFFERENT','symbol':'ETH'}]}));r=m.inspect(self.root);self.assertEqual(r['targets']['ETH']['matching_context_count'],0);self.assertEqual(r['latest_trade_contexts'][0]['instrument_id'],self.trade['asset_id'])
 def test_symlink_refused(self):
  self.seed();p=self.root/'data/transaction_ledger.jsonl';target=self.root/'preserved';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target)
  with self.assertRaises(ValueError):m.inspect(self.root)
 def test_corruption_refused(self):
  self.seed();self.ledger.path.write_text('{}\n')
  with self.assertRaises(Exception):m.inspect(self.root)
 def test_explicit_plan_link(self):
  self.trade['commit_plan_id']='plan1';self.fee['commit_plan_id']='plan1';self.fee['provenance']={};self.seed();r=m.inspect(self.root);self.assertIn('EXPLICIT_COMMIT_PLAN_ID',r['latest_trade_contexts'][0]['link_methods'])
 def test_read_only_guard_subprocess(self):
  import subprocess
  self.seed();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};r=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).parent/'PORQUINHO_A24_REUSO_TRANSACOES_READ_ONLY.py'),str(self.root)],capture_output=True,text=True)
  # Copy source package location into fixture root through read-only symlink for imports.
  self.assertEqual(r.returncode,0);self.assertIn('ModuleNotFoundError',r.stdout)
  (self.root/'universal_portfolio').symlink_to(ROOT/'universal_portfolio',target_is_directory=True)
  r=subprocess.run([sys.executable,'-I','-B',str(Path(__file__).parent/'PORQUINHO_A24_REUSO_TRANSACOES_READ_ONLY.py'),str(self.root)],capture_output=True,text=True);self.assertEqual(json.loads(r.stdout)['status'],'EXISTING_RECORDS_INSPECTED_NOT_MODEL_CERTIFIED')
  for p,raw in before.items():self.assertEqual(p.read_bytes(),raw)
 def durable(self):
  from dataclasses import asdict
  from types import SimpleNamespace
  from universal_portfolio.manual_external_trade_production_authority import build_sequence
  from universal_portfolio.manual_external_trade_durable_store import SCHEMA
  review=SimpleNamespace(review_id='review1',economic_payload={'transaction_type':'BUY','funding_source':'REGISTERED_ACCOUNT_CASH','account_id':self.trade['account_id'],'instrument_id':self.trade['asset_id'],'transaction_currency':self.trade['currency'],'executed_at':self.trade['executed_at'],'quantity':'2','unit_price':'50','gross_amount':'100','fee_amount':'1','fee_currency':'JPY'})
  seq=build_sequence(review=review,confirmation=SimpleNamespace(already_executed_externally=True,review_id='review1',review_sha256='reviewhash'))
  self.trade['identity_fingerprint_v2']=seq.steps[0].identity_fingerprint_v2;self.fee['identity_fingerprint_v2']=seq.steps[1].identity_fingerprint_v2;self.fee['provenance']={}
  row={'sequence_id':seq.sequence_id,'sequence_sha256':seq.sequence_sha256,'authority_sha256':'authorityhash','status':'COMPLETED','sequence':asdict(seq),'authority':{},'journal':{},'created_at':'2026-10-16T01:00:00Z','updated_at':'2026-10-16T01:00:00Z','terminal_detail':None}
  (self.root/'data/manual_external_trade_execution_authorities.json').write_text(json.dumps({'schema':SCHEMA,'records':{seq.sequence_id:row}}))
 def test_durable_sequence_links_canonical_assetless_fee(self):
  self.durable();self.seed();r=m.inspect(self.root);self.assertTrue(r['latest_trade_contexts'][0]['existing_trade_fee_economics_available']);self.assertIn('EXPLICIT_SEQUENCE_STEP_IDENTITY',r['latest_trade_contexts'][0]['link_methods'])
 def test_durable_fee_amount_mismatch_not_reused(self):
  self.durable();self.fee['gross_amount']='9';self.seed();self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['existing_trade_fee_economics_available'])
 def test_durable_trade_quantity_mismatch_not_reused(self):
  self.durable();self.trade['quantity']='3';self.seed();self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['existing_trade_fee_economics_available'])
 def test_wrong_settled_gross_not_reused(self):
  self.trade['gross_amount']='1000';self.seed();self.assertFalse(m.inspect(self.root)['latest_trade_contexts'][0]['existing_trade_fee_economics_available'])
 def test_explicit_manual_transaction_id_link(self):
  self.trade['manual_external_transaction_id']='tx-explicit';self.fee['manual_external_transaction_id']='tx-explicit';self.fee['provenance']={};self.seed();r=m.inspect(self.root);self.assertIn('EXPLICIT_MANUAL_EXTERNAL_TRANSACTION_ID',r['latest_trade_contexts'][0]['link_methods'])
