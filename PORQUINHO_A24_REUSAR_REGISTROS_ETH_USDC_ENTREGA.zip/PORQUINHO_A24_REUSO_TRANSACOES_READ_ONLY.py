"""Inventory existing trade/fee evidence without exporting financial amounts.
Read-only: no commits, recovery, fee creation, model or service operations.
"""
import datetime as dt,hashlib,json,os,sys
from decimal import Decimal,localcontext
from pathlib import Path

def text(v):return isinstance(v,str) and bool(v.strip())
def positive(v):
 try:return not isinstance(v,bool) and Decimal(str(v)).is_finite() and Decimal(str(v))>0
 except Exception:return False

def equal_amount(a,b):
 try:return a is not None and b is not None and not isinstance(a,bool) and not isinstance(b,bool) and Decimal(str(a)).is_finite() and Decimal(str(b)).is_finite() and Decimal(str(a))==Decimal(str(b))
 except Exception:return False

def settled_consistent(row):
 try:
  if not all(positive(row.get(k)) for k in ('quantity','unit_price','gross_amount')):return False
  with localcontext() as ctx:
   ctx.prec=128
   q,p,g=(Decimal(str(row[k])) for k in ('quantity','unit_price','gross_amount'))
   return (q*p).quantize(Decimal(1).scaleb(g.as_tuple().exponent))==g
 except Exception:return False

def stamp(value):
 try:
  t=dt.datetime.fromisoformat(value.replace('Z','+00:00'));return t.astimezone(dt.timezone.utc) if t.tzinfo is not None else None
 except Exception:return None

def iid(row):
 a=row.get('asset_id');b=row.get('instrument_id')
 if a and b and a!=b:return None
 return a or b

def fee_links(trade,events,records):
 from universal_portfolio.ledger_financial_translation import canonical_transaction_type,LedgerTranslationError
 def kind(e):
  try:return canonical_transaction_type(e)
  except LedgerTranslationError:return None
 fees={};diagnostics=[];linked_records=[]
 def add(fee,method,step=None):
  if kind(fee)!='FEE':return
  if fee.get('account_id')!=trade.get('account_id') or fee.get('currency')!=trade.get('currency'):
   diagnostics.append('LINKED_FEE_ACCOUNT_OR_CURRENCY_MISMATCH');return
  if step is not None and not all(equal_amount(fee.get(k),step.get(k)) if k=='gross_amount' else fee.get(k)==step.get(k) for k in ('account_id','currency','gross_amount')):
   diagnostics.append('LINKED_FEE_PAYLOAD_MISMATCH');return
  key=fee['event_id'];fees.setdefault(key,{'event':fee,'methods':set()})['methods'].add(method)
 external=trade.get('external_id')
 if text(external):
  matches=[e for e in events if e.get('external_id')==external]
  if len(matches)==1:
   for e in events:
    if (e.get('provenance') or {}).get('parent_external_id')==external:add(e,'EXPLICIT_PARENT_EXTERNAL_ID')
  else:diagnostics.append('DUPLICATE_EXTERNAL_TRADE_ID_NOT_JOINED')
 for name in ('manual_external_transaction_id','commit_plan_id'):
  value=trade.get(name)
  if not text(value):continue
  matching_trades=[e for e in events if kind(e) in ('BUY','SELL') and e.get(name)==value]
  if len(matching_trades)!=1:
   diagnostics.append('NONUNIQUE_EXPLICIT_TRADE_LINK_NOT_JOINED');continue
  for e in events:
   if kind(e)=='FEE' and e.get(name)==value:add(e,'EXPLICIT_'+name.upper())
 fp=trade.get('identity_fingerprint_v2')
 if text(fp) and sum(e.get('identity_fingerprint_v2')==fp for e in events)==1:
  for record in records.values():
   steps=(record.get('sequence') or {}).get('steps') or []
   matches=[s for s in steps if isinstance(s,dict) and s.get('identity_fingerprint_v2')==fp and s.get('kind') in ('BUY','SELL')]
   if len(matches)!=1:continue
   step=matches[0].get('payload') or {}
   if iid(step)!=iid(trade) or not all(equal_amount(step.get(k),trade.get(k)) if k in ('quantity','gross_amount') else step.get(k)==trade.get(k) for k in ('quantity','gross_amount','account_id','currency')):
    diagnostics.append('SEQUENCE_TRADE_PAYLOAD_MISMATCH');continue
   linked_records.append(record.get('status','UNKNOWN'))
   for s in steps:
    if s.get('kind')!='FEE' or not text(s.get('identity_fingerprint_v2')):continue
    candidates=[e for e in events if e.get('identity_fingerprint_v2')==s['identity_fingerprint_v2']]
    if len(candidates)!=1:diagnostics.append('SEQUENCE_FEE_NOT_UNIQUE_OR_NOT_APPENDED');continue
    add(candidates[0],'EXPLICIT_SEQUENCE_STEP_IDENTITY',s.get('payload') or {})
 return fees,sorted(set(diagnostics)),linked_records

def inspect(root):
 from universal_portfolio.explicit_market_bindings_a24 import local
 from universal_portfolio.ledger import TransactionLedger
 from universal_portfolio.ledger_financial_translation import canonical_transaction_type,LedgerTranslationError
 from universal_portfolio.manual_external_trade_durable_store import _decode_durable_record,SCHEMA as DURABLE_SCHEMA
 root=Path(root).resolve(strict=True)
 rels=['data/transaction_ledger.jsonl','data/manual_external_trade_execution_authorities.json','data/universal_instrument_catalog.json','data/instruments/manual_instruments.json']
 paths=[local(root,rel) for rel in rels]
 def version(p):
  s=p.stat() if p.exists() else None
  return (s.st_size,s.st_mtime_ns,s.st_ino) if s else None
 before={p:version(p) for p in paths}
 if before[paths[0]] is None:raise ValueError('EXISTING_LEDGER_REQUIRED')
 if any(v and v[0]>64*1024*1024 for v in before.values()):raise ValueError('SOURCE_SIZE_LIMIT')
 ledger=TransactionLedger(paths[0]);events=ledger.events()
 if len(events)>100000:raise ValueError('EVENT_COUNT_LIMIT')
 labels={};records={};store_status='MISSING';catalog_conflicts=set()
 for p in paths[2:]:
  if not p.exists():continue
  doc=json.loads(p.read_bytes())
  for row in doc.get('instruments',[]):
   key=row.get('instrument_id');symbol=row.get('symbol')
   if not text(key) or not text(symbol):continue
   if key in labels and labels[key]!=symbol:catalog_conflicts.add(key)
   labels[key]=symbol
 for key in catalog_conflicts:labels.pop(key,None)
 if paths[1].exists():
  doc=json.loads(paths[1].read_bytes())
  if doc.get('schema')!=DURABLE_SCHEMA or not isinstance(doc.get('records'),dict):raise ValueError('DURABLE_STORE_SCHEMA_REQUIRED')
  records=doc['records'];store_status='EXISTING_RECORD_SHAPES_CHECKED'
  if len(records)>10000:raise ValueError('DURABLE_RECORD_LIMIT')
  for record in records.values():_decode_durable_record(record)
 trades=[]
 for e in events:
  try:kind=canonical_transaction_type(e)
  except LedgerTranslationError:continue
  if kind in ('BUY','SELL'):trades.append((e,kind))
 latest={};unknown_time=0
 for e,kind in trades:
  t=stamp(e.get('executed_at'))
  if t is None:unknown_time+=1;continue
  key=(iid(e),e.get('account_id'),e.get('currency'),kind)
  if not all(text(k) for k in key):continue
  if key not in latest or t>latest[key][0]:latest[key]=(t,[(e,kind)])
  elif t==latest[key][0]:latest[key][1].append((e,kind))
 selected=[]
 for t,items in latest.values():
  for e,kind in items:
   fees,issues,states=fee_links(e,events,records);prov=e.get('provenance') or {};fields={
    'explicit_account':text(e.get('account_id')),'explicit_currency':text(e.get('currency')),
    'positive_quantity':positive(e.get('quantity')),'positive_unit_price':positive(e.get('unit_price')),
    'positive_gross_amount':positive(e.get('gross_amount')),'settled_economics_consistent':settled_consistent(e),'aware_execution_timestamp':stamp(e.get('executed_at')) is not None,
    'source_ref':text(e.get('source_ref')) or text(prov.get('source_ref')),
    'provenance':isinstance(prov,dict) and bool(prov),
    'execution_venue_in_trade':any(text((container or {}).get(k)) for container in (e,prov) for k in ('execution_venue_id','broker_id','venue_id'))}
   fee_rows=[f['event'] for f in fees.values()]
   valid_fees=bool(fee_rows) and all(positive(f.get('gross_amount')) or equal_amount(f.get('gross_amount'),0) for f in fee_rows)
   selected.append({'instrument_id':iid(e),'catalog_label':labels.get(iid(e)),
    'label_scope':'EXACT_CATALOG_METADATA_FOR_INVENTORY_ONLY_NO_IDENTITY_REBINDING',
    'account_context_ref':hashlib.sha256(json.dumps([e.get('account_id'),e.get('currency')]).encode()).hexdigest(),
    'currency':e.get('currency'),'side':kind,'latest_timestamp_ambiguous':len(items)>1,'field_presence':fields,
    'linked_fee_event_count':len(fees),'linked_fee_amounts_valid':valid_fees,
    'link_methods':sorted({m for f in fees.values() for m in f['methods']}),'durable_record_states':sorted(set(states)),
    'fee_assetless_but_explicitly_linked_count':sum(not iid(f) for f in fee_rows),
    'existing_trade_fee_economics_available':len(items)==1 and all(fields[k] for k in ('explicit_account','explicit_currency','positive_quantity','positive_unit_price','positive_gross_amount','settled_economics_consistent','aware_execution_timestamp')) and valid_fees and not issues,
    'zero_fee_inferred_from_absence':False,'issues':issues})
 if len(selected)>200:raise ValueError('PUBLIC_CONTEXT_LIMIT')
 if before!={p:version(p) for p in paths}:raise ValueError('SOURCE_CHANGED_DURING_READ_RETRY_AFTER_CYCLE')
 targets={symbol:{'matching_context_count':sum(r['catalog_label']==symbol for r in selected),
  'contexts_with_trade_and_linked_fee':sum(r['catalog_label']==symbol and r['existing_trade_fee_economics_available'] for r in selected)} for symbol in ('ETH','USDC')}
 return {'validation':'A24_EXISTING_MANUAL_TRADE_EVIDENCE_READ_ONLY','status':'EXISTING_RECORDS_INSPECTED_NOT_MODEL_CERTIFIED',
  'ledger_local_chain_verified':True,'durable_store_status':store_status,'source_files_stable_during_read':True,
  'targets':targets,'fee_link_field_presence_counts':{name:sum(bool((e.get('provenance') or {}).get(name) or e.get(name)) for e in events if (e.get('transaction_type') or e.get('event_type'))=='FEE') for name in ('parent_external_id','manual_external_transaction_id','commit_plan_id','identity_fingerprint_v2','source_ref')},'latest_trade_contexts':sorted(selected,key=lambda r:(r['catalog_label'] or '',r['instrument_id'],r['account_context_ref'],r['side'])),
  'trades_with_unknown_time_not_selected_as_latest':unknown_time,'historical_fee_reuse_basis':'OBSERVED_EXECUTED_TRADE_NOT_FUTURE_TARIFF',
  'financial_amounts_exported':False,'quantities_exported':False,'account_ids_exported':False,'financial_mutation':False,
  'history_write_performed':False,'training_requested':False,'services_restarted':False,'canonical_publication_authorized':False}

def main():
 root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root))
 def guard(event,args):
  if event=='open':
   mode,flags=args[1:3]
   if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
  if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind','socket.getaddrinfo'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
 sys.addaudithook(guard)
 try:result=inspect(root)
 except Exception as exc:result={'validation':'A24_EXISTING_MANUAL_TRADE_EVIDENCE_READ_ONLY','status':'INSPECTION_NOT_COMPLETED','error_type':type(exc).__name__,'reason':str(exc) if type(exc) is ValueError else None,'financial_mutation':False,'history_write_performed':False,'services_restarted':False}
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
