"""Reuse the legacy laboratory's features and estimators in an isolated global lane.
No legacy models, learning, snapshots, forecasts, or economic authority are replaced.
"""
import datetime as dt,fcntl,math,os
from pathlib import Path
import numpy as np
import pandas as pd
import sklearn
from threadpoolctl import threadpool_limits
from . import prediction_lab as legacy,global_research_lab_a24 as sources_lab
from universal_portfolio import global_history_source_a24 as history,research_quote_acquisition_a24 as quotes
from universal_portfolio.explicit_market_bindings_a24 import local,digest,load
SCHEMA='porquinho.global-existing-lab-a24/1.0'
STORE='data/brain/global_existing_lab_a24'
METHOD='EXISTING_FEATURES_ESTIMATORS_QUOTE_COHORT_PURGED30_V1'
MAX_FOLDS=12
class ReuseError(ValueError):pass

def flags():return {'authority':'RESEARCH_ONLY','legacy_learning_modified':False,'model_validation_proven':False,'prospective_validation_proven':False,'comparison_authorized':False,'canonical_publication_authorized':False,'execution_authorized':False,'financial_mutation':False}

def finite(x):
 if isinstance(x,bool) or not math.isfinite(float(x)):raise ReuseError('FINITE_RESEARCH_VALUE_REQUIRED')
 return float(x)

def input_frame(bodies):
 rows=[];currencies=set();seen=set()
 for body in bodies:
  history.validate_bundle(body);binding=body['binding'];currencies.add(binding['quote_currency'])
  key=body['series_id']
  if key in seen:raise ReuseError('DUPLICATE_SOURCE_SERIES')
  seen.add(key)
  for row in body['observations']:
   rows.append({**{k:binding[k] for k in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref')},'asset':binding['instrument_id'],
    'date':row['observation_date'],'price':row['price'],'volume':row.get('volume_24h'),'market_cap':row.get('market_cap')})
 if len(currencies)!=1:raise ReuseError('ONE_EXPLICIT_QUOTE_COHORT_REQUIRED')
 if len(rows)>20000:raise ReuseError('COHORT_ROW_LIMIT')
 x,features=legacy._features(pd.DataFrame(rows))
 if x.empty:raise ReuseError('FEATURE_POPULATION_EMPTY')
 return x,features

def jobs(root,demand,now):
 plan,eligible,latest=sources_lab.sources(root,demand,now);cohorts={}
 for key,(path,body) in sorted(latest.items()):
  if quotes.utc(dt.datetime.fromisoformat(body['fetched_at']))>now:raise ReuseError('FUTURE_SOURCE')
  if (now.date()-dt.date.fromisoformat(body['observations'][-1]['observation_date'])).days>3:continue
  cohorts.setdefault(body['binding']['quote_currency'],[]).append((path,body))
 result=[]
 code={rel:digest((Path(__file__).parent/rel).read_text()) for rel in ('prediction_lab.py','global_market_frame_a24.py','global_existing_lab_a24.py')}
 for currency,pairs in sorted(cohorts.items()):
  meta={'schema':SCHEMA,'method':METHOD,'quote_currency':currency,'source_hashes':{b['series_id']:digest(b) for p,b in pairs},
   'engine_versions':{'numpy':np.__version__,'pandas':pd.__version__,'sklearn':sklearn.__version__},'implementation_digests':code,
   'horizon_unit':'OBSERVATIONS','horizon_value':30,'maximum_folds':MAX_FOLDS,'minimum_training_rows':200,'minimum_feature_dates':120,
   'baseline':'SAME_COHORT_MATURED_TRAINING_LABEL_MEAN','model_selection_performed':False,**flags()}
  cohort=digest(meta)
  for algorithm in legacy.ALGORITHMS:
   result.append({'metadata':{**meta,'algorithm':algorithm,'cohort_digest':cohort},'pairs':pairs,'eligible':{b['series_id']:eligible[b['series_id']] for p,b in pairs},
    'path':local(root,STORE+'/experiments/'+cohort+'/'+algorithm+'.json')})
 return plan,result

def model_for(name):
 model=legacy._model(name)
 params=model.get_params(deep=True)
 # Same estimator parameters/seed; resource cap does not change the algorithm.
 updates={k:1 for k in params if k=='n_jobs' or k.endswith('__n_jobs')}
 if updates:model.set_params(**updates)
 return model

def schedule(x):
 dates=np.array(sorted(x['date'].dt.normalize().unique()))
 step=max(1,(len(dates)-120)//MAX_FOLDS or 1)
 out=[]
 for j in list(range(120,len(dates),step))[-MAX_FOLDS:]:
  tr=x.loc[x['forward_30d'].notna()&(x['target_maturity_date']<dates[j])&(x['date']<dates[j])]
  te=x.loc[(x['date'].dt.normalize()==dates[j])&x['forward_30d'].notna()]
  if len(tr)>=200 and not te.empty:out.append((tr,te))
 return out

def paired(rows):
 if not rows:return {'sample_count':0,'model_mae_pp':None,'baseline_mae_pp':None,'result':'NO_PAIRED_SAMPLES'}
 m=sum(abs(finite(r['prediction_pct'])-finite(r['actual_pct'])) for r in rows)/len(rows)
 b=sum(abs(finite(r['baseline_pct'])-finite(r['actual_pct'])) for r in rows)/len(rows)
 return {'sample_count':len(rows),'model_mae_pp':m,'baseline_mae_pp':b,'result':'EQUAL_ERROR' if math.isclose(m,b,rel_tol=1e-9,abs_tol=1e-12) else 'LOWER_ERROR' if m<b else 'HIGHER_ERROR'}

def experiment(job,*,now):
 x,features=input_frame([b for p,b in job['pairs']]);name=job['metadata']['algorithm'];folds=[]
 with threadpool_limits(limits=1):
  for tr,te in schedule(x):
   model=model_for(name);model.fit(tr[features],tr['forward_30d']);pred=model.predict(te[features]);baseline=finite(tr['forward_30d'].mean())
   last=tr['target_maturity_date'].max().date().isoformat()
   for (_,row),value in zip(te.iterrows(),pred):
    folds.append({'instrument_id':row['instrument_id'],'provider':row['provider'],'provider_id':row['provider_id'],'quote_currency':row['quote_currency'],
     'origin':row['date'].date().isoformat(),'target':row['target_maturity_date'].date().isoformat(),'last_training_label_end':last,'training_label_count':len(tr),
     'prediction_pct':finite(value),'actual_pct':finite(row['forward_30d']),'baseline_pct':baseline})
  latest,train=legacy._prediction_frames(x)
  forecast=[]
  if len(train)>=200:
   model=model_for(name);model.fit(train[features],train['forward_30d']);pred=model.predict(latest[features]);baseline=finite(train['forward_30d'].mean())
   for (_,row),value in zip(latest.iterrows(),pred):
    forecast.append({**{k:row[k] for k in ('instrument_id','provider','provider_id','quote_currency')},'origin':row['date'].date().isoformat(),
     'last_training_label_end':train['target_maturity_date'].max().date().isoformat(),'training_label_count':len(train),'value_pct':finite(value),'baseline_pct':baseline})
 return {**job['metadata'],'status':'EXISTING_LAB_REUSED_GLOBAL_RESEARCH_ONLY' if forecast else 'INSUFFICIENT_MATURED_TRAINING_POPULATION',
  'computed_at':now.isoformat(),'feature_names':features,'feature_row_count':len(x),'folds':folds,'forecasts':forecast,
  'evaluation':paired(folds),'evaluation_kind':'RETROSPECTIVE_NOT_ARCHIVED_PROSPECTIVE','evaluation_labels_may_overlap':True,
  'past_source_availability_attested':False,'persisted_estimator_replaces_legacy':False}

def validate(result,job,now,frame=None):
 if not isinstance(result,dict) or any(result.get(k)!=v for k,v in job['metadata'].items()):raise ReuseError('EXPERIMENT_METADATA_MISMATCH')
 if quotes.utc(dt.datetime.fromisoformat(result['computed_at']))>now:raise ReuseError('FUTURE_EXPERIMENT')
 x,features=frame if frame is not None else input_frame([b for p,b in job['pairs']])
 if result.get('feature_names')!=features or result.get('feature_row_count')!=len(x):raise ReuseError('FEATURE_POPULATION_MISMATCH')
 expected={}
 for tr,te in schedule(x):
  for _,row in te.iterrows():
   k=(row['instrument_id'],row['provider'],row['provider_id'],row['quote_currency'],row['date'].date().isoformat())
   expected[k]=(row['target_maturity_date'].date().isoformat(),finite(row['forward_30d']),finite(tr['forward_30d'].mean()),len(tr),tr['target_maturity_date'].max().date().isoformat())
 found=set()
 for row in result.get('folds',[]):
  k=tuple(row[f] for f in ('instrument_id','provider','provider_id','quote_currency','origin'))
  if k in found or k not in expected:raise ReuseError('UNEXPECTED_FOLD_CONTEXT')
  target,actual,baseline,n,last=expected[k]
  if (row['target'],row['training_label_count'],row['last_training_label_end'])!=(target,n,last) or not last<row['origin']<target:raise ReuseError('PURGED_FOLD_BOUNDARY_MISMATCH')
  if not math.isclose(finite(row['actual_pct']),actual,rel_tol=1e-12,abs_tol=1e-12) or not math.isclose(finite(row['baseline_pct']),baseline,rel_tol=1e-12,abs_tol=1e-12):raise ReuseError('PAIRED_TARGET_OR_BASELINE_MISMATCH')
  finite(row['prediction_pct']);found.add(k)
 if found!=set(expected) or result.get('evaluation')!=paired(result['folds']):raise ReuseError('PAIRED_SAMPLE_POPULATION_MISMATCH')
 latest,train=legacy._prediction_frames(x);expected_forecasts={tuple(row[k] for k in ('instrument_id','provider','provider_id','quote_currency')):(row['date'].date().isoformat(),train['target_maturity_date'].max().date().isoformat()) for _,row in latest.iterrows()} if len(train)>=200 else {}
 seen=set()
 for row in result.get('forecasts',[]):
  k=tuple(row[f] for f in ('instrument_id','provider','provider_id','quote_currency'))
  if k in seen or k not in expected_forecasts or (row['origin'],row['last_training_label_end'])!=expected_forecasts[k] or not row['last_training_label_end']<row['origin']:raise ReuseError('CURRENT_FORECAST_CONTEXT_MISMATCH')
  finite(row['value_pct'])
  if row.get('training_label_count')!=len(train) or not math.isclose(finite(row['baseline_pct']),finite(train['forward_30d'].mean()),rel_tol=1e-12,abs_tol=1e-12):raise ReuseError('CURRENT_FORECAST_BASELINE_MISMATCH')
  seen.add(k)
 if seen!=set(expected_forecasts):raise ReuseError('CURRENT_FORECAST_POPULATION_MISMATCH')
 if result.get('evaluation_kind')!='RETROSPECTIVE_NOT_ARCHIVED_PROSPECTIVE' or result.get('past_source_availability_attested') is not False:raise ReuseError('RETROSPECTIVE_SEMANTICS_REQUIRED')
 return result

def run(root,demand,*,now=None,revalidate=None,max_jobs=1):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc));handle=None;created=0
 out={'schema':SCHEMA,'experiments_created':0,'network_requests':0,'training_scope':'NEW_ISOLATED_FITS_USING_EXISTING_CODE_NOT_LEGACY_STATE',**flags()}
 try:
  if type(max_jobs) is not int or not 1<=max_jobs<=20:raise ReuseError('BOUNDED_JOB_COUNT_REQUIRED')
  planned,work=jobs(root,demand,now)
  if not work:return {**out,'status':'AWAITING_ELIGIBLE_GLOBAL_HISTORY'}
  directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True)
  fd=os.open(local(root,STORE+'/lab.lock'),os.O_CREAT|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600);handle=os.fdopen(fd,'w')
  try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return {**out,'status':'EXISTING_GLOBAL_LAB_BUSY'}
  for job in work:
   target=job['path']
   if target.exists():validate(history.read_sealed(target),job,now);continue
   result=experiment(job,now=now);validate(result,job,now)
   current=(revalidate or (lambda:quotes.current_contexts(root)))()
   if digest(load(root))!=planned['binding_digest'] or any(tuple(c) not in current for info in job['eligible'].values() for c in info['funding_contexts']):raise ReuseError('ELIGIBILITY_CHANGED_BEFORE_WRITE')
   if any(history.read_sealed(p)!=b for p,b in job['pairs']):raise ReuseError('SOURCE_CHANGED_BEFORE_WRITE')
   history.store_once(target,result);created+=1
   if created>=max_jobs:break
  return {**out,'status':'EXISTING_GLOBAL_LAB_EXPERIMENTS_RECORDED' if created else 'EXISTING_GLOBAL_LAB_CURRENT','experiments_created':created}
 except Exception as exc:return {**out,'status':'EXISTING_GLOBAL_LAB_UNAVAILABLE','experiments_created':created,'error_type':type(exc).__name__}
 finally:
  if handle is not None:handle.close()

def summary(root,demand,*,now=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc));out={'schema':SCHEMA,'network_requests':0,'history_write_performed':False,**flags()}
 try:
  _,work=jobs(root,demand,now);rows=[];frames={}
  for job in work:
   row={k:job['metadata'][k] for k in ('algorithm','quote_currency','cohort_digest')};row['status']='AWAITING_ISOLATED_RESEARCH_FIT'
   if job['path'].exists():
    cohort=job['metadata']['cohort_digest']
    if cohort not in frames:frames[cohort]=input_frame([b for p,b in job['pairs']])
    result=validate(history.read_sealed(job['path']),job,now,frame=frames[cohort])
    row.update(status=result['status'],computed_at=result['computed_at'],feature_row_count=result['feature_row_count'],forecast_count=len(result['forecasts']),evaluation=result['evaluation'],contexts=[])
    for f in result['forecasts']:
     folds=[x for x in result['folds'] if all(x[k]==f[k] for k in ('instrument_id','provider','provider_id','quote_currency'))]
     row['contexts'].append({**{k:f[k] for k in ('instrument_id','provider','provider_id','quote_currency','origin')},'evaluation':paired(folds)})
   rows.append(row)
  return {**out,'status':'EXISTING_GLOBAL_LAB_INSPECTED','planned_experiment_count':len(work),'completed_experiment_count':sum(r['status']!='AWAITING_ISOLATED_RESEARCH_FIT' for r in rows),'experiments':rows,'selection_policy':'NO_AUTOMATIC_CHAMPION_OR_ENSEMBLE_SELECTION; DESCRIPTIVE_FIXED_METHOD_COMPARISON'}
 except Exception as exc:return {**out,'status':'EXISTING_GLOBAL_LAB_INSPECTION_UNAVAILABLE','error_type':type(exc).__name__,'planned_experiment_count':None,'completed_experiment_count':None,'experiments':[]}
