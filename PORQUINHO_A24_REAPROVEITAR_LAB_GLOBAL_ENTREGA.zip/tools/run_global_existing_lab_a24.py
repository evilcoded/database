"""Explicit bounded isolated research batch. No service, network, or legacy writes."""
import argparse,datetime as dt,json,os,sys
from pathlib import Path

def main(argv=None):
 parser=argparse.ArgumentParser();parser.add_argument('--root',required=True);parser.add_argument('--max-jobs',type=int,default=1,choices=range(1,21));args=parser.parse_args(argv)
 root=Path(args.root).expanduser().resolve(strict=True)
 sys.path.insert(0,str(root))
 from brain.evolution import global_existing_lab_a24 as lab
 # Guard the whole read-model + research operation. Only the isolated new store is writable.
 allowed=(root/lab.STORE).resolve()
 def guard(event,values):
  if event in ('socket.connect','socket.bind','subprocess.Popen','os.system','os.exec','os.fork','os.posix_spawn'):raise PermissionError('ISOLATED_BATCH_NETWORK_OR_PROCESS_DENIED')
  if event=='open':
   path,mode,flags=values
   writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
   if writing and isinstance(path,(str,bytes,os.PathLike)) and not Path(os.fsdecode(path)).resolve().is_relative_to(allowed):raise PermissionError('ISOLATED_BATCH_WRITE_OUTSIDE_STORE_DENIED')
  if event in ('os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.chown','os.truncate','os.link','os.symlink','os.utime'):
   for v in values:
    if isinstance(v,(str,bytes,os.PathLike)) and not Path(os.fsdecode(v)).resolve().is_relative_to(allowed):raise PermissionError('ISOLATED_BATCH_MUTATION_OUTSIDE_STORE_DENIED')
 sys.addaudithook(guard)
 from universal_portfolio.universal_observation_bridge import build_read_only_bridge
 demand=build_read_only_bridge(root).intelligence.get('funded_currency_research') or {}
 result=lab.run(root,demand,max_jobs=args.max_jobs)
 report={'validation':'A24_EXISTING_LAB_GLOBAL_ISOLATED_BATCH','batch':result,'summary':lab.summary(root,demand),
  'legacy_write_guard_active':True,'services_restarted_by_batch':False,'network_requests':0,'financial_mutation':False,'canonical_publication_authorized':False}
 print(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False))
 return 1 if result['status']=='EXISTING_GLOBAL_LAB_UNAVAILABLE' else 0
if __name__=='__main__':raise SystemExit(main())
