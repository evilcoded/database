import copy,datetime as dt,fcntl,unittest
from unittest.mock import patch
import numpy as np
import test_a24_global_research_lab as fixture
from brain.evolution import global_existing_lab_a24 as lab
from universal_portfolio import global_history_source_a24 as h
NOW=fixture.NOW
class FixedModel:
 def fit(self,x,y):self.mean=float(np.mean(y));return self
 def predict(self,x):return np.full(len(x),self.mean)
class Reuse(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Lab();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root;self.demand=self.f.demand;self.f.source()
 def job(self):return lab.jobs(self.root,self.demand,NOW)[1][0]
 def current(self):return {(c['account_id'],c['currency'],c['context_fingerprint']) for c in self.demand['contexts']}
 def runlab(self,**kw):
  with patch.object(lab,'model_for',return_value=FixedModel()):return lab.run(self.root,self.demand,now=NOW,revalidate=self.current,**kw)
 def result(self):
  job=self.job()
  with patch.object(lab,'model_for',return_value=FixedModel()):r=lab.experiment(job,now=NOW)
  return job,r
 def test_reuses_legacy_features_exactly(self):
  body=self.f.body();x,f=lab.input_frame([body]);self.assertEqual(len(f),14);self.assertTrue((x['quote_currency']==body['binding']['quote_currency']).all());self.assertNotIn('price_eur',x)
 def test_source_volume_not_dropped_or_replaced(self):
  body=self.f.body();x,_=lab.input_frame([body]);expected={r['observation_date']:float(r['volume_24h']) for r in body['observations']}
  for _,row in x.iterrows():self.assertEqual(row['_a24_volume'],expected[row['date'].date().isoformat()])
 def test_ten_existing_estimators_planned(self):self.assertEqual([j['metadata']['algorithm'] for j in lab.jobs(self.root,self.demand,NOW)[1]],lab.legacy.ALGORITHMS)
 def test_currency_cohort_mixing_refused(self):
  a=self.f.body();b=copy.deepcopy(a);b['binding']['quote_currency']='JPY'
  with patch.object(h,'validate_bundle',side_effect=lambda x:x):
   b['series_id']='different'
   with self.assertRaisesRegex(ValueError,'ONE_EXPLICIT_QUOTE'):lab.input_frame([a,b])
 def test_duplicate_series_refused(self):
  with self.assertRaisesRegex(ValueError,'DUPLICATE_SOURCE'):lab.input_frame([self.f.body(),self.f.body()])
 def test_one_algorithm_per_default_cycle(self):self.assertEqual(self.runlab()['experiments_created'],1)
 def test_bounded_explicit_batch(self):self.assertEqual(self.runlab(max_jobs=3)['experiments_created'],3)
 def test_bad_batch_bounds_refused(self):
  for n in (0,21,True):self.assertEqual(self.runlab(max_jobs=n)['status'],'EXISTING_GLOBAL_LAB_UNAVAILABLE')
 def test_strict_purged_boundaries_and_30_observations(self):
  job,r=self.result();self.assertGreater(len(r['folds']),0)
  dates=[x['observation_date'] for x in self.f.body()['observations']]
  for row in r['folds']:self.assertLess(row['last_training_label_end'],row['origin']);self.assertEqual(dates.index(row['target'])-dates.index(row['origin']),30)
 def test_same_training_population_baseline_and_equal_fixed_model(self):
  job,r=self.result();self.assertEqual(r['evaluation']['result'],'EQUAL_ERROR');self.assertEqual(lab.validate(r,job,NOW),r)
 def test_current_forecast_is_unlabelled_latest(self):
  job,r=self.result();self.assertEqual(r['forecasts'][0]['origin'],self.f.body()['observations'][-1]['observation_date']);self.assertLess(r['forecasts'][0]['last_training_label_end'],r['forecasts'][0]['origin'])
 def test_tampered_target_refused(self):
  job,r=self.result();r['folds'][0]['actual_pct']+=1
  with self.assertRaises(ValueError):lab.validate(r,job,NOW)
 def test_missing_fold_refused(self):
  job,r=self.result();r['folds'].pop()
  with self.assertRaises(ValueError):lab.validate(r,job,NOW)
 def test_duplicate_fold_refused(self):
  job,r=self.result();r['folds'].append(r['folds'][0])
  with self.assertRaises(ValueError):lab.validate(r,job,NOW)
 def test_wrong_forecast_quote_refused(self):
  job,r=self.result();r['forecasts'][0]['quote_currency']='JPY'
  with self.assertRaises(ValueError):lab.validate(r,job,NOW)
 def test_tampered_forecast_baseline_refused(self):
  job,r=self.result();r['forecasts'][0]['baseline_pct']+=1
  with self.assertRaises(ValueError):lab.validate(r,job,NOW)
 def test_no_canonical_or_legacy_authority(self):
  job,r=self.result()
  for k,v in lab.flags().items():self.assertEqual(r[k],v)
  self.assertFalse(r['model_selection_performed']);self.assertFalse(r['past_source_availability_attested'])
 def test_old_files_preserved_and_repeat_job_immutable(self):
  for rel in ('results/latest.json','results/prediction_lab.json','data/brain/memory.json'):
   p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('PRESERVE')
  self.runlab();before={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in self.root.rglob('*') if p.is_file() and p.name!='lab.lock'}
  self.runlab()
  for p,raw in before.items():self.assertEqual((p.read_bytes(),p.stat().st_mtime_ns),raw)
 def test_readonly_summary_no_fit_network_or_writes(self):
  self.runlab();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  with patch.object(lab,'model_for',side_effect=AssertionError('NO_FIT')),patch.object(h.Transport,'get_json',side_effect=AssertionError('NO_NETWORK')):r=lab.summary(self.root,self.demand,now=NOW)
  self.assertEqual(r['completed_experiment_count'],1);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_removed_binding_excludes_old_results(self):
  self.runlab();self.f.f.f.save([]);self.assertEqual(lab.summary(self.root,self.demand,now=NOW)['planned_experiment_count'],0)
 def test_funding_change_during_fit_no_write(self):
  with patch.object(lab,'model_for',return_value=FixedModel()):r=lab.run(self.root,self.demand,now=NOW,revalidate=lambda:set())
  self.assertEqual(r['experiments_created'],0)
 def test_busy_lock_refused(self):
  directory=self.root/lab.STORE;directory.mkdir(parents=True);p=directory/'lab.lock'
  with p.open('w') as stream:
   fcntl.flock(stream,fcntl.LOCK_EX);self.assertEqual(self.runlab()['status'],'EXISTING_GLOBAL_LAB_BUSY')
 def test_library_version_changes_new_namespace(self):
  before=self.job()['path']
  with patch.object(lab.sklearn,'__version__','future'):self.assertNotEqual(before,self.job()['path'])
 def test_nonfinite_prediction_refused(self):
  model=FixedModel();model.predict=lambda x:np.full(len(x),float('nan'))
  with patch.object(lab,'model_for',return_value=model):self.assertEqual(lab.run(self.root,self.demand,now=NOW,revalidate=self.current)['experiments_created'],0)
 def test_future_observations_do_not_change_earlier_predictions(self):
  job=self.job();changed=copy.deepcopy(job)
  body=changed['pairs'][0][1];response=copy.deepcopy(body['source_response'])
  for point in response['prices'][-20:]:point[1]=str(float(point[1])*1.5)
  replacement=h.bundle(body['binding'],response,now=NOW,binding_digest='fixture')
  changed['pairs']=[(changed['pairs'][0][0],replacement)]
  with patch.object(lab,'model_for',return_value=FixedModel()):a=lab.experiment(job,now=NOW);b=lab.experiment(changed,now=NOW)
  boundary=body['observations'][-21]['observation_date']
  early=lambda r:[f for f in r['folds'] if f['target']<=boundary]
  self.assertGreater(len(early(a)),0);self.assertEqual(early(a),early(b))
 def test_real_ridge_estimator_runs_isolated(self):
  job=self.job();job['metadata']['algorithm']='Ridge';r=lab.experiment(job,now=NOW);self.assertEqual(lab.validate(r,job,NOW)['status'],'EXISTING_LAB_REUSED_GLOBAL_RESEARCH_ONLY')
 def test_all_ten_real_estimators_fit_same_population(self):
  job=self.job();populations=[]
  for name in lab.legacy.ALGORITHMS:
   job['metadata']['algorithm']=name;r=lab.experiment(job,now=NOW);lab.validate(r,job,NOW);populations.append([(f['origin'],f['target']) for f in r['folds']])
  self.assertTrue(all(x==populations[0] for x in populations))
