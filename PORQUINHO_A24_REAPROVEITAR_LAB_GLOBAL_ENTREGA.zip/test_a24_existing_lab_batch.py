import subprocess,tempfile,unittest
from pathlib import Path
PYTHON='/workspace/porquinho-a24/capital-test-venv/bin/python'
ROOT='/workspace/porquinho-a24/project'
CODE='''import sys,socket
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,ROOT)
from tools import run_global_existing_lab_a24 as cli
from brain.evolution import global_existing_lab_a24 as lab
from universal_portfolio import universal_observation_bridge as bridge
bridge.build_read_only_bridge=lambda root:SimpleNamespace(intelligence={})
lab.summary=lambda *a,**k:{}
def action(root,*a,**k):
 TARGET
 return {'status':'OK'}
lab.run=action
try:
 cli.main(['--root',sys.argv[1],'--max-jobs','1'])
except PermissionError:
 print('REFUSED')
'''.replace('ROOT',repr(ROOT))
class Guard(unittest.TestCase):
 def check(self,action):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'data/brain').mkdir(parents=True)
   r=subprocess.run([PYTHON,'-B','-c',CODE.replace('TARGET',action),str(root)],capture_output=True,text=True);self.assertEqual(r.returncode,0,r.stderr);return r.stdout
 def test_legacy_write_refused(self):self.assertIn('REFUSED',self.check("(root/'data/brain/memory.json').write_text('BAD')"))
 def test_network_refused(self):self.assertIn('REFUSED',self.check("socket.socket().connect(('127.0.0.1',9))"))
 def test_only_new_store_writable(self):self.assertNotIn('REFUSED',self.check("p=root/lab.STORE;p.mkdir(parents=True);(p/'new.json').write_text('{}')"))
if __name__=='__main__':unittest.main(verbosity=2)
