import unittest,tempfile,json,datetime as dt
from pathlib import Path
from universal_portfolio.experience_panels_a24 import snapshot_point,maturity,history,build,objectives,transactions
NOW=dt.datetime(2026,10,17,12,tzinfo=dt.timezone.utc)
class Panels(unittest.TestCase):
 def snap(self,**extra):return dict(timestamp='2026-10-16T12:00:00Z',currency='JPY',total_wealth='120',cash='20',portfolio_value='100',**extra)
 def test_explicit_arbitrary_currency(self):self.assertEqual(snapshot_point(self.snap(),now=NOW)['currency'],'JPY')
 def test_currency_not_inferred_from_suffix(self):self.assertIsNone(snapshot_point({'timestamp':'2026-10-16T00:00:00Z','total_wealth_eur':120,'cash_eur':20,'portfolio_value_eur':100},now=NOW))
 def test_legacy_reference_separate(self):
  x={'timestamp':'2026-10-16T00:00:00Z','total_wealth_eur':120,'cash_eur':20,'portfolio_value_eur':100,'cash_reconciliation':{'schema':'porquinho.real-cash-reconciliation/2.0','currency':'EUR','cross_currency_aggregation':False}}
  self.assertIn('NOT_HISTORICALLY_ATTESTED',snapshot_point(x,now=NOW)['scope']);self.assertIsNone(snapshot_point(x,now=NOW)['account_id'])
 def test_inconsistent_totals_refused(self):x=self.snap();x['total_wealth']=500;self.assertIsNone(snapshot_point(x,now=NOW))
 def test_nan_refused(self):x=self.snap();x['total_wealth']='NaN';self.assertIsNone(snapshot_point(x,now=NOW))
 def test_future_refused(self):x=self.snap();x['timestamp']='2027-01-01T00:00:00Z';self.assertIsNone(snapshot_point(x,now=NOW))
 def test_naive_timestamp_refused(self):x=self.snap();x['timestamp']='2026-10-16T00:00:00';self.assertIsNone(snapshot_point(x,now=NOW))
 def test_maturity_tracks_overdue_and_future_separately(self):
  x=maturity({'episodes':[{'asset':'ETH','horizons':[{'status':'PENDING','due_at':'2026-10-16T00:00:00Z','horizon_days':30},{'status':'PENDING','due_at':'2026-10-18T00:00:00Z','horizon_days':60},{'status':'MATURED','due_at':'2026-10-15T00:00:00Z','horizon_days':1}]}]},NOW)
  self.assertEqual((x['pending_future_count'],x['due_pending_count'],x['matured_count']),(1,1,1));self.assertEqual(x['next_due_at'],'2026-10-18T00:00:00+00:00')
 def test_distinct_assets_not_deduped_without_episode_id(self):
  eps=[{'asset':a,'horizons':[{'status':'PENDING','due_at':'2026-10-18T00:00:00Z','horizon_days':30}]} for a in ['ETH','BTC']];self.assertEqual(maturity({'episodes':eps},NOW)['pending_future_count'],2)
 def test_no_invented_maturity(self):self.assertIsNone(maturity({},NOW)['next_due_at'])
 def test_last_stored_daily_snapshot_and_no_hydrated_history(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);(r/'snapshots').mkdir();(r/'snapshots/snapshot_20261016_120000.json').write_text(json.dumps(self.snap()));x=self.snap();x['total_wealth']='130';x['portfolio_value']='110';x['timestamp']='2026-10-16T18:00:00Z';(r/'snapshots/snapshot_20261016_180000.json').write_text(json.dumps(x));out=history(r,NOW)
   self.assertEqual(out['series'][0]['points'][0]['value'],'130');self.assertEqual(len(out['series'][0]['points']),1);self.assertFalse(out['backfill_performed']);self.assertFalse(out['cash_flow_adjusted_return'])
 def test_malformed_ledger_is_unavailable_not_verified_empty(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);(r/'data').mkdir();(r/'data/transaction_ledger.jsonl').write_text('{}\n');self.assertEqual(build(r,now=NOW)['transactions']['status'],'UNAVAILABLE')
 def test_empty_objectives_not_zero_progress_or_return(self):
  with tempfile.TemporaryDirectory() as tmp:
   out=objectives(Path(tmp));self.assertEqual(out['targets'],[]);self.assertEqual(out['progress_status'],'NO_VERIFIED_WEEKLY_PERFORMANCE_WINDOW')
 def test_reader_does_not_modify_sources(self):
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);(r/'snapshots').mkdir();p=r/'snapshots/snapshot_20261016_120000.json';p.write_text(json.dumps(self.snap()));before=p.read_bytes();files=list(r.rglob('*'));out=build(r,now=NOW);self.assertFalse(out['history_write_performed']);self.assertEqual(p.read_bytes(),before);self.assertEqual(files,list(r.rglob('*')))
 def goal_fixture(self,root):
  (root/'data').mkdir();plan={'plan_id':'p','planning_budget_id':'b','source_account_id':'a','currency':'JPY','planning_budget_amount':'1000','status':'ACTIVE','authority':'NONE','execution_mode':'MANUAL'};budget={'budget_id':'b','account_id':'a','currency':'JPY','amount':'1000','status':'ACTIVE','authority':'NONE'}
  (root/'data/investment_plans.json').write_text(json.dumps({'plans':[plan]}));(root/'data/planning_budgets.json').write_text(json.dumps({'budgets':[budget]}));return plan
 def test_existing_weekly_objective_reused_not_recreated(self):
  from universal_portfolio.investment_plan_weekly_target import build as target
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);p=self.goal_fixture(r);t=target(investment_plan=p,objective_return_pct=2).payload();(r/'data/investment_plan_weekly_targets.json').write_text(json.dumps({'targets':[t]}));out=objectives(r);self.assertEqual(out['targets'][0]['objective_amount'],'20');self.assertIsNone(out['targets'][0]['achieved_amount']);self.assertFalse(out['execution_quota'])
 def test_mismatched_stale_goal_not_projected_as_current(self):
  from universal_portfolio.investment_plan_weekly_target import build as target
  with tempfile.TemporaryDirectory() as tmp:
   r=Path(tmp);p=self.goal_fixture(r);t=target(investment_plan=p,objective_return_pct=2).payload();t['reference_capital']='999';(r/'data/investment_plan_weekly_targets.json').write_text(json.dumps({'targets':[t]}));self.assertEqual(objectives(r)['targets'],[])
if __name__=='__main__':unittest.main()
