import copy
import datetime as dt
import fcntl
import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch
import test_a24_learned_allocation_policy as learned
import test_a24_research_economic_series as observations
from brain.evolution import prospective_allocation_policy_a24 as p
from universal_portfolio.explicit_market_bindings_a24 import digest

NOW = learned.NOW.replace(hour=12)
LATER = NOW + dt.timedelta(days=100)


def policy():
    exp = learned.experiment()
    body = {'version': {'method': p.learner.METHOD, 'input_experiments': {'fixture':digest(exp)}},
            'computed_at': NOW.isoformat(), 'research': p.learner.learn([exp],now=NOW)}
    sources = [{**{k:r[k] for k in p.learner.KEY}, 'identity_source_ref':'reviewed-source'} for r in exp['forecasts']]
    return body,sources


def row(source,index,*,price=None,day=None):
    at = NOW + dt.timedelta(days=index+1 if day is None else day)
    value = observations.Series().row()
    value.update(source, observation_date=at.date().isoformat(), fetched_at=at.isoformat(),
                 provider_observed_at=at.isoformat(), price=str(price if price is not None else 100+index))
    value['record_id'] = p.quotes.record_id(value)
    return value


class ForwardTrial(unittest.TestCase):
    def setUp(self):
        self.policy,self.sources=policy();self.issue=p.issue(self.policy,self.sources,now=NOW)

    def market(self,n=31,*,spacing=1):
        records=[row(s,i,day=(i+1)*spacing,price=100+i if j==0 else 100-i) for j,s in enumerate(self.sources) for i in range(n)]
        out=p.series.project(records,now=LATER);out['source_files_stable_during_read']=True
        return out

    def evaluate(self,market=None):return p.evaluate(self.issue,market or self.market(),now=LATER)

    def test_issue_uses_current_time_and_preserves_policy(self):
        before=copy.deepcopy(self.policy);issued=p.issue(self.policy,self.sources,now=NOW+dt.timedelta(hours=1))
        self.assertEqual(issued['issued_at'],(NOW+dt.timedelta(hours=1)).isoformat());self.assertEqual(before,self.policy);self.assertFalse(issued['historical_issue_backfill_performed'])

    def test_daily_id_is_currency_specific_and_protocol_specific(self):
        self.assertNotEqual(p.daily_id('2026-10-17','EUR'),p.daily_id('2026-10-17','BRL'));self.assertEqual(self.issue['issue_id'],p.daily_id(NOW.date().isoformat(),'TST'))

    def test_authorizing_or_future_policy_refused(self):
        self.policy['research']['execution_authorized']=True
        with self.assertRaises(ValueError):p.issue(self.policy,self.sources,now=NOW)
        self.policy['research']['execution_authorized']=False;self.policy['computed_at']=LATER.isoformat()
        with self.assertRaises(ValueError):p.issue(self.policy,self.sources,now=NOW)

    def test_wrong_method_or_horizon_refused(self):
        for key,value in [('method','OTHER'),('horizon_unit','DAYS'),('horizon_value',60)]:
            body=copy.deepcopy(self.policy);body['research'][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):p.issue(body,self.sources,now=NOW)

    def test_source_identity_and_currency_not_inferred(self):
        for key,value in [('instrument_id','OTHER'),('quote_currency','EUR'),('identity_source_ref','')]:
            sources=copy.deepcopy(self.sources);sources[0][key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):p.issue(self.policy,sources,now=NOW)

    def test_duplicate_instrument_or_source_refused(self):
        with self.assertRaises(ValueError):p.issue(self.policy,self.sources+self.sources,now=NOW)

    def test_modified_weight_or_candidate_duplicate_refused(self):
        body=copy.deepcopy(self.policy);body['research']['candidates'][0]['current_research_weights'][0]['weight']=0.9
        with self.assertRaises(ValueError):p.issue(body,self.sources,now=NOW)
        body=copy.deepcopy(self.policy);body['research']['candidates']*=2
        with self.assertRaises(ValueError):p.issue(body,self.sources,now=NOW)

    def test_forged_record_or_future_issue_refused(self):
        body=copy.deepcopy(self.issue);body['candidates'][0]['weights'][0]['fraction_denominator']=10
        with self.assertRaises(ValueError):p.validate_issue(body,now=LATER)
        with self.assertRaises(ValueError):p.validate_issue(self.issue,now=NOW-dt.timedelta(seconds=1))

    def test_thirty_points_are_only_twenty_nine_intervals(self):
        r=self.evaluate(self.market(30));self.assertEqual(r['status'],'PENDING_30_FORWARD_OBSERVATIONS');self.assertEqual(r['common_future_observation_count'],30);self.assertFalse(r['candidate_outcomes'])

    def test_thirty_one_future_points_give_exact_gross_and_control(self):
        r=self.evaluate();c=r['candidate_outcomes'][0];self.assertEqual(Decimal(c['gross_price_return_pct']),Decimal('30'));self.assertEqual(Decimal(c['control_gross_price_return_pct']),Decimal('0'));self.assertIsNone(c['net_return_pct']);self.assertFalse(r['policy_validation_proven']);self.assertFalse(r['original_forecast_error_evaluated'])

    def test_same_day_after_issue_cannot_be_baseline(self):
        records=[row(s,-1,day=0) for s in self.sources]+[row(s,i) for s in self.sources for i in range(30)]
        market=p.series.project(records,now=LATER);market['source_files_stable_during_read']=True
        self.assertEqual(self.evaluate(market)['common_future_observation_count'],30)

    def test_earlier_history_cannot_backfill_trial(self):
        records=[row(s,i,day=i-40) for s in self.sources for i in range(31)]
        market=p.series.project(records,now=LATER);market['source_files_stable_during_read']=True
        self.assertEqual(self.evaluate(market)['common_future_observation_count'],0)

    def test_missing_source_dates_use_common_intersection(self):
        market=self.market();market['series'][1]['observations'].pop(10)
        r=self.evaluate(market);self.assertEqual(r['common_future_observation_count'],30);self.assertFalse(r['candidate_outcomes'])

    def test_changed_provider_or_evidence_never_pooled(self):
        for key in ['provider','provider_id','identity_source_ref','quote_currency']:
            market=self.market();market['series'][0][key]='OTHER'
            with self.subTest(key=key):self.assertEqual(self.evaluate(market)['common_future_observation_count'],0)

    def test_missing_source_does_not_renormalize(self):
        market=self.market();market['series'].pop()
        self.assertFalse(self.evaluate(market)['candidate_outcomes'])

    def test_irregular_calendar_does_not_become_day_horizon(self):
        r=self.evaluate(self.market(spacing=2));self.assertEqual(r['elapsed_calendar_days'],60);self.assertEqual(r['horizon_unit'],'OBSERVATIONS');self.assertEqual(r['horizon_value'],30)

    def test_future_point_or_wrong_sampling_refused(self):
        market=self.market();market['series'][0]['sampling']='CLOSE'
        with self.assertRaises(ValueError):self.evaluate(market)
        market=self.market();market['series'][0]['observations'][0]['fetched_at']=(LATER+dt.timedelta(days=1)).isoformat()
        with self.assertRaises(ValueError):self.evaluate(market)

    def test_duplicate_series_or_observation_refused(self):
        market=self.market();market['series'].append(copy.deepcopy(market['series'][0]))
        with self.assertRaises(ValueError):self.evaluate(market)
        market=self.market();market['series'][0]['observations']*=2
        with self.assertRaises(ValueError):self.evaluate(market)

    def test_nominal_cash_not_renormalized_or_given_yield(self):
        c=self.policy['research']['candidates'][0];c['maximum_selected_sources']=2;c['current_research_weights'][0]['weight']=0.5
        self.issue=p.issue(self.policy,self.sources,now=NOW);r=self.evaluate()['candidate_outcomes'][0]
        self.assertEqual(Decimal(r['gross_price_return_pct']),Decimal('15'));self.assertFalse(r['cash_yield_included']);self.assertFalse(r['trading_costs_included'])

    def test_cash_only_trial_still_requires_control_sources(self):
        self.policy['research']['candidates'][0]['current_research_weights']=[];self.issue=p.issue(self.policy,self.sources,now=NOW)
        self.assertFalse(self.evaluate(self.market(1))['candidate_outcomes']);self.assertEqual(Decimal(self.evaluate()['candidate_outcomes'][0]['gross_price_return_pct']),0)

    def test_negative_return_preserved(self):
        market=self.market()
        for s in market['series']:
            for i,point in enumerate(s['observations']):point['price']=str(100-i)
        self.assertEqual(Decimal(self.evaluate(market)['candidate_outcomes'][0]['gross_price_return_pct']),Decimal('-30'))

    def test_later_points_do_not_change_matured_trial(self):
        self.assertEqual(self.evaluate(self.market(31)),self.evaluate(self.market(40)))

    def test_unknown_authority_never_becomes_validated_result(self):
        market=self.market();market['model_validation_proven']=True
        with self.assertRaises(ValueError):self.evaluate(market)

    def test_generic_currency_and_readonly_inputs(self):
        for source in self.sources:source['quote_currency']='JPY'
        self.policy['research']['quote_currency']='JPY'
        for c in self.policy['research']['candidates']:
            for w in c['current_research_weights']:w['quote_currency']='JPY'
        self.issue=p.issue(self.policy,self.sources,now=NOW);market=self.market();before=copy.deepcopy((self.issue,market));result=self.evaluate(market)
        self.assertEqual(before,(self.issue,market));self.assertEqual(result['quote_currency'],'JPY');self.assertFalse(result['execution_authorized'])


class Persistence(unittest.TestCase):
    def setUp(self):
        self.fixture=learned.Persistence();self.fixture.setUp();self.addCleanup(self.fixture.doCleanups)
        self.root=self.fixture.root;self.now=learned.existing.NOW
        acquisition=self.fixture.f.f.f.f
        first=acquisition.rows();second=acquisition.rows(instrument_id='GLOBAL:MARKET:CLASS:SECOND',provider_id='source-second')
        catalog=self.root/'data/universal_instrument_catalog.json'
        catalog.write_text(json.dumps({'instruments':[{'instrument_id':first['instrument_id']},{'instrument_id':second['instrument_id']}]}))
        acquisition.save([first,second])
        from universal_portfolio.funded_currency_research_a24 import project
        self.demand=project(cash=[{'account_id':'account-BRL','currency':'BRL','amount':'100'}],registry={'accounts':[{'account_id':'account-BRL','institution_id':'bank','currency':'BRL'}],'institutions':[{'institution_id':'bank','country':'PT'}]},candidates=[{'instrument_id':b['instrument_id'],'asset_class':'CRYPTO'} for b in (first,second)])
        self.fixture.demand=self.fixture.f.demand=self.demand
        history=self.fixture.f.f.f
        bundle=p.sealed.bundle(second,history.response(364),now=self.now,binding_digest=digest(p.load(self.root)))
        p.sealed.store_once(p.sealed.path_for(self.root,{'binding':second},self.now),bundle)
        self.fixture.f.runlab();result=self.fixture.run_policy()
        self.assertEqual(result['status'],'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY',result)


    def run_tracker(self,**kwargs):return p.run(self.root,self.demand,clock=lambda:self.now,revalidate=self.fixture.f.current,**kwargs)

    def snapshot(self):return {str(x.relative_to(self.root)):x.read_bytes() for x in self.root.rglob('*') if x.is_file()}

    def test_live_source_capture_and_repeat_preserve_all_existing_data(self):
        old=self.root/'data/memory.sqlite3';old.write_bytes(b'EXISTING_BRAIN_MEMORY');before=self.snapshot()
        first=self.run_tracker();self.assertEqual(first['issues_created'],1,first);self.assertEqual(self.run_tracker()['issues_created'],0)
        after=self.snapshot()
        for name,data in before.items():self.assertEqual(after[name],data)
        self.assertTrue(all(name.startswith(p.STORE+'/') for name in after.keys()-before.keys()))

    def test_capture_does_not_fit_or_request_network(self):
        with patch.object(learned.existing.lab,'model_for',side_effect=AssertionError('NO_FIT')),patch.object(learned.existing.h.Transport,'get_json',side_effect=AssertionError('NO_NETWORK')):
            result=self.run_tracker();self.assertEqual(result['issues_created'],1,result)

    def test_changed_funding_prevents_capture(self):
        result=p.run(self.root,self.demand,clock=lambda:self.now,revalidate=lambda:set());self.assertEqual(result['issues_created'],0);self.assertFalse(list((self.root/p.STORE/'issues').glob('*.json')))

    def test_same_day_policy_change_cannot_replace_first_issue(self):
        self.run_tracker();files=list((self.root/p.STORE/'issues').glob('*.json'));before=files[0].read_bytes();self.fixture.f.runlab();self.fixture.run_policy()
        self.assertEqual(self.run_tracker()['issues_created'],0);self.assertEqual(files[0].read_bytes(),before)

    def test_next_day_is_current_capture_not_backfill(self):
        self.run_tracker();self.now+=dt.timedelta(days=1)
        result=self.run_tracker();self.assertEqual(result['issues_created'],1,result)
        bodies=[p.sealed.read_sealed(x) for x in (self.root/p.STORE/'issues').glob('*.json')];self.assertEqual(len(bodies),2);self.assertEqual(sorted(b['issued_at'] for b in bodies)[-1],self.now.isoformat())

    def test_readonly_summary_and_missing_observations(self):
        self.run_tracker();before=self.snapshot();result=p.summary(self.root,now=self.now)
        self.assertEqual(result['issue_count'],1);self.assertEqual(result['stored_outcome_count'],0);self.assertEqual(result['maximum_common_future_observations'],0);self.assertEqual(before,self.snapshot())

    def test_busy_worker_does_not_create_second_writer(self):
        folder=self.root/p.STORE;folder.mkdir(parents=True)
        with (folder/'producer.lock').open('w') as stream:
            fcntl.flock(stream,fcntl.LOCK_EX);self.assertEqual(self.run_tracker()['status'],'PROSPECTIVE_POLICY_PRODUCER_BUSY')

    def test_tampered_issue_does_not_get_replaced(self):
        self.run_tracker();path=next((self.root/p.STORE/'issues').glob('*.json'));path.write_bytes(path.read_bytes()+b'BROKEN');before=path.read_bytes()
        result=self.run_tracker();self.assertEqual(result['status'],'PROSPECTIVE_POLICY_TRACKING_UNAVAILABLE');self.assertEqual(path.read_bytes(),before)

    def test_empty_tracker_summary_does_not_write(self):
        before=self.snapshot();result=p.summary(self.root,now=self.now);self.assertEqual(result['issue_count'],0);self.assertEqual(result['status'],'AWAITING_FIRST_NORMAL_CYCLE_POLICY_CAPTURE');self.assertEqual(before,self.snapshot())

    def test_orphan_outcome_is_error_not_success(self):
        path=self.root/p.STORE/'outcomes'/('a'*64+'.json');p.sealed.store_once(path,{'orphan':True})
        result=p.summary(self.root,now=self.now);self.assertIsNone(result['stored_outcome_count']);self.assertEqual(result['status'],'PROSPECTIVE_POLICY_TRACKING_UNAVAILABLE')

    def test_clock_reversal_refuses_capture(self):
        times=iter([self.now,self.now-dt.timedelta(seconds=1)])
        result=p.run(self.root,self.demand,clock=lambda:next(times),revalidate=self.fixture.f.current)
        self.assertEqual(result['issues_created'],0);self.assertEqual(result['reason'],'CAPTURE_CLOCK_REVERSED')

    def test_complete_future_path_persisted_once_without_touching_journal(self):
        self.run_tracker();path=next((self.root/p.STORE/'issues').glob('*.json'));body=p.sealed.read_sealed(path)
        at=p.instant(body['issued_at'])
        for i in range(31):
            points=[]
            for source in body['sources']:
                point=row(source,i);stamp=at+dt.timedelta(days=i+1);point.update(observation_date=stamp.date().isoformat(),fetched_at=stamp.isoformat(),provider_observed_at=stamp.isoformat());point['record_id']=p.quotes.record_id(point);points.append(point)
            p.quotes.append_records(self.root,points)
        self.now=at+dt.timedelta(days=32);before={k:v for k,v in self.snapshot().items() if k.startswith(p.quotes.STORE)}
        result=self.run_tracker();self.assertEqual(result['outcomes_created'],1,result);self.assertEqual(self.run_tracker()['outcomes_created'],0)
        summary=p.summary(self.root,now=self.now);self.assertEqual(summary['stored_outcome_count'],1,summary);self.assertFalse(summary['policy_validation_proven'])
        self.assertEqual(before,{k:v for k,v in self.snapshot().items() if k.startswith(p.quotes.STORE)})
