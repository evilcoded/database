"""Immutable daily policy trials; forward paper price paths, never trade authority.
Start at the first common source observation on a UTC day strictly after issue.
This is not the original forecast's error target or a canonical day-horizon cycle.
"""
import datetime as dt
import fcntl
import os
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path
from . import learned_allocation_policy_a24 as learner
from universal_portfolio import global_history_source_a24 as sealed
from universal_portfolio import research_economic_series_a24 as series
from universal_portfolio import research_quote_acquisition_a24 as quotes
from universal_portfolio.explicit_market_bindings_a24 import digest, local, load

SCHEMA = 'porquinho.prospective-allocation-policy-a24/1.0'
STORE = 'data/brain/prospective_allocation_policy_a24'
PROTOCOL = 'FIRST_DAILY_POLICY_SNAPSHOT_FIXED_WEIGHTS_FUTURE_COMMON31_V1'
KEY = learner.KEY + ('identity_source_ref',)
SAMPLING = 'FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE'
PRICING = 'PROVIDER_REPORTED_REQUESTED_CURRENCY'


def flags():
    return {**learner.flags(), 'independent_attestation': False,
            'training_requested': False, 'automatic_promotion': False,
            'canonical_cycles_modified': False, 'old_snapshots_modified': False,
            'historical_issue_backfill_performed': False,
            'fees_or_cash_yield_modelled': False, 'net_return_validated': False,
            'simultaneous_execution_prices_proven': False, 'broker_executable_prices_proven': False}


def instant(value):
    return quotes.utc(dt.datetime.fromisoformat(value.replace('Z', '+00:00')))


def source_key(row):
    values = learner.identity(row) + (row.get('identity_source_ref'),)
    if not isinstance(values[-1], str) or not values[-1].strip():
        raise ValueError('EXPLICIT_IDENTITY_SOURCE_REQUIRED')
    return values[0], values[1].lower(), *values[2:]


def daily_id(day, currency):
    return digest({'protocol': PROTOCOL, 'day_utc': day, 'quote_currency': currency})


def issue(policy, sources, *, now):
    """Pure representation of a policy already verified by learner.work/check_stored."""
    now = quotes.utc(now); research = policy['research']; version = policy['version']
    if research.get('schema') != learner.SCHEMA or research.get('status') != 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY' or research.get('method') != learner.METHOD or version.get('method') != learner.METHOD:
        raise ValueError('VERIFIED_LEARNED_POLICY_CONTRACT_REQUIRED')
    if any(research.get(k) != v for k,v in learner.flags().items()):
        raise ValueError('NONAUTHORIZING_LEARNED_POLICY_REQUIRED')
    if instant(policy['computed_at']) > now:
        raise ValueError('FUTURE_LEARNED_POLICY_REFUSED')
    if (research.get('horizon_unit'), research.get('horizon_value')) != ('OBSERVATIONS', 30):
        raise ValueError('EXPLICIT_OBSERVATION_HORIZON_REQUIRED')
    keys = [source_key(s) for s in sources]; currency = research['quote_currency']
    if not keys or len(keys) > 100 or len(set(keys)) != len(keys) or len({k[0] for k in keys}) != len(keys) or any(k[3] != currency for k in keys):
        raise ValueError('UNIQUE_SINGLE_CURRENCY_SOURCE_UNIVERSE_REQUIRED')
    normalized = [dict(zip(KEY, k)) for k in sorted(keys)]
    pool = {k[:4] for k in keys}; candidates = []; seen = set()
    if not 1 <= len(research['candidates']) <= 1000:
        raise ValueError('BOUNDED_LEARNED_CANDIDATES_REQUIRED')
    for candidate in research['candidates']:
        cid = candidate['candidate_id']; k = candidate['maximum_selected_sources']
        if cid in seen or type(k) is not int or not 1 <= k <= len(keys):
            raise ValueError('UNIQUE_BOUNDED_CANDIDATE_REQUIRED')
        seen.add(cid); weights = []; selected = set()
        if dt.date.fromisoformat(candidate['current_forecast_origin']) > now.date():
            raise ValueError('FUTURE_FORECAST_ORIGIN_REFUSED')
        for row in candidate['current_research_weights']:
            identity = learner.identity(row); identity = identity[0], identity[1].lower(), *identity[2:]
            if identity not in pool or identity in selected or abs(learner.number(row['weight']) - 1/k) > 1e-12:
                raise ValueError('EXACT_LEARNED_SOURCE_WEIGHT_REQUIRED')
            selected.add(identity)
            weights.append({**dict(zip(learner.KEY, identity)), 'fraction_numerator': 1, 'fraction_denominator': k})
        if len(weights) > k:
            raise ValueError('CANDIDATE_SLEEVES_EXCEEDED')
        candidates.append({'candidate_id': cid, 'algorithm': candidate['algorithm'],
            'forecast_origin': candidate['current_forecast_origin'], 'weights': sorted(weights, key=learner.identity),
            'cash_fraction_numerator': k-len(weights), 'cash_fraction_denominator': k})
    return {'schema': SCHEMA, 'kind': 'DAILY_POLICY_TRIAL_ISSUED_NOW', 'protocol': PROTOCOL,
        'issue_id': daily_id(now.date().isoformat(), currency), 'issued_at': now.isoformat(),
        'day_utc': now.date().isoformat(), 'quote_currency': currency,
        'policy_version_digest': digest(version), 'policy_body_digest': digest(policy),
        'policy_snapshot': policy, 'sources': normalized, 'candidates': candidates,
        'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30, 'required_common_points': 31,
        'baseline_rule': 'FIRST_COMMON_UTC_DAY_STRICTLY_AFTER_ISSUE',
        'trial_semantics': 'FIXED_INITIAL_WEIGHTS_PRICE_PATH_NOT_ORIGINAL_FORECAST_ERROR',
        'cash_semantics': 'NOMINAL_ZERO_PRICE_RETURN_NOT_ACCOUNT_INTEREST',
        'control': 'EQUAL_WEIGHT_ALL_SOURCES_SAME_COMMON_UTC_DATES_NOT_SYNCHRONOUS_EXECUTION',
        'sampling': SAMPLING, 'pricing_method': PRICING, **flags()}


def validate_issue(body, *, now):
    at = instant(body['issued_at'])
    if at > quotes.utc(now) or issue(body['policy_snapshot'], body['sources'], now=at) != body:
        raise ValueError('PROSPECTIVE_ISSUE_RECONSTRUCTION_MISMATCH')
    return body


def evaluate(body, market, *, now):
    now = quotes.utc(now); validate_issue(body, now=now)
    if market.get('schema') != series.SCHEMA or market.get('status') not in ('RESEARCH_SERIES_OBSERVED','NO_RESEARCH_OBSERVATIONS') or market.get('source_files_stable_during_read') is not True or any(market.get(k) is not False for k in ('comparison_authorized','model_validation_proven','training_authorized','execution_authorized','canonical_publication_authorized','financial_mutation')):
        raise ValueError('VERIFIED_NONAUTHORIZING_DAILY_SERIES_REQUIRED')
    issued = instant(body['issued_at']); lookup = {}
    for source in market['series']:
        key = source_key(source)
        if key in lookup:
            raise ValueError('AMBIGUOUS_SOURCE_SERIES_REFUSED')
        lookup[key] = source
    paths = {}; common = None
    for context in body['sources']:
        key = source_key(context); source = lookup.get(key); rows = {}
        if source is not None:
            if source['sampling'] != SAMPLING or source['pricing_method'] != PRICING:
                raise ValueError('SOURCE_SAMPLING_OR_PRICING_MISMATCH')
            for point in source['observations']:
                day = dt.date.fromisoformat(point['observation_date']); fetched = instant(point['fetched_at']); observed = instant(point['provider_observed_at'])
                price = Decimal(point['price'])
                if not price.is_finite() or price <= 0 or day != observed.date() or day != fetched.date() or not -30 <= (fetched-observed).total_seconds() <= 1800 or max(fetched,observed) > now:
                    raise ValueError('INVALID_OR_FUTURE_SOURCE_POINT')
                if point['observation_date'] in rows:
                    raise ValueError('DUPLICATE_SOURCE_OBSERVATION_DAY')
                if day > issued.date() and fetched > issued and observed > issued:
                    rows[point['observation_date']] = point
        paths[key] = rows; common = set(rows) if common is None else common & set(rows)
    days = sorted(common or [])
    result = {'schema': SCHEMA, 'kind': 'PROSPECTIVE_POLICY_TRIAL_PROGRESS',
        'issue_id': body['issue_id'], 'issue_digest': digest(body),
        'quote_currency': body['quote_currency'], 'common_future_observation_count': len(days),
        'required_common_points': 31, 'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30,
        'status': 'WAITING_FOR_FIRST_FUTURE_COMMON_OBSERVATION' if not days else 'PENDING_30_FORWARD_OBSERVATIONS',
        'candidate_outcomes': [], **flags()}
    if len(days) < 31:
        return result
    days = days[:31]; first, last = days[0], days[-1]; returns = {}; refs = []
    with localcontext() as ctx:
        ctx.prec = 50
        for key, points in sorted(paths.items()):
            returns[key[:4]] = (Decimal(points[last]['price']) / Decimal(points[first]['price']) - 1) * 100
            refs.append({'source': dict(zip(KEY,key)), 'record_ids': [points[day]['record_id'] for day in days],
                'observation_path_digest': digest([points[day] for day in days])})
        control = sum(returns.values(), Decimal(0))/Decimal(len(returns))
        outcomes = []
        for candidate in body['candidates']:
            gross = sum((returns[learner.identity(w)] * Decimal(w['fraction_numerator']) / Decimal(w['fraction_denominator']) for w in candidate['weights']), Decimal(0))
            outcomes.append({'candidate_id': candidate['candidate_id'], 'gross_price_return_pct': str(gross),
                'control_gross_price_return_pct': str(control), 'difference_to_control_pp': str(gross-control),
                'net_return_pct': None, 'cash_yield_included': False, 'trading_costs_included': False})
    result.update(kind='PROSPECTIVE_POLICY_TRIAL_OUTCOME', status='FORWARD_PAPER_PRICE_PATH_OBSERVED_NOT_POLICY_VALIDATION',
        common_future_observation_count=31, baseline_date=first, maturity_date=last,
        elapsed_calendar_days=(dt.date.fromisoformat(last)-dt.date.fromisoformat(first)).days,
        source_observation_refs=refs, candidate_outcomes=outcomes,
        overlapping_trials_are_independent=False, original_forecast_error_evaluated=False)
    return result


def inventory(root):
    folder = local(root, STORE)
    if not folder.exists():
        return {}, {}
    paths = [*folder.glob('issues/*.json'), *folder.glob('outcomes/*.json')]
    if len(paths) > 4096:
        raise ValueError('PROSPECTIVE_JOURNAL_FILE_LIMIT')
    result = {}
    for path in paths:
        path = local(root, str(path.relative_to(root))); stat = path.stat()
        if not path.is_file() or len(path.stem) != 64 or any(c not in '0123456789abcdef' for c in path.stem):
            raise ValueError('PROSPECTIVE_JOURNAL_PATH_REQUIRED')
        result[path] = (stat.st_size, stat.st_mtime_ns, stat.st_ino)
    if sum(s[0] for s in result.values()) > 64*1024*1024:
        raise ValueError('PROSPECTIVE_JOURNAL_SIZE_LIMIT')
    return {p: sealed.read_sealed(p) for p in result}, result


def inspect(root, *, now):
    root = Path(root).resolve(strict=True); now = quotes.utc(now)
    documents, before = inventory(root); issues = {}; outcomes = {}
    for path, body in documents.items():
        if path.parent.name == 'issues':
            validate_issue(body, now=now)
            if path.stem != body['issue_id']:
                raise ValueError('PROSPECTIVE_ISSUE_PATH_MISMATCH')
            issues[path.stem] = body
        else:
            outcomes[path.stem] = body
    if not set(outcomes) <= set(issues):
        raise ValueError('ORPHAN_PROSPECTIVE_OUTCOME_REFUSED')
    market = series.build(root, now=now) if issues else None
    results = {}
    for key, body in sorted(issues.items()):
        result = evaluate(body, market, now=now)
        if key in outcomes:
            stored = outcomes[key]
            if stored.get('computed_at') is None or instant(stored['computed_at']) > now or {k:v for k,v in stored.items() if k != 'computed_at'} != result:
                raise ValueError('PROSPECTIVE_OUTCOME_OR_SOURCE_RECONSTRUCTION_MISMATCH')
            if result['status'] != 'FORWARD_PAPER_PRICE_PATH_OBSERVED_NOT_POLICY_VALIDATION':
                raise ValueError('PENDING_PROSPECTIVE_OUTCOME_REFUSED')
        results[key] = result
    if before != inventory(root)[1]:
        raise ValueError('PROSPECTIVE_JOURNAL_CHANGED_DURING_READ')
    return issues, outcomes, results


def summary(root, *, now=None):
    base = {'schema': SCHEMA, 'status': 'PROSPECTIVE_POLICY_TRACKING_UNAVAILABLE',
        'issue_count': None, 'stored_outcome_count': None, 'network_requests': 0,
        'history_write_performed': False, **flags()}
    try:
        issues, outcomes, results = inspect(root, now=now or dt.datetime.now(dt.timezone.utc))
        return {**base, 'status': 'PROSPECTIVE_POLICY_TRIALS_INSPECTED' if issues else 'AWAITING_FIRST_NORMAL_CYCLE_POLICY_CAPTURE',
            'issue_count': len(issues), 'stored_outcome_count': len(outcomes),
            'candidate_trial_count': sum(len(b['candidates']) for b in issues.values()),
            'pending_issue_count': sum(not r['candidate_outcomes'] for r in results.values()),
            'matured_issue_count': sum(bool(r['candidate_outcomes']) for r in results.values()),
            'maximum_common_future_observations': max((r['common_future_observation_count'] for r in results.values()), default=0),
            'required_common_points': 31, 'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30,
            'currency_issue_counts': dict(Counter(b['quote_currency'] for b in issues.values())),
            'progress_status_counts': dict(Counter(r['status'] for r in results.values())),
            'sampling': SAMPLING, 'daily_capture_rule': 'FIRST_VALID_NORMAL_CYCLE_PER_CURRENCY_UTC_DAY',
            'baseline_rule': 'FIRST_COMMON_UTC_DAY_STRICTLY_AFTER_ISSUE',
            'overlapping_trials_are_independent': False, 'original_forecast_error_evaluated': False,
            'financial_amounts_exported': False}
    except Exception as exc:
        return {**base, 'error_type': type(exc).__name__, 'reason': str(exc) if isinstance(exc,ValueError) else type(exc).__name__}


def run(root, demand, *, clock=None, revalidate=None):
    clock = clock or (lambda: dt.datetime.now(dt.timezone.utc)); now = quotes.utc(clock())
    root = Path(root).resolve(strict=True); handle = None
    out = {'schema': SCHEMA, 'issues_created': 0, 'outcomes_created': 0,
           'network_requests': 0, 'research_journal_write_performed': False, **flags()}
    try:
        directory = local(root, STORE); directory.mkdir(parents=True, exist_ok=True)
        fd = os.open(local(root, STORE+'/producer.lock'), os.O_CREAT|os.O_WRONLY|os.O_NOFOLLOW, 0o600)
        handle = os.fdopen(fd, 'w')
        try:
            fcntl.flock(handle, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            return {**out, 'status': 'PROSPECTIVE_POLICY_PRODUCER_BUSY'}
        issues, outcomes, results = inspect(root, now=now)
        for key, result in results.items():
            if key not in outcomes and result['candidate_outcomes']:
                sealed.store_once(local(root, STORE+'/outcomes/'+key+'.json'), {**result, 'computed_at': now.isoformat()})
                out.update(outcomes_created=1, research_journal_write_performed=True)
                break
        plan, jobs = learner.work(root, demand, now)
        for job in jobs:
            if not job['path'].exists():
                continue
            policy = learner.check_stored(sealed.read_sealed(job['path']), job, now)
            if policy['research']['status'] != 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY':
                continue
            capture_time = quotes.utc(clock())
            if capture_time < now:
                raise ValueError('CAPTURE_CLOCK_REVERSED')
            key = daily_id(capture_time.date().isoformat(), policy['research']['quote_currency'])
            if key in issues:
                continue
            source_bindings = {}
            for j, _ in job['pairs']:
                for path, body in j['pairs']:
                    binding = body['binding']; source_bindings[source_key(binding)] = binding
            forecasts = {tuple([r['instrument_id'],r['provider'].lower(),r['provider_id'],r['quote_currency']]) for r in job['pairs'][0][1]['forecasts']}
            if {key[:4] for key in source_bindings} != forecasts:
                raise ValueError('EXACT_EXPERIMENT_SOURCE_UNIVERSE_REQUIRED')
            body = issue(policy, list(source_bindings.values()), now=capture_time)
            current = (revalidate or (lambda: quotes.current_contexts(root)))()
            if digest(load(root)) != plan['binding_digest'] or any(tuple(c) not in current for j,_ in job['pairs'] for info in j['eligible'].values() for c in info['funding_contexts']):
                raise ValueError('FUNDED_SOURCE_CONTEXT_CHANGED_BEFORE_CAPTURE')
            if sealed.read_sealed(job['path']) != policy or any(sealed.read_sealed(j['path']) != experiment or any(sealed.read_sealed(p) != b for p,b in j['pairs']) for j,experiment in job['pairs']):
                raise ValueError('POLICY_OR_INPUT_SOURCE_CHANGED_BEFORE_CAPTURE')
            sealed.store_once(local(root, STORE+'/issues/'+body['issue_id']+'.json'), body)
            out.update(issues_created=1, research_journal_write_performed=True)
            break
        return {**out, 'status': 'PROSPECTIVE_POLICY_NORMAL_CYCLE_CHECKED'}
    except Exception as exc:
        return {**out, 'status': 'PROSPECTIVE_POLICY_TRACKING_UNAVAILABLE',
                'error_type': type(exc).__name__, 'reason': str(exc) if isinstance(exc,ValueError) else type(exc).__name__}
    finally:
        if handle is not None:
            handle.close()
