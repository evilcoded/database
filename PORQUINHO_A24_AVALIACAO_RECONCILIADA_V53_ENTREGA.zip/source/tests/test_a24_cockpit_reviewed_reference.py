"""Synthetic coverage of explicit reviewed reference valuation; no network or writes."""
import copy
import unittest
from universal_portfolio.universal_cockpit_a24 import project
from universal_portfolio.position_reference_reconciliation_a24 import SCHEMA

class ReviewedReference(unittest.TestCase):
 def setUp(self):
  self.positions=[dict(instrument_id='FIN:ONE',account_id='account',currency='ABC',quantity='2',cost_basis='150')]
  self.registry={'accounts':[dict(account_id='account',currency='ABC')],'institutions':[]}
  self.quote=dict(instrument_id='RESEARCH:ONE',quote_currency='ABC',provider='Feed',provider_id='one-id',price='100',fetched_at='2026-10-21T12:00:00+00:00')
  self.link=dict(schema=SCHEMA,account_id='account',currency='ABC',position_instrument_id='FIN:ONE',research_instrument_id='RESEARCH:ONE',provider='Feed',provider_id='one-id',canonical_binding_id='binding',canonical_confirmation_digest='confirmation',research_evidence_ref='review',quote_binding_ref='quote-binding',portfolio_id='portfolio',effective_from='2026-10-20')
 def result(self,links=None,observations=None):
  return project(self.positions,[],self.registry,{},observations if observations is not None else [self.quote],observed_at='2026-10-21T13:00:00+00:00',reference_links=[self.link] if links is None else links)
 def test_reviewed_chain_values_and_preserves_financial_identity(self):
  row=self.result()['positions'][0]
  self.assertEqual(row['reference_market_value'],'200');self.assertEqual(row['reference_pnl'],'50')
  self.assertEqual(row['instrument_id'],'FIN:ONE');self.assertEqual(row['reference_identity_chain'],self.link)
  self.assertFalse(row['reference_is_execution_quote']);self.assertIn('NOT_EXECUTION_PRICE',row['valuation_status'])
 def test_without_review_no_alias_or_ticker_join(self):
  self.assertIsNone(self.result(links=[])['positions'][0]['reference_market_value'])
 def test_each_explicit_scope_dimension_is_required(self):
  for key in ['account_id','currency','position_instrument_id','research_instrument_id','provider','provider_id']:
   with self.subTest(key=key):
    link={**self.link,key:'different'}
    self.assertIsNone(self.result(links=[link])['positions'][0]['reference_market_value'])
 def test_provider_ambiguity_not_chosen(self):
  link={**self.link,'provider_id':'other'}
  quote={**self.quote,'provider_id':'other'}
  self.assertIsNone(self.result(links=[self.link,link],observations=[self.quote,quote])['positions'][0]['reference_market_value'])
 def test_duplicate_quote_not_selected(self):
  self.assertIsNone(self.result(observations=[self.quote,self.quote])['positions'][0]['reference_market_value'])
 def test_future_reference_not_used(self):
  self.link['effective_from']='2026-10-22';self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_quote_timestamp_required_and_bounded(self):
  for stamp in [None,'invalid','2026-10-21T12:00:00','2026-10-21T14:00:00+00:00','2026-10-19T12:00:00+00:00']:
   with self.subTest(stamp=stamp):
    self.quote['fetched_at']=stamp;self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_invalid_registered_currency_does_not_use_chain(self):
  self.registry['accounts'][0]['currency']='XYZ';self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_duplicate_position_does_not_use_chain(self):
  self.positions*=2;self.assertTrue(all(p['reference_market_value'] is None for p in self.result()['positions']))
 def test_direct_ambiguous_quotes_not_bypassed_with_alias(self):
  direct={**self.quote,'instrument_id':'FIN:ONE'}
  self.assertIsNone(self.result(observations=[direct,direct,self.quote])['positions'][0]['reference_market_value'])
 def test_direct_identity_behavior_remains(self):
  direct={**self.quote,'instrument_id':'FIN:ONE','price':'110'}
  row=self.result(observations=[direct,self.quote])['positions'][0]
  self.assertEqual(row['reference_market_value'],'220');self.assertNotIn('reference_identity_chain',row)
 def test_nonpositive_prices_or_quantities_not_valued(self):
  for price in ['0','-1','NaN',None]:
   self.quote['price']=price;self.assertIsNone(self.result()['positions'][0]['reference_market_value'])
 def test_no_mutation_or_execution_authority(self):
  before=copy.deepcopy((self.positions,self.registry,self.quote,self.link));result=self.result()
  self.assertEqual(before,(self.positions,self.registry,self.quote,self.link))
  for k in ['execution_authorized','financial_mutation','history_write_performed','cross_currency_aggregation']:self.assertFalse(result[k])
 def test_malformed_chain_refused(self):
  self.link.pop('canonical_confirmation_digest')
  with self.assertRaises(ValueError):self.result()
