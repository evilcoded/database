import json,os,subprocess,tempfile,unittest,zipfile
from pathlib import Path
COMMAND=Path('/workspace/artifacts/PORQUINHO_A24_RASTREAR_BRAIN_EXISTENTE.command')
SOURCE=COMMAND.read_text().split("<<'PREFLIGHT_PY'\n",1)[1].rsplit('\nPREFLIGHT_PY',1)[0]
ns={'__name__':'trace_test'};exec(compile(SOURCE,str(COMMAND),'exec'),ns)
class Trace(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'project';(self.root/'results').mkdir(parents=True);(self.root/'universal_portfolio').mkdir()
 def save(self,x): (self.root/'results/prediction_lab.json').write_text(json.dumps(x))
 def test_missing_is_not_untrained(self):self.assertEqual(ns['lab_reuse'](self.root)['status'],'MISSING');self.assertNotIn('untrained',str(ns['lab_reuse'](self.root)))
 def test_existing_algorithms_and_metrics_preserved(self):
  self.save({'algorithms':[{'algorithm':'Ridge','mae':3,'n':12,'folds':2}],'champion':{'algorithm':'Ridge'},'ensemble_models':['Ridge'],'predictions':[]});r=ns['lab_reuse'](self.root);self.assertEqual(r['algorithm_results'][0]['mae'],3);self.assertEqual(r['champion_algorithm'],'Ridge');self.assertFalse(r['automatic_reuse_authorized'])
 def test_symbol_or_eur_never_fill_identity(self):
  self.save({'predictions':[{'asset':'ETH','price_eur':123,'currency':'EUR'}]});r=ns['lab_reuse'](self.root)['prediction_groups']['predictions'];self.assertEqual(r['field_status_counts']['MISSING_QUOTE_CURRENCY'],1);self.assertEqual(r['field_status_counts']['MISSING_INSTRUMENT_ID'],1)
 def test_complete_context_still_not_verified(self):
  row={'instrument_id':'X','provider':'P','provider_id':'Y','quote_currency':'JPY'};self.save({'predictions':[row,row]});r=ns['lab_reuse'](self.root)['prediction_groups']['predictions'];self.assertEqual(r['duplicate_complete_source_context_count'],1);self.assertFalse(r['context_presence_is_verification'])
 def test_private_values_and_ids_not_exported(self):
  self.save({'predictions':[{'instrument_id':'SECRET','account_id':'ACCOUNT','balance':12345,'prediction_30d_pct':999}]});r=json.dumps(ns['lab_reuse'](self.root));self.assertNotIn('SECRET',r);self.assertNotIn('ACCOUNT',r);self.assertNotIn('12345',r);self.assertNotIn('999',r)
 def test_nonfinite_metric_not_exported(self):
  self.save({'algorithms':[{'algorithm':'Ridge','mae':float('nan'),'n':True}]});r=ns['lab_reuse'](self.root);self.assertIsNone(r['algorithm_results'][0]['mae']);self.assertIsNone(r['algorithm_results'][0]['n']);json.dumps(r,allow_nan=False)
 def test_project_bytes_and_mtimes_preserved(self):
  self.save({'algorithms':[]});p=self.root/'results/prediction_lab.json';before=(p.read_bytes(),p.stat().st_mtime_ns);ns['inspect'](self.root);self.assertEqual(before,(p.read_bytes(),p.stat().st_mtime_ns))
 def test_standalone_zip_only_aggregate_and_no_project_writes(self):
  self.save({'predictions':[{'account_id':'SECRET'}]});home=Path(self.tmp.name)/'home';home.mkdir();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};env=dict(os.environ,HOME=str(home),PORQUINHO_ROOT=str(self.root));r=subprocess.run(['/bin/bash',str(COMMAND)],env=env,text=True,capture_output=True);self.assertEqual(r.returncode,0,r.stderr);z=next((home/'Downloads').glob('*.zip'))
  with zipfile.ZipFile(z) as archive:self.assertEqual(set(archive.namelist()),{'BRAIN_EXISTENTE.json','LEIA.txt'});self.assertNotIn('SECRET',archive.read('BRAIN_EXISTENTE.json').decode())
  self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
if __name__=='__main__':unittest.main(verbosity=2)
