from pathlib import Path
import os,shutil,subprocess,tempfile,json,hashlib
base=Path('/workspace/porquinho-a24');root=base/'project';out=Path('/workspace/artifacts')
metadata=json.loads((out/'PORQUINHO_A24_INTERFACE_AZUL_DESTAQUES_MANIFEST.json').read_text())
with tempfile.TemporaryDirectory(prefix='a24_global_installer_') as tmp:
 target=Path(tmp)/'project';target.mkdir()
 for src in [*root.rglob('*.py'),*root.glob('static/*.js'),*root.glob('static/*.css'),*root.glob('tests/*.js')]:
  if '__pycache__' in src.parts:continue
  dest=target/src.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
 for rel,spec in metadata['files'].items():
  p=target/rel;p.parent.mkdir(parents=True,exist_ok=True)
  if spec['before'] is None:p.unlink(missing_ok=True)
  else:p.write_bytes((base/'blue-before'/Path(rel).name).read_bytes())
 icons=target/'static/crypto-icons';icons.rmdir();assert not icons.exists()
 sentinel=target/'data/preserve.bin';sentinel.parent.mkdir();sentinel.write_bytes(b'UNCHANGED-DATA')
 config=target/'data/instruments/research_identity_links_a24.json';config.parent.mkdir();config.write_bytes(b'{"schema":"porquinho.reviewed-research-identity-links-a24/1.0","scope":"CURRENT_RESEARCH_VIEW_ONLY","links":[]}\n');config_before=config.read_bytes()
 source=target/'data/database/market_daily.csv';source.parent.mkdir();source.write_bytes(b'asset,date,price_eur\nETH,2026-10-01,2000\n');original_market=source.read_bytes()
 (target/'.venv').symlink_to(base/'capital-test-venv',target_is_directory=True)
 env=dict(os.environ,PORQUINHO_ROOT=str(target),PORQUINHO_ACTIVATOR_DIRECTORY=str(Path(tmp)/'Downloads'),PORQUINHO_SKIP_ACTIVATION='1')
 cmd=['/bin/bash',str(out/'PORQUINHO_A24_INTERFACE_AZUL_DESTAQUES_R2.command')]
 logs=[]
 # Corrupted baseline must refuse before any project mutation.
 p=target/'brain/evolution/prediction_lab.py';original=p.read_bytes();p.write_bytes(original+b'\n# external change\n')
 bad=subprocess.run(cmd,env=env,text=True,capture_output=True)
 assert bad.returncode!=0 and 'diverge' in bad.stdout+bad.stderr
 assert not list(target.glob('.porquinho_a24_blue_backup_*'))
 p.write_bytes(original)
 old_result=subprocess.run(['/bin/bash',str(out/'PORQUINHO_A24_INTERFACE_AZUL_DESTAQUES.command')],env=env,text=True,capture_output=True)
 assert old_result.returncode!=0 and 'FileNotFoundError' in old_result.stderr and 'crypto-icons' in old_result.stderr
 assert not icons.exists()
 for rel,spec in metadata['files'].items():
  f=target/rel
  assert (hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None)==spec['before'],rel
 failed_backups=list(target.glob('.porquinho_a24_blue_backup_*'));assert len(failed_backups)==1
 logs.append('ORIGINAL_FAILURE_REPRODUCED_WITH_CRYPTO_DIRECTORY_ABSENT; ROLLBACK_HASHES_VERIFIED')
 for expected in ['PATCH_APPLIED_A24_BLUE_EXPERIENCE','ALREADY_APPLIED']:
  result=subprocess.run(cmd,env=env,text=True,capture_output=True);logs.append(result.stdout+result.stderr)
  assert result.returncode==0,(result.stdout,result.stderr)
  assert expected in result.stdout
  assert sentinel.read_bytes()==b'UNCHANGED-DATA'
  assert config.read_bytes()==config_before
  assert source.read_bytes()==original_market
  assert 'A24_BLUE_READ_ONLY' in result.stdout if expected.startswith('PATCH_') else True
 for rel,spec in metadata['files'].items():assert hashlib.sha256((target/rel).read_bytes()).hexdigest()==spec['after']
 assert len(list(target.glob('.porquinho_a24_blue_backup_*')))==2
 assert len(list(target.glob('.porquinho_a24_blue_backup_*/APPLIED_OK.txt')))==1
 assert icons.is_dir()
 (out/'PORQUINHO_A24_INTERFACE_AZUL_DESTAQUES_R2_INSTALLER_TEST.log').write_text('\n'.join(logs)+'\nBASELINE_MISMATCH_REFUSED; DATA_SENTINEL_PRESERVED; INSTALL_AND_REPEAT_OK\n')
 print('INSTALLER_OK: original missing-directory failure reproduced; rollback verified; fixed application and repeat passed; data preserved')
