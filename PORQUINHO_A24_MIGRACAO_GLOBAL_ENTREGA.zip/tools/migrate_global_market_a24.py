"""Migrate the market table to a verified versioned global research copy."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from universal_portfolio.global_market_migration_a24 import migrate,read_bundle
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default=str(ROOT));p.add_argument('--verify-bundle');a=p.parse_args()
 print(json.dumps(read_bundle(a.root,a.verify_bundle)[0] if a.verify_bundle else migrate(a.root),ensure_ascii=False,indent=2))
