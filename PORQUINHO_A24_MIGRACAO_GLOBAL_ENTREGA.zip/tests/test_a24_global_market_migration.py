import copy,csv,io,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import global_market_migration_a24 as m
class Migration(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();self.source=self.root/m.SOURCE;self.source.parent.mkdir(parents=True)
 def write(self,raw=b'asset,date,price_eur,other\r\nETH,2026-10-01,2000.0100,keep\r\n'):self.source.write_bytes(raw);return raw
 def run_migration(self):
  result=m.migrate(self.root);manifest,records=m.read_bundle(self.root,result['bundle_id']);return result,manifest,records
 def test_legacy_suffix_never_infers_eur(self):
  raw=self.write();r,manifest,rows=self.run_migration();self.assertEqual(self.source.read_bytes(),raw);self.assertIsNone(rows[0]['measures']['price']['quote_currency']);self.assertEqual(rows[0]['measures']['price']['value'],'2000.0100');self.assertEqual(rows[0]['status'],'PRESERVED_UNRESOLVED_NOT_MODEL_READY')
 def test_every_original_cell_and_exact_bytes_preserved(self):
  raw=self.write(b'asset,date,price_eur,note\r\nETH,2026-10-01,2000,"line one\nline two"\r\nETH,2026-10-01,2000,duplicate\r\n')
  r,manifest,rows=self.run_migration();self.assertEqual(len(rows),2);self.assertEqual([x['source_values'] for x in rows],m.parse(raw)[1]);self.assertEqual((self.root/m.STORE/r['bundle_id']/'original.csv').read_bytes(),raw)
 def test_explicit_neutral_metadata_keeps_arbitrary_currency(self):
  self.write(b'asset,date,price,instrument_id,provider,provider_id,quote_currency,identity_source_ref\nX,2026-10-01,12.4,arbitrary:original,Provider,exact,JPY,evidence\n');r,_,rows=self.run_migration();self.assertEqual(rows[0]['measures']['price']['quote_currency'],'JPY');self.assertEqual(rows[0]['identity']['instrument_id'],'arbitrary:original');self.assertFalse(rows[0]['training_authorized'])
 def test_declared_quote_does_not_certify_legacy_column(self):
  self.write(b'asset,date,price_eur,instrument_id,provider,provider_id,quote_currency,identity_source_ref\nX,2026-10-01,12,I,P,p,BRL,ref\n');_,_,rows=self.run_migration();self.assertIsNone(rows[0]['measures']['price']['quote_currency'])
 def test_missing_metadata_neutral_price_remains_unresolved(self):
  self.write(b'asset,date,price,quote_currency\nETH,2026-10-01,2,USD\n');_,_,rows=self.run_migration();self.assertIsNone(rows[0]['measures']['price']['quote_currency'])
 def test_repeat_is_idempotent_preserves_bundle_bytes(self):
  self.write();r,_,_=self.run_migration();before={str(p):p.read_bytes() for p in (self.root/m.STORE/r['bundle_id']).iterdir()};r2,_,_=self.run_migration();self.assertEqual(r2['status'],'EXISTING_MIGRATION_VERIFIED');self.assertEqual(before,{str(p):p.read_bytes() for p in (self.root/m.STORE/r['bundle_id']).iterdir()})
 def test_changed_source_creates_new_version_without_erasing_previous(self):
  self.write();r,_,_=self.run_migration();p=self.root/m.STORE/r['bundle_id']/'original.csv';before=p.read_bytes();self.write(b'asset,date,price_eur\nBTC,2026-10-02,50000\n');r2,_,_=self.run_migration();self.assertNotEqual(r['bundle_id'],r2['bundle_id']);self.assertEqual(before,p.read_bytes())
 def test_bad_width_refuses_without_losing_row(self):
  raw=self.write(b'asset,date,price_eur\nETH,2026-10-01,1,extra\n')
  with self.assertRaisesRegex(m.MigrationError,'WIDTH'):m.migrate(self.root)
  self.assertEqual(self.source.read_bytes(),raw);self.assertFalse((self.root/m.STORE).exists())
 def test_duplicate_headers_refused(self):
  self.write(b'asset,date,asset\nX,2026-01-01,X\n')
  with self.assertRaisesRegex(m.MigrationError,'UNIQUE_HEADERS'):m.migrate(self.root)
 def test_corrupted_bundle_refused_not_repaired(self):
  self.write();r,_,_=self.run_migration();p=self.root/m.STORE/r['bundle_id']/'observations.jsonl';p.write_bytes(p.read_bytes()+b'garbage')
  with self.assertRaisesRegex(m.MigrationError,'INTEGRITY'):m.migrate(self.root)
  self.assertTrue(p.read_bytes().endswith(b'garbage'))
 def test_raw_archive_corruption_refused(self):
  self.write();r,_,_=self.run_migration();p=self.root/m.STORE/r['bundle_id']/'original.csv';p.write_bytes(p.read_bytes().replace(b'2000',b'3000'))
  with self.assertRaisesRegex(m.MigrationError,'INTEGRITY'):m.read_bundle(self.root,r['bundle_id'])
 def test_model_snapshot_matured_history_untouched(self):
  self.write();paths=[self.root/x for x in ['results/latest.json','data/brain/model.bin','data/episodes/matured.jsonl','data/snapshots/history.json']]
  for p in paths:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'original-'+str(p.relative_to(self.root)).encode())
  before={p:p.read_bytes() for p in paths};self.run_migration();self.assertEqual(before,{p:p.read_bytes() for p in paths})
 def test_no_source_no_store_creation(self):
  self.assertEqual(m.migrate(self.root)['status'],'SOURCE_NOT_PRESENT');self.assertFalse((self.root/m.STORE).exists())
 def test_no_sort_or_date_changes(self):
  self.write(b'asset,date,price_eur\nETH,2026-10-03,3\nETH,2026-10-01,1\nETH,bad-date,2\n');_,_,rows=self.run_migration();self.assertEqual([x['observation_date'] for x in rows],['2026-10-03','2026-10-01','bad-date']);self.assertEqual([x['source_row'] for x in rows],[1,2,3])
 def test_bad_and_missing_prices_preserved_not_filtered(self):
  self.write(b'asset,date,price_eur\nX,d,NaN\nX,d,-1\nX,d,\n');_,_,rows=self.run_migration();self.assertEqual([x['measures']['price']['numeric_status'] for x in rows],['INVALID','INVALID','MISSING'])
 def test_source_change_during_stage_aborts_without_commit(self):
  self.write();original=Path.read_bytes;calls=0
  def read(p):
   nonlocal calls
   if p==self.source:
    calls+=1
    if calls==2:return b'changed'
   return original(p)
  with patch.object(Path,'read_bytes',read):
   with self.assertRaisesRegex(m.MigrationError,'SOURCE_CHANGED'):m.migrate(self.root)
  self.assertFalse([p for p in (self.root/m.STORE).iterdir() if p.is_dir()])
 def test_symlink_source_refused(self):
  other=self.root/'other.csv';other.write_bytes(b'asset,date\nX,d\n');self.source.symlink_to(other)
  with self.assertRaisesRegex(ValueError,'SYMLINK'):m.migrate(self.root)
 def test_invalid_bundle_path_refused(self):
  with self.assertRaisesRegex(m.MigrationError,'BUNDLE_ID'):m.read_bundle(self.root,'../other')
 def test_empty_table_headers_retained(self):
  self.write(b'asset,date,price_eur\n');r,manifest,rows=self.run_migration();self.assertEqual(rows,[]);self.assertEqual(manifest['columns'],['asset','date','price_eur'])
 def test_no_network_no_training_or_runtime_switch(self):
  self.write()
  with patch('socket.socket.connect',side_effect=AssertionError('network')),patch('subprocess.Popen',side_effect=AssertionError('process')):r,_,rows=self.run_migration()
  self.assertFalse(r['runtime_switched']);self.assertFalse(r['training_requested']);self.assertFalse(r['canonical_publication_authorized'])
