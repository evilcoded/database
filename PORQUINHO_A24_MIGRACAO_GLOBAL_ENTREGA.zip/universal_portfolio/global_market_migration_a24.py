"""Lossless immutable market-table migration. No unit/identity inference or training."""
import csv,fcntl,hashlib,io,json,os,shutil,tempfile
from decimal import Decimal,InvalidOperation
from pathlib import Path
from .explicit_market_bindings_a24 import local,canonical
SCHEMA='porquinho.global-market-migration-a24/1.0'
SOURCE='data/database/market_daily.csv'
STORE='data/brain/global_market_migrations_a24'
class MigrationError(ValueError):pass

def sha(raw):return hashlib.sha256(raw).hexdigest()
def parse(raw):
 try:
  reader=csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline=''),strict=True);headers=next(reader)
  if len(set(headers))!=len(headers) or not {'asset','date'}.issubset(headers):raise MigrationError('UNIQUE_HEADERS_ASSET_DATE_REQUIRED')
  rows=list(reader)
  if any(len(r)!=len(headers) for r in rows):raise MigrationError('ROW_WIDTH_MISMATCH_NO_ROW_DROPPED')
  return headers,rows
 except (UnicodeError,csv.Error,StopIteration) as exc:raise MigrationError('CSV_INVALID_NO_MIGRATION') from exc

def number(value,positive=False):
 if value is None or value=='':return 'MISSING'
 try:
  n=Decimal(value)
  return 'VALID' if n.is_finite() and (n>0 if positive else n>=0) else 'INVALID'
 except (InvalidOperation,ValueError):return 'INVALID'

def project(raw):
 headers,rows=parse(raw);out=[];counts={}
 for index,values in enumerate(rows,1):
  src=dict(zip(headers,values));metadata={k:src.get(k) or None for k in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref')}
  q=metadata['quote_currency'];complete=all(metadata.values()) and all(v==v.strip() for v in metadata.values()) and q.isascii() and q.isalpha() and q.isupper()
  measures={}
  for field,old in [('price','price_eur'),('volume','volume_eur'),('market_cap','market_cap_eur')]:
   column=field if src.get(field) not in (None,'') else old if src.get(old) not in (None,'') else None
   value=src.get(column) if column else None
   # An _eur column is never evidence for its unit, even alongside other metadata.
   unit=q if complete and column==field else None
   measures[field]={'value':value,'quote_currency':unit,'source_column':column,'numeric_status':number(value,field=='price'),
                    'unit_status':'EXPLICIT_DECLARATION_SOURCE_UNATTESTED' if unit else 'UNVERIFIED_LEGACY_OR_INCOMPLETE_CONTEXT'}
  status='EXPLICIT_CONTEXT_SOURCE_UNATTESTED' if complete and measures['price']['source_column']=='price' and measures['price']['numeric_status']=='VALID' else 'PRESERVED_UNRESOLVED_NOT_MODEL_READY'
  counts[status]=counts.get(status,0)+1
  out.append({'schema':SCHEMA,'source_row':index,'source_values':values,'asset_label':src['asset'],'observation_date':src['date'],
              'identity':metadata,'measures':measures,'status':status,'authority':'RESEARCH_ONLY','training_authorized':False,'canonical_publication_authorized':False})
 data=''.join(canonical(row)+'\n' for row in out).encode()
 return headers,len(rows),counts,data

def read_bundle(root,bundle_id):
 if not isinstance(bundle_id,str) or len(bundle_id)!=64 or any(c not in '0123456789abcdef' for c in bundle_id):raise MigrationError('BUNDLE_ID_INVALID')
 folder=local(root,STORE+'/'+bundle_id)
 manifest=json.loads(local(root,STORE+'/'+bundle_id+'/manifest.json').read_bytes())
 original=local(root,STORE+'/'+bundle_id+'/original.csv').read_bytes();records=local(root,STORE+'/'+bundle_id+'/observations.jsonl').read_bytes()
 headers,count,counts,expected=project(original)
 if manifest!={'schema':SCHEMA,'source_path':SOURCE,'source_sha256':sha(original),'source_size':len(original),'columns':headers,'row_count':count,'status_counts':counts,'observations_sha256':sha(expected),'authority':'RESEARCH_ONLY','active_runtime_switched':False,'canonical_publication_authorized':False} or bundle_id!=sha(original) or records!=expected:
  raise MigrationError('BUNDLE_INTEGRITY_OR_ROW_MAPPING_INVALID')
 return manifest,[json.loads(line) for line in records.splitlines()]

def migrate(root):
 root=Path(root).resolve(strict=True);source=local(root,SOURCE)
 if not source.exists():return {'status':'SOURCE_NOT_PRESENT','source_path':SOURCE,'source_modified':False,'runtime_switched':False}
 if source.stat().st_size>64*1024*1024:raise MigrationError('SOURCE_SIZE_LIMIT_NO_MIGRATION')
 raw=source.read_bytes();headers,count,counts,data=project(raw);bundle_id=sha(raw)
 manifest={'schema':SCHEMA,'source_path':SOURCE,'source_sha256':bundle_id,'source_size':len(raw),'columns':headers,'row_count':count,'status_counts':counts,'observations_sha256':sha(data),'authority':'RESEARCH_ONLY','active_runtime_switched':False,'canonical_publication_authorized':False}
 directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True)
 lock=local(root,STORE+'/migration.lock');fd=os.open(lock,os.O_WRONLY|os.O_CREAT,0o600)
 with os.fdopen(fd,'w') as handle:
  fcntl.flock(handle,fcntl.LOCK_EX);dest=local(root,STORE+'/'+bundle_id);reused=dest.exists()
  if not reused:
   stage=Path(tempfile.mkdtemp(prefix='.staging_',dir=directory))
   try:
    for name,body in [('original.csv',raw),('observations.jsonl',data),('manifest.json',(canonical(manifest)+'\n').encode())]:
     with open(stage/name,'xb',opener=lambda p,flags:os.open(p,flags,0o600)) as stream:stream.write(body);stream.flush();os.fsync(stream.fileno())
    if source.read_bytes()!=raw:raise MigrationError('SOURCE_CHANGED_DURING_MIGRATION_NO_COMMIT')
    os.rename(stage,dest)
   finally:
    if stage.exists():shutil.rmtree(stage)
  verified,records=read_bundle(root,bundle_id)
  if source.read_bytes()!=raw:raise MigrationError('SOURCE_CHANGED_BUNDLE_RETAINED_NOT_ACTIVATED')
 return {'status':'EXISTING_MIGRATION_VERIFIED' if reused else 'GLOBAL_MARKET_COPY_MIGRATED_VERIFIED','bundle_id':bundle_id,'row_count':verified['row_count'],'status_counts':counts,
         'source_bytes_preserved':True,'all_rows_and_columns_preserved':True,'source_modified':False,'snapshots_modified':False,'learning_or_models_modified':False,
         'history_relabelled':False,'runtime_switched':False,'training_requested':False,'financial_mutation':False,'canonical_publication_authorized':False}
