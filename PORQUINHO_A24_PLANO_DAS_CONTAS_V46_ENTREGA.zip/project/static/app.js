/* V36632_RADAR_POLISH */
let dailyChart=null,intraChart=null,lastStatus=null,lastChartSig='';
const $=id=>document.getElementById(id);
const MODELS=['LinearRegression','Ridge','ElasticNet','RandomForest','ExtraTrees','GradientBoosting','HistGradientBoosting','SVR','KNN','AdaBoost'];
function fmt(v,d=2){const n=Number(v);return v==null||!Number.isFinite(n)?'—':n.toLocaleString('pt-PT',{minimumFractionDigits:d,maximumFractionDigits:d})}
function money(v){return '€'+fmt(v,2)}
function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function toast(t){const x=$('toast');x.textContent=t;x.classList.add('show');clearTimeout(window._toast);window._toast=setTimeout(()=>x.classList.remove('show'),3500)}
function openModal(title,html){$('modalTitle').textContent=title;$('modalBody').innerHTML=html;$('modal').classList.remove('hidden')}
function closeModal(){$('modal').classList.add('hidden')}
async function jsonFetch(url,opts={}){
 const r=await fetch(url,opts);
 let j=null;
 try{j=await r.json()}catch(e){}
 if(!r.ok){
   const detail=(j&&((j.error)||(j.message)))?String(j.error||j.message):'';
   throw new Error(`HTTP ${r.status}${detail?' • '+detail:''}`);
 }
 return j;
}
function jobWatch(id,label){toast(label+' enviado…');const timer=setInterval(async()=>{try{const j=await jsonFetch('/api/job/'+encodeURIComponent(id));if(j.status==='done'||j.status==='error'){clearInterval(timer);toast(j.status==='done'?label+' concluído.':'Erro em '+label+': '+(j.error||'verifique o monitor'));await loadStatus(true);await refreshCharts(true)}}catch(e){clearInterval(timer);toast('Falha ao acompanhar '+label+': '+e.message)}},800)}
async function refreshNow(){try{const j=await jsonFetch('/api/refresh',{method:'POST'});jobWatch(j.job_id,'Atualização')}catch(e){toast('Falha: '+e.message)}}
async function hydrate(){try{const j=await jsonFetch('/api/hydrate',{method:'POST'});jobWatch(j.job_id,'Histórico 365d')}catch(e){toast('Falha: '+e.message)}}
async function runModel(){try{const j=await jsonFetch('/api/model',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({algorithm:$('modelSelect').value})});jobWatch(j.job_id,$('modelSelect').value)}catch(e){toast('Falha ao iniciar modelo: '+e.message)}}
async function evolve(){try{const j=await jsonFetch('/api/evolve',{method:'POST'});jobWatch(j.job_id,'Evolução')}catch(e){toast('Falha: '+e.message)}}
async function research(){try{const j=await jsonFetch('/api/research',{method:'POST'});jobWatch(j.job_id,'Aprendizagem web')}catch(e){toast('Falha: '+e.message)}}
function richText(v){let t=String(v??'').trim();if(!t)return '<p>Sem resposta.</p>';const lines=t.split(/\r?\n/);let html='',list=false;for(const raw of lines){const line=raw.trim();if(!line){if(list){html+='</ul>';list=false}continue}if(/^[-•*]\s+/.test(line)){if(!list){html+='<ul>';list=true}html+='<li>'+esc(line.replace(/^[-•*]\s+/,''))+'</li>';continue}if(list){html+='</ul>';list=false}let safe=esc(line).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>');html+='<p>'+safe+'</p>'}if(list)html+='</ul>';return html}
function chatResult(rr){if(rr&&typeof rr==='object'){const main=rr.answer||rr.message||rr.diagnosis||'Análise concluída.';const inv=rr.investigation||rr.repair?.investigation;let detail='';if(inv){const e=inv.error||{},rep=inv.reproduction||{},hyps=inv.hypotheses||[],files=inv.files||[],hits=inv.hits||[],tests=[...(rep.tests||[]),...(inv.task_tests||[])],findings=inv.findings||[];detail+=`<div class="tech-grid">`;if(e.id)detail+=`<div><b>Erro</b><br>${esc(e.id)} • ${esc(e.error_type||'')}</div>`;detail+=`<div><b>Reprodução</b><br>${esc(rep.status||'não testada')}</div></div>`;if(rep.reason)detail+=`<p><b>Resultado:</b> ${esc(rep.reason)}</p>`;if(files.length)detail+=`<p><b>Arquivos investigados:</b> ${files.map(esc).join(', ')}</p>`;if(hyps.length)detail+=`<p><b>Hipótese:</b> ${esc(hyps[0].hypothesis||'')}<br><span class="muted">${esc(hyps[0].evidence||'')}</span></p>`;if(tests.length)detail+=`<p><b>Testes:</b></p><ul>${tests.map(t=>`<li>${t.passed===true?'✓':(t.passed===null||t.skipped?'↷':'✗')} ${esc(t.test||'teste')}${t.module?' — '+esc(t.module):''}</li>`).join('')}</ul>`;const rt=inv.runtime||{};if(rt.response){const rb=rt.response.body||{};detail+=`<p><b>Runtime:</b> HTTP ${esc(rt.response.status_code)} • JSON ${rt.response.is_json?'✓':'✗'}${Array.isArray(rb.rows)?' • '+rb.rows.length+' linha(s)':''}</p>`;}if(findings.length)detail+=`<p><b>Verificações estruturais:</b></p><ul>${findings.map(f=>`<li>${f.present?'✓':'✗'} ${esc(f.check)} — ${esc(f.file)}</li>`).join('')}</ul>`;if(hits.length)detail+=`<p><b>Evidências no código:</b></p><ul>${hits.slice(0,6).map(h=>`<li>${esc(h.file)}:${esc(h.line)} — ${esc(h.text)}</li>`).join('')}</ul>`}else{const bits=[];if(rr.file)bits.push(`<p><b>Arquivo:</b> ${esc(rr.file)}</p>`);if(rr.changes?.length)bits.push(`<ul>${rr.changes.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`);detail=bits.join('')}return `<div class="chat-answer">${richText(main)}</div>${detail?`<details class="technical-details"><summary>Como cheguei a esta conclusão</summary><div class="technical-human">${detail}</div></details>`:''}`}return `<div class="chat-answer">${richText(rr)}</div>`}
async function sendChat(){const input=$('chatInput');const msg=input.value.trim();if(!msg)return;input.value='';$('chatLog').innerHTML+=`<div class="chat-msg user"><b>Você</b><div class="chat-answer">${richText(msg)}</div></div>`;try{const j=await jsonFetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:msg})});const poll=setInterval(async()=>{try{const q=await jsonFetch('/api/job/'+encodeURIComponent(j.job_id));if(q.status==='done'||q.status==='error'){clearInterval(poll);const rr=q.result??q.error;$('chatLog').innerHTML+=`<div class="chat-msg ${q.status==='error'?'loss':''}"><b>Porquinho</b>${chatResult(rr)}</div>`;$('chatLog').scrollTop=$('chatLog').scrollHeight;await loadStatus(true)}}catch(e){clearInterval(poll);$('chatLog').innerHTML+=`<div class="chat-msg loss"><b>Porquinho</b><div class="chat-answer">${richText(e.message)}</div></div>`}},700)}catch(e){$('chatLog').innerHTML+=`<div class="chat-msg loss"><b>Porquinho</b><div class="chat-answer">${richText(e.message)}</div></div>`}}
function openChat(){openModal('💬 Falar com o Porquinho',`<div id="chatLog" style="height:330px;overflow:auto;background:#070c11;border:1px solid #172832;border-radius:10px;padding:10px;font-size:11px;line-height:1.5">Diga naturalmente o que você quer que o Porquinho faça.</div><div style="display:flex;gap:8px;margin-top:8px"><input id="chatInput" placeholder="Ex.: verifique os arquivos de aprendizado e proponha melhorias…" style="flex:1;background:#091119;border:1px solid #263844;color:white;border-radius:9px;padding:10px" onkeydown="if(event.key==='Enter')sendChat()"><button onclick="sendChat()">Enviar</button></div>`);setTimeout(()=>$('chatInput')?.focus(),50)}
function openImport(){openModal('⇩ Importar histórico',`<p style="font-size:11px;color:#aab7bf">O tipo escolhido define como o Porquinho valida e consolida o arquivo. Duplicados são ignorados e somente registros novos entram no banco.</p><div style="display:grid;gap:8px"><label><b>Arquivo</b><br><small id="fileHint">market_daily.csv</small><input type="file" id="histFile" accept=".csv,.zip" onchange="updateHint()"></label><select id="histType" onchange="updateHint()"><option value="daily">Diário — market_daily.csv</option><option value="intraday">10 minutos — market_intraday_10m.csv</option><option value="portfolio">Carteira diária — portfolio_daily.csv</option><option value="outcomes">Outcomes — signal_outcomes.csv</option><option value="legacy">Histórico legado — historico_compacto.csv</option></select><button onclick="uploadHistory()">Importar e consolidar</button><button onclick="hydrate()">Construir/atualizar 365 dias via provedor</button></div>`)}
function updateHint(){const m={daily:'market_daily.csv',intraday:'market_intraday_10m.csv',portfolio:'portfolio_daily.csv',outcomes:'signal_outcomes.csv',legacy:'historico_compacto.csv'};$('fileHint').textContent=m[$('histType').value]||'arquivo CSV compatível'}
async function uploadHistory(){const f=$('histFile').files[0];if(!f){toast('Selecione um arquivo.');return}const fd=new FormData();fd.append('type',$('histType').value);fd.append('file',f);try{const j=await jsonFetch('/api/import',{method:'POST',body:fd});closeModal();jobWatch(j.job_id,'Importação e consolidação')}catch(e){toast('Falha na importação: '+e.message)}}
function renderReaders(p,l){const pnl=Number(p.pnl_eur||0);$('readers').innerHTML=[['P/L TOTAL',money(pnl),pnl>=0?'good':'bad'],['PATRIMÔNIO',money(p.value_eur),'' ],['INVESTIDO',money(p.invested_eur),'' ],['CAIXA',money(p.cash_eur),'' ],['MODELO',l.model||'Baseline',''],['CONFIANÇA',fmt(l.confidence,0)+'/100',l.confidence>=65?'good':l.confidence<45?'bad':'']].map(x=>`<div class="reader ${x[2]}"><div class="label">${x[0]}</div><div class="value">${x[1]}</div><div class="small">${x[0]==='P/L TOTAL'?fmt(p.pnl_pct)+'%':''}</div></div>`).join('')}
function gauge(label,value,mode='normal'){let n=Number(value);if(!Number.isFinite(n))n=0;n=Math.max(0,Math.min(100,n));const cls=mode==='risk'?(n>=75?'bad':'good'):(n>=65?'good':n<45?'bad':'');return `<div class="gauge ${cls}"><div class="gauge-ring" style="--pct:${n}"><div class="gauge-value">${fmt(n,0)}</div></div><div class="glabel">${label}</div></div>`}
function renderGauges(p,l){const scores=p.scores||[];const top=scores[0]||{};const avg=scores.length?scores.reduce((a,s)=>a+Number(s.promising_pct||0),0)/scores.length:0;const risk=scores.length?scores.reduce((a,s)=>a+Number(s.risk||0),0)/scores.length:0;$('gauges').innerHTML=gauge('Confiança',l.confidence)+gauge('Regime',l.regime??0)+gauge('Oportunidade',top.promising_pct??avg)+gauge('Entrada',top.entry??0)+gauge('Risco médio',risk,'risk')}
function renderLearning(l){$('confidenceLabel').textContent=`${fmt(l.confidence,0)}/100`;const cards=[['Observações',l.observations],['Ativos',l.assets],['Modelo',l.model],['Regime',l.regime==null?'—':fmt(l.regime,1)],['Acerto',l.hit_rate==null?'—':fmt(l.hit_rate,1)+'%'],['Correlação',l.corr==null?'—':fmt(l.corr,3)],['MAE',l.mae==null?'—':fmt(l.mae,2)],['Ensaios',l.experiments]];$('learningCards').innerHTML=cards.map(c=>`<div class="learn-card"><div class="k">${c[0]}</div><div class="v">${esc(c[1])}</div></div>`).join('');$('modelSelect').innerHTML=MODELS.map(x=>`<option>${x}</option>`).join('');const algs=l.lab?.algorithms||[];$('experiments').innerHTML=algs.slice(-8).reverse().map(a=>`<div class="exp"><span>${esc(a.algorithm||'—')}</span><span>${a.mae==null?'ERRO':'MAE '+fmt(a.mae,2)+' • HIT '+fmt(a.directional_hit_rate,1)+'%'}</span></div>`).join('')||'<div class="tip">Nenhum ensaio concluído ainda.</div>'}

/* V366252_ACTION_CLARITY */
function v366252Instruction(s){
 /* PORQUINHO_UNIVERSAL_ACTION_DISPLAY_A2 */
 const universal={
  KEEP:['MANTER','Preservar a posição atual.',''],
  DEPLOY_CASH:['APLICAR CAIXA','Aplicar caixa conforme a decisão apresentada.','buy'],
  INCREASE:['AUMENTAR','Aumentar exposição conforme a decisão apresentada.','buy'],
  REDUCE:['REDUZIR','Reduzir exposição conforme a decisão apresentada.','sell'],
  SELL:['VENDER','Encerrar posição conforme a decisão apresentada.','sell'],
  REALLOCATE:['REALOCAR','Realocar capital conforme a decisão apresentada.',''],
  ABSTAIN:['ABSTER-SE','Não há autoridade para alocar nesta decisão.',''],
  ABSTAIN_INSUFFICIENT_EVIDENCE:['ABSTER-SE','Evidência insuficiente para decisão de alocação.',''],
  NO_ALLOCATION:['NÃO ALOCAR','Nenhuma alocação recomendada nesta alternativa.','']
 };
 const universalAction=String(s?.action||'').toUpperCase();
 if(Object.prototype.hasOwnProperty.call(universal,universalAction)){
  const item=universal[universalAction];
  return {text:item[0],detail:item[1]+' Etiqueta informativa; não constitui ordem nem autorização de execução.',pulse:item[2]};
 }
 const a=String(s?.action||'ACOMPANHE').toUpperCase(),state=String(s?.execution_state||'NONE').toUpperCase(),frac=Math.max(0,Math.min(100,Number(s?.execution_fraction_pct||0)));
 if(a==='COMPRE')return{text:'COMPRE',detail:'Considere a compra conforme a alocação sugerida pelo Porquinho.',pulse:'buy'};
 if(a==='VENDA')return{text:'VENDA 100%',detail:'Considere vender 100% da posição. Saída estrutural indicada pelo Brain.',pulse:'sell'};
 if(a==='REALIZE'&&state==='EXECUTE'&&frac>0)return{text:`VENDA ${fmt(frac,0)}%`,detail:`Considere vender ${fmt(frac,0)}% da posição e manter ${fmt(100-frac,0)}%.`,pulse:'sell'};
 if(a==='REALIZE')return{text:'NÃO VENDA AINDA',detail:'Realização em revisão: mantenha 100% enquanto aguarda confirmação adicional.',pulse:''};
 if(a==='MANTENHA')return{text:'MANTENHA',detail:'Nenhuma venda ou compra proposta agora.',pulse:''};
 return{text:'ACOMPANHE',detail:'Nenhuma compra ou venda proposta agora.',pulse:''};
}

/* P2 — provenance-preserving projection of existing Brain experimental signals; read only */
function vP2BrainBadgeClass(action){
 const a=String(action||'').toUpperCase();
 return a==='COMPRE'||a==='INCREASE'||a==='DEPLOY_CASH'?'buy':a==='VENDA'||a==='SELL'||a==='REDUCE'?'sell':a==='REALIZE'?'realize':'watch';
}
function vP2BrainProposal(row){
 if(!row||typeof row!=='object')return null;
 const validAction=a=>typeof a==='string'&&/^[A-Z_ ]{2,48}$/.test(a.trim().toUpperCase());
 const explicit=row.experimental===true&&validAction(row.brain_action);
 if(explicit)return {action:row.brain_action.trim().toUpperCase(),source:'sinal experimental explícito'};
 const status=typeof lastStatus==='object'&&lastStatus?lastStatus:{};
 const p=status.portfolio||{};
 const sources=[status.snapshot?.brain_experimental?.signals,p.brain_experimental?.signals,status.brain_experimental?.signals];
 const signals=sources.find(Array.isArray)||[];
 const asset=String(row.asset||'').trim().toUpperCase();
 if(!asset)return null;
 const currency=x=>String(x?.currency||x?.currency_code||x?.denomination_currency||'').trim().toUpperCase();
 const matches=signals.filter(x=>{
  if(!x||x.experimental!==true||!validAction(x.brain_action))return false;
  if(String(x.asset||'').trim().toUpperCase()!==asset)return false;
  const a=currency(row),b=currency(x);
  if(a&&b&&a!==b)return false;
  // A symbol alone cannot disambiguate an explicitly different instrument identity.
  for(const key of ['instrument_id','canonical_instrument_id','account_id','isin']){
   if(row[key]!=null&&x[key]!=null&&String(row[key])!==String(x[key]))return false;
  }
  return true;
 });
 if(matches.length!==1)return null;
 // If either side supplies a canonical identity, require both sides to supply the same one.
 const m=matches[0];
 for(const key of ['instrument_id','canonical_instrument_id','isin']){
  if((row[key]!=null)!==(m[key]!=null))return null;
 }
 return {action:m.brain_action.trim().toUpperCase(),source:'snapshot Brain experimental'};
}

function v366252ActionBadge(s){
 /* A2: canonical authority is explicit and fail-closed. Never relabel a legacy signal as a Brain decision. */
 const status=(lastStatus&&typeof lastStatus==='object')?lastStatus:{};
 const availability=status.canonical_decision_availability;
 const proposal=vP2BrainProposal(s);
 const action=String(s?.action||'ACOMPANHE').toUpperCase();
 const canonicalActions=new Set(['KEEP','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE','ABSTAIN_INSUFFICIENT_EVIDENCE','NO_ALLOCATION']);
 const hasVerifiedPublication=availability&&availability.status==='AVAILABLE'&&availability.canonical&&availability.canonical.authority==='CANONICAL_RECOMMENDATION';
 const rowIdentity=String(s?.canonical_instrument_id||s?.instrument_id||'');
 const published=hasVerifiedPublication?availability.canonical:null;
 const exact=published&&rowIdentity&&String(published.instrument_ref||'')===rowIdentity&&
   String(published.account_id||'')===String(s?.account_id||'')&&
   String(published.currency||'')===String(s?.currency||'')&&
   canonicalActions.has(String(published.action||''));
 const labels={KEEP:'MANTER',DEPLOY_CASH:'APLICAR SALDO',INCREASE:'AUMENTAR',REDUCE:'REDUZIR',SELL:'VENDER',REALLOCATE:'REALOCAR',ABSTAIN_INSUFFICIENT_EVIDENCE:'ABSTER-SE',NO_ALLOCATION:'NÃO ALOCAR'};
 const primary=exact
   ?`<span class="action-badge watch" title="Decisão canônica publicada com identidade, conta e moeda correspondentes">${esc(labels[published.action])}</span>`
   :a24OperationalBadge(s);
 if(!proposal)return primary;
 const brainCls='watch';
 const researchLabel=({COMPRE:'COMPRA',VENDA:'VENDA',REALIZE:'REALIZAÇÃO',ACOMPANHE:'ACOMPANHAMENTO'})[proposal.action]||proposal.action;
 const experimental=`<span class="action-badge ${brainCls}" title="${esc('Proposta experimental do Brain; não é decisão canônica nem autorização de execução. Fonte: '+proposal.source)}">${esc('EXPERIMENTAL · '+researchLabel)}</span>`;
 return `<span class="vP2-dual-actions">${primary} ${experimental}</span>`;
}
function v366252ExecutionPanel(s){
 const i=v366252Instruction(s),ev=Array.isArray(s?.evidence)?s.evidence:[];
 const e=ev.length?ev.map(x=>`<li>${esc(x.label||x.code||'Evidência')}${x.value==null?'':`: ${esc(String(x.value))}`}</li>`).join(''):'<li>Evidência histórica suficiente ainda não disponível.</li>';
 return `<div class="v366252-exec"><div class="v366252-exec-head">${v366252ActionBadge(s)}<b>${esc(i.detail)}</b></div><div class="v366252-exec-meta"><span>Estado: ${esc(String(s?.execution_state||'—'))}</span><span>Evidência: ${esc(String(s?.evidence_quality||'—'))}</span><span>Validação histórica: ${esc(String(s?.historical_validation||'—'))}</span></div><ul>${e}</ul></div>`;
}

function actionBadge(a){if(a&&typeof a==="object")return v366252ActionBadge(a);const x=String(a||"ACOMPANHE");const c=x==="COMPRE"?"buy":x==="VENDA"?"sell":x==="REALIZE"?"realize":"watch";return `<span class="action-badge ${c}">${esc(x)}</span>`}
function renderPortfolio(p){const n=(p.accounts?.N26||[]).length,r=(p.accounts?.Revolut||[]).length;$('portfolioMeta').textContent=`N26 ${n} • Revolut ${r}`;const rows=p.scores||[];$('portfolioTable').innerHTML='<thead><tr><th>Ativo</th><th>Conta</th><th>KPI</th><th>Ação</th><th>Atual</th><th>Alvo</th><th>Valor</th><th>P/L</th><th>P/L %</th><th>Risk</th><th>7d</th><th>30d</th></tr></thead><tbody>'+rows.map(s=>{const a=String(s.action||'');const cls=a==='COMPRE'?'action-buy':a==='VENDA'?'action-sell':a==='REALIZE'?'action-realize':'';return `<tr class="asset-row ${cls}" onclick="assetDetail(${encodeURIComponent(JSON.stringify(s))})"><td><b>${esc(s.asset)}</b></td><td>${esc(s.account||'—')}</td><td>${fmt(s.promising_pct,1)}</td><td>${actionBadge(s)}</td><td>${fmt(s.current_weight_pct,1)}%</td><td>${fmt(s.target_weight_pct,1)}%</td><td>${money(s.current_value_eur)}</td><td class="${Number(s.pnl_eur)>=0?'gain':'loss'}">${money(s.pnl_eur)}</td><td class="${Number(s.pnl_pct)>=0?'gain':'loss'}">${fmt(s.pnl_pct,1)}%</td><td>${fmt(s.risk,1)}</td><td>${fmt(s.change_7d,1)}%</td><td>${fmt(s.change_30d,1)}%</td></tr>`}).join('')+'</tbody>'}
function assetDetail(encoded){const s=JSON.parse(decodeURIComponent(encoded));openModal('Ativo • '+s.asset,`${v366252ExecutionPanel(s)}<div class="learning-grid">${[['Preço',money(s.price_eur)],['KPI',fmt(s.promising_pct,1)],['Opportunity',fmt(s.opportunity,1)],['Entry',fmt(s.entry,1)],['Asymmetry',fmt(s.asymmetry,1)],['Risk',fmt(s.risk,1)],['Atual',fmt(s.current_weight_pct,1)+'%'],['Alvo',fmt(s.target_weight_pct,1)+'%'],['P/L',money(s.pnl_eur)],['Ação',s.action],['Alvo/Ação',s.target_action]].map(x=>`<div class="learn-card"><div class="k">${esc(x[0])}</div><div class="v">${esc(x[1])}</div></div>`).join('')}</div><p style="font-size:11px;color:#9baab4">${esc(s.reason||'')}</p>`)}
function renderAlerts(l){const a=l.alerts||[];$('alerts').innerHTML=a.slice(-4).reverse().map(x=>{const c=x.action==='COMPRE'?'buy':x.action==='REALIZE'?'realize':'sell';const meta=x.action==='ERRO'?'Diagnóstico automático':`KPI ${fmt(x.promising_pct,1)} • Risk ${fmt(x.risk,1)}`;return `<div class="alert ${c}"><b>${esc(x.action)} • ${esc(x.asset)}</b> — ${esc(x.message||'Sinal novo detectado.')} <span style="color:#9baab4">${esc(meta)}</span></div>`}).join('');renderPatchButton(l)}
function renderPatchButton(l){const p=(l.patches||[]).filter(x=>x.status==='AVAILABLE');const b=$('patchButton');if(!b)return;b.classList.toggle('hidden',p.length===0);$('patchCount').textContent=p.length?`(${p.length})`:''}
async function openPatches(){try{const x=await jsonFetch('/api/patches');const ps=(x.patches||[]).filter(p=>p.status==='AVAILABLE');openModal('🩹 Correções e updates disponíveis',ps.length?ps.map(p=>`<div class="patch-card"><h3>${esc(p.title)}</h3><div class="patch-meta">${esc(p.id)} • risco ${esc(p.risk||'—')}</div><div>${esc(p.summary||'')}</div><ul class="patch-changes">${(p.changes||[]).map(c=>`<li>${esc(c)}</li>`).join('')}</ul><details class="technical-details"><summary>Testes executados</summary><pre>${esc(JSON.stringify(p.tests||[],null,2))}</pre></details><button onclick="implementPatch('${esc(p.id)}')">Implementar</button></div>`).join(''):'<p>Nenhuma correção aguardando implementação.</p>')}catch(e){toast('Falha ao carregar patches: '+e.message)}}
async function implementPatch(id){try{const x=await jsonFetch('/api/patch/'+encodeURIComponent(id)+'/implement',{method:'POST'});closeModal();jobWatch(x.job_id,'Implementação do patch')}catch(e){toast('Falha ao implementar patch: '+e.message)}}
function renderTips(l){const tips=[];if((l.corr||0)<.2)tips.push('Correlação baixa: testar ensemble, features de regime e validação temporal mais longa antes de promover um modelo.');if((l.hit_rate||0)<55)tips.push('Acerto direcional abaixo de 55%: priorizar reversal, persistência de momentum e calibração por regime.');if((l.algorithms_tested||0)<10)tips.push('O laboratório ainda não concluiu os 10 modelos; compare-os antes de escolher um campeão.');tips.push('Dados intraday alimentam memória operacional, mas não contam como dias independentes no treino.');tips.push('Confiança só deve subir quando houver evidência out-of-sample consistente, não por ajuste de escala.');$('tips').innerHTML=tips.map(t=>`<div class="tip">• ${esc(t)}</div>`).join('')}
function renderCharts(d,i,force=false){const daily=(d||[]).filter(r=>r.date);const intra=(i||[]).filter(r=>r.timestamp);const sig=JSON.stringify([daily.map(x=>[x.date,x.asset,x.pnl_eur]),intra.map(x=>[x.timestamp,x.asset,x.pnl_eur])]);if(!force&&sig===lastChartSig)return;lastChartSig=sig;const by={};daily.forEach(r=>(by[r.asset]??=[]).push(r));const labels=[...new Set(daily.map(r=>String(r.date).slice(0,10)))].sort();const datasets=Object.entries(by).map(([a,rs])=>({label:a,data:labels.map(x=>{const r=rs.find(z=>String(z.date).slice(0,10)===x);return r?Number(r.pnl_eur||0):null}),tension:.25,spanGaps:true}));if(dailyChart)dailyChart.destroy();dailyChart=new Chart($('dailyChart'),{type:'line',data:{labels,datasets},options:{responsive:true,maintainAspectRatio:false,animation:false,plugins:{legend:{labels:{color:'#b8c4cb',font:{size:10}}}},scales:{x:{ticks:{color:'#758590',maxTicksLimit:8}},y:{ticks:{color:'#758590'}}}}});const labelsI=[...new Set(intra.map(r=>String(r.timestamp)))].sort();const assets=[...new Set(intra.map(r=>String(r.asset)))];const ds=assets.map(a=>{const data=labelsI.map(ts=>{const r=intra.find(z=>String(z.timestamp)===ts&&String(z.asset)===a);return r?Number(r.pnl_eur||0):null});const valid=data.filter(v=>v!==null&&Number.isFinite(v)).length;return {label:a,data,tension:.25,spanGaps:true,pointRadius:valid<2?4:2,pointHoverRadius:valid<2?6:4}});if(intraChart)intraChart.destroy();intraChart=new Chart($('intradayChart'),{type:'line',data:{labels:labelsI.map(x=>{const d=new Date(x);return Number.isNaN(d.getTime())?String(x).slice(11,16):d.toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'})}),datasets:ds},options:{responsive:true,maintainAspectRatio:false,animation:false,plugins:{legend:{labels:{color:'#b8c4cb',font:{size:10}}}},scales:{x:{ticks:{color:'#758590',maxTicksLimit:8}},y:{ticks:{color:'#758590'}}}}})}
async function refreshCharts(force=false){try{const h=encodeURIComponent($('hours').value);const [a,b]=await Promise.all([jsonFetch('/api/daily'),jsonFetch('/api/intraday?hours='+h)]);renderCharts(a.rows||[],b.rows||[],force)}catch(e){toast('Falha ao atualizar gráficos: '+e.message)}}
async function loadStatus(force=false){try{const x=await jsonFetch('/api/status');lastStatus=x;renderReaders(x.portfolio,x.learning);renderPortfolio(x.portfolio);renderLearning(x.learning);renderGauges(x.portfolio,x.learning);renderAlerts(x.learning);renderTips(x.learning);$('jobList').innerHTML=(x.jobs||[]).slice().reverse().map(j=>`<div class="job"><span>${esc(j.kind)}</span><span class="status-${esc(j.status)}">${esc(j.status)}</span></div>`).join('')||'<div class="tip">Nenhum ensaio em execução.</div>'}catch(e){toast('Falha ao atualizar interface: '+e.message)}}
async function loadAll(){await loadStatus();await refreshCharts()}
setInterval(()=>{$('clock').textContent=new Date().toLocaleTimeString('pt-PT')},1000);setInterval(()=>loadStatus(),5000);setInterval(()=>refreshCharts(),15000);loadAll();

/* Porquinho V3.4.5.1 — isolated browser diagnostics.
   This block must never prevent the dashboard from loading. */
;(function porquinhoBrowserDiagnostics(){
  const state = {stage:'diag_boot'};
  async function send(extra){
    try{
      const c=document.getElementById('intradayChart');
      const payload=Object.assign({},state,extra||{},{
        timestamp:Date.now()/1000,
        user_agent:navigator.userAgent,
        chart_available:(typeof Chart!=='undefined'),
        canvas_present:!!c,
        canvas_width:c ? (c.clientWidth||0) : 0,
        canvas_height:c ? (c.clientHeight||0) : 0,
        intraday_chart_created:(typeof intraChart!=='undefined' && !!intraChart)
      });
      await fetch('/api/browser-diagnostic',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(payload)
      });
    }catch(_e){ /* diagnostics must never break the dashboard */ }
  }
  try{
    window.addEventListener('error',function(e){
      send({stage:'window_error',error_message:e.message||String(e.error||'JavaScript error'),
            error_stack:(e.error&&e.error.stack)||''});
    });
    window.addEventListener('unhandledrejection',function(e){
      const r=e.reason||{};
      send({stage:'unhandled_rejection',error_message:String(r.message||r||'Promise rejection'),
            error_stack:r.stack||''});
    });

    // Wrap refreshCharts without replacing its implementation.
    if(typeof refreshCharts==='function'){
      const originalRefreshCharts=refreshCharts;
      refreshCharts=async function(force){
        await send({stage:'before_refresh'});
        let result;
        try{
          result=await originalRefreshCharts(force);
        }finally{
          let rows=null;
          try{
            const h=encodeURIComponent((document.getElementById('hours')||{}).value||24);
            const resp=await fetch('/api/intraday?hours='+h);
            const data=await resp.json();
            rows=Array.isArray(data.rows)?data.rows.length:null;
          }catch(_e){}
          await send({stage:'after_refresh',intraday_rows:rows});
        }
        return result;
      };
    }
    setTimeout(function(){send({stage:'post_boot_probe'});},2500);

    async function inspectIntradayRender(){
      try{
        const c=document.getElementById('intradayChart'), ch=(typeof intraChart!=='undefined')?intraChart:null;
        const datasets=(ch&&ch.data&&Array.isArray(ch.data.datasets))?ch.data.datasets:[];
        const summary=datasets.map(function(d){const a=Array.isArray(d.data)?d.data:[];let invalid=0,nullish=0;
          a.forEach(function(v){if(v===null||v===undefined){nullish++;return;} if(typeof v==='number'&&!Number.isFinite(v)){invalid++;return;}
            if(typeof v==='object'&&v){['x','y'].forEach(function(k){if(k in v&&typeof v[k]==='number'&&!Number.isFinite(v[k]))invalid++;});}});
          return {label:d.label||'',points:a.length,invalid:invalid,nullish:nullish,hidden:!!d.hidden};});
        const rect=c?c.getBoundingClientRect():null, area=(ch&&ch.chartArea)?ch.chartArea:null, cs=c?getComputedStyle(c):null;
        await send({stage:'render_verification',chart_exists:!!ch,chart_type:(ch&&ch.config&&ch.config.type)||null,
          dataset_count:datasets.length,datasets:summary,chart_area:area?{width:area.width,height:area.height}:null,
          canvas_rect:rect?{width:rect.width,height:rect.height}:null,canvas_display:cs?cs.display:null,
          canvas_visibility:cs?cs.visibility:null,canvas_opacity:cs?cs.opacity:null});
      }catch(e){await send({stage:'render_verification_error',error_message:e.message||String(e),error_stack:e.stack||''});}
    }
    setTimeout(inspectIntradayRender,3200);

  }catch(_e){ /* diagnostics are optional */ }
})();

/* V3.6.0 Porquinho Experience — additive navigation, no API contract changes */
const EXPERIENCE_VIEWS={
 market:{title:'Mercado',desc:'Universo monitorado, sinais e leitura do regime usando os dados reais já carregados pelo Porquinho.'},
 portfolio:{title:'Carteira',desc:'Posições, alvos, P/L e rebalanceamento. A tabela operacional continua sendo a fonte real do sistema.'},
 analysis:{title:'Análises',desc:'Modelos, indicadores, aprendizagem e experimentos quantitativos do Porquinho.'},
 news:{title:'Notícias',desc:'Área preparada para a camada de contexto e pesquisa do Porquinho, sem inventar notícias ou dados externos.'},
 reports:{title:'Relatórios',desc:'Acesso organizado a histórico, importação e futuras saídas consolidadas.'},
 system:{title:'Sistema',desc:'Diagnóstico, Patch Center, jobs e estado operacional do Brain.'},
 settings:{title:'Configurações',desc:'Preferências e controles do módulo Porquinho.'}
};
function moduleCard(title,text,button,action){return `<div class="module-card"><b>${esc(title)}</b><p>${esc(text)}</p>${button?`<button onclick="${action}">${esc(button)}</button>`:''}</div>`}
function showExperienceView(name,button){document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));if(name==='dashboard'){document.getElementById('view-dashboard').classList.add('active-view');document.querySelector('[data-target="dashboard"]')?.classList.add('active');setTimeout(()=>{dailyChart?.resize();intraChart?.resize()},30);return}const cfg=EXPERIENCE_VIEWS[name]||EXPERIENCE_VIEWS.analysis;document.getElementById('view-placeholder').classList.add('active-view');(button||document.querySelector(`[data-target="${name}"]`))?.classList.add('active');$('viewTitle').textContent=cfg.title;$('viewDescription').textContent=cfg.desc;let cards=[];if(name==='market')cards=[moduleCard('Universo monitorado','Veja a tabela real de ativos, KPI, ação, risco e variações no Dashboard.','Voltar ao Dashboard',"showExperienceView('dashboard')"),moduleCard('Atualização de mercado','Solicita uma atualização real dos dados e sinais.','Atualizar agora','refreshNow()'),moduleCard('Histórico','Importe ou hidrate séries históricas usadas pelo motor.','Abrir histórico','openImport()')];else if(name==='portfolio')cards=[moduleCard('Carteira / Alvo','As posições e pesos reais permanecem conectados ao endpoint atual.','Abrir carteira',"showExperienceView('dashboard');document.querySelector('.portfolio-card')?.scrollIntoView({behavior:'smooth'})"),moduleCard('Detalhes por ativo','Clique em qualquer linha da carteira para abrir o diagnóstico real do ativo.'),moduleCard('Rebalanceamento','As ações COMPRE/MANTENHA/VENDA continuam vindo do motor quantitativo, sem lógica fictícia no frontend.')];else if(name==='analysis')cards=[moduleCard('Prediction Lab','Execute um dos algoritmos já suportados pelo laboratório.','Abrir laboratório',"showExperienceView('dashboard');document.querySelector('.learning')?.scrollIntoView({behavior:'smooth'})"),moduleCard('Evolução controlada','Aciona o fluxo de evolução já existente.','Evoluir','evolve()'),moduleCard('Aprendizagem','Executa a pesquisa/aprendizagem existente.','Aprender','research()')];else if(name==='system')cards=[moduleCard('Porquinho IA','Investigue erros, arquitetura e reparos pelo Brain.','Abrir Chat IA','openChat()'),moduleCard('Patch Center','Veja apenas patches atualmente disponíveis para aprovação.','Abrir correções','openPatches()'),moduleCard('Jobs e diagnóstico','O monitor de ensaios e alertas continua no Dashboard.','Ver monitor',"showExperienceView('dashboard');document.getElementById('jobList')?.scrollIntoView({behavior:'smooth'})")];else if(name==='reports')cards=[moduleCard('Importação e consolidação','Importe histórico diário, intraday, carteira ou outcomes.','Abrir histórico','openImport()'),moduleCard('Hidratação 365d','Constrói/atualiza o histórico via provedor existente.','Atualizar 365 dias','hydrate()'),moduleCard('Relatórios','Estrutura pronta para relatórios dedicados em uma próxima etapa; nenhum dado foi simulado.')];else if(name==='news')cards=[moduleCard('Contexto de mercado','A tela está preparada para receber somente notícias reais quando conectarmos uma fonte ao backend.'),moduleCard('Sem conteúdo fictício','A V3.6 não preenche esta área com manchetes simuladas.'),moduleCard('Pesquisa do Brain','Use o Porquinho IA para pesquisa e investigação já suportadas.','Abrir IA','openChat()')];else cards=[moduleCard('Interface','Porquinho Experience V3.6.0 ativa.'),moduleCard('Dados','Nenhuma configuração financeira foi alterada por esta migração.'),moduleCard('Histórico','Importação e hidratação continuam disponíveis.','Abrir histórico','openImport()')];$('viewContent').innerHTML=`<div class="module-grid">${cards.join('')}</div>`;window.scrollTo({top:0,behavior:'smooth'})}
function experienceSearch(q){q=String(q||'').trim();if(!q)return;const rows=[...document.querySelectorAll('#portfolioTable tbody tr')];const hit=rows.find(r=>r.textContent.toLowerCase().includes(q.toLowerCase()));if(hit){showExperienceView('dashboard');hit.scrollIntoView({behavior:'smooth',block:'center'});hit.animate([{background:'rgba(0,239,169,.28)'},{background:'transparent'}],{duration:1600});return}toast('Nenhum ativo visível encontrado para “'+q+'”.')}
/* V38136R4_LAST_ANALYTIC_CYCLE_UI */
const _v36LoadStatus=loadStatus;loadStatus=async function(force=false){
 await _v36LoadStatus(force);
 const el=document.getElementById('lastUpdate');
 if(!el)return;
 const ts=lastStatus?.snapshot?.timestamp || null;
 if(!ts){el.textContent='Último ciclo: —';return}
 const d=new Date(ts);
 el.textContent=Number.isNaN(d.getTime())?'Último ciclo: —':'Último ciclo às '+d.toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'});
}


/* V3.6.1 Porquinho Experience — Mercado & Carteira */
function v361Metric(label,value,sub=''){return `<div class="v361-metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`}
function v361MarketTable(p){const rows=(p?.scores||[]);return `<div class="table-wrap"><table class="v361-table"><thead><tr><th>Ativo</th><th>Preço da lista</th><th>KPI</th><th>Decisão / sinal experimental</th><th>OPP</th><th>ENT</th><th>ASY</th><th>RISK</th><th>7d</th><th>30d</th></tr></thead><tbody>${rows.map(s=>`<tr class="asset-row" onclick="assetDetail(${encodeURIComponent(JSON.stringify(s))})"><td><b>${esc(s.asset)}</b></td><td>${money(s.price_eur)}</td><td>${fmt(s.promising_pct,1)}</td><td>${v366252ActionBadge(s)}</td><td>${fmt(s.opportunity,1)}</td><td>${fmt(s.entry,1)}</td><td>${fmt(s.asymmetry,1)}</td><td>${fmt(s.risk,1)}</td><td class="${Number(s.change_7d)>=0?'gain':'loss'}">${fmt(s.change_7d,1)}%</td><td class="${Number(s.change_30d)>=0?'gain':'loss'}">${fmt(s.change_30d,1)}%</td></tr>`).join('')}</tbody></table></div>`}
function renderMarketView(){const x=lastStatus||{},p=x.portfolio||{},l=x.learning||{},rows=p.scores||[];const buy=rows.filter(s=>a24MarketSignalActions(s).some(a=>['COMPRE','BUY','DEPLOY_CASH','INCREASE'].includes(a))).length,sell=rows.filter(s=>a24MarketSignalActions(s).some(a=>['VENDA','REALIZE','SELL','REDUCE'].includes(a))).length;$('marketMetrics').innerHTML=[v361Metric('Ativos nesta lista',String(rows.length),'Contextos globais no painel abaixo.'),v361Metric('Regime',l.regime==null?'—':fmt(l.regime,1)),v361Metric('Índice de confiança',l.confidence==null?'—':fmt(l.confidence,0)+'/100','Pesquisa; não é probabilidade de acerto.'),v361Metric('Sinais de compra',String(buy),'Sinais exibidos; não são ordens.'),v361Metric('Sinais de venda/redução',String(sell),'Sinais exibidos; não são ordens.')].join('');$('marketUniverse').innerHTML=v361MarketTable(p)}
function v361PortfolioRows(p){const rows=(p?.scores||[]).filter(s=>Number(s.current_value_eur||0)>0||Number(s.current_weight_pct||0)>0||(s.account&&s.account!=='N/A'&&s.account!=='—'));return `<div class="table-wrap"><table class="v361-table"><thead><tr><th>Ativo</th><th>Conta</th><th>Atual</th><th>Alvo</th><th>Valor</th><th>P/L</th><th>P/L %</th><th>Ação</th><th>Risco</th><th>Editar</th></tr></thead><tbody>${rows.map(s=>`<tr class="asset-row" onclick="assetDetail(${encodeURIComponent(JSON.stringify(s))})"><td><b>${esc(s.asset)}</b></td><td>${esc(s.account||'—')}</td><td>${fmt(s.current_weight_pct,1)}%</td><td>${fmt(s.target_weight_pct,1)}%</td><td>${money(s.current_value_eur)}</td><td class="${Number(s.pnl_eur)>=0?'gain':'loss'}">${money(s.pnl_eur)}</td><td class="${Number(s.pnl_pct)>=0?'gain':'loss'}">${fmt(s.pnl_pct,1)}%</td><td>${v366252ActionBadge(s)}</td><td>${fmt(s.risk,1)}</td><td><button class="v38941-edit" data-asset="${esc(s.asset)}" onclick="event.stopPropagation();v38941EditPosition(this.dataset.asset)">Editar</button></td></tr>`).join('')||'<tr><td colspan="10" class="muted">Nenhuma posição real encontrada no snapshot atual.</td></tr>'}</tbody></table></div>`}
function renderPortfolioView(){const p=(lastStatus||{}).portfolio||{};const n=(p.accounts?.N26||[]).length,r=(p.accounts?.Revolut||[]).length;$('portfolioMetricsV361').innerHTML=[v361Metric('Patrimônio',money(p.value_eur)),v361Metric('Investido',money(p.invested_eur)),v361Metric('Caixa',money(p.cash_eur)),v361Metric('P/L total',money(p.pnl_eur),fmt(p.pnl_pct)+'%'),v361Metric('Contas',`N26 ${n} • Revolut ${r}`)].join('');$('portfolioPositionsV361').innerHTML=v361PortfolioRows(p)}
function renderV361Views(){if(!lastStatus)return;renderMarketView();renderPortfolioView()}
const _v361ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));if(name==='market'){$('view-market').classList.add('active-view');(button||document.querySelector('[data-target="market"]'))?.classList.add('active');renderMarketView();window.scrollTo({top:0,behavior:'smooth'});return}if(name==='portfolio'){$('view-portfolio').classList.add('active-view');(button||document.querySelector('[data-target="portfolio"]'))?.classList.add('active');renderPortfolioView();window.scrollTo({top:0,behavior:'smooth'});return}return _v361ShowExperienceView(name,button)}
const _v361LoadStatus=loadStatus;loadStatus=async function(force=false){await _v361LoadStatus(force);renderV361Views()}


/* V3.6.2 Porquinho Experience — Análises & Porquinho IA */
function v362Metric(label,value,sub=''){return `<div class="v361-metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`}
function renderAnalysisView(){
 const l=(lastStatus||{}).learning||{}, algs=l.lab?.algorithms||[];
 $('analysisMetrics').innerHTML=[
  v362Metric('Modelo',l.model||'Baseline'),v362Metric('Confiança',fmt(l.confidence,0)+'/100'),
  v362Metric('Regime',l.regime==null?'—':fmt(l.regime,1)),v362Metric('Acerto',l.hit_rate==null?'—':fmt(l.hit_rate,1)+'%'),
  v362Metric('MAE',l.mae==null?'—':fmt(l.mae,2)),v362Metric('Ensaios',String(l.experiments??algs.length))
 ].join('');
 $('analysisModelSelect').innerHTML=MODELS.map(x=>`<option>${esc(x)}</option>`).join('');
 $('analysisExperiments').innerHTML=algs.slice(-6).reverse().map(a=>`<div class="v362-exp"><b>${esc(a.algorithm||'—')}</b><span>${a.mae==null?'ERRO':'MAE '+fmt(a.mae,2)+' • HIT '+fmt(a.directional_hit_rate,1)+'%'}</span></div>`).join('')||'<div class="muted">Nenhum ensaio concluído ainda.</div>';
 const tips=[]; if((l.corr||0)<.2)tips.push('Correlação baixa: exigir evidência temporal antes de promover modelos.'); if((l.hit_rate||0)<55)tips.push('Acerto direcional abaixo de 55%: revisar features e calibração por regime.'); if((l.algorithms_tested||0)<10)tips.push('O laboratório ainda não concluiu os 10 modelos.'); tips.push('Confiança representa qualidade da evidência, não garantia de retorno.');
 $('analysisGuidance').innerHTML=tips.map(t=>`<div class="v362-tip">• ${esc(t)}</div>`).join('');
 $('analysisAlgorithms').innerHTML=`<div class="table-wrap"><table class="v361-table"><thead><tr><th>Algoritmo</th><th>MAE</th><th>Acerto direcional</th><th>Status</th></tr></thead><tbody>${algs.slice().reverse().map(a=>`<tr><td><b>${esc(a.algorithm||'—')}</b></td><td>${a.mae==null?'—':fmt(a.mae,2)}</td><td>${a.directional_hit_rate==null?'—':fmt(a.directional_hit_rate,1)+'%'}</td><td>${a.mae==null?'ERRO':'AVALIADO'}</td></tr>`).join('')||'<tr><td colspan="4" class="muted">Sem resultados registrados.</td></tr>'}</tbody></table></div>`;
}
async function runAnalysisModel(){try{const sel=$('analysisModelSelect');const j=await jsonFetch('/api/model',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({algorithm:sel.value})});jobWatch(j.job_id,sel.value)}catch(e){toast('Falha ao iniciar modelo: '+e.message)}}
function renderAIState(){const l=(lastStatus||{}).learning||{},p=(l.patches||[]).filter(x=>x.status==='AVAILABLE'),a=l.alerts||[];$('aiState').innerHTML=[['Confiança',fmt(l.confidence,0)+'/100'],['Modelo',l.model||'—'],['Patches pendentes',String(p.length)],['Alertas recentes',String(a.length)]].map(x=>`<div class="v362-state"><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('')}
async function sendAIView(){const input=$('iaInput'),log=$('iaLog');const msg=input.value.trim();if(!msg)return;input.value='';log.innerHTML+=`<div class="chat-msg user"><b>Você</b><div class="chat-answer">${richText(msg)}</div></div>`;log.scrollTop=log.scrollHeight;try{const j=await jsonFetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:msg})});log.innerHTML+=`<div id="iaPending" class="chat-msg"><b>Porquinho</b><div class="chat-answer muted">Investigando…</div></div>`;const poll=setInterval(async()=>{try{const q=await jsonFetch('/api/job/'+encodeURIComponent(j.job_id));if(q.status==='done'||q.status==='error'){clearInterval(poll);$('iaPending')?.remove();const rr=q.result??q.error;log.innerHTML+=`<div class="chat-msg ${q.status==='error'?'loss':''}"><b>Porquinho</b>${chatResult(rr)}</div>`;log.scrollTop=log.scrollHeight;await loadStatus(true);renderAIState()}}catch(e){clearInterval(poll);$('iaPending')?.remove();log.innerHTML+=`<div class="chat-msg loss"><b>Porquinho</b><div class="chat-answer">${richText(e.message)}</div></div>`}},700)}catch(e){log.innerHTML+=`<div class="chat-msg loss"><b>Porquinho</b><div class="chat-answer">${richText(e.message)}</div></div>`}}
function renderV362Views(){if(!lastStatus)return;renderAnalysisView();renderAIState()}
const _v362ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
 document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
 if(name==='analysis'){$('view-analysis').classList.add('active-view');(button||document.querySelector('[data-target="analysis"]'))?.classList.add('active');renderAnalysisView();window.scrollTo({top:0,behavior:'smooth'});return}
 if(name==='ai'){$('view-ai').classList.add('active-view');(button||document.querySelector('[data-target="ai"]'))?.classList.add('active');renderAIState();setTimeout(()=>$('iaInput')?.focus(),50);window.scrollTo({top:0,behavior:'smooth'});return}
 return _v362ShowExperienceView(name,button);
}
const _v362LoadStatus=loadStatus;loadStatus=async function(force=false){await _v362LoadStatus(force);renderV362Views()}


/* V3.6.2.2 — Emerald UI Polish */
function v363Prompt(text){const i=$('iaInput');if(!i)return;i.value=text;i.focus()}
function v363InstallQuickActions(){
 const c=document.querySelector('#view-ai .v362-composer'); if(!c||document.getElementById('v363Quick'))return;
 const q=document.createElement('div');q.id='v363Quick';q.className='v363-quick';
 q.innerHTML=`<button onclick="v363Prompt('Diagnostique o último erro e proponha uma correção segura.')">⌕ Diagnosticar sistema</button><button onclick="v363Prompt('Analise o estado atual do mercado e destaque os sinais relevantes.')">▥ Analisar mercado</button><button onclick="openPatches()">⌁ Ver patches pendentes</button>`;
 c.parentNode.insertBefore(q,c);
}
document.addEventListener('DOMContentLoaded',v363InstallQuickActions);
setTimeout(v363InstallQuickActions,0);


/* V3.6.3 — Executive Dashboard & Responsive Foundation */
function v363ExecMetric(label,value,sub=''){return `<div class="v363-exec-metric"><span>${esc(label)}</span><b>${esc(value)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`}
function renderExecutiveDashboard(){
 // V38138R1_EXEC_DASHBOARD_LIFECYCLE_GUARD
 // Async status refresh may finish while another route owns the DOM.
 // The dashboard renderer is therefore a no-op unless all of its targets are mounted.
 const _v38138r1Targets=['execMetrics','execNow','execPortfolio'].map(id=>$(id));
 if(_v38138r1Targets.some(el=>!el))return;
 const x=lastStatus||{},p=x.portfolio||{},l=x.learning||{},rows=p.scores||[];
 const held=rows.filter(s=>Number(s.current_value_eur||0)>0).sort((a,b)=>Number(b.current_value_eur||0)-Number(a.current_value_eur||0));
 const patches=(l.patches||[]).filter(z=>z.status==='AVAILABLE').length,alerts=(l.alerts||[]).length;
 const buy=rows.filter(s=>a24MarketSignalActions(s).some(a=>['COMPRE','BUY','DEPLOY_CASH','INCREASE'].includes(a))).length,sell=rows.filter(s=>a24MarketSignalActions(s).some(a=>['VENDA','REALIZE','SELL','REDUCE'].includes(a))).length;
 $('execMetrics').innerHTML=[
  v363ExecMetric('Patrimônio',money(p.value_eur)),
  v363ExecMetric('P/L total',money(p.pnl_eur),fmt(p.pnl_pct)+'%'),
  v363ExecMetric('Caixa',money(p.cash_eur)),
  v363ExecMetric('Confiança',fmt(l.confidence,0)+'/100'),
  v363ExecMetric('Regime',l.regime==null?'—':fmt(l.regime,1))
 ].join('');
 const now=[];
 if(buy)now.push(['Sinal de compra',buy+' ativo'+(buy>1?'s':'')]);
 if(sell)now.push(['Venda / realização',sell+' ativo'+(sell>1?'s':'')]);
 if(patches)now.push(['Patch pendente',String(patches)]);
 if(alerts)now.push(['Alertas',String(alerts)]);
 if(!now.length)now.push(['Estado','Nenhuma ação crítica agora']);
 $('execNow').innerHTML=now.map(([a,b])=>`<div class="v363-now-row"><span>${esc(a)}</span><b>${esc(b)}</b></div>`).join('')+
 `<div class="v363-now-actions"><button onclick="showExperienceView('market')">Mercado</button><button onclick="showExperienceView('analysis')">Análises</button><button onclick="showExperienceView('ai')">Porquinho IA</button></div>`;
 $('execPortfolio').innerHTML=held.slice(0,5).map(s=>`<div class="v363-holding"><b>${esc(s.asset)}</b><span>${money(s.current_value_eur)}</span><span class="${Number(s.pnl_pct)>=0?'gain':'loss'}">${fmt(s.pnl_pct,1)}%</span><em>${v366252ActionBadge(s)}</em></div>`).join('')||'<div class="muted">Nenhuma posição encontrada.</div>';
}
function renderV363(){if(lastStatus)renderExecutiveDashboard()}
const _v363LoadStatus=loadStatus;
loadStatus=async function(force=false){await _v363LoadStatus(force);renderV363()}
document.addEventListener('DOMContentLoaded',()=>setTimeout(renderV363,100));

/* V3.6.4 — Adaptive Viewport & Emerald Controls */
let emPortal=null,emActive=null;
function emEnsurePortal(){
 if(emPortal)return emPortal;
 emPortal=document.createElement('div');emPortal.id='emSelectPortal';emPortal.className='em-select-portal';
 emPortal.setAttribute('role','listbox');document.body.appendChild(emPortal);return emPortal;
}
function emCloseSelect(){
 if(emActive){const b=emActive.querySelector('.em-select-btn');if(b)b.setAttribute('aria-expanded','false')}
 if(emPortal){emPortal.classList.remove('open');emPortal.innerHTML=''}
 emActive=null;
}
function emPositionPortal(wrap){
 if(!emPortal||!wrap)return;
 const b=wrap.querySelector('.em-select-btn'),r=b.getBoundingClientRect(),gap=5;
 const below=window.innerHeight-r.bottom-gap,above=r.top-gap;
 const maxH=Math.min(340,Math.max(140,Math.max(below,above)-8));
 const openUp=below<180&&above>below;
 emPortal.style.left=Math.max(8,r.left)+'px';
 emPortal.style.width=Math.max(170,r.width)+'px';
 emPortal.style.maxHeight=maxH+'px';
 if(openUp){emPortal.style.top='auto';emPortal.style.bottom=(window.innerHeight-r.top+gap)+'px'}
 else{emPortal.style.bottom='auto';emPortal.style.top=(r.bottom+gap)+'px'}
}
function emSyncSelect(wrap){
 const native=wrap&&wrap.querySelector('select'),label=wrap&&wrap.querySelector('.em-select-label');
 if(!native||!label)return;
 const opt=native.options[native.selectedIndex];label.textContent=opt?opt.text:'—';
}
function emOpenSelect(wrap){
 const native=wrap.querySelector('select'),portal=emEnsurePortal(); emCloseSelect(); emActive=wrap;
 portal.innerHTML='';
 Array.from(native.options).forEach((o,i)=>{
  const b=document.createElement('button');b.type='button';b.className='em-select-option'+(i===native.selectedIndex?' selected':'');
  b.textContent=o.text;b.dataset.index=String(i);
  b.onclick=(ev)=>{ev.preventDefault();ev.stopPropagation();native.selectedIndex=i;native.dispatchEvent(new Event('change',{bubbles:true}));emSyncSelect(wrap);emCloseSelect();wrap.querySelector('.em-select-btn').focus()};
  portal.appendChild(b);
 });
 wrap.querySelector('.em-select-btn').setAttribute('aria-expanded','true');emPositionPortal(wrap);portal.classList.add('open');
 const sel=portal.querySelector('.selected');if(sel)sel.scrollIntoView({block:'nearest'});
}
function emBuildSelect(native){
 if(!native||native.dataset.emeraldSelect==='2')return;
 /* Upgrade safely from V3.6.3.1 wrapper if present. */
 let old=native.closest('.em-select');
 if(old){
  const parent=old.parentNode;parent.insertBefore(native,old);old.remove();
 }
 native.dataset.emeraldSelect='2';native.classList.add('em-select-native');
 const wrap=document.createElement('div');wrap.className='em-select';native.parentNode.insertBefore(wrap,native);wrap.appendChild(native);
 const btn=document.createElement('button');btn.type='button';btn.className='em-select-btn';btn.setAttribute('aria-haspopup','listbox');btn.setAttribute('aria-expanded','false');
 btn.innerHTML='<span class="em-select-label"></span><span class="em-select-chevron">⌄</span>';wrap.appendChild(btn);emSyncSelect(wrap);
 btn.onclick=(ev)=>{ev.preventDefault();ev.stopPropagation();emActive===wrap?emCloseSelect():emOpenSelect(wrap)};
 btn.onkeydown=(ev)=>{
  if(ev.key==='Escape'){emCloseSelect();return}
  if(ev.key==='Enter'||ev.key===' '||ev.key==='ArrowDown'){ev.preventDefault();if(emActive!==wrap)emOpenSelect(wrap)}
 };
 native.addEventListener('change',()=>emSyncSelect(wrap));
}
function emUpgradeSelects(root=document){root.querySelectorAll('select').forEach(emBuildSelect)}
document.addEventListener('click',e=>{if(!e.target.closest('.em-select-portal')&&!e.target.closest('.em-select'))emCloseSelect()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')emCloseSelect()});
window.addEventListener('resize',()=>{if(emActive)emPositionPortal(emActive)});
window.addEventListener('scroll',()=>{if(emActive)emPositionPortal(emActive)},true);
document.addEventListener('DOMContentLoaded',()=>{
 emEnsurePortal();emUpgradeSelects();
 new MutationObserver(()=>emUpgradeSelects()).observe(document.body,{childList:true,subtree:true});
});
setTimeout(()=>{emEnsurePortal();emUpgradeSelects()},0);


/* V3.6.4.1 — Dashboard Dynamics & UX */
const V3641_CHART_COLORS={
 BTC:'#f59e0b',AAVE:'#ec5f91',BNB:'#f4c430',HYPE:'#a78bfa',SOL:'#22d3ee',
 ETH:'#7c83ff',XMR:'#ff7a18',XRP:'#94a3b8',TRX:'#ef4444',LINK:'#38bdf8'
};
function v3641ChartColor(asset,index=0){
 const fallback=['#35e6b2','#58b8ff','#ffc857','#a78bfa','#ff6f91','#22d3ee','#fb7185','#c4b5fd'];
 return V3641_CHART_COLORS[String(asset||'').toUpperCase()]||fallback[index%fallback.length];
}
function v3641PolishChart(chart){
 if(!chart||!chart.data||!Array.isArray(chart.data.datasets))return;
 chart.data.datasets.forEach((ds,i)=>{
  const c=v3641ChartColor(ds.label,i);
  ds.borderColor=c;ds.backgroundColor=c;ds.pointBackgroundColor=c;ds.pointBorderColor=c;
  ds.borderWidth=2.4;ds.pointRadius=Math.min(Number(ds.pointRadius??2),2.5);ds.pointHoverRadius=5;
 });
 if(chart.options?.plugins?.legend?.labels){
  chart.options.plugins.legend.labels.usePointStyle=true;
  chart.options.plugins.legend.labels.pointStyle='circle';
  chart.options.plugins.legend.labels.boxWidth=8;
 }
 chart.update('none');
}
if(typeof renderCharts==='function'){
 const _v3641RenderCharts=renderCharts;
 renderCharts=function(d,i,force=false){
  const out=_v3641RenderCharts(d,i,force);
  try{v3641PolishChart(dailyChart);v3641PolishChart(intraChart)}catch(_){}
  return out;
 };
}
function v3641AssetGlyph(asset){
 const a=String(asset||'').toUpperCase();
 return ({BTC:'₿',ETH:'Ξ',SOL:'S',BNB:'B',AAVE:'A',HYPE:'H',XMR:'M',XRP:'X',TRX:'T',LINK:'L',DOGE:'Ð',ADA:'A',BCH:'B',UNI:'U',ZEC:'Z',NEAR:'N',XLM:'X',LEO:'L',RAIN:'R',WBT:'W',FIGR_HELOC:'F'})[a]||a.slice(0,2);
}
function v3641DecorateAssetIcons(root=document){
 root.querySelectorAll('tr.asset-row td:first-child').forEach(td=>{
  if(td.querySelector('.asset-icon'))return;
  const b=td.querySelector('b');if(!b)return;
  const asset=(b.textContent||'').trim().toUpperCase();if(!asset)return;
  const wrap=document.createElement('span');wrap.className='asset-cell';
  const icon=document.createElement('span');icon.className='asset-icon';icon.dataset.asset=asset;
  icon.textContent=v3641AssetGlyph(asset);icon.title=asset;icon.setAttribute('aria-hidden','true');
  b.parentNode.insertBefore(wrap,b);wrap.append(icon,b);
 });
 document.querySelectorAll('.v363-holding').forEach(row=>{
  const b=row.querySelector('b');if(!b||row.querySelector('.asset-icon'))return;
  const asset=(b.textContent||'').trim().toUpperCase();
  const wrap=document.createElement('span');wrap.className='asset-cell';
  const icon=document.createElement('span');icon.className='asset-icon';icon.dataset.asset=asset;
  icon.textContent=v3641AssetGlyph(asset);icon.title=asset;icon.setAttribute('aria-hidden','true');
  b.parentNode.insertBefore(wrap,b);wrap.append(icon,b);
 });
}
function v3641RefreshUX(){
 v3641DecorateAssetIcons();
 try{v3641PolishChart(dailyChart);v3641PolishChart(intraChart)}catch(_){}
}
if(typeof renderExecutiveDashboard==='function'){
 const _v3641Exec=renderExecutiveDashboard;
 renderExecutiveDashboard=function(){const r=_v3641Exec();requestAnimationFrame(v3641RefreshUX);return r};
}
if(typeof renderMarketView==='function'){
 const _v3641Market=renderMarketView;
 renderMarketView=function(){const r=_v3641Market();requestAnimationFrame(v3641RefreshUX);return r};
}
if(typeof renderPortfolioView==='function'){
 const _v3641Portfolio=renderPortfolioView;
 renderPortfolioView=function(){const r=_v3641Portfolio();requestAnimationFrame(v3641RefreshUX);return r};
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v3641RefreshUX,120));
new MutationObserver(()=>requestAnimationFrame(()=>v3641DecorateAssetIcons())).observe(document.documentElement,{childList:true,subtree:true});


/* V3.6.4.2 — Chart Visual Refinement */
function v3642RefineChart(chart){
 if(!chart||!chart.data||!Array.isArray(chart.data.datasets))return;
 chart.data.datasets.forEach((ds,i)=>{
  /* Preserve the V3.6.4.1 palette; reduce only visual weight. */
  const c=(typeof v3641ChartColor==='function')?v3641ChartColor(ds.label,i):(ds.borderColor||'#35e6b2');
  ds.borderColor=c;
  ds.backgroundColor=c;
  ds.borderWidth=1.55;
  ds.pointRadius=0;
  ds.pointHoverRadius=4;
  ds.pointHitRadius=9;
  ds.pointBorderWidth=0;
  ds.tension=(typeof ds.tension==='number')?ds.tension:.18;
 });
 chart.update('none');
}
if(typeof v3641PolishChart==='function'){
 const _v3642Polish=v3641PolishChart;
 v3641PolishChart=function(chart){
  _v3642Polish(chart);
  v3642RefineChart(chart);
 };
}
function v3642RefreshCharts(){
 try{v3642RefineChart(dailyChart);v3642RefineChart(intraChart)}catch(_){}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v3642RefreshCharts,160));


/* V3.6.5 — Universal Asset Foundation */
const V365_FMT_BRL=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
async function v365LoadBrazil(){try{const [p,r]=await Promise.all([fetch('/static/data/portfolio_br_v365.json').then(x=>x.json()),fetch('/static/data/asset_registry_v365.json').then(x=>x.json())]);window.V365_BR_PORTFOLIO=p;window.V365_ASSET_REGISTRY=r;v365RenderBrazil(p,r)}catch(e){const x=document.getElementById('brPortfolioRows');if(x)x.innerHTML='<tr><td colspan="7">Falha ao carregar o registry local.</td></tr>'}}
function v365RenderBrazil(p,r){const pos=p.positions||[],principal=pos.reduce((s,x)=>s+(Number(x.principal)||0),0),actual=pos.reduce((s,x)=>s+(Number(x.current_value)||0),0);const k=document.getElementById('brKpis');if(k)k.innerHTML=[['Referência conhecida',V365_FMT_BRL.format(p.known_amount_reference_total_brl),'Não representa valor atual consolidado'],['Posições',String(pos.length),'PF + PJ'],['Principal informado',V365_FMT_BRL.format(principal),'Valores de aplicação conhecidos'],['Saldo atual informado',V365_FMT_BRL.format(actual),'Somente posições ACTUAL']].map(x=>`<div class="v365-kpi"><small>${x[0]}</small><strong>${x[1]}</strong><span>${x[2]}</span></div>`).join('');const b=document.getElementById('brPortfolioRows');if(b)b.innerHTML=pos.map(x=>{const ref=x.current_value!=null?V365_FMT_BRL.format(x.current_value):V365_FMT_BRL.format(x.principal||0);const idx=x.indexer_pct!=null?`${x.indexer} ${x.indexer_pct}%`:x.indexer;const unk=/UNKNOWN/.test((x.value_quality||'')+(x.rate_quality||''));return `<tr><td>${x.institution}</td><td>${x.name}</td><td>${x.account_type}</td><td>${x.subclass}</td><td>${ref}</td><td>${idx}</td><td><span class="v365-quality ${unk?'unknown':''}">${x.value_quality}</span></td></tr>`}).join('');const f=document.getElementById('brFamilies');if(f)f.innerHTML=(r.families||[]).map(x=>`<div class="v365-family"><b>${x.label}</b><span>${x.types.length} tipos</span></div>`).join('');const rr=document.getElementById('brRadar');if(rr)rr.innerHTML=(r.radar_seed||[]).map(x=>`<div class="v365-asset"><b>${x.symbol}</b><span>${x.name}</span></div>`).join('');const rc=document.getElementById('brRadarCount');if(rc)rc.textContent=`${(r.radar_seed||[]).length} ativos seed`}
document.addEventListener('DOMContentLoaded',v365LoadBrazil);
/* V3.6.5.1 — Brazil Route Hotfix */
const _v3651ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
  if(name!=='brazil') return _v3651ShowExperienceView(name,button);
  document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
  const view=document.getElementById('view-brazil');
  if(!view){ console.error('V3.6.5.1: view-brazil ausente'); return; }
  view.classList.add('active-view');
  (button||document.querySelector('[data-target="brazil"]'))?.classList.add('active');
  if(window.V365_BR_PORTFOLIO && window.V365_ASSET_REGISTRY){
    v365RenderBrazil(window.V365_BR_PORTFOLIO,window.V365_ASSET_REGISTRY);
    setTimeout(()=>{if(typeof v3661LoadMarketData==='function')v3661LoadMarketData()},80);
  } else {
    v365LoadBrazil();
    setTimeout(()=>{if(typeof v3661LoadMarketData==='function')v3661LoadMarketData()},300);
  }
  window.scrollTo({top:0,behavior:'smooth'});
};


/* V3.6.6.1 Live Market Data Integration */
function v3661Esc(v){return String(v??'—').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]))}
function v3661Fmt(o){if(o.value==null)return '—';return `${Number(o.value).toLocaleString('pt-BR',{maximumFractionDigits:4})} ${v3661Esc(o.unit||'')}`}
async function v3661LoadMarketData(){const box=document.getElementById('brMacroCards');try{const [m,r]=await Promise.all([fetch('/api/market-data/macro',{cache:'no-store'}).then(x=>{if(!x.ok)throw Error('macro '+x.status);return x.json()}),fetch('/api/market-data/radar',{cache:'no-store'}).then(x=>{if(!x.ok)throw Error('radar '+x.status);return x.json()})]);if(box)box.innerHTML=(m.observations||[]).map(o=>`<div class="v3661-macro-card"><div><b>${v3661Esc(o.symbol)}</b><span>${v3661Esc(o.freshness)}</span></div><strong>${v3661Fmt(o)}</strong><small>${v3661Esc(o.source)}</small><small>Observado: ${v3661Esc(o.observed_at||'indisponível')} • ${v3661Esc(o.quality)}</small></div>`).join('');if(typeof v36621RefreshRadar==='function')v36621RefreshRadar()}catch(e){if(box)box.innerHTML=`<div class="v3661-empty">Market Data indisponível • ${v3661Esc(e.message)}</div>`}}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v3661LoadMarketData,220));

/* v3662LoadAfterLegacy: market layer renders after legacy Brazil renderer. */

/* V36621_RADAR_FINAL_RENDER */
async function v36621RefreshRadar(){
  try{
    const r=await fetch('/api/market-data/radar',{cache:'no-store'}).then(x=>{if(!x.ok)throw Error('radar '+x.status);return x.json()});
    const el=document.getElementById('brRadar'), count=document.getElementById('brRadarCount');
    if(!el||!r||!Array.isArray(r.assets))return;
    el.innerHTML=r.assets.map(x=>{
      const hasPrice=x.price!==null&&x.price!==undefined;
      const p=hasPrice?new Intl.NumberFormat('pt-BR',{style:'currency',currency:x.currency||'BRL'}).format(x.price):'—';
      const c=(x.change_pct===null||x.change_pct===undefined)?'—':`${Number(x.change_pct)>=0?'+':''}${Number(x.change_pct).toFixed(2)}%`;
      return `<div class="v365-asset v36632-radar-card" title="${v3661Esc((x.status||'PROVIDER_PENDING')+' · '+(x.quality||'')+(x.note?' · '+x.note:''))}"><div class="v36632-head"><b>${v3661Esc(x.symbol)}</b><span>${v3661Esc(x.family||'')}</span></div><div class="v36632-price">${v3661Esc(p)}</div><div class="v36632-change ${Number(x.change_pct)>0?'up':Number(x.change_pct)<0?'down':'flat'}">${hasPrice?v3661Esc(c):'Cotação indisponível'}</div><div class="v36632-meta"><span class="v36632-dot ${String(x.freshness||'').toLowerCase()}"></span><b>${v3661Esc(x.freshness||'UNAVAILABLE')}</b><span>${v3661Esc(x.source||'provider pendente')}</span></div></div>`;
    }).join('');
    if(count)count.textContent=`${r.assets.length} ativos · Market Data`;
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v36621RefreshRadar,700));

/* V3678_FIXED_INCOME_UI */
const V3678_BRL=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
function v3678Name(c){return c?.identity?.name||c?.identity?.position_id||'—'}
function v3678Inst(c){return c?.identity?.institution||'—'}
function v3678Map(cs){const m={};(cs||[]).forEach(c=>m[c?.identity?.position_id]=c);return m}
function v3678Render(data){
 const cs=data.contracts||[],ds=data.decisions||[],map=v3678Map(cs),state=document.getElementById('fiEngineState'),sum=document.getElementById('fiSummary'),pos=document.getElementById('fiPositions'),opp=document.getElementById('fiOpportunities');
 if(state)state.textContent='motor conectado';
 const amount=c=>Number(c?.valuation?.current_value)||Number(c?.valuation?.principal)||0;
 const known=cs.reduce((n,c)=>n+amount(c),0),inst={};cs.forEach(c=>inst[v3678Inst(c)]=(inst[v3678Inst(c)]||0)+amount(c));
 const top=Object.entries(inst).sort((a,b)=>b[1]-a[1])[0];
 if(sum)sum.innerHTML=[['Contratos',cs.length,'renda fixa'],['Referência conhecida',V3678_BRL.format(known),'current value, senão principal'],['Maior instituição',top?top[0]:'—',top&&known?(top[1]/known*100).toFixed(1)+'%':'—'],['Learning',(data.learning?.observations||0)+' observações',(data.learning?.outcomes||0)+' outcomes']].map(x=>`<div class="v3678-kpi"><small>${v3661Esc(x[0])}</small><strong>${v3661Esc(x[1])}</strong><span>${v3661Esc(x[2])}</span></div>`).join('');
 if(pos)pos.innerHTML=cs.map(c=>{const y=c?.yield||{},ev=c?.evidence||{},pct=y?.benchmark_pct;return `<div class="v3678-position"><div><b>${v3661Esc(v3678Name(c))}</b><span>${v3661Esc(v3678Inst(c))} • ${v3661Esc(c?.identity?.account_type||'—')}</span></div><strong>${V3678_BRL.format(amount(c))}</strong><small>${v3661Esc(y?.indexer||'UNKNOWN')}${pct!=null?' '+v3661Esc(pct)+'%':''}</small><em>${v3661Esc(ev.level||ev.status||'UNKNOWN')}</em></div>`}).join('');
 const ranked=ds.filter(d=>d.economic_advantage_brl!=null).sort((a,b)=>Number(b.economic_advantage_brl)-Number(a.economic_advantage_brl)).slice(0,8);
 if(opp)opp.innerHTML=ranked.map(d=>{const act=d.action||'MANTENHA',cls=act==='COMPRE'?'buy':act==='VENDA_RESGATE'?'sell':'hold',label=act==='VENDA_RESGATE'?'VENDA / RESGATE':act,blocks=d.blockers||[];return `<div class="v3678-opportunity"><div class="v3678-op-head"><div><small>${v3661Esc(v3678Name(map[d.current_position_id]))} →</small><b>${v3661Esc(v3678Name(map[d.candidate_position_id]))}</b></div><span class="v3678-action ${cls}">${v3661Esc(label)}</span></div><div class="v3678-op-metrics"><span>Vantagem <b>${V3678_BRL.format(Number(d.economic_advantage_brl)||0)}</b></span><span>Retorno <b>${Number(d.economic_advantage_pct_points||0).toFixed(2)} p.p.</b></span><span>Confiança <b>${v3661Esc(d.confidence?.level||'—')}</b></span></div><p>${blocks.length?'Bloqueios: '+v3661Esc(blocks.join(' • ')):'Sem bloqueios declarados pelo motor.'}</p></div>`}).join('')||'<div class="v3661-empty">Nenhuma comparação calculável no momento.</div>';
}
async function v3678LoadFixedIncome(){const state=document.getElementById('fiEngineState');if(!state)return;try{const r=await fetch('/api/fixed-income/intelligence',{cache:'no-store'});if(!r.ok)throw Error('fixed-income '+r.status);v3678Render(await r.json())}catch(e){state.textContent='indisponível';const x=document.getElementById('fiOpportunities');if(x)x.innerHTML=`<div class="v3661-empty">Inteligência indisponível • ${v3661Esc(e.message)}</div>`}}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v3678LoadFixedIncome,850));

/* V36781_UI_DATA_COHERENCE */
function v36781Amount(c){
 const cv=Number(c?.valuation?.current_value);
 if(Number.isFinite(cv)&&cv>0)return cv;
 const p=Number(c?.principal?.amount);
 return Number.isFinite(p)?p:0;
}
function v36781Evidence(c){
 const y=c?.yield||{};
 if(y.evidence_level)return y.evidence_level;
 if(y.rate_quality==='USER_CONFIRMED')return 'CONFIRMED';
 if(y.rate_quality==='WEB_CURRENT_NEEDS_CONTRACT_CONFIRMATION')return 'REFERENCE';
 if(y.rate_quality==='PRODUCT_DEFINED')return 'PRODUCT_DEFINED';
 return 'UNKNOWN';
}
function v36781Canonical(ds){
 const seen=new Set(),out=[];
 for(const d of (ds||[])){
   const a=d.current_position_id,b=d.candidate_position_id;
   if(!a||!b)continue;
   const key=[a,b].sort().join('::');
   if(seen.has(key))continue;
   seen.add(key);
   const rev=(ds||[]).find(x=>x.current_position_id===b&&x.candidate_position_id===a);
   let pick=d;
   const dv=Number(d.economic_advantage_brl),rv=Number(rev?.economic_advantage_brl);
   if(rev && Number.isFinite(rv) && (!Number.isFinite(dv) || rv>dv))pick=rev;
   out.push(pick);
 }
 return out;
}
const v3678RenderBase=v3678Render;
v3678Render=function(data){
 const cs=data.contracts||[],ds=v36781Canonical(data.decisions||[]),map=v3678Map(cs);
 const state=document.getElementById('fiEngineState'),sum=document.getElementById('fiSummary'),pos=document.getElementById('fiPositions'),opp=document.getElementById('fiOpportunities');
 if(state)state.textContent='motor conectado';
 const known=cs.reduce((n,c)=>n+v36781Amount(c),0),inst={};
 cs.forEach(c=>inst[v3678Inst(c)]=(inst[v3678Inst(c)]||0)+v36781Amount(c));
 const top=Object.entries(inst).sort((a,b)=>b[1]-a[1])[0];
 if(sum)sum.innerHTML=[['Contratos',cs.length,'renda fixa'],['Referência conhecida',V3678_BRL.format(known),'valor atual, senão principal'],['Maior instituição',top?top[0]:'—',top&&known?(top[1]/known*100).toFixed(2)+'%':'—'],['Learning',(data.learning?.observations||0)+' observações',(data.learning?.outcomes||0)+' outcomes']].map(x=>`<div class="v3678-kpi"><small>${v3661Esc(x[0])}</small><strong>${v3661Esc(x[1])}</strong><span>${v3661Esc(x[2])}</span></div>`).join('');
 if(pos)pos.innerHTML=cs.map(c=>{const y=c?.yield||{},pct=y?.benchmark_pct;return `<div class="v3678-position"><div><b>${v3661Esc(v3678Name(c))}</b><span>${v3661Esc(v3678Inst(c))} • ${v3661Esc(c?.identity?.account_type||'—')}</span></div><strong>${V3678_BRL.format(v36781Amount(c))}</strong><small>${v3661Esc(y?.indexer||'UNKNOWN')}${pct!=null?' '+v3661Esc(pct)+'%':''}</small><em>${v3661Esc(v36781Evidence(c))}</em></div>`}).join('');
 const ranked=ds.filter(d=>d.economic_advantage_brl!=null).sort((a,b)=>Number(b.economic_advantage_brl)-Number(a.economic_advantage_brl)).slice(0,8);
 if(opp)opp.innerHTML=ranked.map(d=>{const act=d.action||'MANTENHA',cls=act==='COMPRE'?'buy':act==='VENDA_RESGATE'?'sell':'hold',label=act==='VENDA_RESGATE'?'VENDA / RESGATE':act,blocks=d.blockers||[];return `<div class="v3678-opportunity"><div class="v3678-op-head"><div><small>${v3661Esc(v3678Name(map[d.current_position_id]))} →</small><b>${v3661Esc(v3678Name(map[d.candidate_position_id]))}</b></div><span class="v3678-action ${cls}">${v3661Esc(label)}</span></div><div class="v3678-op-metrics"><span>Vantagem <b>${V3678_BRL.format(Number(d.economic_advantage_brl)||0)}</b></span><span>Retorno <b>${Number(d.economic_advantage_pct_points||0).toFixed(2)} p.p.</b></span><span>Confiança <b>${v3661Esc(d.confidence?.level||'—')}</b></span></div><p>${blocks.length?'Bloqueios: '+v3661Esc(blocks.join(' • ')):'Sem bloqueios declarados pelo motor.'}</p></div>`}).join('')||'<div class="v3661-empty">Nenhuma comparação calculável no momento.</div>';
}



/* V3710_EQUITY_UI */
const V3710_BRL=new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'});
function v3710Assets(doc){const a=doc?.assets;return Array.isArray(a)?Object.fromEntries(a.map(x=>[x?.identity?.symbol||x?.symbol,x]).filter(x=>x[0])):(a||{})}
function v3710ActionClass(a){return a==='COMPRE'?'buy':a==='VENDA'?'sell':a==='MANTENHA'?'hold':'watch'}
function v3710Pct(v){const n=Number(v);return Number.isFinite(n)?`${Math.round(n*100)}%`:'—'}
function v3710Score(v){const n=Number(v);return Number.isFinite(n)?`${n>=0?'+':''}${n.toFixed(3)}`:'—'}
function v3710Render(data){
 const state=$('eqEngineState'),sum=$('eqSummary'),box=$('eqDecisions');
 if(!state||!sum||!box)return;
 const ds=data?.decisions?.decisions||[],opp=v3710Assets(data?.opportunity),market=v3710Assets(data?.market);
 const learn=data?.learning?.summary||{},port=data?.portfolio?.equity_portfolio||{};
 const counts={COMPRE:0,MANTENHA:0,ACOMPANHE:0,VENDA:0};ds.forEach(d=>{if(counts[d.action]!=null)counts[d.action]++});
 state.textContent='motor conectado';
 sum.innerHTML=[
  ['Universo',String(ds.length),'ações • ETFs • BDRs'],
  ['COMPRE',String(counts.COMPRE),'evidência decisória atual'],
  ['Carteira',port.status==='EMPTY'?'Sem posições':`${(port.positions||[]).length} posições`,'sleeve de equities'],
  ['Learning',String(learn.observations||0),`${learn.observed_outcomes||0} outcomes observados`]
 ].map(x=>`<div class="v3710-kpi"><small>${esc(x[0])}</small><b>${esc(x[1])}</b><span>${esc(x[2])}</span></div>`).join('');
 const ranked=[...ds].sort((a,b)=>Number(b.opportunity_score??-99)-Number(a.opportunity_score??-99));
 box.innerHTML=`<div class="v3710-table-wrap"><table class="v3710-table"><thead><tr><th>Ativo</th><th>Decisão</th><th>Score</th><th>Evidência</th><th>Confidence</th><th>Posição</th><th>Execução</th></tr></thead><tbody>${
  ranked.map(d=>`<tr class="v3710-row" onclick="v3710OpenAsset('${esc(d.symbol)}')"><td><b>${esc(d.symbol)}</b></td><td><span class="v3710-action ${v3710ActionClass(d.action)}">${esc(d.action)}</span></td><td>${esc(v3710Score(d.opportunity_score))}</td><td>${esc(v3710Pct(d.evidence_quality))}</td><td>${esc(d.confidence?.level||'—')}</td><td>${d.has_position?'SIM':'NÃO'}</td><td>${esc(d.execution||'MANUAL_ONLY')}</td></tr>`).join('')
 }</tbody></table></div>`;
 window.V3710_EQUITY_DATA=data;
}
function v3710OpenAsset(symbol){
 const data=window.V3710_EQUITY_DATA||{},ds=data?.decisions?.decisions||[],d=ds.find(x=>x.symbol===symbol)||{};
 const opp=v3710Assets(data?.opportunity)[symbol]||{},fund=v3710Assets(data?.fundamentals)[symbol]||{},tech=v3710Assets(data?.technical)[symbol]||{},risk=v3710Assets(data?.risk_regime)[symbol]||{};
 const metrics=fund.metrics||{};
 const metric=(k)=>metrics[k]?.value==null?'—':fmt(metrics[k].value,2);
 const html=`<div class="v3710-detail">
  <div class="v3710-detail-hero"><div><small>DECISÃO</small><h2>${esc(symbol)}</h2></div><span class="v3710-action ${v3710ActionClass(d.action)}">${esc(d.action||'—')}</span></div>
  <div class="v3710-detail-grid">
   <div><small>Opportunity score</small><b>${esc(v3710Score(d.opportunity_score))}</b></div>
   <div><small>Evidência</small><b>${esc(v3710Pct(d.evidence_quality))}</b></div>
   <div><small>Confidence</small><b>${esc(d.confidence?.level||'—')}</b></div>
   <div><small>Execução</small><b>${esc(d.execution||'MANUAL_ONLY')}</b></div>
  </div>
  <div class="v3710-detail-cols">
   <section><b>Fundamental</b><p>Coverage: ${esc(fund.coverage||'—')}</p><p>P/E: ${esc(metric('trailingPE'))} • P/B: ${esc(metric('priceToBook'))}</p><p>ROE: ${esc(metric('returnOnEquity'))} • Margem: ${esc(metric('profitMargins'))}</p></section>
   <section><b>Opportunity</b><p>${esc(opp.opportunity_state||'—')}</p><p>Componentes: ${esc((opp.available_components||[]).join(', ')||'—')}</p></section>
   <section><b>Risco & técnico</b><p>Risk snapshot: ${risk&&Object.keys(risk).length?'disponível':'—'}</p><p>Technical snapshot: ${tech&&Object.keys(tech).length?'disponível':'—'}</p></section>
  </div>
  <p class="v365-note">A decisão é produzida pelo Equity Decision Engine. Confidence mede qualidade da evidência. Nenhuma ordem é executada por esta tela.</p>
 </div>`;
 openModal(`Ações & ETFs • ${symbol}`,html);
}
async function v3710LoadEquities(){
 const state=$('eqEngineState');if(!state)return;
 try{const r=await fetch('/api/equities/intelligence',{cache:'no-store'});if(!r.ok)throw Error('equities '+r.status);v3710Render(await r.json())}
 catch(e){state.textContent='indisponível';const b=$('eqDecisions');if(b)b.innerHTML='<div class="muted">Equity Intelligence indisponível.</div>'}
}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v3710LoadEquities,950));


/* PORQUINHO V3.8.0.14 — FINANCIAL IMPORT UI */
let FIUI_SESSION=null, FIUI_REVIEW=null;
const _fiuiShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
 if(name==='financial-import'){
  document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
  $('view-financial-import')?.classList.add('active-view');
  (button||document.querySelector('[data-target="financial-import"]'))?.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'}); return;
 }
 return _fiuiShowExperienceView(name,button);
};
function fiuiEsc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function fiuiToken(){const el=$('fiuiToken');return String(el?.value||'').trim()}
function fiuiHeaders(json=false){const t=fiuiToken();const h={'X-Bridge-Token':t};if(json)h['Content-Type']='application/json';return h}
function fiuiStatus(msg,bad=false){const e=$('fiuiState');if(e){e.textContent=msg;e.classList.toggle('fiui-error',!!bad)}}
function fiuiClear(){FIUI_SESSION=null;FIUI_REVIEW=null;if($('fiuiFile'))$('fiuiFile').value='';if($('fiuiInstitution'))$('fiuiInstitution').value='';if($('fiuiToken'))$('fiuiToken').value='';if($('fiuiSummary'))$('fiuiSummary').innerHTML='';if($('fiuiResults'))$('fiuiResults').innerHTML='<div class="muted">Nenhuma revisão carregada.</div>';fiuiStatus('Sessão local limpa.')}
function fiuiReviewItems(r){return r?.items||r?.review?.items||[]}
function fiuiCandidates(r){return r?.candidates||r?.review?.candidates||[]}
function fiuiReconClass(x){return String(x?.reconciliation_status||x?.classification||x?.status||'UNRESOLVED').toUpperCase()}
function fiuiReviewStatus(x){return String(x?.review_status||'').toUpperCase()}
function fiuiCandidate(x){return x?.candidate_id||x?.import_candidate?.candidate_id||null}
function fiuiRender(r){
 FIUI_REVIEW=r;
 const items=fiuiReviewItems(r), candidates=fiuiCandidates(r), byCandidate=new Map(candidates.map(c=>[String(c?.candidate_id||''),c]));
 const counts={};items.forEach(x=>{const k=fiuiReconClass(x);counts[k]=(counts[k]||0)+1});
 if($('fiuiSummary'))$('fiuiSummary').innerHTML=['NEW','MATCHED','DUPLICATE','CONFLICT','UNRESOLVED'].map(k=>`<div class="v3710-kpi"><small>${k}</small><b>${counts[k]||0}</b><span>${k==='NEW'?'candidatos':'revisão'}</span></div>`).join('');
 if(!items.length){$('fiuiResults').innerHTML='<div class="muted">Revisão criada, mas nenhum item foi retornado.</div>';return}
 $('fiuiResults').innerHTML=items.map(x=>{
  const k=fiuiReconClass(x), reviewStatus=fiuiReviewStatus(x), cid=fiuiCandidate(x), candidate=cid?byCandidate.get(String(cid)):null, tx=candidate||x.transaction||x.normalized_transaction||x;
  const desc=tx.memo||tx.name||tx.description||tx.payee||'Transação';
  const amt=tx.amount??tx.value??'—', currency=tx.currency?` ${tx.currency}`:'';
  const date=tx.date||tx.posted_at||tx.datetime||'—', txType=tx.transaction_type||tx.raw_type||'';
  const can=k==='NEW'&&reviewStatus==='IMPORT_CANDIDATE'&&cid&&candidate;
  const reviewBadge=reviewStatus&&reviewStatus!==k?`<span class="fiui-badge review-status">${fiuiEsc(reviewStatus)}</span>`:'';
  const detail=`${fiuiEsc(date)} • ${fiuiEsc(amt)}${fiuiEsc(currency)}${txType?` • ${fiuiEsc(txType)}`:''}`;
  return `<div class="fiui-row"><div><span class="fiui-badge ${k.toLowerCase()}">${fiuiEsc(k)}</span>${reviewBadge}<b>${fiuiEsc(desc)}</b><small>${detail}</small></div><div>${can?`<button onclick="fiuiApprove('${fiuiEsc(cid)}')">Aprovar importação</button>`:'<span class="fiui-locked">Sem commit</span>'}</div></div>`
 }).join('');
}
async function fiuiAnalyze(){
 const file=$('fiuiFile')?.files?.[0];if(!file){fiuiStatus('Selecione um arquivo OFX.',true);return}if(!fiuiToken()){fiuiStatus('Informe o Bridge token para autenticar a chamada.',true);return}
 const fd=new FormData();fd.append('file',file);fd.append('institution_hint',$('fiuiInstitution')?.value||'');fiuiStatus('Analisando…');
 try{const res=await fetch('/api/financial-import/v1/ofx/review',{method:'POST',headers:fiuiHeaders(false),body:fd});const data=await res.json();if(!res.ok)throw Error(data.message||data.error||('HTTP '+res.status));FIUI_SESSION=data.session_id||data.review_session_id||data.id;if(!FIUI_SESSION)throw Error('Sessão de revisão não retornada pelo backend.');fiuiRender(data);fiuiStatus('Revisão criada. Nenhuma transação foi importada automaticamente.')}catch(e){fiuiStatus('Falha: '+e.message,true)}
}
async function fiuiApprove(candidateId){
 if(!FIUI_SESSION||!candidateId)return;if(!confirm('Aprovar explicitamente a importação desta transação para o ledger?'))return;
 try{const res=await fetch(`/api/financial-import/v1/review/${encodeURIComponent(FIUI_SESSION)}/approve`,{method:'POST',headers:fiuiHeaders(true),body:JSON.stringify({candidate_id:candidateId,approval:true})});const data=await res.json();if(!res.ok)throw Error(data.error||('HTTP '+res.status));fiuiStatus('Commit controlado concluído. Atualizando revisão…');const rr=await fetch(`/api/financial-import/v1/review/${encodeURIComponent(FIUI_SESSION)}`,{headers:fiuiHeaders(false),cache:'no-store'});const rd=await rr.json();if(rr.ok)fiuiRender(rd);else fiuiStatus('Commit concluído; não foi possível recarregar a revisão.',true)}catch(e){fiuiStatus('Commit rejeitado: '+e.message,true)}
}
/* V3.8.9.4.1 */
async function v38941EditPosition(asset){try{const j=await jsonFetch('/api/portfolio/position/'+encodeURIComponent(asset)),p=j.position||{};openModal('Editar posição • '+esc(asset),`<div style="display:grid;gap:10px"><div class="muted">Registro manual. Nenhuma ordem será enviada à corretora.</div><label>Operação<select id="peMode" onchange="v38941Mode()"><option value="REALIZE">Registrar realização/venda</option><option value="ADJUST">Ajustar posição</option></select></label><div id="peRealize"><label>Percentual realizado<input id="pePct" type="number" min=".01" max="100" step=".01" value="25"></label><label>Valor recebido (€), opcional<input id="peProceeds" type="number" min="0" step=".01"></label><label>Taxa (€)<input id="peFee" type="number" min="0" step=".01" value="0"></label><p class="muted">Atual: ${esc(p.quantity)} unidades • custo € ${esc(p.amount_eur)}</p></div><div id="peAdjust" style="display:none"><label>Quantidade restante<input id="peQty" type="number" step="any" value="${esc(p.quantity)}"></label><label>Custo restante (€)<input id="peCost" type="number" step=".01" value="${esc(p.amount_eur)}"></label><label>Conta<input id="peAccount" value="${esc(p.account||'N/A')}"></label></div><button onclick="v38941Save('${asset}')">Confirmar alteração manual</button></div>`)}catch(e){toast(e.message)}}
function v38941Mode(){let m=$('peMode').value;$('peRealize').style.display=m==='REALIZE'?'block':'none';$('peAdjust').style.display=m==='ADJUST'?'block':'none'}
async function v38941Save(asset){let m=$('peMode').value,s=((lastStatus||{}).portfolio?.scores||[]).find(x=>x.asset===asset)||{},b=m==='REALIZE'?{asset,mode:m,percent:Number($('pePct').value),proceeds_eur:$('peProceeds').value,fee_eur:$('peFee').value,suggested_action:s.action||null,suggested_percent:Number($('pePct').value)}:{asset,mode:m,quantity:Number($('peQty').value),amount_eur:Number($('peCost').value),account:$('peAccount').value};try{await jsonFetch('/api/portfolio/position',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});closeModal();toast('Carteira atualizada.');await refreshNow()}catch(e){toast(e.message)}}
/* V3.8.9.4.1-r1 — complete values + preview confirmation */
async function v38941EditPosition(asset){
 try{
  const j=await jsonFetch('/api/portfolio/position/'+encodeURIComponent(asset)),p=j.position||{};
  const s=((lastStatus||{}).portfolio?.scores||[]).find(x=>String(x.asset).toUpperCase()===String(asset).toUpperCase())||{};
  const suggested=Number(s.execution_fraction_pct||s.realize_fraction_pct||s.realize_pct||25);
  openModal('Editar posição • '+esc(asset),`<div style="display:grid;gap:10px">
   <div class="muted">Registro manual. Nenhuma ordem será enviada à corretora.</div>
   <label>Operação<select id="peMode" onchange="v38941Mode()"><option value="REALIZE">Registrar realização/venda</option><option value="ADJUST">Ajustar posição</option></select></label>
   <div id="peRealize">
    <label>Percentual realizado<input id="pePct" type="number" min=".01" max="100" step=".01" value="${suggested}"></label>
    <label>Valor bruto recebido (€)<input id="peProceeds" type="number" min="0" step=".01" placeholder="Obrigatório"></label>
    <label>Taxa da venda (€)<input id="peFee" type="number" min="0" step=".01" placeholder="0 se não houve"></label>
    <p class="muted">Atual: ${esc(p.quantity)} unidades • custo contabilizado € ${esc(p.amount_eur)}</p>
   </div>
   <div id="peAdjust" style="display:none">
    <label>Quantidade restante<input id="peQty" type="number" step="any" value="${esc(p.quantity)}"></label>
    <label>Custo restante (€)<input id="peCost" type="number" step=".01" value="${esc(p.amount_eur)}"></label>
    <label>Conta<input id="peAccount" value="${esc(p.account||'N/A')}"></label>
   </div>
   <button onclick="v38941Preview('${asset}')">Revisar antes de confirmar</button>
  </div>`);
 }catch(e){toast(e.message)}
}
function v38941Mode(){let m=$('peMode').value;$('peRealize').style.display=m==='REALIZE'?'block':'none';$('peAdjust').style.display=m==='ADJUST'?'block':'none'}
async function v38941Preview(asset){
 const mode=$('peMode').value;
 if(mode==='ADJUST'){return v38941ConfirmAdjust(asset)}
 const pct=Number($('pePct').value),pro=$('peProceeds').value,fee=$('peFee').value;
 if(!(pct>0&&pct<=100)){toast('Informe um percentual válido.');return}
 if(pro===''||fee===''){toast('Preencha valor recebido e taxa (0 se não houve).');return}
 const j=await jsonFetch('/api/portfolio/position/'+encodeURIComponent(asset)),p=j.position||{};
 const q=Number(p.quantity),c=Number(p.amount_eur),sold=q*pct/100,remain=q-sold,remainCost=c*(1-pct/100),net=Number(pro)-Number(fee);
 openModal('Confirmar realização • '+esc(asset),`<div style="display:grid;gap:9px">
  <b>Confira antes de preparar a revisão</b>
  <div>Realização: <b>${pct.toFixed(2)}%</b></div>
  <div>Quantidade vendida: <b>${sold.toFixed(8)}</b> ${esc(asset)}</div>
  <div>Quantidade restante: <b>${remain.toFixed(8)}</b> ${esc(asset)}</div>
  <div>Custo restante: <b>€ ${remainCost.toFixed(2)}</b></div>
  <div>Recebido bruto: <b>€ ${Number(pro).toFixed(2)}</b></div>
  <div>Taxa: <b>€ ${Number(fee).toFixed(2)}</b></div>
  <div>Recebido líquido: <b>€ ${net.toFixed(2)}</b></div>
  <div class="muted">Ao continuar, será preparada uma revisão governada. Nenhuma posição será alterada, nenhuma transação será gravada no ledger e o alerta permanecerá ativo.</div>
  <div style="display:flex;gap:8px"><button onclick="v38941EditPosition('${asset}')">Voltar</button><button onclick="v38941CommitRealize('${asset}',${pct},${Number(pro)},${Number(fee)})">Preparar revisão</button></div>
 </div>`);
}
async function v38941CommitRealize(asset,pct,pro,fee){
 const s=((lastStatus||{}).portfolio?.scores||[]).find(x=>String(x.asset).toUpperCase()===String(asset).toUpperCase())||{};
 try{
   const j=await jsonFetch('/api/portfolio/position',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset,mode:'REALIZE',percent:pct,proceeds_eur:pro,fee_eur:fee,suggested_action:s.action||'REALIZE',suggested_percent:pct})});
   if(j.status!=='REVIEW_REQUIRED'||j.commit_ready!==false||j.explicit_approval_received!==false||j.ledger_append!==false||j.portfolio_csv_write!==false||!j.session_id||!j.sell_candidate_id){
     throw new Error('Resposta de revisão governada inesperada.');
   }
   openModal('Aprovar revisão • '+esc(asset),`<div style="display:grid;gap:9px">
    <b>Realização preparada para revisão</b>
    <div>Ativo: <b>${esc(asset)}</b></div>
    <div>Revisão SELL: <code>${esc(String(j.sell_review_sha256||''))}</code></div>
    ${j.fee_candidate_id?`<div>Revisão FEE separada: <code>${esc(String(j.fee_review_sha256||''))}</code></div>`:''}
    <div class="muted">Aprovar agora registra somente sua aprovação explícita sobre esta revisão preparada no servidor. Ainda não cria plano de commit, não grava no ledger, nenhuma posição foi alterada e o alerta permanece ativo.</div>
    <div style="display:flex;gap:8px"><button onclick="closeModal()">Cancelar</button><button onclick="v38941ApproveRealize('${asset}','${j.session_id}','${j.sell_candidate_id}','${j.fee_candidate_id||''}')">Aprovar revisão</button></div>
   </div>`);
 }catch(e){toast(e.message)}
}
async function v38941ApproveRealize(asset,sessionId,sellCandidateId,feeCandidateId){
 try{
   const body={approval:true,sell_candidate_id:sellCandidateId,fee_candidate_id:feeCandidateId||null};
   const j=await jsonFetch('/api/portfolio/position/review/'+encodeURIComponent(sessionId)+'/approve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
   if(j.status!=='COMMIT_PLAN_READY'||j.explicit_approval_received!==true||j.commit_ready!==false||j.commit_plan_created!==true||!j.sell_plan_sha256||(j.fee_approval_sha256&&!j.fee_plan_sha256)||j.ledger_append!==false||j.alerts_acknowledged!==0||j.canonical_real_ledger_authorized!==false){
     throw new Error('Resposta de aprovação governada inesperada.');
   }
   openModal('Confirmar registro da venda • '+esc(asset),`<div style="display:grid;gap:9px">
     <b>Revisão aprovada e plano governado preparado.</b>
     <div class="muted">A próxima confirmação registra no ledger a venda que você já executou externamente. Nenhuma ordem será enviada à corretora.</div>
     <div class="muted">Os fatos financeiros já estão vinculados à revisão aprovada e não serão reenviados pelo navegador.</div>
     <div style="display:flex;gap:8px"><button onclick="closeModal()">Cancelar</button><button onclick="v38941ExecuteApprovedRealize('${asset}','${sessionId}')">Confirmar registro da venda</button></div>
   </div>`);
 }catch(e){toast(e.message)}
}

async function v38941ExecuteApprovedRealize(asset,sessionId){
 try{
   const j=await jsonFetch('/api/portfolio/position/review/'+encodeURIComponent(sessionId)+'/execute',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({confirmation:true})});
   if(j.status!=='COMPLETED'||j.all_required_commits_ok!==true||!j.sell_event_id){
     throw new Error('Registro governado não foi concluído.');
   }
   closeModal();
   toast('Venda registrada no ledger com sucesso • nenhuma ordem foi enviada à corretora.');
   await loadStatus(true);
 }catch(e){toast(e.message)}
}

async function v38941ConfirmAdjust(asset){
 toast('Ajuste de posição temporariamente indisponível: requer fluxo próprio de reconciliação, sem converter ajuste em compra.');
}
/* V3.8.9.4.1-r2 */
const _v38941r2ActionBadgeBase = v366252ActionBadge;
v366252ActionBadge = function(s){
 if(s && s.execution_acknowledged && s.execution_ack_scope==='CURRENT_SIGNAL_INSTANCE' && s.action==='REALIZE'){
   return `<span class="pill">REALIZADO ✓</span><div class="muted" style="font-size:9px;margin-top:3px">${esc(s.display_note||'Realização executada; aguardando novo sinal.')}</div>`;
 }
 return _v38941r2ActionBadgeBase(s);
};

/* V3.8.13.0 — Experience Foundation */
const V38130_ASSET_ICON={BTC:'₿',ETH:'◆',SOL:'≋',BNB:'◆',AAVE:'A',HYPE:'H',LINK:'⬡',AVAX:'▲',MATIC:'⬡',ATOM:'✦'};
function v38130AssetIcon(a){a=String(a||'').toUpperCase();return `<span class="v38130-coin v38130-${esc(a)}">${esc(V38130_ASSET_ICON[a]||a.slice(0,1)||'?')}</span>`}
function v38130Help(t){return `<span class="v38130-help" title="${esc(t)}">?</span>`}

// V381310_LEARNING_BRAIN_COCKPIT
function v381310FmtDate(v){if(!v)return '—';try{return new Date(v).toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}catch(e){return String(v)}}
function v381310Help(title,text){return `<span class="v381310-help" title="${esc(text)}" aria-label="${esc(title+': '+text)}">?</span>`}
function v381310Action(e){const a=String(e.brain_action||'—');return a+(e.experimental?'*':'')}
async function v381310Learning(){
 v38130Placeholder('Aprendizado / Brain','Episódios de decisão, divergências experimentais e maturação longitudinal — observação, não execução.',`<div id="v381310Learning"><article class="card"><div class="card-head"><b>Carregando aprendizado…</b><span>somente leitura</span></div></article></div>`);
 const host=$('v381310Learning'); if(!host)return;
 try{
  const d=await jsonFetch('/api/experience/learning'); if(d.state!=='OK')throw new Error(d.error||'estado indisponível');
  const eps=d.episodes||[], out=d.outcomes||{}, oe=out.episodes||[];
  const hcount=oe.reduce((n,e)=>n+(e.horizons||[]).length,0), matured=Number(out.matured_horizon_count||0), pending=Math.max(0,hcount-matured);
  const byAsset={}; eps.forEach(e=>(byAsset[e.asset]||(byAsset[e.asset]=[])).push(e));
  const transitions=Object.entries(byAsset).filter(([a,v])=>v.length>1).flatMap(([a,v])=>{v=v.sort((x,y)=>String(x.started_at).localeCompare(String(y.started_at)));return v.slice(1).map((e,i)=>({asset:a,from:v[i],to:e}))}).sort((a,b)=>String(b.to.started_at).localeCompare(String(a.to.started_at)));
  const rows=eps.slice(0,60).map(e=>`<tr><td><b>${esc(e.asset||'—')}</b></td><td>${v381310FmtDate(e.started_at)}</td><td>${esc(e.production_action||'—')}</td><td class="${e.experimental?'v381310-exp':''}">${esc(v381310Action(e))}</td><td>${esc(e.evidence_status||'—')}</td><td>${Number(e.observation_count||0)}</td><td>${esc(e.outcome_status||'PENDING')}</td></tr>`).join('');
  const trans=transitions.length?transitions.map(t=>`<div class="v381310-transition"><b>${esc(t.asset)}</b><span>${esc(v381310Action(t.from))} → <strong>${esc(v381310Action(t.to))}</strong></span><small>${v381310FmtDate(t.to.started_at)} • Motor: ${esc(t.to.production_action||'—')}</small></div>`).join(''):'<div class="v381310-empty">Nenhuma mudança de estado entre episódios ainda.</div>';
  host.innerHTML=`<section class="v381310-kpis"><div><small>EPISÓDIOS</small><b>${eps.length}</b><span>${d.distinct_assets||0} ativos</span></div><div><small>PARIDADE</small><b>${d.parity_episode_count||0}</b><span>Brain = Motor</span></div><div><small>EXPERIMENTAIS</small><b>${d.experimental_episode_count||0}</b><span>divergências registradas*</span></div><div><small>AVALIAÇÕES FUTURAS</small><b>${hcount}</b><span>${pending} pendentes • ${matured} maturadas</span></div></section>
  <section class="v381310-grid"><article class="card"><div class="card-head"><b>Transições de decisão</b><span>novo episódio quando o estado muda</span></div>${trans}</article><article class="card"><div class="card-head"><b>Contrato de aprendizado</b><span>governança</span></div><div class="v381310-contract"><p><b>* Experimental</b>${v381310Help('Experimental','O asterisco indica evidência ainda não consolidada. Não representa probabilidade nem ordem automática.')}</p><p><b>Confidence</b>${v381310Help('Confidence','Qualidade da evidência disponível; não é probabilidade de acerto.')}</p><p><b>Horizontes</b><span>30 • 60 • 90 • 180 dias</span></p><p><b>Maturação</b><span>primeira observação válida no/apos vencimento, dentro da janela contratada</span></p><p><b>Execução</b><span>MANUAL_ONLY</span></p><p><b>Promoção automática</b><span>${d.automatic_promotion?'ATIVA':'DESATIVADA'}</span></p></div></article></section>
  <article class="card v381310-tablecard"><div class="card-head"><b>Histórico de episódios</b><span>evidência longitudinal • mais recentes primeiro</span></div><div class="table-wrap"><table class="v381310-table"><thead><tr><th>Ativo</th><th>Início</th><th>Motor</th><th>Brain</th><th>Evidência</th><th>Obs.</th><th>Outcome</th></tr></thead><tbody>${rows}</tbody></table></div></article><div class="v381310-note">Esta tela é observacional. Sinais com * usam evidência não consolidada; não alteram a ação operacional, pesos, thresholds, carteira ou ledger e não executam ordens.</div>`;
 }catch(e){if(host)host.innerHTML=`<article class="card"><div class="card-head"><b>Aprendizado indisponível</b><span>fail closed</span></div><p class="muted">${esc(e.message)}</p></article>`}
}

function v38130Placeholder(title,desc,body){document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));$('view-placeholder').classList.add('active-view');$('viewTitle').textContent=title;$('viewDescription').textContent=desc;$('viewContent').innerHTML=body;window.scrollTo({top:0,behavior:'smooth'})}
function v38130Analytics(){
 const p=(lastStatus||{}).portfolio||{},rows=p.scores||[];
 v38130Placeholder('Analytics','Resultados visuais do Porquinho. Todos os gráficos usarão somente dados existentes no backend.',`
 <div class="v38130-filterbar"><b>Filtros globais</b><select><option>1D</option><option>7D</option><option>30D</option><option>90D</option><option>1A</option><option>TUDO</option></select><select><option>Todos os ativos</option>${rows.map(x=>`<option>${esc(x.asset)}</option>`).join('')}</select><select><option>EUR</option><option>BRL</option></select><button onclick="refreshCharts(true)">Atualizar dados</button></div>
 <div class="v38130-analytics-grid"><article class="card"><div class="card-head"><b>Evolução / Intraday ${v38130Help('Série intraday real; o frontend não inventa pontos.')}</b><span>read path reparado</span></div><div class="v38130-chart-note">Fundação instalada. A próxima entrega traz os gráficos para esta tela com filtros por ativo, conta, moeda, período e métrica.</div></article>
 <article class="card"><div class="card-head"><b>Performance por ativo ${v38130Help('P/L e ações vêm do motor atual.')}</b></div>${rows.map(s=>`<div class="v38130-row">${v38130AssetIcon(s.asset)}<b>${esc(s.asset)}</b><span>${money(s.current_value_eur)}</span><span class="${Number(s.pnl_eur)>=0?'gain':'loss'}">${money(s.pnl_eur)}</span>${v366252ActionBadge(s)}</div>`).join('')||'<span class="muted">Sem posições.</span>'}</article></div>`);
}
function v38130Transactions(){
  v38130Placeholder(
    'Transações',
    'Histórico financeiro confirmado • ledger canônico verificado • somente leitura',
    `<div class="page-head"><div><h2>Transações</h2><p>Histórico financeiro confirmado • ledger canônico verificado • somente leitura</p></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" onclick="showExperienceView('financial-import')">Importação financeira</button><button class="btn" onclick="v38130LoadTransactionHistory()">Atualizar</button></div></div>
    <div class="card"><div id="transactions-history-status" class="muted">Carregando histórico confirmado…</div><div id="transactions-history-table"></div></div>`
  );
  v38130LoadTransactionHistory();
}

/* R21.386LX3_TRANSACTIONS_PLACEHOLDER_SHELL_CONTRACT_REPAIR */

function v38130TxEsc(v){ return String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function v38130TxValue(row){ const raw=row.gross_amount; if(raw===null||raw===undefined||raw==='') return '—'; const n=Number(raw); if(!Number.isFinite(n)) return v38130TxEsc(raw); try{return new Intl.NumberFormat('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2}).format(n);}catch(_){return n.toFixed(2);} }
function v38130TxDate(v){ if(!v)return '—'; const d=new Date(v); if(Number.isNaN(d.getTime()))return v38130TxEsc(v); try{return d.toLocaleString('pt-PT',{dateStyle:'short',timeStyle:'short'});}catch(_){return v38130TxEsc(v);} }
function v38130TxLabel(row){ const t=String(row.transaction_type||'').toUpperCase(); const labels={CASH_IN:'Entrada de caixa',DEPOSIT:'Depósito',FEE:'Taxa',SELL:'Venda'}; return labels[t]||t||String(row.event_type||'Evento financeiro'); }

async function v38130LoadTransactionHistory(){
 const status=document.getElementById('transactions-history-status'),host=document.getElementById('transactions-history-table'); if(!status||!host)return;
 status.textContent='Carregando histórico confirmado…'; host.innerHTML='';
 try{
  const r=await fetch('/api/portfolio/history/transactions',{method:'GET',headers:{'Accept':'application/json'}}); if(!r.ok)throw new Error('HTTP '+r.status);
  const payload=await r.json(); const rows=Array.isArray(payload)?payload:(Array.isArray(payload.records)?payload.records:(Array.isArray(payload.transactions)?payload.transactions:[]));
  if(!rows.length){status.textContent='Nenhuma transação financeira confirmada disponível.';return;}
  status.textContent=`${rows.length} evento(s) financeiro(s) confirmado(s).`;
  host.innerHTML=`<div style="overflow:auto;margin-top:12px"><table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left;padding:8px">Data</th><th style="text-align:left;padding:8px">Tipo</th><th style="text-align:left;padding:8px">Ativo / descrição</th><th style="text-align:left;padding:8px">Conta</th><th style="text-align:right;padding:8px">Valor</th><th style="text-align:left;padding:8px">Moeda</th><th style="text-align:left;padding:8px">Origem</th></tr></thead><tbody>${rows.map(row=>{
   const desc=row.asset_id||row.memo||row.external_id||'—',source=row.source||'—';
   const detail=JSON.stringify({event_id:row.event_id||null,event_type:row.event_type||null,transaction_type:row.transaction_type||null,source_ref:row.source_ref||null,candidate_id:row.candidate_id||null,provenance_sha256:row.provenance_sha256||null,review_sha256:row.review_sha256||null,approval_sha256:row.approval_sha256||null,identity_fingerprint_v2:row.identity_fingerprint_v2||null,history_projection:row._history_projection||null},null,2);
   return `<tr style="border-top:1px solid rgba(127,127,127,.18)"><td style="padding:8px;white-space:nowrap">${v38130TxDate(row.executed_at)}</td><td style="padding:8px">${v38130TxEsc(v38130TxLabel(row))}</td><td style="padding:8px">${v38130TxEsc(desc)}</td><td style="padding:8px">${v38130TxEsc(row.account_id||'—')}</td><td style="padding:8px;text-align:right;white-space:nowrap">${v38130TxValue(row)}</td><td style="padding:8px">${v38130TxEsc(row.currency||'—')}</td><td style="padding:8px"><details><summary style="cursor:pointer">${v38130TxEsc(source)}</summary><pre style="white-space:pre-wrap;max-width:520px">${v38130TxEsc(detail)}</pre></details></td></tr>`;
  }).join('')}</tbody></table></div>`;
 }catch(err){status.textContent='Não foi possível carregar o histórico de transações.';host.innerHTML=`<div class="muted" style="margin-top:8px">${v38130TxEsc(err&&err.message?err.message:String(err))}</div>`;}
}

/* R21.386LX_TRANSACTIONS_UI_READ_ONLY_HISTORY_WIRING */

function v38130Assets(){v38130Placeholder('Ativos','Cadastro e acompanhamento universal de ativos.',`<article class="card"><div class="card-head"><b>Cadastro de ativos</b><span>fundação</span></div><p class="muted">Nenhuma posição será inventada. O formulário será ligado ao Asset Registry existente com validação explícita.</p></article>`)}

/* R21.368B_PLANNING_EXPERIENCE */
/* R21.369E_PLANNING_SELECTOR_EXPERIENCE */
let r21369eDims=null;
function r21368bMoney(v,c){try{return new Intl.NumberFormat('pt-PT',{style:'currency',currency:String(c||'EUR')}).format(Number(v||0))}catch(e){return String(c||'')+' '+Number(v||0).toFixed(2)}}
async function r21369eLoadDims(){const r=await fetch('/api/planning-dimensions',{cache:'no-store'}),d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));if(d.metadata?.cross_currency_aggregation!==false||d.metadata?.account_asset_class_binding!==false)throw Error('PLANNING_DIMENSIONS_SAFETY_CONTRACT');r21369eDims=d;return d}
function r21369eOptions(values,label){return '<option value="">'+label+'</option>'+(values||[]).map(x=>'<option value="'+esc(x)+'">'+esc(x)+'</option>').join('')}
function r21369eFiltered(){const d=r21369eDims||{},u=$('r21369eUniverse')?.value||'',c=$('r21369eCurrency')?.value||'';return r21369jCompatibleAccounts(d,u,c)}
function r21369eSyncPlanning(){const d=r21369eDims||{},us=$('r21369eUniverse'),cs=$('r21369eCurrency'),a=$('r21369eAccount'),info=$('r21368bCashInfo'),amt=$('r21368bAmount');if(!a||!cs)return;const uid=us?.value||'',prevCur=String(cs.value||'').toUpperCase(),allowed=uid?r21369jCompatibleCurrencies(d,uid):Array.from(new Set((d.currencies||[]).map(x=>String(x).toUpperCase())));cs.innerHTML='<option value="">Todas as moedas</option>'+allowed.map(c=>'<option value="'+esc(c)+'">'+esc(c)+'</option>').join('');if(uid&&allowed.length===1)cs.value=allowed[0];else if(allowed.includes(prevCur))cs.value=prevCur;const old=a.value,rows=r21369jCompatibleAccounts(d,uid,cs.value||'');a.innerHTML='<option value="">Selecione a conta</option>'+rows.map(x=>'<option value="'+esc(x.account_id)+'">'+esc(x.institution_name||'Instituição')+' — '+esc(x.name||'Conta')+' • '+esc(x.currency)+' • disponível '+esc(r21368bMoney(x.cash_available,x.currency))+'</option>').join('');if(rows.some(x=>String(x.account_id)===old))a.value=old;const x=rows.find(x=>String(x.account_id)===String(a.value||''));if(info)info.textContent=x?((x.institution_name||'Instituição')+' — '+(x.name||'Conta')+' • '+x.currency+' • caixa disponível '+r21368bMoney(x.cash_available,x.currency)):'Selecione uma conta compatível.';if(amt){amt.max=x?String(x.cash_available):'';if(x&&Number(amt.value)>Number(x.cash_available))amt.value=''}}
function r21369jUniverseOptions(d){ return '<option value="">Todos os universos</option>'+r21369jUniverseRows(d).map(u=>'<option value="'+esc(u.universe_id)+'">'+esc(u.name)+'</option>').join(''); }
function r21369jUniverseRows(d){ return Array.isArray(d?.universes)?d.universes:[]; }
function r21369jUniverseById(d,id){ return r21369jUniverseRows(d).find(x=>String(x.universe_id)===String(id))||null; }
function r21369jCompatibleCurrencies(d,id){
  const u=r21369jUniverseById(d,id); return u?Array.from(new Set((u.currencies||[]).map(x=>String(x).toUpperCase()))):[];
}
function r21369jCompatibleAccounts(d,id,currency){
  const allowed=r21369jCompatibleCurrencies(d,id), cur=String(currency||"").toUpperCase();
  return (d?.accounts||[]).filter(a=>{ const ac=String(a.currency||"").toUpperCase(); return (!id||allowed.includes(ac))&&(!cur||ac===cur); });
}


let r21379hInvestmentDims=null;
async function r21379hLoadInvestmentDimensions(){
 const r=await fetch('/api/investment-planning/dimensions',{cache:'no-store'}),d=await r.json();
 if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));
 if(d.financial_authority!=='NONE'||d.cross_currency_aggregation!==false||d.silent_fx!==false)throw Error('INVESTMENT_DIMENSIONS_SAFETY_CONTRACT_VIOLATION');
 r21379hInvestmentDims=d;return d;
}
function r21379hOptions(rows){
 return (rows||[]).map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name||x.id)+'</option>').join('');
}
function r21379hClassOptions(rows){
 return (rows||[]).map(x=>'<label style="display:block"><input type="checkbox" name="r21379hAssetClass" value="'+esc(x.id)+'"> '+esc(x.name||x.id)+'</label>').join('');
}
/* r21.381d2 — explicit coordinated activation Experience */
async function r21381dActivatePlan(planId){
 if(!confirm('Ativar este plano? O capital de planejamento será reservado e o plano passará para ACTIVE. Isto não movimenta caixa, não cria ordem e não concede autoridade de execução.'))return;
 try{
  const r=await fetch('/api/investment-plans/'+encodeURIComponent(planId)+'/activate-coordinated',{method:'POST'}),d=await r.json();
  if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));
  if(d.ledger_mutated!==false||d.cash_mutated!==false||d.authority_changed!==false||d.automatic_execution_authorized!==false||d.order_proposal_created!==false)throw Error('COORDINATED_ACTIVATION_SAFETY_CONTRACT_VIOLATION');
  const b=d.planning_budget||{},x=d.plan||{};
  if(String(b.status||'').toUpperCase()!=='ACTIVE'||String(x.status||'').toUpperCase()!=='ACTIVE'||String(x.authority||'NONE')!=='NONE')throw Error('COORDINATED_ACTIVATION_INCOMPLETE');
  closeModal();
  toast('Capital reservado e plano ativado. Nenhum caixa foi movimentado e nenhuma autoridade de execução foi concedida.');
  await r21368bOpenPlanning();
 }catch(e){
  toast('Não foi possível concluir a ativação coordenada: '+(e.message||String(e))+'. O estado pode ser retomado com segurança.');
 }
}

async function r21379nPlanLifecycle(planId,action){
 const label=action==='cancel'?'Cancelar':'Encerrar';
 if(!confirm(label+' este plano de investimento? Esta ação altera somente o lifecycle do plano e não movimenta caixa.'))return;
 const r=await fetch('/api/investment-plans/'+encodeURIComponent(planId)+'/'+action,{method:'POST'}),d=await r.json();
 if(!r.ok||!d.ok){toast('Falha: '+(d.error||('HTTP '+r.status)));return}
 if(d.planning_budget_mutated!==false||d.ledger_mutated!==false||d.cash_mutated!==false||d.authority_changed!==false||d.automatic_execution_authorized!==false||d.order_proposal_created!==false){toast('Resposta recusada: contrato de segurança inválido.');return}
 closeModal();toast('Plano '+(action==='cancel'?'cancelado':'encerrado')+'.');r21368bOpenPlanning();
}
async function r21379hOpenInvestmentPlan(budgetId){
 try{
  const pr=await fetch('/api/investment-plans?planning_budget_id='+encodeURIComponent(budgetId),{cache:'no-store'}),pd=await pr.json();
  if(!pr.ok||!pd.ok)throw Error(pd.error||('HTTP '+pr.status));
  if(pd.financial_authority!=='NONE'||pd.ledger_mutated!==false||pd.cash_mutated!==false||pd.authority_changed!==false)throw Error('INVESTMENT_PLAN_READ_SAFETY_CONTRACT_VIOLATION');
  const existing=(pd.plans||[]).filter(x=>['DRAFT','ACTIVE'].includes(String(x.status||'').toUpperCase()));
  if(existing.length>1)throw Error('MULTIPLE_OPEN_INVESTMENT_PLANS_FOR_BUDGET');
  if(existing.length===1){
   const x=existing[0],st=String(x.status||'').toUpperCase(),acts=st==='ACTIVE'?'<div class="v38265-actions v21379n-plan-actions"><button onclick="r21379nPlanLifecycle(\''+esc(x.plan_id)+'\',\'cancel\')">Cancelar plano</button><button onclick="r21379nPlanLifecycle(\''+esc(x.plan_id)+'\',\'close\')">Encerrar plano</button></div>':st==='DRAFT'?'<div class="v38265-actions v21379n-plan-actions"><button onclick="r21381dActivatePlan(\''+esc(x.plan_id)+'\')">Ativar plano</button><button onclick="r21379nPlanLifecycle(\''+esc(x.plan_id)+'\',\'cancel\')">Cancelar plano</button></div>':'';
   openModal('Plano de investimento','<div class="v38265-form v21379n-plan-view"><div><b>'+esc(st)+'</b> • '+esc(x.plan_id||'')+'</div><div><b>Estratégia:</b> '+esc(x.strategy||'—')+'</div><div><b>Horizonte:</b> '+esc(x.period||'—')+'</div><div><b>Classes:</b> '+esc((x.allowed_asset_classes||[]).join(', '))+'</div><div><b>Execução:</b> '+esc(x.execution_mode||'MANUAL')+'</div><div class="muted">Plano existente vinculado a este orçamento. Autoridade financeira: '+esc(x.authority||'NONE')+'. Nenhum novo plano será criado.</div>'+acts+'</div>');
   return;
  }
  const [d,pd0]=await Promise.all([r21379hLoadInvestmentDimensions(),fetch('/api/planning-dimensions',{cache:'no-store'}).then(async r=>{const q=await r.json();if(!r.ok||!q.ok)throw Error(q.error||('HTTP '+r.status));return q})]);
  const br=await fetch('/api/planning-budgets',{cache:'no-store'}),bd=await br.json();if(!br.ok||!bd.ok)throw Error(bd.error||('HTTP '+br.status));
  const b=(bd.budgets||[]).find(q=>String(q.budget_id)===String(budgetId));if(!b)throw Error('PLANNING_BUDGET_NOT_FOUND');
  const universes=(pd0.universes||[]).filter(u=>u.active!==false&&(u.currencies||[]).map(c=>String(c).toUpperCase()).includes(String(b.currency||'').toUpperCase()));
  if(!universes.length)throw Error('NO_COMPATIBLE_INVESTMENT_UNIVERSE');
  const uopts=universes.map(u=>'<option value="'+esc(u.universe_id)+'">'+esc(u.name||u.universe_id)+' • '+esc((u.currencies||[]).join(', '))+'</option>').join('');
  openModal('Definir plano de investimento','<div class="v38265-form"><div class="muted">Dimensões carregadas das Registries canônicas. O universo é selecionado explicitamente entre os compatíveis com a moeda do orçamento.</div><label>Universo<select id="r21380aUniverse">'+uopts+'</select></label><label>Estratégia<select id="r21379hStrategy">'+r21379hOptions(d.strategies)+'</select></label><label>Horizonte<select id="r21379hPeriod">'+r21379hOptions(d.horizons)+'</select></label><div><b>Classes de ativos permitidas</b>'+r21379hClassOptions(d.asset_classes)+'</div><button onclick="r21379hReviewInvestmentPlan(\''+esc(budgetId)+'\')">Revisar plano</button></div>');
 }catch(e){toast('Não foi possível carregar o plano: '+(e.message||String(e)))}
}
function r21379hReviewInvestmentPlan(budgetId){
 const universe=$('r21380aUniverse')?.value||'',strategy=$('r21379hStrategy')?.value||'',period=$('r21379hPeriod')?.value||'';
 const classes=[...document.querySelectorAll('input[name="r21379hAssetClass"]:checked')].map(x=>x.value);
 if(!universe||!strategy||!period||!classes.length){toast('Selecione universo, estratégia, horizonte e ao menos uma classe de ativo.');return}
 const validC=new Set((r21379hInvestmentDims?.asset_classes||[]).map(x=>x.id));
 if(classes.some(x=>!validC.has(x)))throw Error('UNREGISTERED_ASSET_CLASS');
 const validS=new Set((r21379hInvestmentDims?.strategies||[]).map(x=>x.id));
 const validH=new Set((r21379hInvestmentDims?.horizons||[]).map(x=>x.id));
 if(!validS.has(strategy)||!validH.has(period))throw Error('UNREGISTERED_PLANNING_DIMENSION');
 const payload=encodeURIComponent(JSON.stringify({planning_budget_id:budgetId,universe_id:universe,period,strategy,allowed_asset_classes:classes,execution_mode:'MANUAL'}));
 openModal('Revisar plano de investimento','<div class="v38265-form"><div><b>Universo:</b> '+esc(universe)+'</div><div><b>Estratégia:</b> '+esc(strategy)+'</div><div><b>Horizonte:</b> '+esc(period)+'</div><div><b>Classes:</b> '+esc(classes.join(', '))+'</div><div><b>Execução:</b> MANUAL</div><div class="muted">Authority=NONE. Criar o DRAFT registra somente a intenção de investimento; não reserva capital, não cria ordem e não movimenta caixa.</div><button onclick="r21380eCreateInvestmentPlanDraft(\''+payload+'\')">Criar plano DRAFT</button></div>');
}
async function r21380eCreateInvestmentPlanDraft(encoded){
 let body;try{body=JSON.parse(decodeURIComponent(encoded))}catch(e){toast('Payload do plano inválido.');return}
 if(!body||body.execution_mode!=='MANUAL'||!body.planning_budget_id||!body.universe_id||!body.period||!body.strategy||!Array.isArray(body.allowed_asset_classes)||!body.allowed_asset_classes.length){toast('Plano recusado: dimensões incompletas.');return}
 if(!confirm('Criar este plano como DRAFT? Isto não reserva capital, não movimenta caixa e não concede autoridade de execução.'))return;
 try{
  const r=await fetch('/api/investment-plans/drafts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),d=await r.json();
  if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));
  const x=d.draft||d.plan||{};
  if(d.persisted!==true||String(d.status||x.status||'').toUpperCase()!=='DRAFT'||String(d.authority||x.authority||'')!=='NONE'||d.planning_budget_mutated!==false||d.ledger_mutated!==false||d.cash_mutated!==false||d.authority_changed!==false||d.order_proposal_created!==false||d.automatic_execution_authorized!==false)throw Error('INVESTMENT_PLAN_DRAFT_SAFETY_CONTRACT_VIOLATION');
  closeModal();toast('Plano DRAFT criado sem movimentar caixa.');await r21368bOpenPlanning();
 }catch(e){
  if(String(e.message||e)==='INVESTMENT_PLAN_ALREADY_EXISTS_FOR_BUDGET'){
   try{const bid=String(body.planning_budget_id||''),rr=await fetch('/api/investment-plans?planning_budget_id='+encodeURIComponent(bid),{cache:'no-store'}),dd=await rr.json();if(rr.ok&&dd.ok&&dd.financial_authority==='NONE'&&dd.ledger_mutated===false&&dd.cash_mutated===false&&dd.authority_changed===false){const open=(dd.plans||[]).filter(q=>['DRAFT','ACTIVE'].includes(String(q.status||'').toUpperCase()));if(open.length===1){closeModal();toast('O plano já havia sido criado. Estado reconciliado sem nova criação.');await r21368bOpenPlanning();return}}}catch(_){}
  }
  toast('Não foi possível criar o plano DRAFT: '+(e.message||String(e)))
 }
}
async function r21368bOpenPlanning(){try{const d=await r21369eLoadDims();const [rr,pr]=await Promise.all([fetch('/api/planning-budgets',{cache:'no-store'}),fetch('/api/investment-plans',{cache:'no-store'})]),dd=await rr.json(),pd=await pr.json(),existing=rr.ok&&dd.ok?(dd.budgets||[]):[];if(!pr.ok||!pd.ok)throw Error(pd.error||('HTTP '+pr.status));if(pd.financial_authority!=='NONE'||pd.ledger_mutated!==false||pd.cash_mutated!==false||pd.authority_changed!==false)throw Error('INVESTMENT_PLAN_READ_SAFETY_CONTRACT_VIOLATION');r21379rOpenPlanBudgets=new Set((pd.plans||[]).filter(x=>['DRAFT','ACTIVE'].includes(String(x.status||'').toUpperCase())).map(x=>String(x.planning_budget_id||'')));openModal('Planejar investimento','<div class="v38265-form"><label>Universo<select id="r21369eUniverse" onchange="r21369eSyncPlanning()">'+r21369jUniverseOptions(d)+'</select></label><label>Moeda<select id="r21369eCurrency" onchange="r21369eSyncPlanning()">'+r21369eOptions(d.currencies,'Todas as moedas')+'</select></label><label>Fonte do capital<select id="r21369eAccount" onchange="r21369eSyncPlanning()"><option value="">Selecione a conta</option></select></label><div id="r21368bCashInfo" class="muted">Selecione uma conta compatível.</div><label>Capital planejado<input id="r21368bAmount" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0,00"></label><div class="muted">A conta fornece o capital. Classes de ativos e estratégia pertencem ao plano e serão definidas separadamente.</div><div class="muted">Não movimenta caixa, não escreve no ledger e não concede autoridade. Planejado (DRAFT) não reserva capital; Reservado (ACTIVE) reserva capacidade de planejamento.</div><button onclick="r21368bReviewPlanning()">Revisar planejamento</button><div class="card" style="margin-top:12px"><div class="card-head"><b>Planejamentos existentes</b><span>'+existing.length+' total</span></div>'+r21372cBudgetRows(existing)+'</div></div>');r21369eSyncPlanning()}catch(e){toast('Não foi possível carregar o planejamento: '+(e.message||String(e)))}}
function r21368bReviewPlanning(){const rows=r21369eFiltered(),aid=$('r21369eAccount')?.value||'',x=rows.find(q=>String(q.account_id)===String(aid)),amount=Number($('r21368bAmount')?.value||0);if(!x){toast('Selecione a conta de origem.');return}if(!Number.isFinite(amount)||amount<=0){toast('Informe um valor válido.');return}if(amount>Number(x.cash_available)){toast('O capital planejado excede o caixa disponível desta conta.');return}openModal('Confirmar planejamento','<div class="v38265-form"><div><b>'+esc(r21368bMoney(amount,x.currency))+'</b> para planejamento</div><div class="muted">'+esc(x.institution_name||'Instituição')+' — '+esc(x.name||'Conta')+' • '+esc(x.currency)+'</div><div class="muted">Nenhum dinheiro será movimentado.</div><button onclick="r21368bCreatePlanning(\''+esc(x.account_id)+'\',\''+String(amount)+'\')">Confirmar criação do plano</button></div>')}
async function r21368bCreatePlanning(accountId,amount){const x=(r21369eDims?.accounts||[]).find(q=>String(q.account_id)===String(accountId));if(!x){toast('Conta de planejamento não encontrada.');return}const body={account_id:x.account_id,amount:Number(amount)};try{const r=await fetch('/api/planning-budgets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));if(d.ledger_mutated!==false||d.cash_mutated!==false||d.authority_changed!==false)throw Error('PLANNING_BUDGET_SAFETY_CONTRACT_VIOLATION');closeModal();toast('Planejamento criado sem movimentar o caixa.')}catch(e){toast('Não foi possível criar o planejamento: '+(e.message||String(e)))}}
/* R21.372C3_PLANNING_BUDGET_LIFECYCLE_UI */
let r21379rOpenPlanBudgets=new Set();
function r21372cStatusLabel(s){return ({DRAFT:'Planejado',ACTIVE:'Reservado',CANCELLED:'Cancelado',CLOSED:'Encerrado'})[String(s||'').toUpperCase()]||String(s||'—')}
function r21372cBudgetRows(rows){return (rows||[]).map(b=>{const st=String(b.status||'DRAFT').toUpperCase(),id=String(b.budget_id||''),a=(r21369eDims?.accounts||[]).find(x=>String(x.account_id)===String(b.account_id)),nm=a?((a.institution_name||'Instituição')+' — '+(a.name||'Conta')):'Conta '+String(b.account_id||'—'),ac=st==='DRAFT'?'<button onclick="r21379hOpenInvestmentPlan(\''+esc(id)+'\')">'+(r21379rOpenPlanBudgets.has(id)?'Ver plano':'Definir plano')+'</button> <button onclick="r21372cActivate(\''+esc(id)+'\')">Reservar capital</button> <button onclick="r21372cCancel(\''+esc(id)+'\')">Cancelar</button>':st==='ACTIVE'?'<button onclick="r21379hOpenInvestmentPlan(\''+esc(id)+'\')">'+(r21379rOpenPlanBudgets.has(id)?'Ver plano':'Definir plano')+'</button> <button onclick="r21372cCancel(\''+esc(id)+'\')">Cancelar reserva</button> <button onclick="r21372cClose(\''+esc(id)+'\')">Encerrar</button>':'';return '<div class="v38130-row r21379q-budget-row"><div><b>'+esc(r21372cStatusLabel(st))+'</b><small>'+esc(nm)+' • '+esc(b.currency||'')+'</small></div><strong>'+esc(r21368bMoney(b.amount,b.currency))+'</strong><span class="r21379q-budget-actions">'+ac+'</span></div>'}).join('')||'<div class="muted">Nenhum planejamento criado.</div>'}
async function r21372cAction(id,action){if(!confirm('Confirmar alteração do planejamento? Esta ação não movimenta caixa nem concede autoridade de execução.'))return;try{const r=await fetch('/api/planning-budgets/'+encodeURIComponent(id)+'/'+action,{method:'POST'}),d=await r.json();if(!r.ok||!d.ok)throw Error(d.error||('HTTP '+r.status));if(d.ledger_mutated===true||d.cash_mutated===true||d.authority_changed===true)throw Error('PLANNING_LIFECYCLE_SAFETY_CONTRACT_VIOLATION');toast(action==='activate'?'Capital reservado para planejamento.':action==='cancel'?'Planejamento/reserva cancelado.':'Planejamento encerrado.');await r21368bOpenPlanning()}catch(e){toast('Não foi possível atualizar o planejamento: '+(e.message||String(e)))}}
function r21372cActivate(id){return r21372cAction(id,'activate')}
function r21372cCancel(id){return r21372cAction(id,'cancel')}
function r21372cClose(id){return r21372cAction(id,'close')}

function r21368bAttachPlanningAction(){
 const title=document.getElementById('viewTitle'),content=document.getElementById('viewContent');if(!title||!content||String(title.textContent||'').trim()!=='Contas e Bancos')return false;
 const actions=content.querySelector('.v38279r4-registry > div:last-child')||content.querySelector('.v38266-account-actions > div:last-child');if(!actions||actions.querySelector('[data-r21368b-planning]'))return !!actions;
 const b=document.createElement('button');b.className='primary';b.setAttribute('data-r21368b-planning','1');b.textContent='Planejar investimento';b.onclick=r21368bOpenPlanning;
 const accountButton=[...actions.querySelectorAll('button')].find(x=>(x.textContent||'').includes('+ Conta'));if(accountButton)actions.insertBefore(b,accountButton);else actions.appendChild(b);return true;
}

/* R21.366B_MANUAL_CASH_EXPERIENCE */
/* R21.375D_CANONICAL_CASH_ACCOUNT_SELECTOR
   Cash operations select from the canonical Registry, never from existing cash/positions.
   This makes zero/unknown-balance registered accounts eligible without inventing cash. */
async function r21375dCashAccounts(){
 const reg=await jsonFetch('/api/investment-registry'), institutions=reg.institutions||[], im=new Map(institutions.map(i=>[i.institution_id,i]));
 return (reg.accounts||[]).filter(a=>String(a.account_id||'').startsWith('acct_')&&String(a.currency||'').trim()).map(a=>{const i=im.get(a.institution_id)||{};return {id:String(a.account_id),currency:String(a.currency),institution_name:String(i.name||a.institution_id||'Instituição'),account_name:String(a.name||'Conta'),account_type:String(a.account_type||'ACCOUNT'),owner_profile:String(a.owner_profile||'UNSPECIFIED')}}).sort((a,b)=>(a.institution_name+' '+a.account_name).localeCompare(b.institution_name+' '+b.account_name));
}
async function r21366bOpenCash(operation){
 const op=String(operation||'').toUpperCase();
 if(!['DEPOSIT','WITHDRAWAL'].includes(op))return;
 try{
  const accounts=await r21375dCashAccounts();
  if(!accounts.length){toast('Nenhuma conta canônica disponível para operação de caixa.');return}
  const opts=accounts.map(a=>`<option value="${esc(a.id)}">${esc(a.institution_name)} • ${esc(a.account_name)} • ${esc(a.currency)}${a.owner_profile&&a.owner_profile!=='UNSPECIFIED'?' • '+esc(a.owner_profile):''}</option>`).join('');
  openModal(op==='DEPOSIT'?'Adicionar dinheiro':'Retirar dinheiro',`<div class="v38265-form"><label>Conta<select id="r21366bAccount">${opts}</select></label><label>Valor<input id="r21366bAmount" type="number" min="0.01" step="0.01" inputmode="decimal" placeholder="0,00"></label><div class="muted">A conta e a moeda vêm do Registro Universal canônico. Caixa sem conta vinculada não é oferecido para operação.</div><button onclick="r21366bReview('${op}')">Revisar operação</button></div>`);
 }catch(e){toast('Não foi possível carregar as contas canônicas: '+(e.message||String(e)))}
}
async function r21366bReview(operation){
 const account_id=$('r21366bAccount')?.value,gross_amount=$('r21366bAmount')?.value;
 if(!account_id||!gross_amount||Number(gross_amount)<=0){toast('Informe conta e valor válido.');return}
 try{
  const r=await fetch('/api/manual-cash/review',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({account_id,operation,gross_amount})});
  const d=await r.json();if(!r.ok)throw Error(d.error||('HTTP '+r.status));
  if(!d.session_id||!d.candidate_id||!d.review_sha256)throw Error('REVIEW_CONTRACT_INCOMPLETE');
  const cashAccounts=await r21375dCashAccounts(); const selected=cashAccounts.find(a=>a.id===account_id); const accountLabel=selected?`${selected.institution_name} · ${selected.account_name} · ${selected.currency}`:'Conta selecionada';
  if(!confirm(`Revisão preparada para ${operation==='DEPOSIT'?'adicionar':'retirar'} ${gross_amount} em ${accountLabel}.\n\nConfirmar ainda NÃO grava no ledger.`))return;
  await r21366bConfirm(d);
 }catch(e){toast('Não foi possível preparar a operação: '+(e.message||String(e)))}
}
async function r21366bConfirm(review){
 try{
  const r=await fetch('/api/manual-cash/confirm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:review.session_id,candidate_id:review.candidate_id,review_sha256:review.review_sha256,confirmation:true})});
  const d=await r.json();if(!r.ok)throw Error(d.error||('HTTP '+r.status));
  if(!d.receipt_sha256||d.explicit_execution_required!==true)throw Error('CONFIRM_CONTRACT_INCOMPLETE');
  if(!confirm('Autorização preparada.\n\nExecutar agora? Esta confirmação gravará a transação no ledger canônico.'))return;
  await r21366bExecute(d.receipt_sha256);
 }catch(e){toast('Não foi possível confirmar: '+(e.message||String(e)))}
}
async function r21366bExecute(receipt_sha256){
 try{
  const r=await fetch('/api/manual-cash/execute',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({receipt_sha256,confirmation:true,executed_by:'MANUAL_UI'})});
  const d=await r.json();if(!r.ok)throw Error(d.error||('HTTP '+r.status));
  toast('Operação de caixa concluída no ledger canônico.');
  if(typeof closeModal==='function')closeModal();
  await loadStatus(false);
  /* R21.375D_ACCOUNT_CASH_IMMEDIATE_REFRESH:
     loadStatus refreshes legacy consumers; the active Accounts Experience reads
     canonical cash from live-projection, so re-render it explicitly after execution. */
  const active=document.querySelector('.nav-item.active')?.dataset?.target;
  if(active==='accounts'&&typeof v38130Accounts==='function')await v38130Accounts();
 }catch(e){toast('Não foi possível executar: '+(e.message||String(e)))}
}

function v38130Accounts(){const acc=((lastStatus||{}).portfolio||{}).accounts||{};v38130Placeholder('Contas e Bancos','Ativos organizados por instituição.',`<div class="v38130-bank-grid">${Object.entries(acc).map(([bank,items])=>`<article class="card"><div class="card-head"><b>${esc(bank)}</b><span>${items.length} ativo(s)</span></div>${items.map(x=>`<div class="v38130-row">${v38130AssetIcon(x.asset)}<b>${esc(x.asset)}</b><span>${money(x.current_value_eur||x.amount_eur)}</span></div>`).join('')||'<span class="muted">Sem ativos.</span>'}</article>`).join('')||'<article class="card"><span class="muted">Nenhuma conta retornada.</span></article>'}</div>`)}
const _v38130Show=showExperienceView;
showExperienceView=function(name,button){
 document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));(button||document.querySelector(`[data-target="${name}"]`))?.classList.add('active');
 if(name==='analytics'){v38130Analytics();return} if(name==='transactions'){v38130Transactions();return} if(name==='assets'){v38130Assets();return} if(name==='accounts'){v38130Accounts();return}
 return _v38130Show(name,button)
};

/* V3.8.13.0-r1 — true rolling-time chart contract */
function v38130r1RenderIntraday(rows,hours){
 const c=$('intradayChart'); if(!c||typeof Chart==='undefined') return;
 const now=new Date(), start=new Date(now.getTime()-Number(hours||24)*3600000);
 const clean=(rows||[]).filter(r=>r.timestamp&&r.asset).map(r=>({...r,_t:new Date(r.timestamp)})).filter(r=>!Number.isNaN(r._t.getTime())&&r._t>=start&&r._t<=now);
 const assets=[...new Set(clean.map(r=>String(r.asset)))];
 const datasets=assets.map(a=>({label:a,data:clean.filter(r=>String(r.asset)===a).map(r=>({x:r._t.getTime(),y:Number(r.pnl_eur||0)})),tension:.25,spanGaps:true,pointRadius:2}));
 if(intraChart) intraChart.destroy();
 intraChart=new Chart(c,{type:'line',data:{datasets},options:{responsive:true,maintainAspectRatio:false,animation:false,parsing:false,
  plugins:{legend:{labels:{color:'#b8c4cb',font:{size:10}}},tooltip:{callbacks:{title:(items)=>items.length?new Date(items[0].parsed.x).toLocaleString('pt-PT'):''}}},
  scales:{x:{type:'linear',min:start.getTime(),max:now.getTime(),ticks:{color:'#758590',maxTicksLimit:8,callback:(v)=>new Date(v).toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}},y:{ticks:{color:'#758590'}}}}});
}
refreshCharts=async function(force=false){
 try{
  const h=Number($('hours')?.value||24);
  const [a,b]=await Promise.all([jsonFetch('/api/daily'),jsonFetch('/api/intraday?hours='+encodeURIComponent(h))]);
  renderCharts(a.rows||[],[],force);
  v38130r1RenderIntraday(b.rows||[],h);
 }catch(e){toast('Falha ao atualizar gráficos: '+e.message)}
};

/* V3.8.13.1 — Executive Dashboard */
function v38131Help(t){return `<span class="v38131-help" title="${esc(t)}">?</span>`}
function v38131Held(p){return (p.scores||[]).filter(s=>Number(s.current_value_eur||0)>0)}
function v38131ActionClass(a){a=String(a||'');return a==='COMPRE'?'buy':(['VENDA','REALIZE'].includes(a)?'sell':'watch')}
function v38131Install(){
 const host=document.getElementById('executiveDashboard'); if(!host||document.getElementById('v38131Executive'))return;
 host.innerHTML=`<div id="v38131Executive" class="v38131">
 <div class="v38131-goal"><div><small>OBJETIVO OPERACIONAL</small><h2>Crescimento em curto prazo com o caixa disponível</h2><p>Identificar oportunidades usando a inteligência atual do Porquinho, respeitando risco, evidência e controle humano. Nenhum retorno é garantido.</p></div><span class="v38131-chip">EXECUÇÃO MANUAL</span></div>
 <div id="v38131Kpis" class="v38131-kpis"></div>
 <div class="v38131-grid">
  <article class="card"><div class="card-head"><b>Estado do sistema</b><span>ciclo • produtor • governança</span></div><div id="v38131Health"></div></article>
  <article class="card"><div class="card-head"><b>Oportunidades agora</b><span>somente sinais do motor</span></div><div id="v38131Opp"></div></article>
 </div>
 <div class="v38131-grid">
  <article class="card"><div class="card-head"><b>Posições reais</b><button onclick="showExperienceView('portfolio')">Carteira →</button></div><div id="v38131Positions"></div></article>
  <article class="card"><div class="card-head"><b>Contas</b><span>posição consolidada por conta</span></div><div id="v38131Accounts"></div></article>
 </div>
 <div class="v38131-note">Confidence = qualidade da evidência, não probabilidade de lucro. As ações exibidas vêm do motor existente; esta tela não recalcula sinais.</div>
 </div>`;
}
async function v38131Render(){
 v38131Install(); if(!document.getElementById('v38131Executive')||!lastStatus)return;
 const p=lastStatus.portfolio||{},l=lastStatus.learning||{},held=v38131Held(p);
 const invested=Number(p.invested_eur||0),value=Number(p.value_eur||0),cash=Number(p.cash_eur||0),pnl=Number(p.pnl_eur||0);
 document.getElementById('v38131Kpis').innerHTML=[
  ['Patrimônio',money(value),'carteira + caixa'],
  ['Resultado',money(pnl),fmt(p.pnl_pct,1)+'%'],
  ['Caixa disponível',money(cash),'capital não alocado'],
  ['Posições',String(held.length),'ativos com valor real'],
  ['Evidência',fmt(l.confidence,0)+'/100','qualidade, não probabilidade']
 ].map(x=>`<div class="v38131-kpi"><span>${esc(x[0])}</span><b>${esc(x[1])}</b><small>${esc(x[2])}</small></div>`).join('');
 let h={};try{h=await jsonFetch('/api/experience/health')}catch(e){}
 const ac=h.auto_cycle||{},ip=h.intraday_producer||{};
 document.getElementById('v38131Health').innerHTML=[
  ['Auto ciclo',ac.state||'SEM TELEMETRIA',h.cadence_seconds?`${h.cadence_seconds/60} min`:'—'],
  ['Intraday',ip.state||'SEM TELEMETRIA',ip.written!=null?`${ip.written} registros no último ciclo`:'—'],
  ['Compras automáticas',h.execution_buy||'UNSUPPORTED','controle humano'],
  ['Vendas automáticas',h.execution_sell||'UNSUPPORTED','controle humano']
 ].map(x=>`<div class="v38131-row"><span>${esc(x[0])}</span><b>${esc(x[1])}</b><small>${esc(x[2])}</small></div>`).join('');
 const opp=(p.scores||[]).filter(s=>['COMPRE','REALIZE','VENDA','KEEP','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE','ABSTAIN_INSUFFICIENT_EVIDENCE','NO_ALLOCATION'].includes(String(s.action||'').toUpperCase())).sort((a,b)=>Number(b.promising_pct||0)-Number(a.promising_pct||0));
 document.getElementById('v38131Opp').innerHTML=opp.length?opp.slice(0,6).map(s=>`<div class="v38131-opp"><b>${esc(s.asset)}</b>${v366252ActionBadge(s)}<small>KPI ${fmt(s.promising_pct,1)} • OPP ${fmt(s.opportunity,1)} • RISK ${fmt(s.risk,1)}</small></div>`).join(''):`<div class="v38131-empty">Nenhuma ação disponível no snapshot atual.</div>`;
 document.getElementById('v38131Positions').innerHTML=held.sort((a,b)=>Number(b.current_value_eur||0)-Number(a.current_value_eur||0)).map(s=>`<div class="v38131-pos"><b>${esc(s.asset)}</b><span>${esc(s.account||'—')}</span><strong>${money(s.current_value_eur)}</strong><em class="${Number(s.pnl_eur)>=0?'gain':'loss'}">${money(s.pnl_eur)} • ${fmt(s.pnl_pct,1)}%</em></div>`).join('')||'<div class="v38131-empty">Nenhuma posição real.</div>';
 const by={};held.forEach(s=>{const a=s.account||'Sem conta';by[a]=(by[a]||0)+Number(s.current_value_eur||0)});
 document.getElementById('v38131Accounts').innerHTML=Object.entries(by).sort((a,b)=>b[1]-a[1]).map(([a,v])=>`<div class="v38131-account"><span class="v38131-bankmark">${esc(a.slice(0,2).toUpperCase())}</span><div><b>${esc(a)}</b><small>valor atual das posições</small></div><strong>${money(v)}</strong></div>`).join('')||'<div class="v38131-empty">Sem contas com posições.</div>';
}
const _v38131LoadStatus=loadStatus;
loadStatus=async function(force=false){await _v38131LoadStatus(force);await v38131Render()}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v38131Render,150));

/* V38132R1_ANALYTICS */
let v38132Chart=null;
function v38132Held(){return (((lastStatus||{}).portfolio||{}).scores||[]).filter(x=>Number(x.current_value_eur||0)>0)}
function v38132Universe(){return (((lastStatus||{}).portfolio||{}).scores||[])}
function v38132Shell(){
 v38130Placeholder('Analytics','Carteira real, histórico intraday e universo monitorado sem misturar posições com ativos apenas observados.',`
 <div id="v38132Analytics" class="v38132">
 <div class="v38132-filters">
 <label>Período<select id="v38132Period" onchange="v38132Refresh()"><option value="6">6H</option><option value="12">12H</option><option value="24" selected>24H</option></select></label>
 <label>Ativo<select id="v38132Asset" onchange="v38132Refresh()"><option value="ALL">Todos da carteira</option></select></label>
 <label>Conta<select id="v38132Account" onchange="v38132RenderTables()"><option value="ALL">Todas</option></select></label>
 <label>Métrica<select id="v38132Metric" onchange="v38132Refresh()"><option value="pnl_eur">P/L €</option><option value="pnl_pct">P/L %</option><option value="current_value_eur">Valor atual €</option></select></label>
 <label>Moeda<select disabled title="BRL somente com fonte cambial real e auditável"><option>EUR</option></select></label></div>
 <div class="v38132-kpis" id="v38132Kpis"></div>
 <div class="v38132-grid"><article class="card"><div class="card-head"><b>Intraday da carteira</b><span title="Snapshots efetivamente gravados pelo produtor intraday.">observações reais • ?</span></div><div class="v38132-canvas"><canvas id="v38132Chart"></canvas></div><div id="v38132ChartEmpty" class="v38132-empty"></div></article>
 <article class="card"><div class="card-head"><b>Performance da carteira</b><span>somente posições reais</span></div><div id="v38132Performance"></div></article></div>
 <article class="card"><div class="card-head"><b>Universo monitorado</b><span title="Confidence é qualidade da evidência, não probabilidade de lucro.">KPI • OPP • ENT • ASY • RISK • ?</span></div><div class="table-wrap"><table class="v38132-table"><thead><tr><th>Ativo</th><th>Posição</th><th>KPI</th><th>OPP</th><th>ENT</th><th>ASY</th><th>RISK</th><th>Ação</th></tr></thead><tbody id="v38132Universe"></tbody></table></div></article>
 <div class="v38132-note">EUR é a moeda operacional. BRL permanece desabilitado até existir fonte cambial real e auditável; nenhuma conversão é inventada pelo frontend.</div></div>`);
}
function v38132Fill(){
 const h=v38132Held(),a=$('v38132Asset'),c=$('v38132Account');if(!a||!c)return;const av=a.value||'ALL',cv=c.value||'ALL';
 a.innerHTML='<option value="ALL">Todos da carteira</option>'+h.map(x=>`<option value="${esc(x.asset)}">${esc(x.asset)}</option>`).join('');
 const ac=[...new Set(h.map(x=>x.account||'Sem conta'))].sort();c.innerHTML='<option value="ALL">Todas</option>'+ac.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
 if([...a.options].some(o=>o.value===av))a.value=av;if([...c.options].some(o=>o.value===cv))c.value=cv;
}
function v38132RenderTables(){
 const acc=$('v38132Account')?.value||'ALL',h=v38132Held().filter(x=>acc==='ALL'||(x.account||'Sem conta')===acc),val=h.reduce((z,x)=>z+Number(x.current_value_eur||0),0),pnl=h.reduce((z,x)=>z+Number(x.pnl_eur||0),0);
 $('v38132Kpis').innerHTML=[['Valor das posições',money(val)],['P/L das posições',money(pnl)],['Ativos em carteira',String(h.length)],['Universo monitorado',String(v38132Universe().length)]].map(x=>`<div><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('');
 $('v38132Performance').innerHTML=h.sort((a,b)=>Number(b.current_value_eur||0)-Number(a.current_value_eur||0)).map(x=>`<div class="v38132-perf"><div><b>${esc(x.asset)}</b><small>${esc(x.account||'—')}</small></div><strong>${money(x.current_value_eur)}</strong><span class="${Number(x.pnl_eur)>=0?'gain':'loss'}">${money(x.pnl_eur)} • ${fmt(x.pnl_pct,2)}%</span></div>`).join('')||'<div class="v38132-empty">Nenhuma posição real neste filtro.</div>';
 $('v38132Universe').innerHTML=v38132Universe().sort((a,b)=>Number(b.promising_pct||0)-Number(a.promising_pct||0)).map(x=>`<tr><td><b>${esc(x.asset)}</b></td><td>${Number(x.current_value_eur||0)>0?money(x.current_value_eur):'—'}</td><td>${fmt(x.promising_pct,1)}</td><td>${fmt(x.opportunity,1)}</td><td>${fmt(x.entry,1)}</td><td>${fmt(x.asymmetry,1)}</td><td>${fmt(x.risk,1)}</td><td>${esc(x.action||'—')}</td></tr>`).join('');
}
async function v38132Refresh(){
 v38132Fill();v38132RenderTables();const hrs=Number($('v38132Period')?.value||24),asset=$('v38132Asset')?.value||'ALL',metric=$('v38132Metric')?.value||'pnl_eur';
 let rows=[];try{rows=await jsonFetch('/api/intraday?hours='+hrs)}catch(e){} if(!Array.isArray(rows))rows=rows.rows||rows.data||[];
 const held=new Set(v38132Held().map(x=>String(x.asset)));rows=rows.filter(r=>held.has(String(r.asset))&&(asset==='ALL'||String(r.asset)===asset));const g={};rows.forEach(r=>(g[r.asset]??=[]).push(r));
 const ds=Object.entries(g).map(([name,rr])=>({label:name,data:rr.map(r=>({x:new Date(r.timestamp).getTime(),y:Number(r[metric]||0)})).filter(q=>Number.isFinite(q.x)&&Number.isFinite(q.y)),borderWidth:2,pointRadius:2,tension:.25,fill:false}));
 if(v38132Chart){v38132Chart.destroy();v38132Chart=null}$('v38132ChartEmpty').textContent=ds.length?'':`Sem observações intraday reais para ${hrs}h neste filtro.`;if(!ds.length)return;
 v38132Chart=new Chart($('v38132Chart'),{type:'line',data:{datasets:ds},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'nearest',intersect:false},scales:{x:{type:'linear',min:Date.now()-hrs*3600000,max:Date.now(),ticks:{callback:v=>new Date(v).toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}},y:{ticks:{callback:v=>metric==='pnl_pct'?v+'%':'€'+Number(v).toFixed(1)}}}}});
}
const _v38132OldAnalytics=v38130Analytics;
v38130Analytics=function(){v38132Shell();setTimeout(v38132Refresh,0)};

/* V38133_UI */
function v38133BrainPanel(){
 const x=lastStatus||{},p=x.portfolio||{},b=p.brain_experimental||x.brain_experimental||{},sig=b.signals||[],exp=sig.filter(z=>z.experimental),cash=Number(p.cash_eur??b.cash_available_eur??0);
 return `<article class="card v38133-brain"><div class="card-head"><div><b>Brain experimental</b><span>canal paralelo • execução manual</span></div><span class="v38133-star" title="* = cálculo experimental ainda não consolidado. Não representa probabilidade.">*</span></div><div class="v38133-cash"><div><small>CAIXA ATIVO</small><b>${money(cash)}</b></div><span>${b.cash_state==='EXPERIMENTAL_ALLOCATION_AVAILABLE'?'há alocação experimental sugerida*':'aguardando oportunidade elegível'}</span></div>${exp.length?`<div class="v38133-list">${exp.sort((a,b)=>Number(b.promising_pct||0)-Number(a.promising_pct||0)).map(r=>`<div class="v38133-row"><div><b>${esc(r.asset)}</b><small>Motor: ${esc(r.production_action)}</small></div><strong>${esc(r.display_action)}</strong><span>${Number(r.experimental_cash_suggestion_eur||0)>0?'Aporte sugerido* '+money(r.experimental_cash_suggestion_eur):esc(r.rationale)}</span></div>`).join('')}</div>`:'<div class="v38133-empty">Nenhuma divergência experimental neste ciclo. O caixa continua sendo reavaliado.</div>'}<div class="v38133-foot">* sinal experimental / evidência não consolidada. Não altera a ação operacional e não executa ordens automaticamente.</div></article>`;
}
function v38133Mount(){const dash=document.getElementById('view-dashboard');if(!dash)return;let host=document.getElementById('v38133Host');if(!host){host=document.createElement('div');host.id='v38133Host';dash.appendChild(host)}host.innerHTML=v38133BrainPanel()}
const _v38133LoadStatus=loadStatus;loadStatus=async function(force=false){await _v38133LoadStatus(force);v38133Mount()}
document.addEventListener('DOMContentLoaded',()=>setTimeout(v38133Mount,500));

// V381310 route wrapper
const _v381310ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
 if(name==='learning'){
  document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));
  document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
  (button||document.querySelector('[data-target="learning"]'))?.classList.add('active');
  v381310Learning(); window.scrollTo({top:0,behavior:'smooth'}); return;
 }
 return _v381310ShowExperienceView(name,button);
}


/* V38141_OPPORTUNITY_COCKPIT_RESPONSIVE_SIDEBAR — read-only presentation */
function v38141N(v,d=1){const n=Number(v);return Number.isFinite(n)?n.toFixed(d):'—'}
function v38141M(v){const n=Number(v);return Number.isFinite(n)?new Intl.NumberFormat('pt-PT',{style:'currency',currency:'EUR'}).format(n):'—'}
function v38141AC(a){a=String(a||'').toUpperCase();return a.startsWith('COMPRE')?'buy':a.startsWith('VENDA')?'sell':a.startsWith('REALIZE')?'realize':'watch'}
function v38141Lane(x){x=String(x||'NONE').toUpperCase();return x==='CONSOLIDATED'?'Consolidado':x==='EXPERIMENTAL'?'Experimental *':'Caixa em espera'}
/* V38160_OPPORTUNITY_RANKING_CAPITAL_COMPETITION_UI */
function v38160Competition(x){
 const c=x?.capital_competition||{},n=Number(c.eligible_in_lane||0),r=Number(c.rank_in_lane||0),share=Number(c.allocation_share_pct||0);
 if(!r||!n)return '';
 const why=n===1?'100% do caixa sugerido porque não há outro candidato elegível nesta faixa; isto não representa tamanho ideal de posição.':`${share.toFixed(1)}% do caixa sugerido pela competição proporcional entre ${n} candidatos elegíveis.`;
 return `<div class="v38160-comp"><span>Prioridade relativa <b>${r} de ${n}</b></span><span>Participação no caixa <b>${share.toFixed(1)}%</b></span><small>${why}</small></div>`;
}
function v38141Render(o){
 const rows=Array.isArray(o?.opportunities)?o.opportunities:[];
 const rank=x=>String(x.decision_lane||'')==='CONSOLIDATED'?0:String(x.decision_lane||'')==='EXPERIMENTAL'?1:2;
 const all=[...rows].sort((a,b)=>rank(a)-rank(b)||Number(b.suggested_allocation_eur||0)-Number(a.suggested_allocation_eur||0)||Number(b.promising_pct||0)-Number(a.promising_pct||0));
 const act=all.filter(x=>rank(x)<2);
 const k=`<div class="v38141-kpis"><div><small>Caixa disponível</small><b>${v38141M(o.cash_available_eur)}</b><span>100% avaliado • sem investimento forçado</span></div><div><small>Faixa de decisão</small><b>${esc(v38141Lane(o.allocation_lane))}</b><span>consolidado tem prioridade</span></div><div><small>Alocação sugerida</small><b>${v38141M(o.allocated_cash_eur)}</b><span>execução ${esc(o.execution||'MANUAL_ONLY')}</span></div><div><small>Caixa em espera</small><b>${v38141M(o.unallocated_cash_eur)}</b><span>permanece líquido sem oportunidade elegível</span></div></div>`;
 const help=`<div class="v38141-help"><b>Como interpretar</b><span><strong>*</strong> = evidência ainda não consolidada; não significa probabilidade menor.</span><span><strong>Qualidade da evidência</strong> não é probabilidade de acerto.</span><span>Execução manual; sem promoção automática.</span></div>`;
 const focus=act.length?`<article class="card"><div class="card-head v38141-cardhead"><div class="v38141-headcopy"><b>Oportunidades elegíveis agora</b><small>Motor + Brain + caixa real</small><em>Consolidado tem prioridade sobre Experimental *</em></div><span class="v38141-count">${act.length}</span></div><div class="v38141-focus">${act.map(x=>`<div class="v38141-fcard ${String(x.decision_lane||'').toLowerCase()}"><div class="v38141-fhead"><div><b>${esc(x.asset||'—')}</b><small>${esc(x.decision_lane||'')}</small></div><span class="action-badge ${v38141AC(x.display_action)}">${esc(x.display_action||'—')}</span></div><strong>${v38141M(x.suggested_allocation_eur)}</strong><div class="v381421-allocation-row"><small>alocação sugerida</small><button class="v38142-why" data-json="${encodeURIComponent(JSON.stringify(x))}" onclick="v38142Why(this)">Por que este sinal?</button></div>${v38160Competition(x)}<div class="v38141-mini"><span>KPI<b>${v38141N(x.promising_pct)}</b></span><span>OPP<b>${v38141N(x.opportunity)}</b></span><span>ENT<b>${v38141N(x.entry)}</b></span><span>ASY<b>${v38141N(x.asymmetry)}</b></span><span>RISK<b>${v38141N(x.risk)}</b></span></div><p>Motor: <b>${esc(x.production_action||'—')}</b> • Brain: <b>${esc(x.brain_action||'—')}${x.experimental?' *':''}</b> • Posição: <b>${x.has_position?'SIM':'NÃO'}</b></p></div>`).join('')}</div></article>`:`<article class="card"><div class="v38141-empty"><b>Nenhuma oportunidade elegível neste ciclo.</b><span>O caixa permanece em espera; o Porquinho não força investimento.</span></div></article>`;
 const table=`<article class="card"><div class="card-head v38141-cardhead"><div class="v38141-headcopy"><b>Universo monitorado</b><small>Motor × Brain experimental × evidência</small></div><span class="v38141-count">${all.length} ativos</span></div><div class="v38141-twrap"><table class="v38141-table"><thead><tr><th>Ativo</th><th>Faixa</th><th>Motor</th><th>Brain</th><th>KPI</th><th>OPP</th><th>ENT</th><th>ASY</th><th>RISK</th><th>Evidência</th><th>Posição</th><th>Sugestão</th></tr></thead><tbody>${all.map(x=>`<tr><td><b>${esc(x.asset||'—')}</b></td><td>${esc(x.decision_lane||'MONITOR')}</td><td>${esc(x.production_action||'—')}</td><td>${esc(x.brain_action||'—')}${x.experimental?' *':''}</td><td>${v38141N(x.promising_pct)}</td><td>${v38141N(x.opportunity)}</td><td>${v38141N(x.entry)}</td><td>${v38141N(x.asymmetry)}</td><td>${v38141N(x.risk)}</td><td>${esc(x.evidence_status||'—')}</td><td>${x.has_position?'SIM':'NÃO'}</td><td><b>${Number(x.suggested_allocation_eur||0)>0?v38141M(x.suggested_allocation_eur):'—'}</b></td></tr>`).join('')}</tbody></table></div></article>`;
 return `<div class="v38141">${k}${help}${focus}${table}<div class="v38141-foot">${esc(o.schema||'—')} • ${esc(o.mode||'—')} • confidence = ${esc(o.confidence_semantics||'EVIDENCE_QUALITY_NOT_PROBABILITY')} • produção ${esc(o.production_effect||'NONE')}</div></div>`;
}
async function v38141Opportunities(button){
 document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));(button||document.querySelector('[data-target="opportunities"]'))?.classList.add('active');
 const host=$('view-placeholder');host.classList.add('active-view');$('viewTitle').textContent='Oportunidades';$('viewDescription').textContent='Motor + Brain experimental + caixa real + universo monitorado.';$('viewContent').innerHTML='<div class="v38141-loading">Carregando snapshot real…</div>';
 try{const s=await jsonFetch('/api/status');const o=s?.snapshot?.opportunity_intelligence;if(!o||o.schema!=='porquinho.opportunity-intelligence/1.0')throw Error('contrato opportunity-intelligence indisponível');$('viewContent').innerHTML=v38141Render(o)}catch(e){$('viewContent').innerHTML=`<div class="card v38141-error"><b>Oportunidades indisponíveis</b><span>${esc(e.message||String(e))}</span></div>`}
}
const _v38141_showExperienceView=showExperienceView;showExperienceView=function(name,button){if(name==='opportunities'){v38141Opportunities(button);return}return _v38141_showExperienceView(name,button)};

/* V38141R3_OPPORTUNITY_COCKPIT_UI_POLISH - presentation only */

/* V38142_OPPORTUNITY_EXPLAINABILITY */
/* V38191R2_OUTCOME_MODAL_LIVE_STATUS */
async function v38142Why(btn){
 let x={};try{x=JSON.parse(decodeURIComponent(btn.dataset.json||''))}catch(e){console.error('V381421 explainability payload',e);return}
 const e=x.explainability||{},fav=e.favorable_factors||[],lim=e.limiting_factors||[],fail=e.production_failed_gates||[],feat=e.raw_features||{};
 const ls=((lastStatus||{}).snapshot||{}).opportunity_lifecycle||((lastStatus||{}).opportunity_lifecycle)||{};
 const life=(ls.assets||{})[String(x.asset||'')]||null;
 const ms=((lastStatus||{}).snapshot||{}).opportunity_state_memory||((lastStatus||{}).opportunity_state_memory)||{};
 const memory=(ms.assets||{})[String(x.asset||'')]||null;
 let statusForModal=lastStatus||{};
 try{statusForModal=await jsonFetch('/api/status');lastStatus=statusForModal}catch(_e){}
 const os=((statusForModal||{}).snapshot||{}).opportunity_outcomes||((statusForModal||{}).opportunity_outcomes)||{};
 const outcome=(os.opportunities||[]).find(q=>String(q?.asset||'').toUpperCase()===String(x.asset||'').toUpperCase())||null;
 const sm=((statusForModal||{}).snapshot||{}).opportunity_state_model||((statusForModal||{}).opportunity_state_model)||{};
 const stateModel=(sm.assets||{})[String(x.asset||'').toUpperCase()]||null;
 const ce=((statusForModal||{}).snapshot||{}).opportunity_episode_continuity||((statusForModal||{}).opportunity_episode_continuity)||{};
 const episodeHistory=v38211EpisodeHistory(ce,String(x.asset||'').toUpperCase());
 const dur=life&&Number.isFinite(Number(life.duration_seconds))?Number(life.duration_seconds):null;
 const durText=dur==null?'—':(dur>=86400?`${Math.floor(dur/86400)}d ${Math.floor((dur%86400)/3600)}h`:`${Math.floor(dur/3600)}h ${Math.floor((dur%3600)/60)}min`);
 const dateText=v=>{if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?'—':d.toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC'};
 const metric=k=>life?.metrics?.[k]||{};
 const mrow=k=>{const m=metric(k),hist=m.history_available===true,cur=m.current==null?'—':v38141N(m.current),delta=m.delta==null?'—':((Number(m.delta)>0?'+':'')+v38141N(m.delta));return `<div class="v381431-metric"><b>${esc(k)}</b><span>${hist?`${v38141N(m.start)} → ${cur}`:`${cur} atual`}</span><em>${hist?delta:'histórico indisponível'}</em></div>`};
 const lifecycle=life?`<section class="v381431-life"><div class="v381431-lifehead"><div><h4>Histórico desta oportunidade</h4><small>persistência temporal • somente leitura</small></div><span>${esc(durText)} • ${Number(life.consecutive_observations||0)} observações</span></div><div class="v381431-meta"><span>Desde <b>${esc(dateText(life.started_at))}</b></span><span>Última observação <b>${esc(dateText(life.last_observed_at))}</b></span></div><div class="v381431-metrics">${['KPI','OPP','ENT','ASY','RISK'].map(mrow).join('')}</div><div class="v381431-note">${esc(life.independence_note||'Repeated intraday observations describe persistence; they are not independent evidence.')} Histórico ausente permanece indisponível; nenhum valor é inventado.</div></section>`:`<section class="v381431-life"><h4>Histórico desta oportunidade</h4><div class="v381431-unavailable">Lifecycle indisponível para este ativo no snapshot atual. Nenhum histórico foi inferido.</div></section>`;
 const o=document.createElement('div');o.className='v38142-overlay';
 o.innerHTML=`<div class="v38142-modal"><button class="v38142-close">X</button><div class="v38142-title"><div><b>${esc(x.asset||'—')}</b><small>Explicação do sinal atual • somente leitura</small></div><span class="action-badge ${v38141AC(x.display_action)}">${esc(x.display_action||'—')}</span></div><section><h4>Motor × Brain</h4><p>Motor: <b>${esc(x.production_action||'—')}</b> • Brain: <b>${esc(x.brain_action||'—')}${x.experimental?' *':''}</b></p><small>${esc(e.brain_rule||'—')}</small></section><div class="v38142-cols"><section><h4>Fatores favoráveis ao Brain</h4>${fav.map(v=>`<span class="ok">✓ ${esc(v)}</span>`).join('')||'<span>—</span>'}</section><section><h4>Limitadores</h4>${lim.map(v=>`<span class="warn">• ${esc(v)}</span>`).join('')||'<span>Nenhum limitador na regra experimental.</span>'}</section></div><section><h4>Motor de produção</h4>${fail.length?fail.map(v=>`<span class="warn">• ${esc(v)}</span>`).join(''):`<span>${x.production_action==='COMPRE'?'Os gates de compra do Motor foram satisfeitos.':'Os três gates básicos de compra não explicam isoladamente a ação; a decisão exibida continua exatamente a calculada pelo Motor.'}</span>`}</section><section><h4>Features observadas</h4><div class="v38142-features">${Object.entries(feat).map(([k,v])=>`<span>${esc(k)}<b>${v==null?'—':v38141N(v)}</b></span>`).join('')}</div></section><section><h4>Alocação sugerida</h4><p><b>${v38141M(x.suggested_allocation_eur)}</b></p><small>${esc(e.allocation_formula||'—')}</small>${x.capital_competition?.rank_in_lane?`<div class="v38160-modalcomp"><span>Prioridade relativa: <b>${Number(x.capital_competition.rank_in_lane)} de ${Number(x.capital_competition.eligible_in_lane||0)}</b></span><span>Participação no caixa: <b>${v38141N(x.capital_competition.allocation_share_pct)}%</b></span><em>${Number(x.capital_competition.eligible_in_lane||0)===1?'100% ocorre apenas por não haver concorrente elegível nesta faixa; não é uma recomendação de tamanho ideal de posição.':'A divisão é proporcional à fórmula existente entre os candidatos elegíveis da faixa selecionada.'}</em></div>`:''}</section>${stateModel?v38201StateCockpit(stateModel):''}${episodeHistory}${lifecycle}${life?v38171Dynamics(life):''}${memory?v38181StateMemory(memory):''}${outcome?v38191Outcome(outcome,os):''}${life?v38150Evolution(life):''}<div class="v38142-note">* = evidência não consolidada, não probabilidade menor. Explicação descritiva: não altera ação, pesos, thresholds, carteira ou ledger. Execução manual.</div></div>`;
 document.body.appendChild(o);v38150Init(o);o.querySelector('.v38142-close').onclick=()=>o.remove();o.onclick=ev=>{if(ev.target===o)o.remove()};
}

/* V381421_EXPLAINABILITY_UI_FIX — presentation/payload transport only */

/* V38150_OPPORTUNITY_EVOLUTION_UI — descriptive only */
/* V38150_OPPORTUNITY_EVOLUTION_UI — descriptive only */
/* V38171_DYNAMICS_COCKPIT - presentation only */
/* V38181_STATE_MEMORY_COCKPIT */
function v38181StateMemory(mem){
 if(!mem)return '';
 const tr=mem.transitions||[],cur=mem.current_state||'INSUFFICIENT',per=mem.persistence_label||'INSUFFICIENT',run=Number(mem.current_run_observations||0);
 const lab={FORTALECENDO:'Fortalecendo',DETERIORANDO:'Deteriorando',ESTAVEL:'Estável',INSUFFICIENT:'Insuficiente'};
 const fmt=t=>{try{return new Date(t).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC'}catch(e){return '—'}};
 const items=tr.map((t,i)=>`<div class="v38181-step"><span class="v38181-dot ${(t.to_state||'').toLowerCase()}"></span><div><b>${lab[t.to_state]||t.to_state}</b><small>${fmt(t.observed_at)} · ${t.complete_observations} obs. completas</small></div></div>${i<tr.length-1?'<span class="v38181-arrow">→</span>':''}`).join('');
 const pt=per==='PERSISTENT'?`Persistente ×${run}`:(per==='RECENT'?`Recente ×${run}`:'Ainda insuficiente');
 return `<div class="v38181-memory"><div class="v38181-memory-head"><div><h4>Memória da dinâmica</h4><small>mudanças de estado reconstruídas do episódio</small></div><span class="v38181-persist ${per.toLowerCase()}">${pt}</span></div><div class="v38181-flow">${items||'<span class="v38181-empty">Ainda não há transição classificável.</span>'}</div><div class="v38181-memory-note">Estado atual: <b>${lab[cur]||cur}</b>. Persistência significa continuidade em observações intradiárias consecutivas; não representa evidências independentes. Esta memória não altera sinal, ranking ou alocação.</div></div>`;
}

function v38171Dynamics(life){
 const d=life?.dynamics||{},state=d.state||'INSUFFICIENT',comps=d.components||{};
 const labels={KPI:'KPI',OPP:'OPP',ENT:'ENT',ASY:'ASY',RISK:'RISK'};
 const dirLabel={FAVORABLE:'favorável',UNFAVORABLE:'desfavorável',STABLE:'estável'};
 const rows=Object.keys(labels).map(k=>{
   const c=comps[k];if(!c)return '';
   const cls=(c.direction||'').toLowerCase(),delta=Number(c.favorable_delta);
   return `<div class="v38171-component ${cls}"><span>${k}</span><b>${dirLabel[c.direction]||c.direction||'—'}</b><small>${Number.isFinite(delta)?`${delta>=0?'+':''}${delta.toFixed(2)} direção favorável`:'—'}</small></div>`;
 }).join('');
 const stateClass=state.toLowerCase(),obs=Number(d.available_observations||0),min=Number(d.minimum_observations||0);
 const summary=state==='INSUFFICIENT'?`Dados insuficientes: ${obs}/${min} observações completas.`:`Saldo direcional ${Number(d.net_direction||0)>=0?'+':''}${Number(d.net_direction||0)} • ${obs} observações completas`;
 return `<div class="v38171-dyn"><div class="v38171-head"><div><h4>Dinâmica da oportunidade</h4><small>leitura temporal descritiva • não altera o sinal</small></div><span class="v38171-state ${stateClass}">${state}</span></div><div class="v38171-summary">${summary}</div>${rows?`<div class="v38171-components">${rows}</div>`:''}<div class="v38171-note">Compara a média das 3 primeiras com as 3 últimas observações completas. RISK tem orientação inversa. Deadband: ${Number(d.deadband_score_points||0.25).toFixed(2)} ponto. As observações descrevem persistência temporal e não são evidências independentes.</div></div>`;
}

function v38150Evolution(life){
 const evo=life?.evolution||{},pts=Array.isArray(evo.points)?evo.points:[],cov=evo.coverage||{},keys=['KPI','OPP','ENT','ASY','RISK'];
 if(!pts.length)return `<div class="v38150-empty">Evolução temporal ainda indisponível. Nenhum ponto foi inferido.</div>`;
 const data=encodeURIComponent(JSON.stringify({points:pts,coverage:cov,capture_boundary_at:evo.capture_boundary_at||null}));
 return `<div class="v38150-evo"><div class="v38150-evohead"><div><h4>Evolução da oportunidade</h4><small>observações reais • sem interpolação</small></div><div class="v38150-tabs">${['ALL',...keys].map((k,i)=>`<button class="${i===0?'active':''}" data-k="${k}">${k==='ALL'?'Todas':k}</button>`).join('')}</div></div><div class="v38150-chart" data-evo="${data}"></div><div class="v38150-coverage">${keys.map(k=>{const c=cov[k]||{};return `<span><b>${k}</b> ${Number(c.points||0)} obs.${c.complete_for_episode?' • episódio completo':' • captura parcial'}</span>`}).join('')}</div><div class="v38150-note">Cada ponto representa uma observação registrada, não uma evidência independente. Linhas começam somente na primeira observação disponível; ausências anteriores permanecem ausentes.</div></div>`;
}
/* V38151_EVOLUTION_POLISH_CAPTURE_BOUNDARY */
function v38150Draw(box,key='ALL'){
 let d={};try{d=JSON.parse(decodeURIComponent(box.dataset.evo||''))}catch(e){return}
 const pts=d.points||[],keys=key==='ALL'?['KPI','OPP','ENT','ASY','RISK']:[key],W=720,H=210,L=38,R=12,T=12,B=28,iw=W-L-R,ih=H-T-B;
 const times=pts.map(p=>new Date(p.observed_at).getTime()).filter(Number.isFinite);if(!times.length)return;
 const t0=Math.min(...times),t1=Math.max(...times),span=Math.max(1,t1-t0),y=v=>T+(100-Number(v))/100*ih,x=t=>L+(t-t0)/span*iw;
 const bt=d.capture_boundary_at?new Date(d.capture_boundary_at).getTime():NaN;
 const boundary=Number.isFinite(bt)&&bt>=t0&&bt<=t1?(()=>{const bx=x(bt),right=bx<(W*.62);return `<line class="v38151-boundary" x1="${bx}" y1="${T}" x2="${bx}" y2="${H-B}"/><text class="v38151-boundary-label" x="${right?bx+5:bx-5}" y="${T+10}" text-anchor="${right?'start':'end'}">captura completa disponível daqui em diante</text>`})():'';
 const grid=[0,25,50,75,100].map(v=>`<line x1="${L}" y1="${y(v)}" x2="${W-R}" y2="${y(v)}"/><text x="${L-7}" y="${y(v)+3}" text-anchor="end">${v}</text>`).join('');
 const paths=keys.map(k=>{let seg=[],out=[],prev=-2;pts.forEach((p,i)=>{if(p[k]==null){if(seg.length){out.push(seg);seg=[]}prev=-2;return}const q=[x(new Date(p.observed_at).getTime()),y(p[k])];if(prev!==i-1&&seg.length){out.push(seg);seg=[]}seg.push(q);prev=i});if(seg.length)out.push(seg);return out.map(a=>`<polyline class="v38150-line k-${k}" points="${a.map(q=>q[0]+','+q[1]).join(' ')}"/>`).join('')}).join('');
 const dots=keys.map(k=>pts.filter(p=>p[k]!=null).map(p=>`<circle class="v38150-dot k-${k}" cx="${x(new Date(p.observed_at).getTime())}" cy="${y(p[k])}" r="2.6"><title>${k} ${p[k]} • ${new Date(p.observed_at).toLocaleString('pt-PT',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'})} UTC</title></circle>`).join('')).join('');
 const fmt=t=>new Date(t).toLocaleString('pt-PT',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'});
 box.innerHTML=`<svg viewBox="0 0 ${W} ${H}" role="img"><g class="v38150-grid">${grid}</g>${boundary}${paths}${dots}<text class="v38150-axis" x="${L}" y="${H-7}">${fmt(t0)}</text><text class="v38150-axis" x="${W-R}" y="${H-7}" text-anchor="end">${fmt(t1)} UTC</text></svg>`;
}
function v38150Init(root){
 root.querySelectorAll('.v38150-chart').forEach(b=>v38150Draw(b,'ALL'));
 root.querySelectorAll('.v38150-tabs button').forEach(btn=>btn.onclick=()=>{const wrap=btn.closest('.v38150-evo');wrap.querySelectorAll('.v38150-tabs button').forEach(x=>x.classList.remove('active'));btn.classList.add('active');v38150Draw(wrap.querySelector('.v38150-chart'),btn.dataset.k)});
}


/* V38211_OPPORTUNITY_EPISODE_HISTORY_COCKPIT - presentation only */
function v38211EpisodeHistory(env,asset){
 const rows=(env?.episodes||[]).filter(e=>String(e?.asset||'').toUpperCase()===String(asset||'').toUpperCase()).sort((a,b)=>String(a.started_at||'').localeCompare(String(b.started_at||'')));
 if(!rows.length)return `<div class="v38211-history"><div class="v38211-head"><div><h4>Histórico de episódios</h4><small>continuidade longitudinal • somente leitura</small></div><span>0 episódios</span></div><div class="v38211-empty">Nenhum episódio canônico disponível para este ativo. Nada foi inferido.</div></div>`;
 const dt=v=>{if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?'—':d.toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC'};
 const action=e=>e.display_action||(e.experimental?`${e.brain_action||'—'}*`:(e.production_action||e.brain_action||'—'));
 const cards=rows.map((e,i)=>{
   const cur=e.episode_phase==='CURRENT',act=action(e),ref=e.reference_price_status==='AVAILABLE'?'Referência disponível':'Aguardando referência';
   const outcome=Number(e.matured_horizons||0)>0?`${Number(e.matured_horizons)} horizonte(s) maduro(s)`:ref;
   return `<div class="v38211-episode ${cur?'current':'ended'}"><div class="v38211-top"><span class="v38211-index">${i+1}</span><span class="action-badge ${v38141AC(act)}">${esc(act)}</span><em>${cur?'ATUAL':'ENCERRADO'}</em></div><div class="v38211-actions"><span>Motor <b>${esc(e.production_action||'—')}</b></span><span>Brain <b>${esc(e.brain_action||'—')}${e.experimental?' *':''}</b></span></div><div class="v38211-time"><span>Início <b>${esc(dt(e.started_at))}</b></span><span>${cur?'Última observação':'Última observação antes da mudança'} <b>${esc(dt(e.last_observed_at))}</b></span></div><div class="v38211-bottom"><span>${Number(e.observation_count||0)} obs.</span><span>${esc(outcome)}</span><span>${Number(e.pending_horizons||0)} pend. · ${Number(e.matured_horizons||0)} mad. · ${Number(e.unavailable_horizons||0)} indisp.</span></div></div>`;
 }).join('<span class="v38211-arrow">→</span>');
 return `<div class="v38211-history"><div class="v38211-head"><div><h4>Histórico de episódios</h4><small>sequência canônica do Motor × Brain • continuidade longitudinal</small></div><span>${rows.length} episódio${rows.length===1?'':'s'}</span></div><div class="v38211-flow">${cards}</div><div class="v38211-note">“Encerrado” significa que um novo estado de decisão começou depois; a interface mostra a última observação real e não inventa uma data de término. Os resultados 30/60/90/180 permanecem vinculados ao episódio canônico mesmo após ele deixar a oportunidade ativa. Retornos são descritivos, não classificam acerto/erro e não alteram sinal, ranking ou alocação.</div></div>`;
}

/* V38191_OPPORTUNITY_OUTCOME_COCKPIT */
/* V38201_OPPORTUNITY_STATE_COCKPIT - presentation only */
function v38201StateCockpit(m){
 if(!m)return '';
 const sig=m.signal_state||{},obs=m.observation_state||{},dyn=m.dynamics_state||{},per=m.persistence_state||{},out=m.outcome_state||{};
 const stateLab={FORTALECENDO:'Fortalecendo',DETERIORANDO:'Deteriorando',ESTAVEL:'Estável',INSUFFICIENT:'Insuficiente'};
 const perLab={PERSISTENT:'Persistente',RECENT:'Recente',INSUFFICIENT:'Insuficiente'};
 const outLab={AWAITING_REFERENCE:'Aguardando referência',REFERENCE_AVAILABLE:'Referência disponível',HORIZONS_PENDING:'Horizontes pendentes',MATURED_AVAILABLE:'Resultado disponível',HORIZONS_UNAVAILABLE:'Horizontes indisponíveis'};
 const enough=obs.state==='SUFFICIENT_FOR_DESCRIPTIVE_DYNAMICS',n=Number(obs.complete_metric_observations||0),min=Number(obs.minimum_for_descriptive_dynamics||0),run=Number(per.current_run_observations||0);
 return `<div class="v38201-state"><div class="v38201-head"><div><h4>Estado da oportunidade</h4><small>síntese dos contratos existentes • somente leitura</small></div><span class="action-badge ${v38141AC(sig.display_action)}">${esc(sig.display_action||'—')}</span></div><div class="v38201-grid"><div><small>Sinal</small><b>${esc(sig.decision_lane||'—')}</b><span>Motor ${esc(sig.production_action||'—')} · Brain ${esc(sig.brain_action||'—')}${sig.experimental?' *':''}</span></div><div><small>Dinâmica</small><b>${esc(stateLab[dyn.state]||dyn.state||'—')}</b><span>${dyn.net_direction==null?'saldo indisponível':`saldo ${Number(dyn.net_direction)>=0?'+':''}${Number(dyn.net_direction)}`}</span></div><div><small>Persistência</small><b>${esc(perLab[per.label]||per.label||'—')}${run?` ×${run}`:''}</b><span>${esc(stateLab[per.state]||per.state||'—')}</span></div><div><small>Observação</small><b>${n} completas</b><span>${enough?'cobertura suficiente para dinâmica descritiva':`insuficiente • mínimo ${min}`}</span></div><div><small>Resultado</small><b>${esc(outLab[out.state]||out.state||'—')}</b><span>retorno futuro descritivo; não classifica acerto/erro</span></div></div><div class="v38201-note">Esta síntese não cria um novo sinal. Dinâmica, persistência e resultados não alteram decisão, ranking ou alocação. Observações intradiárias repetidas descrevem continuidade e não são evidências independentes.</div></div>`;
}

function v38191Outcome(o,env){
 if(!o)return '';
 const dt=v=>{if(!v)return '—';try{return new Date(v).toLocaleString('pt-PT',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC'}catch(e){return '—'}};
 const day=v=>{if(!v)return '—';const d=new Date(String(v)+'T00:00:00Z');return Number.isNaN(d.getTime())?esc(v):d.toLocaleDateString('pt-PT',{day:'2-digit',month:'2-digit',year:'numeric',timeZone:'UTC'})};
 const money=v=>v==null?'—':'€'+Number(v).toLocaleString('pt-PT',{minimumFractionDigits:2,maximumFractionDigits:8});
 const reason=o.reason==='REFERENCE_PRICE_UNAVAILABLE_AFTER_EPISODE_START'?'Aguardando a primeira observação diária de preço em um dia posterior ao início do episódio. O dado diário do mesmo dia não tem resolução temporal suficiente para provar que ocorreu depois do sinal.':(o.reason==='INVALID_EPISODE_START'?'Início do episódio inválido; nenhuma referência foi inferida.':(o.reason||'Referência ainda indisponível.'));
 const ref=o.reference_status==='AVAILABLE'?`<div class="v38191-ref available"><span>Referência disponível</span><b>${money(o.reference_price_eur)}</b><small>${day(o.reference_date)}${o.reference_source?' · '+esc(o.reference_source):''}</small></div>`:`<div class="v38191-ref waiting"><span>Aguardando referência</span><b>—</b><small>${esc(reason)}</small></div>`;
 const hs=Array.isArray(o.horizons)?o.horizons:[],by=new Map(hs.map(h=>[Number(h.horizon_days),h]));
 const cards=(env?.horizons_days||[30,60,90,180]).map(n=>{const h=by.get(Number(n));if(!h)return `<div class="v38191-h pending"><span>${n} dias</span><b>Aguardando referência</b><small>O horizonte só é calculado após existir preço de referência temporalmente válido.</small></div>`;const st=String(h.status||'UNAVAILABLE');if(st==='PENDING')return `<div class="v38191-h pending"><span>${n} dias</span><b>Pendente</b><small>Vencimento: ${esc(dt(h.due_at))}</small></div>`;if(st==='MATURED'){const r=Number(h.return_pct);return `<div class="v38191-h matured"><span>${n} dias</span><b>${Number.isFinite(r)?(r>=0?'+':'')+r.toFixed(2)+'%':'—'}</b><small>${day(h.maturity_date)} · retorno descritivo</small></div>`}return `<div class="v38191-h unavailable"><span>${n} dias</span><b>Indisponível</b><small>${esc(h.reason||'Preço de maturação indisponível dentro da janela contratual.')}</small></div>`}).join('');
 return `<div class="v38191-outcome"><div class="v38191-head"><div><h4>Resultado da oportunidade</h4><small>acompanhamento prospectivo • somente leitura</small></div><span>${esc(o.decision_lane||'—')} · ${esc(o.display_action||'—')}</span></div><div class="v38191-meta"><span>Episódio iniciado <b>${esc(dt(o.episode_started_at))}</b></span><span>Dinâmica na avaliação <b>${esc(o.dynamics_at_evaluation||'—')}</b></span><span>Memória <b>${esc(o.memory_state_at_evaluation||'—')}${o.memory_run_at_evaluation!=null?' ×'+Number(o.memory_run_at_evaluation):''}</b></span></div>${ref}<div class="v38191-horizons">${cards}</div><div class="v38191-note">30/60/90/180 dias usam o contrato existente: primeira observação registrada no vencimento ou até 3 dias depois. Retornos futuros são descritivos e não classificam a oportunidade como “acerto” ou “erro”. Nenhum valor é interpolado ou inventado. Esta seção não altera sinal, ranking ou alocação.</div></div>`;
}

/* V381431_OPPORTUNITY_LIFECYCLE_UI - presentation only; derived lifecycle */


/* V38230_OUTCOME_LEARNING_READINESS_COCKPIT */
function v38230N(v,d=0){const n=Number(v);return Number.isFinite(n)?n:d}
function v38230Pct(n,d){n=v38230N(n);d=v38230N(d);return d>0?Math.max(0,Math.min(100,n/d*100)):0}
function v38230GateLabel(k){const m={minimum_eligible_episodes:'Episódios maduros completos',minimum_distinct_assets:'Ativos distintos',minimum_episode_start_span_days:'Dispersão temporal',maximum_single_asset_share:'Concentração máxima'};return m[k]||k}
function v38230GateValue(k,g){const a=g?.actual,r=g?.required;if(k==='minimum_episode_start_span_days')return `${v38230N(a).toFixed(1)} / ${r} dias`;if(k==='maximum_single_asset_share')return `${(v38230N(a)*100).toFixed(0)}% / ≤ ${(v38230N(r)*100).toFixed(0)}%`;return `${v38230N(a)} / ${r}`}
function v38230GateProgress(k,g){const a=v38230N(g?.actual),r=v38230N(g?.required);if(k==='maximum_single_asset_share')return a===0?0:(a<=r?100:Math.max(5,100*r/a));return r>0?Math.min(100,100*a/r):0}
function v38230RenderGroup(g){const gates=g?.gates||{};const gateHtml=Object.entries(gates).map(([k,v])=>`<div class="v38230-gate ${v?.pass?'pass':'wait'}"><div><span>${esc(v38230GateLabel(k))}</span><b>${esc(v38230GateValue(k,v))}</b></div><div class="v38230-bar"><i style="width:${v38230GateProgress(k,v).toFixed(1)}%"></i></div></div>`).join('');return `<article class="v38230-group"><div class="v38230-grouphead"><div><b>${esc(g.brain_action||'—')}</b><span>${v38230N(g.horizon_days)} dias</span></div><em class="${g.status==='ELIGIBLE_FOR_DESCRIPTIVE_RESEARCH'?'eligible':'waiting'}">${g.status==='ELIGIBLE_FOR_DESCRIPTIVE_RESEARCH'?'ELEGÍVEL PARA PESQUISA':'NÃO ELEGÍVEL'}</em></div>${gateHtml}</article>`}
async function v381310Learning(){
 v38130Placeholder('Aprendizado / Brain','Evidência longitudinal, maturação e prontidão para pesquisa — observação, não execução.',`<div id="v381310Learning"><article class="card"><div class="card-head"><b>Carregando aprendizado…</b><span>somente leitura</span></div></article></div>`);
 const host=$('v381310Learning'); if(!host)return;
 try{
   const s=await jsonFetch('/api/status'); lastStatus=s;
   const f=s?.outcome_learning_foundation||s?.snapshot?.outcome_learning_foundation;
   const e=s?.outcome_evidence_eligibility||s?.snapshot?.outcome_evidence_eligibility;
   if(!f||f.schema!=='porquinho.outcome-learning-foundation/1.0')throw Error('contrato outcome-learning-foundation/1.0 indisponível');
   if(!e||e.schema!=='porquinho.outcome-evidence-eligibility-summary/1.0')throw Error('contrato outcome-evidence-eligibility-summary/1.0 indisponível');
   const total=v38230N(f.canonical_episode_count),complete=v38230N(f.complete_initial_feature_count),partial=v38230N(f.partial_initial_feature_count),unavail=v38230N(f.unavailable_initial_feature_count),matured=v38230N(f.matured_horizon_count);
   const horizons=total*4,pending=Math.max(0,horizons-matured),coverage=v38230Pct(complete,total);
   const groups=e.groups||[],eligible=v38230N(e.eligible_group_count);
   const state=eligible>0?'EVIDÊNCIA ELEGÍVEL PARA PESQUISA':(matured>0?'MATURAÇÃO EM AVALIAÇÃO':'ACUMULANDO EVIDÊNCIA');
   const horizonCards=[30,60,90,180].map(h=>{const gs=groups.filter(g=>Number(g.horizon_days)===h),n=gs.reduce((a,g)=>a+v38230N(g.eligible_episode_count),0),ok=gs.filter(g=>g.status==='ELIGIBLE_FOR_DESCRIPTIVE_RESEARCH').length;return `<div class="v38230-h"><span>${h} DIAS</span><b>${n}</b><small>episódios elegíveis • ${ok} grupo(s) aptos</small></div>`}).join('');
   const groupHtml=groups.map(v38230RenderGroup).join('')||'<div class="v381310-empty">Nenhum grupo de elegibilidade disponível.</div>';
   host.innerHTML=`<section class="v38230-hero"><div><small>OUTCOME LEARNING READINESS</small><h2>${esc(state)}</h2><p>O Brain está coletando episódios e aguardando Outcomes temporalmente válidos. Elegibilidade para pesquisa não significa aprendizado consolidado nem autorização de produção.</p></div><span class="v38230-readonly">READ-ONLY</span></section>
   <section class="v38230-kpis"><div><small>EPISÓDIOS CANÔNICOS</small><b>${total}</b><span>unidade independente de evidência</span></div><div><small>FEATURES INICIAIS COMPLETAS</small><b>${complete}</b><span>${coverage.toFixed(1)}% • ${partial} parciais • ${unavail} indisponíveis</span></div><div><small>OUTCOMES MADUROS</small><b>${matured}</b><span>${pending} avaliações ainda pendentes</span></div><div><small>GRUPOS ELEGÍVEIS</small><b>${eligible}</b><span>${v38230N(e.not_eligible_group_count)} ainda não elegíveis</span></div></section>
   <article class="card v38230-stage"><div class="card-head"><b>Onde estamos no aprendizado</b><span>separação semântica</span></div><div class="v38230-stages"><div class="active"><i>1</i><b>Dados coletados</b><span>${total} episódios canônicos registrados</span></div><div class="${matured>0?'active':''}"><i>2</i><b>Evidência elegível</b><span>exige Outcome maduro + features completas + gates</span></div><div class="${eligible>0?'active':''}"><i>3</i><b>Pesquisa descritiva</b><span>elegibilidade não promove modelo</span></div><div><i>4</i><b>Aprendizado validado</b><span>não disponível nesta fase</span></div></div></article>
   <section class="v38230-grid"><article class="card"><div class="card-head"><b>Cobertura dos episódios</b><span>primeira observação • sem backfill</span></div><div class="v38230-coverage"><div class="v38230-donut" style="--pct:${coverage.toFixed(1)}"><strong>${coverage.toFixed(0)}%</strong><span>completos</span></div><div><p><b>${complete}</b> completos</p><p><b>${partial}</b> parciais</p><p><b>${unavail}</b> indisponíveis</p><small>Dados históricos ausentes permanecem indisponíveis; não são inventados.</small></div></div></article><article class="card"><div class="card-head"><b>Horizontes de Outcome</b><span>30 • 60 • 90 • 180 dias</span></div><div class="v38230-horizons">${horizonCards}</div></article></section>
   <article class="card v38230-wide"><div class="card-head"><b>Prontidão por Brain Action × horizonte</b><span>critérios fixados antes do primeiro Outcome maduro</span></div><div class="v38230-groups">${groupHtml}</div><div class="v38230-contract">Contrato: ≥ ${e.contract?.minimum_eligible_episodes??'—'} episódios • ≥ ${e.contract?.minimum_distinct_assets??'—'} ativos • ≥ ${e.contract?.minimum_episode_start_span_days??'—'} dias • concentração ≤ ${Number(e.contract?.maximum_single_asset_share||0)*100}%.</div></article>
   <div class="v38230-note"><b>Como interpretar:</b> observações intradiárias repetidas mostram persistência, mas não contam como evidências independentes. <b>Confidence</b> significa qualidade da evidência, não probabilidade de acerto. Retornos futuros são descritivos, não classificação automática de sucesso. Nenhuma informação desta tela altera Motor, Brain, ranking, alocação, pesos, thresholds, carteira ou ledger.</div>`;
 }catch(err){if(host)host.innerHTML=`<article class="card"><div class="card-head"><b>Aprendizado indisponível</b><span>fail closed</span></div><p class="muted">${esc(err.message||String(err))}</p></article>`}
}



/* V38240_PORTFOLIO_ACCOUNTS_COCKPIT */
function v38240Held(p){return (p?.scores||[]).filter(x=>Number(x.current_value_eur||0)>0||Number(x.current_weight_pct||0)>0)}
function v38240AccountMap(p){const out={};for(const x of v38240Held(p)){const a=String(x.account||'Sem conta');(out[a]??=[]).push(x)}return out}
function v38240BankMark(a){const k=String(a||'').toUpperCase();if(k.includes('N26'))return '<span class="v38240-bank n26">N26</span>';if(k.includes('REVOLUT'))return '<span class="v38240-bank rev">R</span>';return `<span class="v38240-bank">${esc(k.slice(0,2)||'—')}</span>`}
function v38240PnlClass(n){return Number(n)>=0?'gain':'loss'}
function v382401PositionBasis(x){return Number(x.current_value_eur||0)-Number(x.pnl_eur||0)}

function v38240Portfolio(){
 const p=(lastStatus||{}).portfolio||{},held=v38240Held(p),by=v38240AccountMap(p),positions=held.slice().sort((a,b)=>Number(b.current_value_eur||0)-Number(a.current_value_eur||0));
 const accounts=Object.entries(by).map(([name,items])=>({name,items,value:items.reduce((z,x)=>z+Number(x.current_value_eur||0),0),pnl:items.reduce((z,x)=>z+Number(x.pnl_eur||0),0)})).sort((a,b)=>b.value-a.value);
 const posValue=positions.reduce((z,x)=>z+Number(x.current_value_eur||0),0),cash=Number(p.cash_eur||0),wealth=Number(p.value_eur||0)||posValue+cash;
 $('portfolioMetricsV361').innerHTML=`<div class="v38240-kpis"><div><small>PATRIMÔNIO</small><b>${money(wealth)}</b><span>posições + caixa reconhecido</span></div><div><small>POSIÇÕES REAIS</small><b>${money(posValue)}</b><span>${positions.length} ativo(s) com posição</span></div><div><small>INVESTIDO</small><b>${money(p.invested_eur)}</b><span>base de custo canônica</span></div><div><small>CAIXA</small><b>${money(cash)}</b><span>disponível reconhecido</span></div><div><small>P/L TOTAL</small><b class="${v38240PnlClass(p.pnl_eur)}">${money(p.pnl_eur)}</b><span>${fmt(p.pnl_pct,2)}%</span></div></div>`;
 $('portfolioPositionsV361').innerHTML=`<div class="v38240-layout"><section><div class="v38240-sectionhead"><div><b>Posições reais</b><span>somente ativos efetivamente em carteira</span></div><em>${positions.length} posições</em></div><div class="v38240-positiongrid">${positions.map(x=>`<article class="v38240-pos"><div class="v38240-poshead">${v38130AssetIcon(x.asset)}<div><b>${esc(x.asset)}</b><span>${esc(x.account||'Sem conta')}</span></div><strong>${money(x.current_value_eur)}</strong></div><div class="v38240-posstats"><span>Base da posição <b>${money(v382401PositionBasis(x))}</b></span><span>P/L <b class="${v38240PnlClass(x.pnl_eur)}">${money(x.pnl_eur)} • ${fmt(x.pnl_pct,2)}%</b></span><span>Peso <b>${fmt(x.current_weight_pct,1)}%</b></span><span>Alvo <b>${fmt(x.target_weight_pct,1)}%</b></span></div><div class="v38240-posfoot">${v366252ActionBadge(x)}<button onclick="v38941EditPosition('${esc(x.asset)}')">Editar posição</button></div></article>`).join('')||'<div class="muted">Nenhuma posição real reconhecida.</div>'}</div></section><aside><div class="v38240-sectionhead"><div><b>Por conta</b><span>consolidação das posições</span></div></div>${accounts.map(a=>`<article class="v38240-account">${v38240BankMark(a.name)}<div><b>${esc(a.name)}</b><span>${a.items.length} ativo(s)</span></div><strong>${money(a.value)}</strong><small class="${v38240PnlClass(a.pnl)}">P/L ${money(a.pnl)}</small></article>`).join('')||'<div class="muted">Sem contas com posições.</div>'}<article class="v38240-cash"><small>CAIXA FORA DAS POSIÇÕES</small><b>${money(cash)}</b><span>Não é distribuído artificialmente entre contas.</span></article></aside></div><div class="v38240-note">Carteira mostra somente posições reais. Ativos apenas monitorados continuam no Mercado/Oportunidades. Valores e P/L vêm do payload operacional existente; esta tela não recalcula sinais nem executa ordens.</div>`;
}
let v382421EntityRegistry=null;
async function v382421LoadEntities(){try{const r=await fetch('/api/account-entities',{cache:'no-store'}),j=await r.json();if(r.ok&&j.ok)v382421EntityRegistry=j.registry;}catch(e){}return v382421EntityRegistry}
function v382421EntityForLegacy(name){return (v382421EntityRegistry?.entities||[]).find(e=>e.legacy_account_value===name)||null}
async function v382421EditMetadata(id){
 const e=(v382421EntityRegistry?.entities||[]).find(x=>x.account_id===id);if(!e)return;
 const friendly=prompt('Nome amigável da conta (opcional):',e.friendly_name||'');if(friendly===null)return;
 const institution=prompt('Instituição — informe apenas se quiser registrá-la explicitamente:',e.institution_name||'');if(institution===null)return;
 const r=await fetch('/api/account-entities/'+encodeURIComponent(id)+'/metadata',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({friendly_name:friendly,institution_name:institution})});
 const j=await r.json();if(!r.ok||!j.ok){alert('Não foi possível salvar os metadados: '+(j.error||r.status));return}
 await v382421LoadEntities();v38240Accounts();
}
function v38242EntitySemantics(){return {layer:'INSTITUTION → ACCOUNT → POSITION',registry:'data/account_entities.json',role:'IDENTITY_METADATA_ONLY',positionAuthority:'data/portfolio.csv → account',historicalProvenance:'UNAVAILABLE_NOT_INVENTED'}}
function v38241AccountProvenance(x){
 const a=String(x?.account||'').trim();
 return {assignment:a&&a!=='N/A'&&a!=='—'?'CANONICAL_POSITION_ACCOUNT':'UNASSIGNED',source:'data/portfolio.csv',currency:'EUR',provenance:'ORIGIN_EVENT_NOT_RECORDED'};
}
async function v38240Accounts(){
 await v382421LoadEntities();
 const v38266reg=await v38265Registry();
 const p=(lastStatus||{}).portfolio||{},by=v38240AccountMap(p),entries=Object.entries(by).sort((a,b)=>b[1].reduce((z,x)=>z+Number(x.current_value_eur||0),0)-a[1].reduce((z,x)=>z+Number(x.current_value_eur||0),0));
 const posValue=entries.reduce((z,[,items])=>z+items.reduce((q,x)=>q+Number(x.current_value_eur||0),0),0),cash=Number(p.cash_eur||0);
 const assigned=entries.reduce((z,[,items])=>z+items.filter(x=>v38241AccountProvenance(x).assignment==='CANONICAL_POSITION_ACCOUNT').length,0),total=entries.reduce((z,[,items])=>z+items.length,0);
 v38130Placeholder('Contas e Bancos','Gestão das atribuições de conta já existentes na carteira. A posição continua sendo a fonte canônica; metadados ausentes não são inventados.',`
 <section class="v38266-account-actions"><div><small>REGISTRO UNIVERSAL</small><b>Instituições e contas</b><span>Uma autoridade para Brasil, Europa e futuros mercados.</span></div><div><button onclick="v38265OpenInstitution()">+ Instituição</button><button onclick="r21366bOpenCash('DEPOSIT')">+ Adicionar dinheiro</button><button onclick="r21366bOpenCash('WITHDRAWAL')">− Retirar dinheiro</button><button class="primary" onclick="v38265OpenAccount()">+ Conta</button></div></section>
 <section class="v38266-registry">${(v38266reg.institutions||[]).map(inst=>`<article class="card"><div class="card-head"><b>${esc(inst.name)}</b><span>${esc(inst.country)} • ${esc(inst.institution_type)}</span></div>${(v38266reg.accounts||[]).filter(a=>a.institution_id===inst.institution_id).map(a=>`<div class="v38130-row"><span>▤</span><b>${esc(a.name)}</b><span>${esc(a.currency)} • ${esc(a.account_type)} • ${esc(a.management_mode)} • ${esc(a.owner_profile||'UNSPECIFIED')}</span></div>`).join('')||'<span class="muted">Nenhuma conta cadastrada.</span>'}</article>`).join('')||'<article class="card"><span class="muted">Nenhuma instituição no registro universal. Os registros legados abaixo permanecem preservados e não foram migrados automaticamente.</span></article>'}</section>
 <section class="v38240-accountkpis v38241-kpis">
 <div><small>VALOR EM POSIÇÕES</small><b>${money(posValue)}</b><span>somente posições reais</span></div>
 <div><small>CONTAS COM POSIÇÕES</small><b>${entries.length}</b><span>derivadas das posições</span></div>
 <div><small>ATRIBUIÇÕES CANÔNICAS</small><b>${assigned}/${total}</b><span>campo account da posição</span></div>
 <div><small>CAIXA CONSOLIDADO</small><b>${money(cash)}</b><span>origem não rateada</span></div></section>
 <div class="v38241-contract">
 <div><b>Contrato de conta</b><span>A atribuição continua em <code>data/portfolio.csv → account</code>. Esta tela não cria uma segunda fonte de verdade.</span></div>
 <div><b>Moeda operacional</b><span>EUR • contrato atual do portfólio europeu</span></div>
 <div><b>Proveniência histórica</b><span>Não registrada por posição. Exibida como indisponível em vez de inferida.</span></div>
 <div><b>Execução</b><span>Alterações continuam manuais pelo fluxo existente de edição da posição.</span></div></div>
 <div class="v38240-bankgrid">${entries.map(([name,items])=>{const value=items.reduce((z,x)=>z+Number(x.current_value_eur||0),0),pnl=items.reduce((z,x)=>z+Number(x.pnl_eur||0),0);const ent=v382421EntityForLegacy(name),display=ent?.friendly_name||name,inst=ent?.institution_name||'Instituição não registrada';return `<article class="card v38240-bankcard"><div class="v38240-bankhead">${v38240BankMark(name)}<div><b>${esc(display)}</b><span>${esc(inst)} • ${items.length} posição(ões) real(is) • EUR</span><small>${esc(ent?.account_id||'identidade indisponível')} • ${esc(ent?.metadata_provenance||'sem provenance prospectiva')}</small></div><strong>${money(value)}</strong>${ent?`<button class="v382421-metaedit" onclick="v382421EditMetadata('${esc(ent.account_id)}')">Editar metadados</button>`:''}</div><div class="v38240-bankpnl"><span>P/L das posições</span><b class="${v38240PnlClass(pnl)}">${money(pnl)}</b></div>${items.slice().sort((a,b)=>Number(b.current_value_eur||0)-Number(a.current_value_eur||0)).map(x=>{const pr=v38241AccountProvenance(x);return `<div class="v38240-bankrow v38241-row">${v38130AssetIcon(x.asset)}<div><b>${esc(x.asset)}</b><span>${fmt(x.current_weight_pct,1)}% da carteira • ${esc(pr.assignment==='CANONICAL_POSITION_ACCOUNT'?'atribuição canônica':'sem atribuição')}</span><small>Origem histórica: indisponível</small></div><strong>${money(x.current_value_eur)}</strong><em class="${v38240PnlClass(x.pnl_eur)}">${money(x.pnl_eur)} • ${fmt(x.pnl_pct,2)}%</em><button onclick="v38941EditPosition('${esc(x.asset)}')">Editar conta</button></div>`}).join('')}</article>`}).join('')||'<article class="card"><span class="muted">Nenhuma conta com posição real retornada.</span></article>'}</div>
 <div class="v38240-note"><b>Caixa:</b> ${money(cash)} consolidado. Não é atribuído artificialmente a N26, Revolut ou outra instituição sem origem canônica explícita.</div>`)
}
const _v38240AccountsLegacy=v38130Accounts;v38130Accounts=function(){v38240Accounts()}


/* V382401_PORTFOLIO_COST_LAYOUT_FIX */
/* Presentation-only: position basis = canonical current_value_eur - canonical pnl_eur. No portfolio data is rewritten. */

/* V38241_ACCOUNT_PROVENANCE_FOUNDATION */
/* Read-mostly account management foundation. Canonical assignment remains portfolio.csv account; no second account registry. */

/* V38242_ACCOUNT_ENTITY_FOUNDATION */
/* Registry is identity metadata only. It does not own positions, cash, execution, scoring, or allocation. */

/* V382421_ACCOUNT_ENTITY_UI_METADATA */
/* Explicit metadata writes only; portfolio.csv account remains position authority. */

// V38265_BR_POSITION_REGISTRATION_UI
async function v38265Registry(){return await jsonFetch('/api/investment-registry')}
async function v38265Instruments(){return await jsonFetch('/api/instruments')}
function v38265Field(label,body){return `<label class="v38265-field"><span>${label}</span>${body}</label>`}
function v38265OpenInstitution(){openModal('Cadastrar instituição',`<div class="v38265-form">${v38265Field('Nome','<input id="v38265InstName" placeholder="Ex.: Itaú, XP, BTG Pactual">')}${v38265Field('País','<input id="v38265InstCountry" value="BR">')}${v38265Field('Tipo','<select id="v38265InstType"><option>BANK</option><option>BROKER</option><option>FINTECH</option><option>OTHER</option></select>')}<p class="v38265-note">Identidade institucional manual. Não importa posições nem executa transações.</p><button class="v38265-save" onclick="v38265SaveInstitution()">Salvar instituição</button></div>`)}
async function v38265SaveInstitution(){try{await jsonFetch('/api/investment-registry/institution',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('v38265InstName').value.trim(),country:$('v38265InstCountry').value.trim(),institution_type:$('v38265InstType').value})});closeModal();toast('Instituição cadastrada.')}catch(e){toast('Falha: '+e.message)}}
/* R21.201_CURRENCY_REGISTRY_UI */
async function v38265Currencies(){return await jsonFetch('/api/currency-registry')}
async function v38265OpenAccount(){try{const [r,cr]=await Promise.all([v38265Registry(),v38265Currencies()]),a=r.institutions||[],cc=(cr.currencies||[]).filter(x=>x.active);if(!a.length){toast('Cadastre primeiro uma instituição.');v38265OpenInstitution();return}openModal('Cadastrar conta de investimento',`<div class="v38265-form">${v38265Field('Instituição',`<select id="v38265AccInst">${a.map(x=>`<option value="${esc(x.institution_id)}">${esc(x.name)} • ${esc(x.country)}</option>`).join('')}</select>`)}${v38265Field('Nome','<input id="v38265AccName" placeholder="Ex.: Conta investimentos">')}${v38265Field('Plano da conta (opcional)','<input id="v38265AccPlan" maxlength="120" placeholder="Nome do plano no banco ou corretora">')}${v38265Field('Tipo','<select id="v38265AccType"><option>INVESTMENT</option><option>BROKERAGE</option><option>BANK</option><option>OTHER</option></select>')}${v38265Field('Moeda',`<select id="v38265AccCurrency">${cc.map(x=>`<option value="${esc(x.currency_code)}">${esc(x.currency_code)} • ${esc(x.name)}</option>`).join('')}</select>`)}${v38265Field('Perfil do titular','<select id="v38265AccOwner"><option value="UNSPECIFIED">Não especificado</option><option value="PF">Pessoa física (PF)</option><option value="PJ">Pessoa jurídica (PJ)</option></select>')}<p class="v38265-note">Conta manual. O cadastro não movimenta dinheiro.</p><button class="v38265-save" onclick="v38265SaveAccount()">Salvar conta</button></div>`)}catch(e){toast('Falha: '+e.message)}}
async function v38265SaveAccount(){try{await jsonFetch('/api/investment-registry/account',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({institution_id:$('v38265AccInst').value,name:$('v38265AccName').value.trim(),account_type:$('v38265AccType').value,currency:$('v38265AccCurrency').value,owner_profile:$('v38265AccOwner').value,pricing_plan:$('v38265AccPlan').value.trim()||null})});closeModal();toast('Conta cadastrada.')}catch(e){toast('Falha: '+e.message)}}
async function v38265OpenPosition(){try{const [r,i]=await Promise.all([v38265Registry(),v38265Instruments()]),a=r.accounts||[],n=(i.instruments||[]).filter(x=>x.instrument_id && String(x.asset_class||'').toUpperCase()==='EQUITY' && ['B3','BR_B3_EQUITY'].includes(String(x.market||'').toUpperCase()));if(!a.length){toast('Cadastre primeiro uma conta.');v38265OpenAccount();return}const today=new Date().toISOString().slice(0,10);openModal('Cadastrar posição • Ações B3',`<div class="v38265-form">${v38265Field('Conta',`<select id="v38265PosAccount">${a.map(x=>`<option value="${esc(x.account_id)}">${esc(x.name)} • ${esc(x.currency)}</option>`).join('')}</select>`)}${v38265Field('Instrumento',`<select id="v38265PosInstrument" onchange="v38265SyncCurrency()">${n.map(x=>`<option value="${esc(x.instrument_id)}" data-currency="${esc(x.currency||'')}">${esc(x.symbol)} • ${esc(x.asset_class||'EQUITY')}</option>`).join('')}</select>`)}${v38265Field('Quantidade','<input id="v38265PosQty" type="number" min="0" step="any">')}${v38265Field('Custo médio (opcional)','<input id="v38265PosCost" type="number" min="0" step="any">')}${v38265Field('Data da posição',`<input id="v38265PosAsOf" type="date" value="${today}">`)}${v38265Field('Moeda','<input id="v38265PosCurrency" maxlength="3" value="BRL">')}<p class="v38265-note">Registra posição já existente. Não cria COMPRA/VENDA, não escreve ledger e não habilita REALIZE.</p><button class="v38265-save" onclick="v38265SavePosition()">Registrar posição</button></div>`);v38265SyncCurrency()}catch(e){toast('Falha: '+e.message)}}
function v38265SyncCurrency(){const o=$('v38265PosInstrument')?.selectedOptions?.[0],c=o?.dataset?.currency;if(c&&$('v38265PosCurrency')){$('v38265PosCurrency').value=c;$('v38265PosCurrency').readOnly=true}else if($('v38265PosCurrency'))$('v38265PosCurrency').readOnly=false}
async function v38265SavePosition(){try{const cost=$('v38265PosCost').value.trim();await jsonFetch('/api/br-equity/positions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({account_id:$('v38265PosAccount').value,instrument_id:$('v38265PosInstrument').value,quantity:Number($('v38265PosQty').value),average_cost:cost===''?null:Number(cost),as_of:$('v38265PosAsOf').value,currency:$('v38265PosCurrency').value.trim().toUpperCase()})});closeModal();toast('Posição registrada e projeção verificada atualizada.');if(typeof v3710LoadEquity==='function')await v3710LoadEquity()}catch(e){toast('Falha: '+e.message)}}

/* V38268_SYSTEM_KNOWLEDGE_UI */
let v38268KnowledgeCache=null;
function v38268KnowledgeCard(c){const paths=[...(c.code||[]),...(c.ui||[]),...(c.data||[])];return `<div class="v38268-kcard"><div class="v38268-khead"><b>${esc(c.id||'componente')}</b><span>${esc(c.authority||'—')}</span></div><p>${esc(c.role||'')}</p><div class="v38268-tags">${(c.aliases||[]).slice(0,8).map(x=>`<span>${esc(x)}</span>`).join('')}</div><details><summary>Arquivos, autoridade e limites</summary><div class="v38268-paths">${paths.map(x=>`<code>${esc(x)}</code>`).join('')}</div><ul>${(c.limits||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></details></div>`}
async function v38268LoadSystemKnowledge(force=false){try{if(force||!v38268KnowledgeCache)v38268KnowledgeCache=await jsonFetch('/api/system-knowledge');const x=v38268KnowledgeCache,cs=x.components||[],i=x.integrity||{};$('v38268KnowledgeIntegrity').innerHTML=`<div class="v38268-integrity ${i.current?'good':'bad'}"><b>${i.current?'Arquitetura consistente':'Conhecimento desatualizado'}</b><span>${esc(String(cs.length))} componentes • stale ${esc(String(i.stale_count??'—'))}</span></div>`;$('v38268KnowledgeResults').innerHTML=cs.map(v38268KnowledgeCard).join('')||'<div class="muted">Nenhum componente registrado.</div>';return x}catch(e){$('v38268KnowledgeResults').innerHTML=`<div class="loss">${esc(e.message)}</div>`;return null}}
async function v38268SearchKnowledge(){const q=$('v38268KnowledgeQuery')?.value?.trim()||'';if(!q){await v38268LoadSystemKnowledge(true);return}try{const x=await jsonFetch('/api/system-knowledge/search?q='+encodeURIComponent(q));$('v38268KnowledgeResults').innerHTML=(x.components||[]).map(v38268KnowledgeCard).join('')||'<div class="muted">Nenhum componente correspondente. O Porquinho não inventará uma localização.</div>'}catch(e){toast('Falha ao consultar conhecimento: '+e.message)}}
function v38268RenderLearning(){const l=(lastStatus||{}).learning||{};if(!$('v38268LearningMetrics'))return;$('v38268LearningMetrics').innerHTML=[v361Metric('Modelo',l.model||'Baseline'),v361Metric('Confiança',fmt(l.confidence,0)+'/100','qualidade da evidência'),v361Metric('Observações',String(l.observations??'—')),v361Metric('Ensaios',String(l.experiments??'—'))].join('');$('v38268MarketLearning').innerHTML=`<div class="v38268-market-grid">${[['Regime',l.regime==null?'—':fmt(l.regime,1)],['Acerto',l.hit_rate==null?'—':fmt(l.hit_rate,1)+'%'],['Correlação',l.corr==null?'—':fmt(l.corr,3)],['MAE',l.mae==null?'—':fmt(l.mae,2)]].map(x=>`<div><span>${esc(x[0])}</span><b>${esc(x[1])}</b></div>`).join('')}</div>`}
const _v38268ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){if(name==='learning'){document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));$('view-learning').classList.add('active-view');(button||document.querySelector('[data-target="learning"]'))?.classList.add('active');v38268RenderLearning();v38268LoadSystemKnowledge();window.scrollTo({top:0,behavior:'smooth'});return}return _v38268ShowExperienceView(name,button)}
const _v38268LoadStatus=loadStatus;loadStatus=async function(force=false){await _v38268LoadStatus(force);v38268RenderLearning()}

/* V38269_ACCOUNT_ONBOARDING_RECONCILIATION */
async function v38269Reconciliation(){return await jsonFetch('/api/investment-registry/reconciliation')}
function v38269AccountPositions(aid,positions){
 const ps=(positions||[]).filter(p=>p.account_id===aid);
 if(!ps.length)return '<div class="v38269-empty">Nenhuma posição verificada nesta conta.</div>';
 return ps.map(p=>`<div class="v38269-pos"><div><b>${esc(p.symbol||p.instrument_id)}</b><span>${esc(p.instrument_id||'')}</span></div><div><strong>${esc(String(p.quantity))}</strong><small>${esc(p.currency||'—')} • custo ${p.average_cost==null?'indisponível':esc(String(p.average_cost))}</small></div></div>`).join('')
}
async function v38269OpenPositionForAccount(accountId){
 try{
  const [r,i]=await Promise.all([v38265Registry(),v38265Instruments()]);
  const a=(r.accounts||[]).find(x=>x.account_id===accountId);
  if(!a){toast('Conta universal não encontrada.');return}
  const n=(i.instruments||[]).filter(x=>x.instrument_id && String(x.asset_class||'').toUpperCase()==='EQUITY' && ['B3','BR_B3_EQUITY'].includes(String(x.market||'').toUpperCase()));
  openModal('Vincular posição • '+a.name,`<div class="v38265-form">
   <div class="v38269-contract"><b>Instrumento conhecido ≠ posição possuída</b><span>Selecione uma identidade já conhecida. A posição só será criada após sua confirmação explícita.</span></div>
   ${v38265Field('Instrumento',`<select id="v38265PosInstrument" onchange="v38265SyncCurrency()">${n.map(x=>`<option value="${esc(x.instrument_id)}" data-currency="${esc(x.currency||'')}">${esc(x.symbol)} • ${esc(x.asset_class||'—')} • ${esc(x.instrument_id)}</option>`).join('')}</select>`)}
   <input id="v38265PosAccount" type="hidden" value="${esc(accountId)}">
   ${v38265Field('Quantidade','<input id="v38265PosQty" type="number" step="any" min="0" placeholder="Quantidade efetivamente possuída">')}
   ${v38265Field('Custo médio por unidade','<input id="v38265PosCost" type="number" step="any" min="0" placeholder="Opcional; necessário para P/L de realização">')}
   ${v38265Field('Moeda','<input id="v38265PosCurrency" placeholder="BRL">')}
   ${v38265Field('Posição válida em','<input id="v38265PosAsOf" type="date">')}
   <div class="v38269-confirm"><label><input id="v38269ConfirmOwnership" type="checkbox"> Confirmo que esta posição existe nesta conta e que quantidade/data foram informadas por mim.</label></div>
   <div class="modal-actions"><button onclick="closeModal()">Cancelar</button><button class="primary" onclick="v38269SavePosition()">Confirmar posição</button></div></div>`);
  v38265SyncCurrency(); const d=$('v38265PosAsOf');if(d)d.value=new Date().toISOString().slice(0,10)
 }catch(e){toast('Falha ao preparar posição: '+e.message)}
}
async function v38269SavePosition(){
 if(!$('v38269ConfirmOwnership')?.checked){toast('Confirme explicitamente a existência da posição.');return}
 try{
  const cost=$('v38265PosCost').value.trim();
  await jsonFetch('/api/br-equity/positions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
   account_id:$('v38265PosAccount').value,instrument_id:$('v38265PosInstrument').value,
   quantity:$('v38265PosQty').value,average_cost:cost===''?null:cost,
   currency:$('v38265PosCurrency').value.trim(),as_of:$('v38265PosAsOf').value
  })});
  closeModal();toast('Posição vinculada com evidência explícita.');await v38240Accounts()
 }catch(e){toast('Não foi possível vincular posição: '+e.message)}
}
function v38269InstitutionMark(name){const n=String(name||'').toUpperCase();if(n.includes('ITAÚ')||n.includes('ITAU'))return 'I';if(n.includes('BRADESCO'))return 'B';if(n.includes('NUBANK'))return 'NU';if(n.includes('C6'))return 'C6';return n.slice(0,2)}
async function v38269UniversalAccountsPanel(){
 const x=await v38269Reconciliation(), inst=x.institutions||[], accounts=x.accounts||[], positions=x.positions||[];
 if(!inst.length)return `<section class="v38269-onboard"><div class="v38269-onboard-copy"><small>PRIMEIRO PASSO</small><b>Cadastre suas instituições reais</b><span>Itaú, Bradesco, Nubank e C6 podem ser cadastrados aqui. Nenhuma posição será criada automaticamente.</span></div><button onclick="v38265OpenInstitution()">+ Instituição</button></section>`;
 return `<section class="v38269-universal">${inst.map(i=>{const aa=accounts.filter(a=>a.institution_id===i.institution_id);return `<article class="v38269-inst"><header><span class="v38269-instmark">${esc(v38269InstitutionMark(i.name))}</span><div><b>${esc(i.name)}</b><small>${esc(i.country)} • ${esc(i.institution_type)}</small></div><em>${aa.length} conta(s)</em></header>${aa.length?aa.map(a=>`<div class="v38269-account"><div class="v38269-accounthead"><div><b>${esc(a.name)}</b><span>${esc(a.account_type)} • ${esc(a.currency)} • ${esc(a.management_mode)}</span></div><button onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button><button onclick="r21386ls19aOpenManualTrade('${esc(a.account_id)}')">+ Registrar investimento</button></div>${v38269AccountPositions(a.account_id,positions)}</div>`).join(''):'<div class="v38269-empty">Nenhuma conta cadastrada nesta instituição.</div>'}</article>`}).join('')}</section>`
}
const _v38269Accounts=v38240Accounts;
v38240Accounts=async function(){
 await _v38269Accounts();
 const host=document.querySelector('#view-placeholder .v38266-registry');
 if(host){
  try{host.innerHTML=await v38269UniversalAccountsPanel()}
  catch(e){host.innerHTML=`<div class="v38269-empty">Registro universal indisponível: ${esc(e.message)}</div>`}
 }
}


/* V382691_ACCOUNT_UX_POLISH */
function v382691RegionFlag(country){const c=String(country||'').trim().toUpperCase();if(['BR','BRA','BRAZIL','BRASIL'].includes(c))return '🇧🇷';if(['EU','EUR','EUROPE','EUROPA','EUROPEAN UNION','UE'].includes(c))return '🇪🇺';const eu={PT:'🇵🇹',ES:'🇪🇸',FR:'🇫🇷',DE:'🇩🇪',IT:'🇮🇹',NL:'🇳🇱',BE:'🇧🇪',IE:'🇮🇪',AT:'🇦🇹',LU:'🇱🇺',FI:'🇫🇮',GR:'🇬🇷'};return eu[c]||'🌐'}
function v382691Brand(i){return `<span class="v382691-brand">${esc(v38269InstitutionMark(i?.name||''))}</span>`}
async function v382691EditInstitution(id){try{const r=await v38265Registry(),i=(r.institutions||[]).find(x=>x.institution_id===id);if(!i)return toast('Instituição não encontrada.');openModal('Editar instituição',`<div class="v38265-form">${v38265Field('Nome',`<input id="v382691InstName" value="${esc(i.name)}">`)}${v38265Field('País / jurisdição',`<input id="v382691InstCountry" value="${esc(i.country)}">`)}${v38265Field('Tipo',`<select id="v382691InstType">${['BANK','BROKER','FINTECH','EXCHANGE','OTHER'].map(x=>`<option ${x===i.institution_type?'selected':''}>${x}</option>`).join('')}</select>`)}<div class="modal-actions"><button onclick="closeModal()">Cancelar</button><button class="primary" onclick="v382691SaveInstitution('${esc(id)}')">Salvar alterações</button></div></div>`)}catch(e){toast(e.message)}}
async function v382691SaveInstitution(id){try{await jsonFetch('/api/investment-registry/institution/'+encodeURIComponent(id),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('v382691InstName').value.trim(),country:$('v382691InstCountry').value.trim(),institution_type:$('v382691InstType').value})});closeModal();toast('Instituição atualizada.');await v38240Accounts()}catch(e){toast('Não foi possível atualizar: '+e.message)}}
async function v382691EditAccount(id){try{const r=await v38265Registry(),a=(r.accounts||[]).find(x=>x.account_id===id);if(!a)return toast('Conta não encontrada.');openModal('Editar conta',`<div class="v38265-form">${v38265Field('Nome',`<input id="v382691AccName" value="${esc(a.name)}">`)}${v38265Field('Plano da conta (opcional)',`<input id="v382691AccPlan" maxlength="120" value="${esc(a.pricing_plan||'')}" placeholder="Nome do plano no banco ou corretora">`)}${v38265Field('Tipo',`<input id="v382691AccType" value="${esc(a.account_type)}">`)}${v38265Field('Moeda',`<input id="v382691AccCurrency" value="${esc(a.currency)}">`)}${v38265Field('Perfil do titular',`<select id="v382691AccOwner">${[['UNSPECIFIED','Não especificado'],['PF','Pessoa física (PF)'],['PJ','Pessoa jurídica (PJ)']].map(x=>`<option value="${x[0]}" ${x[0]===(a.owner_profile||'UNSPECIFIED')?'selected':''}>${x[1]}</option>`).join('')}</select>`)}<div class="v38269-contract"><b>Identidade preservada</b><span>Não altera account_id, instituição, posições, execução ou conectores.</span></div><div class="modal-actions"><button onclick="closeModal()">Cancelar</button><button class="primary" onclick="v382691SaveAccount('${esc(id)}')">Salvar alterações</button></div></div>`)}catch(e){toast(e.message)}}
async function v382691SaveAccount(id){try{await jsonFetch('/api/investment-registry/account/'+encodeURIComponent(id),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('v382691AccName').value.trim(),account_type:$('v382691AccType').value.trim(),currency:$('v382691AccCurrency').value.trim(),owner_profile:$('v382691AccOwner').value,pricing_plan:$('v382691AccPlan').value.trim()||null})});closeModal();toast('Conta atualizada.');await v38240Accounts()}catch(e){toast('Não foi possível atualizar: '+e.message)}}
const _v382691Panel=v38269UniversalAccountsPanel;
v38269UniversalAccountsPanel=async function(){const x=await v38269Reconciliation(),inst=x.institutions||[],accounts=x.accounts||[],positions=x.positions||[];if(!inst.length)return _v382691Panel();return `<section class="v38269-universal">${inst.map(i=>{const aa=accounts.filter(a=>a.institution_id===i.institution_id);return `<article class="v38269-inst"><header>${v382691Brand(i)}<div><b>${esc(i.name)}</b><small>${esc(i.country)} • ${esc(i.institution_type)}</small></div><span class="v382691-flag">${v382691RegionFlag(i.country)}</span><button class="v382691-pencil" title="Editar instituição" onclick="v382691EditInstitution('${esc(i.institution_id)}')">✎</button><em>${aa.length} conta(s)</em></header>${aa.length?aa.map(a=>`<div class="v38269-account"><div><b>${esc(a.name)}</b><small>${esc(a.account_type)} • ${esc(a.currency)} • ${esc(a.management_mode)}</small></div><button class="v382691-pencil account" title="Editar conta" onclick="v382691EditAccount('${esc(a.account_id)}')">✎</button><button onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button>${v38269AccountPositions(a.account_id,positions)}</div>`).join(''):'<div class="v38269-empty">Nenhuma conta cadastrada nesta instituição.</div>'}</article>`}).join('')}</section>`}



/* V382692_ACCOUNT_UI_REFINEMENT */
function v382692Flag(country){const c=String(country||'').trim().toUpperCase();if(['BR','BRA','BRAZIL','BRASIL'].includes(c))return '🇧🇷';if(['EU','EUR','EUROPE','EUROPA','UE','EUROPEAN UNION'].includes(c))return '🇪🇺';const m={PT:'🇵🇹',ES:'🇪🇸',FR:'🇫🇷',DE:'🇩🇪',IT:'🇮🇹',NL:'🇳🇱',BE:'🇧🇪',IE:'🇮🇪',AT:'🇦🇹',LU:'🇱🇺',FI:'🇫🇮',GR:'🇬🇷'};return m[c]||'🌐'}
function v382692UniversalCard(i,aa,positions){return `<article class="v382692-card"><header class="v382692-head"><div class="v382692-ident">${v382691Brand(i)}<div><b>${esc(i.name)}</b><small>${esc(i.country)} · ${esc(i.institution_type)}</small></div></div><div class="v382692-tools"><span class="v382692-flag">${v382692Flag(i.country)}</span><span class="v382692-count">${aa.length} conta(s)</span><button class="v382692-edit" title="Editar instituição" onclick="v382691EditInstitution('${esc(i.institution_id)}')">✎</button></div></header><div class="v382692-divider"></div>${aa.length?aa.map(a=>`<section class="v382692-account"><div class="v382692-accounttop"><div class="v382692-accountname"><b>${esc(a.name)}</b><small>${esc(a.account_type)} · ${esc(a.currency)} · ${esc(a.management_mode)} · ${esc(a.owner_profile||'UNSPECIFIED')}</small></div><div class="v382692-accountactions"><button class="v382692-edit" title="Editar conta" onclick="v382691EditAccount('${esc(a.account_id)}')">✎</button><button class="v382692-link" onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button></div></div>${v38269AccountPositions(a.account_id,positions)}</section>`).join(''):'<div class="v38269-empty">Nenhuma conta cadastrada nesta instituição.</div>'}</article>`}
v38269UniversalAccountsPanel=async function(){const x=await v38269Reconciliation(),inst=x.institutions||[],accounts=x.accounts||[],positions=x.positions||[];if(!inst.length)return _v382691Panel();return `<section class="v382692-grid">${inst.map(i=>v382692UniversalCard(i,accounts.filter(a=>a.institution_id===i.institution_id),positions)).join('')}</section>`}
function v382692LegacyFlag(name){const n=String(name||'').toUpperCase();return (n.includes('N26')||n.includes('REVOLUT'))?'🇪🇺':'🌐'}
const _v382692Accounts=v38240Accounts;
v38240Accounts=async function(){await _v382692Accounts();document.querySelectorAll('.v38240-bankgrid > article, .v38240-bankgrid > .card').forEach(card=>{const flag=v382692LegacyFlag(card.textContent||'');if(flag!=='🌐'&&!card.querySelector('.v382692-legacyflag')){const el=document.createElement('span');el.className='v382692-legacyflag';el.textContent=flag;el.title='Conta europeia legada';card.style.position='relative';card.appendChild(el)}})}



/* V382693_UNIFIED_ACCOUNT_CARD_LAYOUT */
function v382693UniversalAccountBlock(i,a,positions){
 const ps=(positions||[]).filter(p=>p.account_id===a.account_id);
 return `<section class="v382693-account">
   <div class="v382693-accountbar">
    <div><b>${esc(a.name)}</b><small>${esc(a.account_type)} · ${esc(a.currency)} · ${esc(a.management_mode)} · ${esc(a.owner_profile||'UNSPECIFIED')}</small></div>
    <div class="v382693-accounttools"><button class="v382691-pencil" title="Editar conta" onclick="v382691EditAccount('${esc(a.account_id)}')">✎</button><button class="v382693-link" onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button></div>
   </div>
   <div class="v382693-positions">${v38269AccountPositions(a.account_id,positions)}</div>
 </section>`;
}
function v382693UniversalCard(i,accounts,positions){
 const aa=(accounts||[]).filter(a=>a.institution_id===i.institution_id);
 return `<article class="v382693-bankcard">
  <header class="v382693-bankhead">
   <div class="v382693-bankidentity">${v382691Brand(i)}<div><b>${esc(i.name)}</b><small>${esc(i.country)} · ${esc(i.institution_type)}</small></div></div>
   <div class="v382693-headtools"><span class="v382693-flag">${v382692Flag(i.country)}</span><span>${aa.length} conta(s)</span><button class="v382691-pencil" title="Editar instituição" onclick="v382691EditInstitution('${esc(i.institution_id)}')">✎</button></div>
  </header>
  <div class="v382693-accountlist">${aa.length?aa.map(a=>v382693UniversalAccountBlock(i,a,positions)).join(''):'<div class="v38269-empty">Nenhuma conta cadastrada nesta instituição.</div>'}</div>
 </article>`;
}
v38269UniversalAccountsPanel=async function(){
 const x=await v38269Reconciliation(),inst=x.institutions||[],accounts=x.accounts||[],positions=x.positions||[];
 if(!inst.length)return _v382691Panel();
 return `<section class="v382693-grid">${inst.map(i=>v382693UniversalCard(i,accounts,positions)).join('')}</section>`;
}
function v382693FixLegacyCards(){
 document.querySelectorAll('.v38240-bankgrid > article, .v38240-bankgrid > .card').forEach(card=>{
   card.classList.add('v382693-legacycard');
   const flag=v382692LegacyFlag(card.textContent||'');
   card.querySelectorAll('.v382692-legacyflag').forEach(x=>x.remove());
   let head=card.querySelector('.v38240-bankhead')||card.querySelector('.card-head')||card.firstElementChild;
   if(head && flag!=='🌐' && !head.querySelector('.v382693-legacyflag')){
     const el=document.createElement('span');el.className='v382693-legacyflag';el.textContent=flag;head.appendChild(el);
   }
 });
}
const _v382693Accounts=v38240Accounts;
v38240Accounts=async function(){await _v382693Accounts();v382693FixLegacyCards()}


/* V38270_UNIVERSAL_INSTRUMENT_CATALOG_UI */
async function v38270Assets(){v38130Placeholder('Ativos','Catálogo universal de instrumentos. Instrumento conhecido não significa posição possuída.',`<section class="v38270-head"><div><small>IDENTIDADE • NÃO PROPRIEDADE</small><h2>Catálogo Universal</h2><p>Identidades reutilizáveis por mercado e classe. Posições continuam vinculadas às contas.</p></div><div class="v38270-filters"><input id="v38270Q" placeholder="Buscar ativo" oninput="v38270Load()"><select id="v38270Class" onchange="v38270Load()"><option value="">Todas as classes</option></select></div></section><div id="v38270Summary" class="v38270-summary"></div><div id="v38270Rows" class="v38270-grid"></div>`);await v38270Load()}
async function v38270Load(){const box=document.getElementById('v38270Rows');if(!box)return;try{const q=encodeURIComponent(document.getElementById('v38270Q')?.value||''),cl=encodeURIComponent(document.getElementById('v38270Class')?.value||'');const d=await jsonFetch('/api/instruments?q='+q+'&asset_class='+cl),rows=d.instruments||[],sel=document.getElementById('v38270Class');if(sel&&sel.options.length===1)Object.keys(d.summary?.by_asset_class||{}).sort().forEach(x=>sel.insertAdjacentHTML('beforeend',`<option value="${esc(x)}">${esc(x)}</option>`));document.getElementById('v38270Summary').innerHTML=`<b>${rows.length}</b><span> instrumentos exibidos</span><em>Catálogo = identidade, não carteira</em>`;box.innerHTML=rows.map(x=>`<article class="v38270-card"><div class="v38270-symbol">${esc(x.symbol||'—')}</div><div class="v38270-body"><b>${esc(x.name||x.symbol||'—')}</b><span>${esc(x.asset_class||'UNAVAILABLE')} · ${esc(x.market||'UNAVAILABLE')} · ${esc(x.jurisdiction||'UNAVAILABLE')}</span><small>${esc(x.instrument_id||'—')}</small></div><div class="v38270-cur">${esc(x.currency||'UNAVAILABLE')}</div></article>`).join('')||'<div class="muted">Nenhum instrumento encontrado.</div>'}catch(e){box.innerHTML='<div class="muted">Catálogo indisponível: '+esc(e.message)+'</div>'}}
const _v38270Show=showExperienceView;showExperienceView=function(name,button){if(name==='assets'){document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));(button||document.querySelector('[data-target="assets"]'))?.classList.add('active');v38270Assets();return}return _v38270Show(name,button)};

/* V3.8.27.2 UNIVERSAL INSTRUMENT ONBOARDING */
async function v38272OpenInstrumentOnboarding(){let c;try{c=await jsonFetch('/api/instruments/onboarding-contract')}catch(e){toast(e.message);return}openModal('Cadastrar instrumento',`<div style="display:grid;gap:9px"><div class="muted">Identidade do catálogo; não cria posição ou compra.</div><label>Classe<select id="v38272Class" onchange="v38272Toggle()">${c.asset_classes.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Jurisdição<input id="v38272Jur" placeholder="BR, PT, EU, GLOBAL"></label><label>Mercado<input id="v38272Market" placeholder="B3, OTC_BR, CRYPTO"></label><label>Nome<input id="v38272Name"></label><label>Moeda<input id="v38272Currency" placeholder="BRL, EUR, USD"></label><div id="v38272Generic"><label>Símbolo<input id="v38272Symbol"></label></div><div id="v38272FI" style="display:none;gap:9px"><label>Produto<select id="v38272Product">${c.fixed_income.product_types.map(x=>`<option>${esc(x)}</option>`).join('')}</select></label><label>Emissor<input id="v38272Issuer"></label><label>Identificador externo (opcional)<input id="v38272External"></label><div class="muted">Taxa, indexador, vencimento, liquidez, principal e tributação ficam na posição/contrato.</div></div><label>Proveniência<input id="v38272Prov" placeholder="Documento/contrato informado pelo usuário"></label><label><input id="v38272Confirm" type="checkbox"> Confirmo: somente identidade, não posição.</label><button onclick="v38272SaveInstrument()">Cadastrar instrumento</button></div>`);v38272Toggle()}
function v38272Toggle(){let f=$('v38272Class')?.value==='FIXED_INCOME';$('v38272FI').style.display=f?'grid':'none';$('v38272Generic').style.display=f?'none':'block'}
async function v38272SaveInstrument(){if(!$('v38272Confirm').checked){toast('Confirme o escopo de identidade.');return}let c=$('v38272Class').value,b={asset_class:c,jurisdiction:$('v38272Jur').value,market:$('v38272Market').value,name:$('v38272Name').value,currency:$('v38272Currency').value,provenance:$('v38272Prov').value};if(c==='FIXED_INCOME'){b.product_type=$('v38272Product').value;b.issuer=$('v38272Issuer').value;b.external_identifier=$('v38272External').value}else b.symbol=$('v38272Symbol').value;try{const h=await r21386ls19aMutationHeaders();let r=await fetch('/api/instruments/manual',{method:'POST',headers:h,body:JSON.stringify(b)}),j=await r.json();if(!r.ok)throw Error(j.error||r.status);closeModal();toast('Instrumento cadastrado. Nenhuma posição criada.');if(R21386LS19A.accountId)await r21386ls19aOpenManualTrade(R21386LS19A.accountId);else if(typeof v38270LoadAssets==='function')await v38270LoadAssets()}catch(e){toast('Cadastro recusado: '+e.message)}}

/* V3.8.27.2-r1 — ATIVOS ONBOARDING ENTRYPOINT REPAIR
   DOM-level additive hook: independent of which historical renderer currently owns Ativos. */
function v38272r1EnsureAssetsOnboardingButton(){
  const view=document.getElementById('view-placeholder');
  if(!view || !view.classList.contains('active-view')) return false;
  const title=document.getElementById('viewTitle');
  if(!title || String(title.textContent||'').trim()!=='Ativos') return false;
  if(document.getElementById('v38272OnboardingButton')) return true;
  const content=document.getElementById('viewContent');
  if(!content) return false;
  const head=content.querySelector('.card-head') || content.querySelector('article.card') || content;
  const b=document.createElement('button');
  b.id='v38272OnboardingButton';
  b.type='button';
  b.textContent='+ Cadastrar instrumento';
  b.onclick=v38272OpenInstrumentOnboarding;
  b.title='Adiciona identidade ao catálogo; não cria posição ou compra.';
  if(head.classList && head.classList.contains('card-head')) head.appendChild(b);
  else head.insertBefore(b,head.firstChild);
  return true;
}
const _v38272r1ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
  const out=_v38272r1ShowExperienceView(name,button);
  if(name==='assets'){
    [0,40,120,300,700].forEach(ms=>setTimeout(v38272r1EnsureAssetsOnboardingButton,ms));
  }
  return out;
};
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelector('[data-target="assets"]')?.addEventListener('click',()=>setTimeout(v38272r1EnsureAssetsOnboardingButton,80));
});


/* V38275_UNIVERSAL_POSITION_ROUTER */
async function v38275OpenForAccount(accountId){
 try{
  const [reg,ins,cap]=await Promise.all([v38265Registry(),v38265Instruments(),jsonFetch('/api/positions/capabilities')]);
  const a=(reg.accounts||[]).find(x=>x.account_id===accountId);if(!a){toast('Conta nao encontrada.');return}
  const cm=new Map((cap.instruments||[]).map(x=>[x.instrument_id,x])),base=ins.instruments||[],extra=(cap.instruments||[]).filter(x=>!base.some(y=>y.instrument_id===x.instrument_id)),n=base.concat(extra);
  const opts=n.map(x=>{const c=cm.get(x.instrument_id)||{};return '<option value="'+esc(x.instrument_id)+'" data-route="'+esc(c.route||'')+'" data-currency="'+esc(x.currency||'')+'">'+esc(x.symbol||x.name||x.instrument_id)+' - '+esc(x.asset_class||'-')+' - '+esc(c.position_registration||'UNSUPPORTED')+'</option>'}).join('');
  openModal('Vincular posicao - '+a.name,'<div class="v38265-form"><div class="muted">Fluxo definido pela classe e mercado explicitos. O cadastro nao executa compra.</div>'+v38265Field('Instrumento','<select id="v38275Instrument" onchange="v38275RouteForm()">'+opts+'</select>')+'<div id="v38275RouteBox"></div></div>');
  window.v38275AccountId=accountId;window.v38275AccountCurrency=a.currency;v38275RouteForm();
 }catch(e){toast('Nao foi possivel vincular posicao: '+e.message)}
}
function v38275RouteForm(){const s=$('v38275Instrument'),o=s&&s.options[s.selectedIndex],box=$('v38275RouteBox');if(!o||!box)return;const r=o.dataset.route,cur=o.dataset.currency||'';if(r==='BR_EQUITY_SPECIALIZED'){box.innerHTML='<div class="muted">Acao B3: fluxo especializado existente.</div><button class="primary" onclick="v38275OpenEquity()">Continuar</button>';return}if(r==='FIXED_INCOME_SPECIALIZED'){const t=new Date().toISOString().slice(0,10);box.innerHTML=v38265Field('Principal','<input id="v38275Principal" type="number" min="0" step="0.01">')+v38265Field('Data da aplicacao','<input id="v38275Date" type="date" value="'+t+'">')+v38265Field('Moeda','<input id="v38275Currency" value="'+esc(cur)+'" readonly>')+v38265Field('Indexador','<select id="v38275Indexer"><option>UNKNOWN</option><option>CDI</option><option>SELIC</option><option>IPCA</option><option>FIXED</option></select>')+v38265Field('% benchmark','<input id="v38275Pct" type="number" step="any">')+v38265Field('Taxa fixa % a.a.','<input id="v38275Fixed" type="number" step="any">')+v38265Field('Spread %','<input id="v38275Spread" type="number" step="any">')+v38265Field('Vencimento','<input id="v38275Maturity" type="date">')+v38265Field('Liquidez','<select id="v38275Liquidity"><option>UNKNOWN</option><option>DAILY</option><option>AT_MATURITY</option></select>')+v38265Field('Regime tributario','<input id="v38275Tax" value="UNKNOWN">')+v38265Field('Garantia/protecao','<input id="v38275Guarantee" value="UNKNOWN">')+'<div class="muted">Campos desconhecidos permanecem UNKNOWN. REALIZE nao e habilitado.</div><button class="primary" onclick="v38275SaveFI()">Registrar posicao</button>';return}box.innerHTML='<div class="muted">Registro de posicao ainda nao suportado para esta classe/mercado.</div>'}
function v38275OpenEquity(){const iid=$('v38275Instrument').value;closeModal();v38265OpenPosition().then(()=>setTimeout(()=>{let a=$('v38265PosAccount'),i=$('v38265PosInstrument');if(a)a.value=window.v38275AccountId;if(i){i.value=iid;if(typeof v38265SyncCurrency==='function')v38265SyncCurrency()}},0))}
async function v38275SaveFI(){try{const val=id=>$(id)?.value||'',num=id=>val(id)===''?null:Number(val(id));const r=await fetch('/api/positions/fixed-income',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({account_id:window.v38275AccountId,instrument_id:$('v38275Instrument').value,principal:num('v38275Principal'),principal_date:val('v38275Date'),currency:val('v38275Currency'),indexer:val('v38275Indexer'),indexer_pct:num('v38275Pct'),fixed_rate:num('v38275Fixed'),spread:num('v38275Spread'),maturity_date:val('v38275Maturity')||null,liquidity_type:val('v38275Liquidity'),tax_regime:val('v38275Tax')||'UNKNOWN',guarantee_type:val('v38275Guarantee')||'UNKNOWN',provenance:'EXPLICIT_USER_POSITION_ENTRY'})});let d={};try{d=await r.json()}catch(_e){}if(!r.ok)throw Error(d.error||('HTTP '+r.status));closeModal();toast('Posicao de renda fixa registrada. Nenhuma compra foi executada.');try{if(typeof v38276RefreshPositionSurfaces==='function')await v38276RefreshPositionSurfaces()}catch(_e){}}catch(e){toast('Falha: '+e.message)}}
v38269OpenPositionForAccount=v38275OpenForAccount;

/* v38276_position_onboarding_e2e — projection refresh only */
async function v38276RefreshPositionSurfaces(){
 try { await jsonFetch('/api/positions'); } catch(e) {}
 try { if(typeof v38269RenderAccounts==='function') await v38269RenderAccounts(); } catch(e) {}
}

/* V3.8.27.7-r1 additive universal portfolio projection; legacy crypto authority untouched. */
function v38277Money(v,c){if(v==null)return '—';try{return new Intl.NumberFormat('pt-PT',{style:'currency',currency:c||'EUR'}).format(Number(v))}catch(e){return String(v)+' '+String(c||'')}}
async function v38277RenderUniversalPositions(){
 const host=document.getElementById('portfolioPositionsV361'); if(!host)return;
 let d;try{d=await jsonFetch('/api/portfolio/universal')}catch(e){return}
 const rows=d.positions||[]; if(!rows.length)return;
 const block=document.getElementById('v38277UniversalBlock')||document.createElement('section');
 block.id='v38277UniversalBlock';block.className='card';block.style.marginTop='14px';
 block.innerHTML=`<div class="card-head"><b>Posições universais</b><span>Projeção • sem conversão cambial silenciosa</span></div>
 <div class="table-wrap"><table class="v361-table"><thead><tr><th>Ativo</th><th>Classe</th><th>Conta</th><th>Moeda</th><th>Quantidade / principal</th><th>Valor atual</th><th>Valuation</th></tr></thead><tbody>${
 rows.map(x=>`<tr><td><b>${esc(x.symbol||x.instrument_id||'—')}</b></td><td>${esc(x.asset_class||x.position_domain||'—')}</td><td>${esc(x.account_name||x.account_id||'—')}</td><td>${esc(x.valuation_currency||x.currency||'—')}</td><td>${x.position_domain==='FIXED_INCOME'?v38277Money(x.principal,x.currency):fmt(x.quantity,6)}</td><td>${v38277Money(x.current_value,x.valuation_currency||x.currency)}</td><td>${esc(x.valuation_status||'UNAVAILABLE')}</td></tr>`).join('')
 }</tbody></table></div>
 <div class="muted" style="margin-top:8px">${Object.entries(d.totals_by_currency||{}).map(([c,x])=>`${esc(c)}: ${v38277Money(x.current_value,c)} • ${x.valued_positions}/${x.positions} com valuation`).join(' &nbsp; | &nbsp; ')}</div>`;
 host.parentElement?.appendChild(block);
}
const _v38277RenderPortfolioView=renderPortfolioView;
renderPortfolioView=function(){const r=_v38277RenderPortfolioView();v38277RenderUniversalPositions();return r}

/* V38278_FIXED_INCOME_ONBOARDING_REPAIR */
const _v38278OpenInstrumentOnboarding=v38272OpenInstrumentOnboarding;
v38272OpenInstrumentOnboarding=async function(){
 await _v38278OpenInstrumentOnboarding();
 const cl=$('v38272Class'),jur=$('v38272Jur'),market=$('v38272Market'),prov=$('v38272Prov');
 if(jur&&!jur.value)jur.value='BR';
 if(cl){const sync=()=>{const fi=cl.value==='FIXED_INCOME';if(fi&&market){market.placeholder='OTC_BR';if(!market.value)market.value='OTC_BR';}if(fi&&prov)prov.placeholder='Ex.: extrato/posição confirmada no Bradesco';};cl.addEventListener('change',sync);sync();}
 const box=cl?.closest('.modal-box')||cl?.closest('[role="dialog"]');if(box)box.classList.add('v38278-fi-modal');
};
const _v38278SaveInstrument=v38272SaveInstrument;
v38272SaveInstrument=async function(){
 if($('v38272Class')?.value==='FIXED_INCOME'){
  const req=[['v38272Jur','Jurisdição'],['v38272Market','Mercado'],['v38272Name','Nome'],['v38272Currency','Moeda'],['v38272Product','Produto'],['v38272Issuer','Emissor'],['v38272Prov','Proveniência']];
  const missing=req.filter(([id])=>!String($(id)?.value||'').trim()).map(([,n])=>n);
  if(missing.length){toast('Preencha antes de cadastrar: '+missing.join(', '));return;}
 }
 return _v38278SaveInstrument();
};


/* V38278R1_CATALOG_REFRESH_REPAIR */
const _v38278r1SaveInstrument=v38272SaveInstrument;
v38272SaveInstrument=async function(){
 await _v38278r1SaveInstrument();
 if(!$('v38272Class') && typeof v38270Load==='function') await v38270Load();
};

/* V38279R2_FI_ACCOUNTS_PROJECTION_REPAIR — read-only UI projection */
async function v38279r2UniversalPositions(){
  try{const d=await jsonFetch('/api/positions');return Array.isArray(d?.positions)?d.positions:[]}
  catch(e){return []}
}
function v38279r2Money(v,c){
  if(v==null||v==='')return '—';
  try{return new Intl.NumberFormat('pt-BR',{style:'currency',currency:c||'BRL'}).format(Number(v))}
  catch(e){return String(v)+' '+String(c||'')}
}
function v38279r2PositionLabel(p){
  if(p.position_domain==='FIXED_INCOME'){
    const rate=(p.indexer&&p.indexer!=='UNKNOWN')?(p.indexer_pct!=null?`${p.indexer_pct}% ${p.indexer}`:p.indexer):'taxa não informada';
    return `<div class="v38279r2-pos"><div><b>${esc(p.name||p.instrument_id||'Renda fixa')}</b><span>FIXED_INCOME · ${esc(p.currency||'UNAVAILABLE')}</span></div><div class="v38279r2-posval"><b>${v38279r2Money(p.principal,p.currency)}</b><span>${esc(rate)} · ${esc(p.liquidity_type||'UNKNOWN')}</span></div></div>`;
  }
  return `<div class="v38279r2-pos"><div><b>${esc(p.symbol||p.name||p.instrument_id||'Posição')}</b><span>${esc(p.position_domain||p.asset_class||'POSITION')}</span></div></div>`;
}
async function v38279r2ApplyAccountsProjection(){
  const view=document.getElementById('view-accounts');if(!view)return;
  const positions=await v38279r2UniversalPositions();
  const reg=await jsonFetch('/api/investment-registry').catch(()=>({accounts:[]}));
  for(const a of (reg.accounts||[])){
    const mine=positions.filter(p=>p.account_id===a.account_id);if(!mine.length)continue;
    const btn=[...view.querySelectorAll('button')].find(b=>(b.getAttribute('onclick')||'').includes(a.account_id)&&/Vincular posi/i.test(b.textContent||''));
    const card=btn?.closest('article,section,.card,.v38269-card,.v38269-account-card')||btn?.parentElement?.parentElement;if(!card)continue;
    let box=card.querySelector('.v38279r2-account-positions');
    if(!box){box=document.createElement('div');box.className='v38279r2-account-positions';const empty=[...card.querySelectorAll('*')].find(x=>(x.textContent||'').trim()==='Nenhuma posição verificada nesta conta.');if(empty)empty.replaceWith(box);else card.appendChild(box)}
    box.innerHTML=mine.map(v38279r2PositionLabel).join('');
  }
  const kpi=[...view.querySelectorAll('*')].find(el=>{const t=el.textContent||'';return t.includes('VALOR EM POSIÇÕES')&&t.includes('CONTAS COM POSIÇÕES')&&t.includes('ATRIBUIÇÕES CANÔNICAS')&&t.includes('CAIXA CONSOLIDADO')&&el.children.length>=4});
  const regbox=[...view.querySelectorAll('*')].find(el=>{const t=(el.textContent||'').trim();return t.includes('REGISTRO UNIVERSAL')&&t.includes('Instituições e contas')&&el.querySelectorAll('button').length>=1});
  if(kpi&&regbox){
    let anchor=regbox;
    while(anchor.parentElement&&anchor.parentElement!==view&&![...anchor.parentElement.children].includes(kpi))anchor=anchor.parentElement;
    const parent=anchor.parentElement;if(parent&&kpi.parentElement===parent)parent.insertBefore(kpi,anchor.nextSibling);
    kpi.classList.add('v38279r2-kpis');
  }
  const fi=positions.filter(p=>p.position_domain==='FIXED_INCOME'),byCur={};
  fi.forEach(p=>{if(p.principal!=null){const c=p.currency||'UNAVAILABLE';byCur[c]=(byCur[c]||0)+Number(p.principal)}});
  if(fi.length){
    let note=view.querySelector('#v38279r2ProjectionNote');if(!note){note=document.createElement('div');note.id='v38279r2ProjectionNote';note.className='v38279r2-note'}
    note.innerHTML=`<b>Posições especializadas verificadas</b><span>${fi.length} renda fixa · ${Object.entries(byCur).map(([c,v])=>v38279r2Money(v,c)).join(' · ')} · sem conversão cambial silenciosa</span>`;
    if(kpi?.parentElement)kpi.insertAdjacentElement('afterend',note);
  }
}
const _v38279r2RenderAccounts=(typeof v38269RenderAccounts==='function')?v38269RenderAccounts:null;
if(_v38279r2RenderAccounts){
  v38269RenderAccounts=async function(){const r=await _v38279r2RenderAccounts.apply(this,arguments);await v38279r2ApplyAccountsProjection();return r}
}

/* V38279R3_UNIFIED_ACCOUNT_CARD_RENDERER
   Presentation-only convergence. Authorities remain unchanged. */
function v38279r3Money(v,c){
  if(v==null||v==='')return '—';
  try{return new Intl.NumberFormat('pt-BR',{style:'currency',currency:c||'EUR'}).format(Number(v))}
  catch(e){return `${v} ${c||''}`}
}
function v38279r3Flag(country){
  const x=String(country||'').toUpperCase();
  if(x==='BR')return '🇧🇷'; if(['PT','EU','DE','ES','FR','IT','NL','IE','AT','BE','LU'].includes(x))return '🇪🇺';
  return '🌐';
}
function v38279r3LegacyAccounts(){
  const p=(lastStatus||{}).portfolio||{}, out=[];
  for(const name of ['N26','Revolut']){
    const rows=p.accounts?.[name]||[];
    if(!rows.length)continue;
    const value=rows.reduce((s,x)=>s+Number(x.value_eur||x.value||0),0);
    out.push({
      key:'legacy:'+name, institution_name:name, account_name:name, currency:'EUR',
      country:'EU', management_mode:'LEGACY', account_id:null, value:value,
      positions:rows.map(x=>({
        position_domain:'CRYPTO',symbol:x.asset||x.symbol,name:x.asset||x.symbol,
        currency:'EUR',current_value:Number(x.value_eur||x.value||0),
        pnl:Number(x.pnl_eur||x.pnl||0), pnl_pct:x.pnl_pct
      }))
    });
  }
  return out;
}
function v38279r3PositionValue(p){
  if(p.position_domain==='FIXED_INCOME')return p.principal==null?null:Number(p.principal);
  if(p.current_value!=null)return Number(p.current_value);
  if(p.value!=null)return Number(p.value);
  return null;
}
function v38279r3PositionRow(p){
  const val=v38279r3PositionValue(p), c=p.currency||p.valuation_currency||'';
  if(p.position_domain==='FIXED_INCOME'){
    const rate=(p.indexer&&p.indexer!=='UNKNOWN')?(p.indexer_pct!=null?`${p.indexer_pct}% ${p.indexer}`:p.indexer):'Taxa não informada';
    const liq=p.liquidity_type==='DAILY'?'Liquidez diária':(p.liquidity_type||'Liquidez não informada');
    const mat=p.maturity_date?` · venc. ${String(p.maturity_date).split('-').reverse().join('/')}`:'';
    return `<div class="v38279r3-pos"><div><b>${esc(p.name||p.instrument_id||'Renda fixa')}</b><small>FIXED_INCOME · ${esc(rate)} · ${esc(liq)}${esc(mat)}</small></div><strong>${v38279r3Money(val,c)}</strong></div>`;
  }
  const pnl=p.pnl!=null?` · P/L ${v38279r3Money(p.pnl,c)}`:'';
  return `<div class="v38279r3-pos"><div><b>${esc(p.symbol||p.name||p.instrument_id||'Posição')}</b><small>${esc(p.position_domain||p.asset_class||'POSITION')}${esc(pnl)}</small></div><strong>${v38279r3Money(val,c)}</strong></div>`;
}
function v38279r3Card(a){
  const total=a.value!=null?a.value:a.positions.reduce((s,p)=>s+(v38279r3PositionValue(p)||0),0);
  const tools=a.account_id
    ? `<button onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button>`
    : `<button disabled title="Conta legada; metadados continuam no fluxo existente">Legado</button>`;
  return `<article class="v38279r3-card">
    <header><div class="v38279r3-ident"><span class="v38279r3-mark">${esc((a.institution_name||'?').slice(0,2).toUpperCase())}</span><div><b>${esc(a.institution_name||'Instituição')}</b><small>${esc(a.account_name||'Conta')} · ${esc(a.currency||'UNAVAILABLE')} · ${esc(a.management_mode||'UNAVAILABLE')}</small></div></div>
    <div class="v38279r3-headright"><span>${v38279r3Flag(a.country)}</span><strong>${v38279r3Money(total,a.currency)}</strong></div></header>
    <div class="v38279r3-tools">${tools}</div>
    <div class="v38279r3-positions">${a.positions.length?a.positions.map(v38279r3PositionRow).join(''):'<span class="muted">Nenhuma posição verificada nesta conta.</span>'}</div>
  </article>`;
}
async function v38279r3Render(){
  const view=document.getElementById('view-accounts'); if(!view)return;
  let reg,pos;
  try{[reg,pos]=await Promise.all([jsonFetch('/api/investment-registry'),jsonFetch('/api/positions')])}catch(e){return}
  const institutions=reg.institutions||[], accounts=reg.accounts||[], positions=pos.positions||[];
  const im=new Map(institutions.map(i=>[i.institution_id,i]));
  const canonical=accounts.map(a=>{
    const i=im.get(a.institution_id)||{};
    const mine=positions.filter(p=>p.account_id===a.account_id);
    return {key:a.account_id,account_id:a.account_id,institution_name:i.name||a.institution_id,account_name:a.name||'Conta',
      currency:a.currency,country:i.country||'BR',management_mode:a.management_mode||'MANUAL',positions:mine};
  });
  const all=canonical.concat(v38279r3LegacyAccounts());

  /* Keep the existing Registro Universal as the registration surface. */
  const regSurface=[...view.querySelectorAll('*')].find(el=>{
    const t=(el.textContent||''); return t.includes('REGISTRO UNIVERSAL')&&t.includes('Instituições e contas')&&el.querySelectorAll('button').length>=1;
  });
  if(!regSurface)return;

  /* Find the highest local wrapper that still represents only Registro Universal. */
  let regBlock=regSurface;
  while(regBlock.parentElement&&regBlock.parentElement!==view){
    const t=regBlock.parentElement.textContent||'';
    if(t.includes('VALOR EM POSIÇÕES')||t.includes('N26')||t.includes('Itaú Unibanco'))break;
    regBlock=regBlock.parentElement;
  }

  let host=view.querySelector('#v38279r3UnifiedAccounts');
  if(!host){host=document.createElement('section');host.id='v38279r3UnifiedAccounts';regBlock.insertAdjacentElement('afterend',host)}

  const totals={}; let accountsWithPositions=0;
  all.forEach(a=>{if(a.positions.length)accountsWithPositions++; const v=a.value!=null?a.value:a.positions.reduce((s,p)=>s+(v38279r3PositionValue(p)||0),0); if(v){totals[a.currency]=(totals[a.currency]||0)+v}});
  const totalText=Object.entries(totals).map(([c,v])=>v38279r3Money(v,c)).join(' · ')||'—';
  host.innerHTML=`<div class="v38279r3-kpis">
    <div><small>VALOR EM POSIÇÕES</small><b>${totalText}</b><span>por moeda, sem FX implícito</span></div>
    <div><small>CONTAS COM POSIÇÕES</small><b>${accountsWithPositions}</b><span>projeção universal</span></div>
    <div><small>CONTAS REGISTRADAS</small><b>${all.length}</b><span>legadas + canônicas</span></div>
    <div><small>MOEDAS</small><b>${Object.keys(totals).sort().join(' · ')||'—'}</b><span>sem consolidação cambial</span></div>
  </div>
  <div class="v38279r3-grid">${all.map(v38279r3Card).join('')}</div>
  <div class="v38279r3-note">Uma projeção visual para todas as contas. Autoridades financeiras originais preservadas.</div>`;

  /* Hide old parallel account/KPI generations, but never delete or mutate their data. */
  [...view.children].forEach(ch=>{
    if(ch===host||ch===regBlock||ch.contains(regBlock)||regBlock.contains(ch))return;
    const t=ch.textContent||'';
    if(t.includes('VALOR EM POSIÇÕES')||t.includes('CONTRATO DE CONTA')||t.includes('Editar metadados')||
       (t.includes('Itaú Unibanco')&&t.includes('Bradesco'))||(t.includes('N26')&&t.includes('Revolut'))){
      ch.classList.add('v38279r3-superseded');
    }
  });
}
const _v38279r3ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
  const r=_v38279r3ShowExperienceView.apply(this,arguments);
  if(name==='accounts')requestAnimationFrame(()=>v38279r3Render());
  return r;
};
document.addEventListener('DOMContentLoaded',()=>{if(document.getElementById('view-accounts')?.classList.contains('active-view'))requestAnimationFrame(()=>v38279r3Render())});

/* R21.373I4_CANONICAL_ACCOUNT_INTELLIGENCE_JOIN */
function r21373iScoreRows(accountId){
 const rows=(((lastStatus||{}).portfolio||{}).scores)||[],aid=String(accountId||'');
 return rows.filter(s=>String(s.account_id||s.account||'')===aid);
}
function r21373iEnrichPositions(accountId,positions){
 const scores=r21373iScoreRows(accountId);
 return (positions||[]).map(p=>{
  const symbol=String(p.symbol||p.asset||p.instrument_id||'').split(':').pop().toUpperCase();
  const s=scores.find(x=>String(x.asset||x.symbol||'').toUpperCase()===symbol)||null;
  if(!s)return p;
  const eur=String(p.currency||'').toUpperCase()==='EUR'; return {...p,current_value:p.current_value??(eur?s.current_value_eur??null:null),pnl:p.pnl??(eur?s.pnl_eur??null:null),pnl_pct:p.pnl_pct??(eur?s.pnl_pct??null:null),intelligence:s};
 });
}
function r21373iAccountIntelligence(a){
 const scores=r21373iScoreRows(a.account_id);
 return {...a,positions:r21373iEnrichPositions(a.account_id,a.positions||[]),intelligence_rows:scores};
}

/* V38279R4_RUNTIME_ACCOUNT_RENDERER_CONSOLIDATION */
function v38279r4LegacyAccounts(){
  const p=(lastStatus||{}).portfolio||{},out=[];
  for(const name of ['N26','Revolut']){
    const rows=p.accounts?.[name]||[]; if(!rows.length)continue;
    out.push({legacy:true,institution_name:name,country:'EU',institution_type:'FINANCIAL',
      account_id:null,account_name:name,account_type:'INVESTMENT',currency:'EUR',management_mode:'LEGACY',
      positions:rows.map(x=>({position_domain:'CRYPTO',symbol:x.asset||x.symbol,name:x.asset||x.symbol,
        currency:'EUR',current_value:Number(x.current_value_eur??x.value_eur??x.value??0),
        pnl:Number(x.pnl_eur??x.pnl??0),pnl_pct:x.pnl_pct}))});
  } return out;
}
function v38279r4Card(a){
  const vals=(a.positions||[]).map(v38279r3PositionValue).filter(v=>v!=null);
  const total=vals.reduce((s,v)=>s+Number(v||0),0);
  const cash=a.canonical_cash||null;
  const cashText=cash&&cash.amount!=null?v38279r3Money(Number(cash.amount),cash.currency||a.currency):'—';
  const legacyEntity=a.legacy&&typeof v382421EntityForLegacy==='function'?v382421EntityForLegacy(a.institution_name):null;
  const tools=a.legacy
    ? (legacyEntity?`<button onclick="v382421EditMetadata('${esc(legacyEntity.account_id)}')">Editar metadados</button>`:'')
    : `<button onclick="v382691EditAccount('${esc(a.account_id)}')">Editar conta</button><button class="primary" onclick="v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button>`;
  return `<article class="v38279r4-card"><header class="v38279r4-head">
    <div class="v38279r4-ident"><span class="v38279r4-mark">${esc((a.institution_name||'?').slice(0,2).toUpperCase())}</span><div><b>${esc(a.institution_name||'Instituição')}</b><small>${esc(a.country||'UNAVAILABLE')} · ${esc(a.institution_type||'UNAVAILABLE')}</small></div></div>
    <div class="v38279r4-summary"><span>${v38279r3Flag(a.country)}</span><div><small>VALOR EM POSIÇÕES</small><strong>${vals.length?v38279r3Money(total,a.currency):'—'}</strong><small>CAIXA DISPONÍVEL · ${cashText}</small></div></div></header>
    <div class="v38279r4-accountline"><div><b>${esc(a.account_name||'Conta')}</b><small>${esc(a.account_type||'ACCOUNT')} · ${esc(a.currency||'UNAVAILABLE')} · ${esc(a.management_mode||'UNAVAILABLE')} · ${esc(a.owner_profile||'UNSPECIFIED')}</small></div><div class="v38279r4-actions">${tools}</div></div>
    <div class="v38279r4-positions">${(a.positions||[]).length?(a.positions||[]).map(v38279r3PositionRow).join(''):'<span class="muted">Nenhuma posição verificada nesta conta.</span>'}</div></article>`;
}
async function v38279r4Render(){
  const placeholder=document.getElementById('view-placeholder'),content=document.getElementById('viewContent'),title=document.getElementById('viewTitle');
  if(!placeholder||!content||!title||String(title.textContent||'').trim()!=='Contas e Bancos')return false;
  let reg,pos,live; try{[reg,pos,live]=await Promise.all([jsonFetch('/api/investment-registry'),jsonFetch('/api/positions'),jsonFetch('/api/portfolio/live-projection')])}
  catch(e){content.innerHTML=`<article class="card"><b>Contas indisponíveis</b><p class="muted">${esc(e.message||String(e))}</p></article>`;return false}
  /* R21.374N_ACCOUNT_EXPERIENCE_CANONICAL_CUTOVER:
     Registry owns account identity; Universal Positions owns position visibility;
     Canonical Live Projection supplies cash only. Never merge live positions into ownership. */
  const institutions=reg.institutions||[],accounts=reg.accounts||[],positions=pos.positions||[],cashRows=((live||{}).projection||{}).cash||[];
  const cashByAccount=new Map();
  cashRows.forEach(x=>{const aid=String(x.account_id||'');if(aid&&aid!=='None'&&aid.startsWith('acct_'))cashByAccount.set(aid,{amount:x.amount,currency:x.currency,portfolio_id:x.portfolio_id,source:x.source})});
  const im=new Map(institutions.map(i=>[i.institution_id,i]));
  const canonical=accounts.map(a=>{const i=im.get(a.institution_id)||{};return r21373iAccountIntelligence({
    legacy:false,institution_name:i.name||a.institution_id,country:i.country||'UNAVAILABLE',institution_type:i.institution_type||'UNAVAILABLE',owner_profile:a.owner_profile||'UNSPECIFIED',canonical_cash:cashByAccount.get(a.account_id)||null,
    account_id:a.account_id,account_name:a.name||'Conta',pricing_plan:a.pricing_plan||null,account_type:a.account_type||'ACCOUNT',currency:a.currency||'UNAVAILABLE',
    management_mode:a.management_mode||'MANUAL',positions:positions.filter(p=>p.account_id===a.account_id)});}); /* R21.373M_CANONICAL_ACCOUNT_VISUAL_CUTOVER */ const all=canonical;
  const totals={};let withPositions=0,positionCount=0;
  all.forEach(a=>{if(a.positions.length)withPositions++;positionCount+=a.positions.length;const sum=a.positions.map(v38279r3PositionValue).filter(v=>v!=null).reduce((z,v)=>z+Number(v||0),0);if(sum)totals[a.currency]=(totals[a.currency]||0)+sum});
  const totalText=Object.entries(totals).sort().map(([c,v])=>v38279r3Money(v,c)).join(' · ')||'—';
  content.innerHTML=`<section class="v38279r4-registry"><div><small>REGISTRO UNIVERSAL</small><b>Instituições e contas</b><span>Uma autoridade para Brasil, Europa e futuros mercados.</span></div><div><button onclick="v38265OpenInstitution()">+ Instituição</button><button onclick="r21366bOpenCash('DEPOSIT')">+ Adicionar dinheiro</button><button onclick="r21366bOpenCash('WITHDRAWAL')">− Retirar dinheiro</button><button class="primary" onclick="v38265OpenAccount()">+ Conta</button></div></section>
  <section class="v38279r4-kpis"><div><small>VALOR EM POSIÇÕES</small><b>${totalText}</b><span>por moeda, sem FX implícito</span></div><div><small>CONTAS COM POSIÇÕES</small><b>${withPositions}</b><span>projeção universal</span></div><div><small>POSIÇÕES CANÔNICAS</small><b>${positionCount}</b><span>ownership universal · proveniência preservada</span></div><div><small>MOEDAS</small><b>${Object.keys(totals).sort().join(' · ')||'—'}</b><span>sem consolidação cambial</span></div></section>
  <section id="v38279r4UnifiedAccounts" class="v38279r4-grid">${all.map(v38279r4Card).join('')}</section>
  <div class="v38279r4-note">Uma única projeção visual para todas as contas. Fontes financeiras e autoridades originais permanecem separadas e preservadas.</div>`; return true;
}
/* Actual runtime authority: v38130Accounts -> v38240Accounts -> #viewContent. */
v38130Accounts=async function(){await v38240Accounts();await v38279r4Render();};
/* R21.375B_COMPACT_ACCOUNT_EXPERIENCE_NAV_SCROLL_FOUNDATION */
let R21375B_ACCOUNTS=[];
function r21375bFriendly(v){const x=String(v||'').toUpperCase();return ({INVESTMENT:'Investimentos',BANK:'Conta corrente',CREDIT:'Crédito',MANUAL:'Manual',CONNECTED_READ:'Conectada · leitura',CONNECTED_EXECUTE:'Conectada · execução',PF:'PF',PJ:'PJ',UNSPECIFIED:'Perfil não informado'}[x]||String(v||'—'))}
function r21375bPositionName(p){return String(p.name||p.symbol||p.asset||p.instrument_id||'Posição').replace(/^CRYPTO:GLOBAL:/,'')}
function r21375bAccountMetrics(a){const vals=(a.positions||[]).map(v38279r3PositionValue).filter(v=>v!=null);return {value:vals.length?vals.reduce((z,v)=>z+Number(v||0),0):null,count:(a.positions||[]).length}}
function r21375bCompactCard(a){const m=r21375bAccountMetrics(a),cash=a.canonical_cash||null,value=m.value==null?'—':v38279r3Money(m.value,a.currency),cashText=cash&&cash.amount!=null?v38279r3Money(Number(cash.amount),cash.currency||a.currency):'—';return `<button type="button" class="r21375b-account" onclick="r21375bOpenAccount('${esc(a.account_id)}')"><span class="r21375b-mark">${esc((a.institution_name||'?').slice(0,2).toUpperCase())}</span><span class="r21375b-main"><b>${esc(a.institution_name||'Instituição')}</b><small>${esc(a.account_name||'Conta')} · ${esc(a.currency||'—')} · ${esc(r21375bFriendly(a.owner_profile))} · Plano: ${esc(a.pricing_plan||'Não informado')}</small></span><span class="r21375b-stat"><small>POSIÇÕES</small><b>${m.count}</b></span><span class="r21375b-stat"><small>VALOR CONHECIDO</small><b>${value}</b></span><span class="r21375b-stat"><small>CAIXA DISPONÍVEL</small><b>${cashText}</b></span><span class="r21375b-chevron">›</span></button>`}
function r21375bDetailPosition(p){const current=p.current_value!=null?v38279r3Money(Number(p.current_value),p.currency):'—',principal=p.principal!=null?v38279r3Money(Number(p.principal),p.currency):'—',kind=String(p.asset_class||p.position_domain||'Posição').replaceAll('_',' ');return `<div class="r21375b-pos"><div><b>${esc(r21375bPositionName(p))}</b><small>${esc(kind)} · ${esc(p.currency||'—')}</small></div><div><small>VALOR ATUAL</small><b>${current}</b></div><div><small>PRINCIPAL</small><b>${principal}</b></div></div>`}
function r21375bOpenAccount(accountId){const a=R21375B_ACCOUNTS.find(x=>String(x.account_id)===String(accountId));if(!a)return;const m=r21375bAccountMetrics(a),cash=a.canonical_cash||null,cashText=cash&&cash.amount!=null?v38279r3Money(Number(cash.amount),cash.currency||a.currency):'—';openModal((a.institution_name||'Instituição')+' • '+(a.account_name||'Conta'),`<div class="r21375b-detail-meta">${esc(r21375bFriendly(a.account_type))} · ${esc(a.currency||'—')} · ${esc(r21375bFriendly(a.management_mode))} · ${esc(r21375bFriendly(a.owner_profile))} · Plano: ${esc(a.pricing_plan||'Não informado')}</div><div class="r21375b-detail-kpis"><div><small>POSIÇÕES</small><b>${m.count}</b></div><div><small>CAIXA DISPONÍVEL</small><b>${cashText}</b></div></div><div class="r21375b-detail-actions"><button onclick="closeModal();v382691EditAccount('${esc(a.account_id)}')">Editar conta</button><button class="primary" onclick="closeModal();v38269OpenPositionForAccount('${esc(a.account_id)}')">+ Vincular posição</button><button onclick="closeModal();r21386ls19aOpenManualTrade('${esc(a.account_id)}')">+ Registrar investimento</button></div><div class="r21375b-detail-list">${(a.positions||[]).length?(a.positions||[]).map(r21375bDetailPosition).join(''):'<span class="muted">Nenhuma posição vinculada.</span>'}</div>`)}
const r21375bBaseRender=v38279r4Render;
v38279r4Render=async function(){const ok=await r21375bBaseRender();if(!ok)return ok;const content=document.getElementById('viewContent');if(!content)return ok;let reg,live;try{[reg,live]=await Promise.all([jsonFetch('/api/investment-registry'),jsonFetch('/api/portfolio/live-projection')])}catch(e){return ok}const institutions=reg.institutions||[],accounts=reg.accounts||[],liveProjection=((live||{}).projection||{}),positions=(liveProjection.positions||[]).filter(p=>Number(p.quantity)>0).map(p=>Object.assign({},p,{current_value:p.market_value,principal:p.cost_basis,position_domain:(String(p.instrument_id||'').split(':')[0]||'POSITION')})),cashRows=liveProjection.cash||[],cashByAccount=new Map();cashRows.forEach(x=>{const aid=String(x.account_id||'');if(aid&&aid!=='None'&&aid.startsWith('acct_'))cashByAccount.set(aid,{amount:x.amount,currency:x.currency,portfolio_id:x.portfolio_id,source:x.source})});const im=new Map(institutions.map(i=>[i.institution_id,i]));R21375B_ACCOUNTS=accounts.map(a=>{const i=im.get(a.institution_id)||{};return r21373iAccountIntelligence({legacy:false,institution_name:i.name||a.institution_id,country:i.country||'UNAVAILABLE',institution_type:i.institution_type||'UNAVAILABLE',owner_profile:a.owner_profile||'UNSPECIFIED',canonical_cash:cashByAccount.get(a.account_id)||null,account_id:a.account_id,account_name:a.name||'Conta',pricing_plan:a.pricing_plan||null,account_type:a.account_type||'ACCOUNT',currency:a.currency||'UNAVAILABLE',management_mode:a.management_mode||'MANUAL',positions:positions.filter(p=>p.account_id===a.account_id)})});const host=document.getElementById('v38279r4UnifiedAccounts');if(host){host.className='r21375b-account-list';host.innerHTML=R21375B_ACCOUNTS.map(r21375bCompactCard).join('')}return true}
const R21375B_VIEW_KEY='porquinho.experience.view.v1',R21375B_SCROLL_KEY='porquinho.experience.scroll.v1';
const r21375bBaseShowExperienceView=showExperienceView;
showExperienceView=function(name,button){const r=r21375bBaseShowExperienceView.apply(this,arguments);try{sessionStorage.setItem(R21375B_VIEW_KEY,String(name||'dashboard'))}catch(e){}return r};
function r21375bSaveScroll(){try{sessionStorage.setItem(R21375B_SCROLL_KEY,String(Math.max(0,window.scrollY||0)))}catch(e){}}
window.addEventListener('pagehide',r21375bSaveScroll);window.addEventListener('beforeunload',r21375bSaveScroll);
document.addEventListener('DOMContentLoaded',()=>{let view=null,y=0;try{view=sessionStorage.getItem(R21375B_VIEW_KEY);y=Number(sessionStorage.getItem(R21375B_SCROLL_KEY)||0)}catch(e){}if(view&&document.querySelector(`[data-target="${CSS.escape(view)}"]`)){setTimeout(()=>{showExperienceView(view,document.querySelector(`[data-target="${CSS.escape(view)}"]`));requestAnimationFrame(()=>window.scrollTo({top:y,behavior:'auto'}))},0)}})

const r21368bAccountsRuntime=v38130Accounts;
v38130Accounts=async function(){await r21368bAccountsRuntime();r21368bAttachPlanningAction();};

/* V382710_FIXED_INCOME_VALUATION_UI */
async function v382710OpenValuation(positionId,currency,name){
  const now=new Date().toISOString().slice(0,16);
  openModal('Registrar valuation • '+(name||'Renda fixa'),`
    <div class="v382710-note">Observação de saldo. Não altera principal e não cria transação.</div>
    <label>Saldo bruto<input id="v382710Gross" type="number" min="0" step="0.01"></label>
    <label>Saldo líquido<input id="v382710Net" type="number" min="0" step="0.01"></label>
    <div class="form-grid"><label>IRRF observado<input id="v382710Irrf" type="number" min="0" step="0.01"></label><label>IOF observado<input id="v382710Iof" type="number" min="0" step="0.01"></label></div>
    <div class="form-grid"><label>Alíquota IR atual (%)<input id="v382710Ir" type="number" min="0" step="0.01"></label><label>Próxima alíquota (%)<input id="v382710NextIr" type="number" min="0" step="0.01"></label></div>
    <label>Observado em<input id="v382710At" type="datetime-local" value="${now}"></label>
    <label>Proveniência<input id="v382710Prov" value="Observação explícita do app da instituição"></label>
    <div class="modal-actions"><button onclick="closeModal()">Cancelar</button><button class="primary" onclick="v382710SaveValuation('${esc(positionId)}','${esc(currency)}')">Salvar observação</button></div>`);
}
async function v382710SaveValuation(pid,currency){
  const val=id=>document.getElementById(id)?.value||null;
  const at=val('v382710At');
  const payload={position_id:pid,currency,gross_balance:val('v382710Gross'),net_balance:val('v382710Net'),
    irrf:val('v382710Irrf'),iof:val('v382710Iof'),current_ir_rate:val('v382710Ir'),next_ir_rate:val('v382710NextIr'),
    observed_at:at?new Date(at).toISOString():null,provenance:val('v382710Prov')};
  try{
    await jsonFetch('/api/positions/fixed-income/valuations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    closeModal(); await v38279r4Render();
  }catch(e){alert('Valuation não salvo: '+(e.message||String(e)))}
}
const v382710BasePositionRow=v38279r3PositionRow;
v38279r3PositionRow=function(p){
  let html=v382710BasePositionRow(p);
  if((p.position_domain==='FIXED_INCOME'||p.asset_class==='FIXED_INCOME')&&p.position_id){
    html=html.replace('</div>',` <button class="v382710-mini" onclick="v382710OpenValuation('${esc(p.position_id)}','${esc(p.currency||'')}','${esc(p.name||'Renda fixa')}')">+ Valuation</button></div>`);
  }
  return html;
};

/* V382710R1_VALUATION_MODAL_REPAIR: showModal -> canonical openModal */

/* V382711_FIXED_INCOME_VALUATION_PROJECTION */
async function v382711LatestValuations(){
  try{
    const x=await jsonFetch('/api/positions/fixed-income/valuations');
    return x.latest_by_position||{};
  }catch(e){ return {}; }
}
function v382711Money(v,c){
  if(v==null||!Number.isFinite(Number(v)))return '—';
  return v38279r3Money(Number(v),c);
}
function v382711ValuationBlock(p,o){
  if(!o)return `<div class="v382711-unavailable">Valuation indisponível · principal ${v382711Money(p.principal,p.currency)}</div>`;
  const principal=Number(p.principal||0),gross=Number(o.gross_balance),net=Number(o.net_balance);
  const gg=gross-principal,ng=net-principal;
  let at=o.observed_at||'';
  try{at=new Date(at).toLocaleString('pt-PT')}catch(e){}
  return `<div class="v382711-valuation">
    <span><small>Principal</small><b>${v382711Money(principal,p.currency)}</b></span>
    <span><small>Bruto observado</small><b>${v382711Money(gross,p.currency)}</b><em>${gg>=0?'+':''}${v382711Money(gg,p.currency)}</em></span>
    <span><small>Líquido observado</small><b>${v382711Money(net,p.currency)}</b><em>${ng>=0?'+':''}${v382711Money(ng,p.currency)}</em></span>
    <span><small>Observado em</small><b>${esc(at)}</b><em>${esc(o.deduction_reconciliation||'')}</em></span>
  </div>`;
}
const v382711BaseR4Render=v38279r4Render;
v38279r4Render=async function(){
  const ok=await v382711BaseR4Render(); if(!ok)return ok;
  const vals=await v382711LatestValuations();
  let pos; try{pos=await jsonFetch('/api/positions')}catch(e){return ok}
  for(const p of (pos.positions||[])){
    if((p.position_domain!=='FIXED_INCOME'&&p.asset_class!=='FIXED_INCOME')||!p.position_id)continue;
    const btn=[...document.querySelectorAll('.v382710-mini')].find(b=>(b.getAttribute('onclick')||'').includes(p.position_id));
    if(!btn)continue;
    const host=btn.closest('.v38279r3-pos')||btn.parentElement?.parentElement;
    if(host&&!host.querySelector('.v382711-valuation,.v382711-unavailable'))host.insertAdjacentHTML('beforeend',v382711ValuationBlock(p,vals[p.position_id]));
  }
  /* Replace only BRL FI contribution in KPI with latest gross observation; never mix currencies. */
  const all=(pos.positions||[]).filter(p=>p.position_domain==='FIXED_INCOME'||p.asset_class==='FIXED_INCOME');
  const brl=all.reduce((z,p)=>z+Number((vals[p.position_id]||{}).gross_balance??p.principal??0),0);
  const kpi=document.querySelector('.v38279r4-kpis>div:first-child b');
  if(kpi&&brl) {
    const eur=(kpi.textContent.match(/€\s*[\d.,]+/)||[])[0];
    kpi.textContent=`${v382711Money(brl,'BRL')}${eur?' · '+eur:''}`;
  }
  return ok;
};

/* V382712_UNIVERSAL_PORTFOLIO_VALUATION_INTEGRATION */
function v382712Money(v,c){return v==null?'—':v38279r3Money(Number(v),c)}
async function v382712RenderPortfolioValuation(){
  const host=document.querySelector('.v38277-universal-table')||document.querySelector('[data-v38277-universal]')||document.querySelector('#universalPositions');
  if(!host)return false;
  let d;try{d=await jsonFetch('/api/portfolio/universal/valued')}catch(e){return false}
  const rows=d.fixed_income_positions||[]; if(!rows.length)return true;
  const html=rows.map(p=>`<div class="v382712-row">
    <div><b>${esc(p.name||p.instrument_id)}</b><small>${esc(p.asset_class)} · ${esc(p.currency||'UNAVAILABLE')}</small></div>
    <div><small>Principal</small><b>${v382712Money(p.principal,p.currency)}</b></div>
    <div><small>Bruto atual</small><b>${v382712Money(p.current_gross_value,p.currency)}</b><em>${p.gross_gain==null?'':((p.gross_gain>=0?'+':'')+v382712Money(p.gross_gain,p.currency))}</em></div>
    <div><small>Líquido / resgate</small><b>${v382712Money(p.current_net_value,p.currency)}</b><em>${p.net_gain==null?'':((p.net_gain>=0?'+':'')+v382712Money(p.net_gain,p.currency))}</em></div>
    <div><small>Valuation</small><b>${esc(p.valuation_status)}</b><em>${esc(p.observed_at||'')}</em></div>
  </div>`).join('');
  host.innerHTML=`<div class="v382712-head"><b>Posições universais • valuation observado</b><span>Sem conversão cambial silenciosa</span></div>${html}`;
  return true;
}
const v382712BasePortfolioRenderer=v38277RenderUniversalPositions;
v38277RenderUniversalPositions=async function(...args){
  const r=await v382712BasePortfolioRenderer(...args);
  await v382712RenderPortfolioValuation();
  return r;
};

/* V382712R1_RUNTIME_PORTFOLIO_VALUATION_REPAIR
   Actual visible authority is #v38277UniversalBlock, created by v38277RenderUniversalPositions. */
async function v382712r1RenderActualUniversalBlock(){
  const block=document.getElementById('v38277UniversalBlock');
  if(!block)return false;
  let d; try{d=await jsonFetch('/api/portfolio/universal/valued')}catch(e){return false}
  const rows=d.fixed_income_positions||[];
  if(!rows.length)return true;
  block.innerHTML=`<div class="card-head"><b>Posições universais</b><span>Valuation observado • sem conversão cambial silenciosa</span></div>
  <div class="table-wrap"><table class="v361-table"><thead><tr>
    <th>Ativo</th><th>Classe</th><th>Conta</th><th>Moeda</th><th>Principal</th>
    <th>Bruto atual</th><th>Líquido / resgate</th><th>Rend. bruto</th><th>Rend. líquido</th><th>Valuation</th>
  </tr></thead><tbody>${rows.map(p=>`<tr>
    <td><b>${esc(p.name||p.instrument_id||'—')}</b><div class="muted">${esc(p.instrument_id||'')}</div></td>
    <td>${esc(p.asset_class||'—')}</td><td>${esc(p.account_id||'—')}</td><td>${esc(p.currency||'—')}</td>
    <td>${v38277Money(p.principal,p.currency)}</td>
    <td>${v38277Money(p.current_gross_value,p.currency)}</td>
    <td>${v38277Money(p.current_net_value,p.currency)}</td>
    <td>${p.gross_gain==null?'—':((p.gross_gain>=0?'+':'')+v38277Money(p.gross_gain,p.currency))}</td>
    <td>${p.net_gain==null?'—':((p.net_gain>=0?'+':'')+v38277Money(p.net_gain,p.currency))}</td>
    <td><b>${esc(p.valuation_status||'UNAVAILABLE')}</b><div class="muted">${esc(p.observed_at||'')}</div></td>
  </tr>`).join('')}</tbody></table></div>
  <div class="muted" style="margin-top:8px">${Object.entries(d.totals_by_currency||{}).map(([c,v])=>`${esc(c)}: ${v38277Money(v,c)}`).join(' &nbsp; | &nbsp; ')}</div>`;
  return true;
}

/* R21_386KU_COMPACT_POSITION_DETAIL_START
   Universal portfolio presentation contract:
   compact common summary -> class-specialized detail modal.
   Read-only presentation; no financial/execution authority. */
let r21386kuPositionDetailRows=[];
function r21386kuVal(v,fallback='—'){return (v===null||v===undefined||v==='')?fallback:v}
function r21386kuMoney(v,c){return v==null?'—':v38277Money(Number(v),c)}
function r21386kuGain(v,c){
  if(v==null)return '—';
  const n=Number(v); if(!Number.isFinite(n))return '—';
  return (n>0?'+':'')+r21386kuMoney(n,c);
}
function r21386kuFriendly(v){
  const x=String(r21386kuVal(v)).replaceAll('_',' ').toLowerCase();
  return x==='—'?'—':x.replace(/(^|\s)\S/g,m=>m.toUpperCase());
}
function r21386kuField(label,value){
  return `<div class="r21386ku-field"><small>${esc(label)}</small><b>${value}</b></div>`;
}
function r21386kuSpecialized(p){
  const domain=String(p.position_domain||p.asset_class||'').toUpperCase();
  if(domain==='FIXED_INCOME'){
    const fields=[
      ['Indexador',r21386kuFriendly(p.indexer)],
      ['% benchmark',p.indexer_pct==null?'—':esc(p.indexer_pct)+'%'],
      ['Taxa fixa a.a.',p.fixed_rate==null?'—':esc(p.fixed_rate)+'%'],
      ['Spread',p.spread==null?'—':esc(p.spread)+'%'],
      ['Vencimento',esc(r21386kuVal(p.maturity_date))],
      ['Liquidez',r21386kuFriendly(p.liquidity_type)],
      ['Regime tributário',r21386kuFriendly(p.tax_regime)],
      ['Garantia / proteção',r21386kuFriendly(p.guarantee_type)]
    ];
    return `<section class="r21386ku-section"><h4>Características do ativo</h4><div class="r21386ku-grid">${fields.map(([a,b])=>r21386kuField(a,b)).join('')}</div></section>`;
  }
  const quantity=p.quantity==null?'—':esc(fmt(p.quantity,6));
  return `<section class="r21386ku-section"><h4>Características da posição</h4><div class="r21386ku-grid">${r21386kuField('Quantidade',quantity)}${r21386kuField('Classe',esc(r21386kuFriendly(domain||p.asset_class)))}</div></section>`;
}
function r21386kuOpenPosition(i){
  const p=r21386kuPositionDetailRows[Number(i)]; if(!p)return;
  const c=p.currency||p.valuation_currency||'';
  const title=p.name||p.symbol||p.instrument_id||'Posição';
  const principal=p.principal;
  const gross=p.current_gross_value??p.current_value;
  const net=p.current_net_value;
  const html=`<div class="r21386ku-detail">
    <div class="r21386ku-detail-meta">${esc(r21386kuFriendly(p.asset_class||p.position_domain))} · ${esc(p.account_name||p.account_id||'Conta indisponível')} · ${esc(c||'Moeda indisponível')}</div>
    <section class="r21386ku-section"><h4>Posição financeira</h4><div class="r21386ku-grid">
      ${r21386kuField('Principal',r21386kuMoney(principal,c))}
      ${r21386kuField('Bruto atual',r21386kuMoney(gross,c))}
      ${r21386kuField('Líquido / resgate',r21386kuMoney(net,c))}
      ${r21386kuField('Moeda',esc(c||'—'))}
    </div></section>
    <section class="r21386ku-section"><h4>Resultado</h4><div class="r21386ku-grid">
      ${r21386kuField('Ganho bruto',r21386kuGain(p.gross_gain,c))}
      ${r21386kuField('Ganho líquido',r21386kuGain(p.net_gain,c))}
    </div></section>
    ${r21386kuSpecialized(p)}
    <section class="r21386ku-section"><h4>Valuation e origem</h4><div class="r21386ku-grid">
      ${r21386kuField('Status',esc(r21386kuVal(p.valuation_status,'UNAVAILABLE')))}
      ${r21386kuField('Observado em',esc(r21386kuVal(p.observed_at)))}
      ${r21386kuField('Instrumento',esc(r21386kuVal(p.instrument_id)))}
      ${r21386kuField('Conta',esc(r21386kuVal(p.account_name||p.account_id)))}
    </div></section>
    <div class="r21386ku-note">Detalhe somente leitura · nenhuma compra, venda ou conversão cambial é executada nesta visualização.</div>
  </div>`;
  openModal(title,html);
}
function r21386kuSummaryRow(p,i){
  const c=p.currency||p.valuation_currency||'';
  const value=p.current_gross_value??p.current_value??p.principal;
  const gain=p.gross_gain??p.net_gain;
  const cls=r21386kuFriendly(p.asset_class||p.position_domain);
  const status=r21386kuFriendly(p.valuation_status||'UNAVAILABLE');
  return `<button type="button" class="r21386ku-row" onclick="r21386kuOpenPosition(${i})" aria-label="Ver detalhes de ${esc(p.name||p.symbol||p.instrument_id||'posição')}">
    <span class="r21386ku-main"><b>${esc(p.name||p.symbol||p.instrument_id||'—')}</b><small>${esc(cls)} · ${esc(p.account_name||p.account_id||'—')} · ${esc(c||'—')}</small></span>
    <span class="r21386ku-stat"><small>VALOR ATUAL</small><b>${r21386kuMoney(value,c)}</b></span>
    <span class="r21386ku-stat"><small>RESULTADO</small><b>${r21386kuGain(gain,c)}</b></span>
    <span class="r21386ku-status"><small>STATUS</small><b>${esc(status)}</b></span>
    <span class="r21386ku-chevron">›</span>
  </button>`;
}
async function r21386kuRenderCompactUniversalBlock(){
  const block=document.getElementById('v38277UniversalBlock'); if(!block)return false;
  let d; try{d=await jsonFetch('/api/portfolio/universal/valued')}catch(e){return false}
  let rows=Array.isArray(d.fixed_income_positions)?d.fixed_income_positions:[];
  if(!rows.length){
    try{const u=await jsonFetch('/api/portfolio/universal');rows=Array.isArray(u.positions)?u.positions:[]}catch(e){}
  }
  if(!rows.length)return true;
  r21386kuPositionDetailRows=rows;
  const totals=Object.entries(d.totals_by_currency||{}).map(([c,v])=>{
    const n=(v&&typeof v==='object')?(v.current_value??v.current_gross_value??v.total):v;
    return `<span><b>${esc(c)}</b> ${r21386kuMoney(n,c)}</span>`;
  }).join('');
  block.innerHTML=`<div class="card-head r21386ku-head"><div><b>Posições universais</b><small>Resumo universal · clique em uma posição para ver todos os detalhes</small></div><span>Sem conversão cambial silenciosa</span></div>
    <div class="r21386ku-list">${rows.map(r21386kuSummaryRow).join('')}</div>
    ${totals?`<div class="r21386ku-totals">${totals}</div>`:''}`;
  return true;
}
const r21386kuBaseUniversalRenderer=v38277RenderUniversalPositions;
v38277RenderUniversalPositions=async function(...args){
  const r=await r21386kuBaseUniversalRenderer(...args);
  await r21386kuRenderCompactUniversalBlock();
  return r;
};
/* R21_386KU_COMPACT_POSITION_DETAIL_END */

const v382712r1BaseUniversalRenderer=v38277RenderUniversalPositions;
v38277RenderUniversalPositions=async function(...args){
  const r=await v382712r1BaseUniversalRenderer(...args);
  await v382712r1RenderActualUniversalBlock();
  return r;
};

/* Porquinho V3.8.28.4 — Universal Intelligence presentation overlay.
   Read-only projection. Does not become financial authority. */
async function v38284UniversalIntelligence(){
  return await jsonFetch('/api/intelligence/universal');
}
function v38284FmtAction(a){
  if(a==='UNAVAILABLE_PENDING_DOMAIN_AUTHORITY') return 'Decisão especializada pendente';
  if(a==='UNAVAILABLE_HELD_ACTION_WITHOUT_VERIFIED_POSITION') return 'Ação bloqueada · posição não verificada';
  return a || 'Indisponível';
}
function v38284Card(x){
  const held=x.held?'Posição real':'Monitorado';
  return `<div class="v38284-card">
    <div class="v38284-card-top"><strong>${x.instrument_id||'Instrumento'}</strong><span>${held}</span></div>
    <div class="v38284-action">${v38284FmtAction(x.specialized_action)}</div>
    <div class="v38284-meta">${x.asset_class||'—'} · ${x.currency||'—'} · evidência ${x.evidence_quality||'indisponível'}</div>
  </div>`;
}
async function v38284RenderPortfolioIntelligence(){
  const host=document.getElementById('v38277UniversalBlock');
  if(!host) return;
  const d=await v38284UniversalIntelligence();
  let old=document.getElementById('v38284PortfolioIntel');
  if(old) old.remove();
  const box=document.createElement('section'); box.id='v38284PortfolioIntel'; box.className='v38284-panel';
  const s=d.summary||{}, pending=d.pending_intelligence||[];
  box.innerHTML=`<div class="v38284-head"><div><strong>Inteligência da carteira</strong><small>Projeção universal · leitura</small></div>
    <div class="v38284-kpis"><span>${s.held_positions||0} posições</span><span>${s.buy_opportunities||0} oportunidade(s)</span><span>${s.pending_or_unavailable_intelligence||0} pendência(s)</span></div></div>
    ${pending.length?`<div class="v38284-pending"><strong>Inteligência pendente</strong>${pending.map(v38284Card).join('')}</div>`:''}`;
  host.appendChild(box);
}
async function v38284RenderOpportunities(){
  const d=await v38284UniversalIntelligence();
  const title=[...document.querySelectorAll('h1,h2,h3')].find(x=>(x.textContent||'').trim().toLowerCase().includes('oportun'));
  if(!title) return;
  let host=document.getElementById('v38284Opportunities');
  if(!host){host=document.createElement('section');host.id='v38284Opportunities';host.className='v38284-panel';title.insertAdjacentElement('afterend',host);}
  const opp=d.opportunities||[];
  const lanes=d.by_currency||{};
  host.innerHTML=`<div class="v38284-head"><div><strong>Oportunidades universais</strong><small>Somente decisões especializadas COMPRE · sem FX silencioso</small></div>
    <div class="v38284-kpis"><span>${opp.length} COMPRE</span>${Object.entries(lanes).map(([c,v])=>`<span>${c}: caixa ${v.cash_available==null?'indisponível':v.cash_available}</span>`).join('')}</div></div>
    <div class="v38284-grid">${opp.length?opp.map(v38284Card).join(''):'<div class="v38284-empty">Nenhuma decisão especializada COMPRE disponível agora. Caixa continua sendo uma alternativa válida.</div>'}</div>`;
}
/* Hook actual runtime entrypoints; preserve existing renderers first. */
if(typeof renderPortfolioView==='function'){
  const v38284PrevPortfolioView=renderPortfolioView;
  renderPortfolioView=async function(...args){const r=await v38284PrevPortfolioView.apply(this,args);await v38284RenderPortfolioIntelligence();return r;}
}
if(typeof v38141Opportunities==='function'){
  const v38284PrevOpp=v38141Opportunities;
  v38141Opportunities=async function(...args){const r=await v38284PrevOpp.apply(this,args);await v38284RenderOpportunities();return r;}
}

/* V3.8.28.4-r2 — consolidate visible eligible opportunities after legacy renderer. */
function v38284r2Esc(v){return (typeof esc==='function')?esc(String(v??'')):String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function v38284r2UniversalOpportunityCard(x){
 const id=x.instrument_id||'Instrumento';
 const sym=(id.split(':').pop()||id);
 const model=x.specialized_model||'MODELO ESPECIALIZADO';
 return `<div class="v38141-fcard v38284r2-universal-card">
   <div class="v38141-fhead"><div><b>${v38284r2Esc(sym)}</b><small>${v38284r2Esc(x.asset_class||'—')} · ${v38284r2Esc(x.market||'—')}</small></div><span class="v38284r2-buy">COMPRE</span></div>
   <div class="v38284r2-currency">${v38284r2Esc(x.currency||'—')} · ${v38284r2Esc(model)}</div>
   <div class="v38284r2-meta">Evidência: ${v38284r2Esc(x.evidence_quality||'indisponível')} · posição: NÃO</div>
 </div>`;
}
async function v38284r2ConsolidateVisibleOpportunities(){
 const d=await v38284UniversalIntelligence();
 const host=document.getElementById('view-placeholder'); if(!host)return;
 const heads=[...host.querySelectorAll('b,strong')];
 const label=heads.find(x=>(x.textContent||'').trim()==='Oportunidades elegíveis agora');
 if(!label)return;
 const article=label.closest('article'); if(!article)return;
 const focus=article.querySelector('.v38141-focus'); if(!focus)return;

 /* Preserve rich legacy crypto cards only when they are truly COMPRE in the universal projection. */
 const allowed=new Set((d.opportunities||[]).map(x=>(x.instrument_id||'').split(':').pop()));
 [...focus.children].forEach(card=>{
   const b=card.querySelector('b'); const sym=(b?.textContent||'').trim();
   if(sym && !allowed.has(sym)) card.remove();
 });
 const present=new Set([...focus.children].map(card=>(card.querySelector('b')?.textContent||'').trim()));
 (d.opportunities||[]).forEach(x=>{
   const sym=(x.instrument_id||'').split(':').pop();
   if(!present.has(sym)) focus.insertAdjacentHTML('beforeend',v38284r2UniversalOpportunityCard(x));
 });
 const count=article.querySelector('.v38141-count'); if(count)count.textContent=String((d.opportunities||[]).length);
 const em=article.querySelector('.v38141-headcopy em'); if(em)em.textContent='Motores especializados · sem ranking bruto entre mercados';
 const small=article.querySelector('.v38141-headcopy small'); if(small)small.textContent='Cripto + Brasil + futuros mercados elegíveis';
 /* Remove the temporary top duplicate universal panel now that canonical visible section is universal. */
 document.getElementById('v38284Opportunities')?.remove();
}
async function v38284r2PortfolioIntelRuntime(){
 /* Wait for async universal position block to exist; then attach intelligence exactly once. */
 for(let i=0;i<12;i++){
   if(document.getElementById('v38277UniversalBlock')){await v38284RenderPortfolioIntelligence();return;}
   await new Promise(r=>setTimeout(r,80));
 }
}
if(typeof v38141Opportunities==='function'){
 const v38284r2PrevOpp=v38141Opportunities;
 v38141Opportunities=async function(...args){
   const r=await v38284r2PrevOpp.apply(this,args);
   await v38284r2ConsolidateVisibleOpportunities();
   return r;
 };
}
if(typeof renderPortfolioView==='function'){
 const v38284r2PrevPortfolio=renderPortfolioView;
 renderPortfolioView=async function(...args){
   const r=await v38284r2PrevPortfolio.apply(this,args);
   await v38284r2PortfolioIntelRuntime();
   return r;
 };
}

/* V3.8.28.4-r3 — stable sibling host for portfolio intelligence.
   Never append intelligence inside #v38277UniversalBlock because valuation refresh rewrites it. */
async function v38284r3RenderStablePortfolioIntelligence(){
  const universal=document.getElementById('v38277UniversalBlock');
  if(!universal || !universal.parentElement) return;
  const d=await v38284UniversalIntelligence();
  let box=document.getElementById('v38284PortfolioIntel');
  if(!box){
    box=document.createElement('section');
    box.id='v38284PortfolioIntel';
    box.className='v38284-panel v38284r3-stable';
  }
  /* Stable sibling: move out if an older renderer placed it inside the rewritten block. */
  if(box.parentElement!==universal.parentElement || box.previousElementSibling!==universal){
    universal.insertAdjacentElement('afterend',box);
  }
  const s=d.summary||{}, pending=d.pending_intelligence||[];
  box.innerHTML=`<div class="v38284-head"><div><strong>Inteligência da carteira</strong><small>Projeção universal · leitura</small></div>
    <div class="v38284-kpis"><span>${s.held_positions||0} posições</span><span>${s.buy_opportunities||0} oportunidade(s)</span><span>${s.pending_or_unavailable_intelligence||0} pendência(s)</span></div></div>
    ${pending.length?`<div class="v38284-pending"><strong>Inteligência pendente</strong>${pending.map(v38284Card).join('')}</div>`:''}`;
}
/* Override old append target with stable implementation, preserving all callers. */
v38284RenderPortfolioIntelligence=v38284r3RenderStablePortfolioIntelligence;

/* R21_386KV_FINAL_RENDER_OWNER_START
   Final presentation ownership for Universal Positions.
   Historical renderers remain data/valuation producers; KU owns the visible compact projection.
   Read-only UI wiring only; no financial/execution authority. */
const r21386kvBaseUniversalRenderer=v38277RenderUniversalPositions;
v38277RenderUniversalPositions=async function(...args){
  const result=await r21386kvBaseUniversalRenderer.apply(this,args);
  await r21386kuRenderCompactUniversalBlock();
  return result;
};
async function r21386kvReconcileUniversalPresentation(){
  if(!document.getElementById('v38277UniversalBlock')) return false;
  await r21386kuRenderCompactUniversalBlock();
  return true;
}
const r21386kvBaseIntelRenderer=v38284RenderPortfolioIntelligence;
v38284RenderPortfolioIntelligence=async function(...args){
  await r21386kvReconcileUniversalPresentation();
  return await r21386kvBaseIntelRenderer.apply(this,args);
};
/* R21_386KV_FINAL_RENDER_OWNER_END */

/* R21_386KS_SINGLE_DOM_OWNER_START
   #v38277UniversalBlock is the canonical structural anchor.
   This reconciler is the sole final DOM-order authority.
   Presentation only; no financial or execution authority. */
function r21386ksReconcilePortfolioLayout(){
  const universal=document.getElementById('v38277UniversalBlock');
  const intel=document.getElementById('v38284PortfolioIntel');
  if(!universal || !intel || !universal.parentElement) return false;
  if(intel.parentElement!==universal.parentElement || universal.nextElementSibling!==intel){
    universal.insertAdjacentElement('afterend',intel);
  }
  return true;
}
const r21386ksBaseIntelRenderer=v38284RenderPortfolioIntelligence;
v38284RenderPortfolioIntelligence=async function(...args){
  const result=await r21386ksBaseIntelRenderer.apply(this,args);
  r21386ksReconcilePortfolioLayout();
  return result;
};
/* R21_386KS_SINGLE_DOM_OWNER_END */

/* V38285_OPPORTUNITY_EXPERIENCE — cross-market presentation authority; READ ONLY */
function v38285Evidence(v){const n=Number(v);return Number.isFinite(n)?`${Math.round(n*100)}%`:'—'}
function v38285BRCard(d){
 const rat=Array.isArray(d.rationale)?d.rationale.join(' • '):(d.rationale||'—');
 const ctx=d.context||{};
 return `<div class="v38285-br-card"><div class="v38285-card-head"><div><span class="v38285-market">BR • AÇÃO</span><b>${esc(d.symbol||'—')}</b></div><span class="v3710-action ${v3710ActionClass(d.action)}">${esc(d.action||'—')}</span></div><div class="v38285-br-metrics"><span>Opportunity score<b>${esc(v3710Score(d.opportunity_score))}</b></span><span>Evidência<b>${esc(v38285Evidence(d.evidence_quality))}</b></span><span>Confidence<b>${esc(d.confidence?.level||'—')}</b></span><span>Posição<b>${d.has_position?'SIM':'NÃO'}</b></span></div><p>${esc(rat)}</p><div class="v38285-context">Ruleset <b>${esc(d.ruleset||'—')}</b> • técnico ${ctx.technical_available?'disponível':'indisponível'} • risco ${ctx.risk_available?'disponível':'indisponível'} • sizing ${d.sizing==null?'não definido':'disponível'}</div></div>`;
}
function v38285CryptoCard(x){
 return `<div class="v38285-crypto-card"><div class="v38285-card-head"><div><span class="v38285-market">CRYPTO • EXPERIMENTAL</span><b>${esc(x.asset||'—')}</b></div><span class="action-badge ${v38141AC(x.display_action||x.brain_action)}">${esc(x.display_action||x.brain_action||'—')}</span></div><div class="v38141-mini"><span>KPI<b>${v38141N(x.promising_pct)}</b></span><span>OPP<b>${v38141N(x.opportunity)}</b></span><span>ENT<b>${v38141N(x.entry)}</b></span><span>ASY<b>${v38141N(x.asymmetry)}</b></span><span>RISK<b>${v38141N(x.risk)}</b></span></div><p>${esc(x.rationale||'')}</p><div class="v38285-context">Motor <b>${esc(x.production_action||'—')}</b> • Brain <b>${esc(x.brain_action||'—')} *</b> • evidência <b>${esc(x.evidence_status||'—')}</b> • posição <b>${x.has_position?'SIM':'NÃO'}</b>${Number(x.experimental_cash_suggestion_eur||0)>0?` • caixa experimental <b>${v38141M(x.experimental_cash_suggestion_eur)}</b>`:''}</div></div>`;
}
function v38285Render(status,equities){
 const snap=status?.snapshot||{},brain=snap.brain_experimental||{},signals=Array.isArray(brain.signals)?brain.signals:[];
 const decisions=Array.isArray(equities?.decisions?.decisions)?equities.decisions.decisions:[];
 // A3: classify the existing producer's output without granting Brain authority.
 // Legacy COMPRE remains specialized evidence, not a universal canonical decision.
 const universalActions=new Set(['KEEP','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE','ABSTAIN','ABSTAIN_INSUFFICIENT_EVIDENCE','NO_ALLOCATION']);
 const canonical=decisions.filter(d=>d&&d.canonical_recommendation===true&&d.canonical_promotion_status==='VERIFIED'&&universalActions.has(String(d.action||'').toUpperCase()));
 const specialized=decisions.filter(d=>d&&String(d.action||'').toUpperCase()==='COMPRE'&&!canonical.includes(d));
 const experimental=signals.filter(x=>x.experimental===true).sort((a,b)=>{const ab=String(a.brain_action||'')==='COMPRE'?0:1,bb=String(b.brain_action||'')==='COMPRE'?0:1;return ab-bb||Number(b.promising_pct||0)-Number(a.promising_pct||0)});
 const cash=Number(snap.cash_eur??brain.cash_available_eur??0);
 const header=`<div class="v38285-kpis"><div><small>Decisões canônicas verificadas</small><b>${canonical.length}</b><span>autoridade de produção</span></div><div><small>Análises experimentais</small><b>${experimental.length}</b><span>Brain paralelo • não elegível</span></div><div><small>Caixa EUR</small><b>${v38141M(cash)}</b><span>alternativa válida</span></div><div><small>Execução</small><b>MANUAL</b><span>nenhuma mutação financeira</span></div></div>`;
 const eligible=`<article class="card v38285-section"><div class="card-head v38141-cardhead"><div class="v38141-headcopy"><b>Oportunidades elegíveis</b><small>Decisões canônicas por mercado</small><em>Campos e semântica do mercado de origem são preservados.</em></div><span class="v38141-count">${canonical.length}</span></div>${canonical.length?`<div class="v38285-grid">${canonical.map(v38285BRCard).join('')}</div>`:`<div class="v38141-empty"><b>Nenhuma oportunidade canônica elegível agora.</b><span>Caixa permanece uma alternativa válida; o Porquinho não força investimento.</span></div>`}</article>`;
 const specializedSection=`<article class="card v38285-section"><div class="card-head v38141-cardhead"><div class="v38141-headcopy"><b>Sinais especializados (não canônicos universais)</b><small>Saídas do produtor legado, sem promoção</small></div><span class="v38141-count">${specialized.length}</span></div>${specialized.length?`<div class="v38285-grid">${specialized.map(v38285BRCard).join('')}</div>`:'<div class="v38141-empty">Nenhum sinal especializado.</div>'}</article>`;
 const exp=`<article class="card v38285-section"><div class="card-head v38141-cardhead"><div class="v38141-headcopy"><b>Análises experimentais do Brain</b><small>autoridade persistida do Brain experimental</small><em>* Experimental não é elegibilidade canônica e não promove decisões automaticamente.</em></div><span class="v38141-count">${experimental.length}</span></div>${experimental.length?`<div class="v38285-grid">${experimental.map(v38285CryptoCard).join('')}</div>`:`<div class="v38141-empty"><b>Visão experimental indisponível neste ciclo.</b><span>Nenhum sinal é sintetizado quando a autoridade experimental não fornece dados.</span></div>`}</article>`;
 const guard=`<div class="v38141-help v38285-guard"><b>Contrato de autoridade</b><span>Saídas especializadas legadas não são promovidas a decisões canônicas universais.</span><span>Propostas experimentais (*) mantêm autoridade separada das decisões canônicas verificadas.</span><span>Não existe ranking bruto entre mercados, conversão FX forçada ou alocação de capital cross-currency.</span></div>`;
 return `<div class="v38141 v38285">${header}${guard}${eligible}${specializedSection}${exp}<div class="v38141-foot">V3.8.28.5 • Opportunity Experience • READ ONLY • NO SECOND BRAIN • NO FINANCIAL MUTATION</div></div>`;
}
async function v38285Opportunities(button){
 document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));(button||document.querySelector('[data-target="opportunities"]'))?.classList.add('active');
 const host=$('view-placeholder');host.classList.add('active-view');$('viewTitle').textContent='Oportunidades';$('viewDescription').textContent='Elegibilidade canônica e inteligência experimental em autoridades distintas.';$('viewContent').innerHTML='<div class="v38141-loading">Carregando autoridades reais…</div>';
 try{const [s,e]=await Promise.all([jsonFetch('/api/status'),jsonFetch('/api/equities/intelligence')]);$('viewContent').innerHTML=v38285Render(s,e)}catch(err){$('viewContent').innerHTML=`<div class="card v38141-error"><b>Opportunity Experience indisponível</b><span>${esc(err.message||String(err))}</span></div>`}
}
const _v38285_showExperienceView=showExperienceView;showExperienceView=function(name,button){if(name==='opportunities'){v38285Opportunities(button);return}return _v38285_showExperienceView(name,button)};

/* G1.5-r10.2 — Settings / APIs & Data, additive to original Settings cards. */
function g15CredentialSourceLabel(source){const x=String(source||'NONE');if(x==='MACOS_KEYCHAIN')return 'Keychain do macOS';if(x==='ENV_FALLBACK')return 'Variável de ambiente';return 'Não configurada'}
function g15CredentialStatusBadge(c){return `<span class="g15-status ${c?.configured?'is-ok':''}">${c?.configured?'● Configurada':'○ Não configurada'}</span>`}
function g15CredentialCard(c){const pid=esc(c.provider_id||''),label=esc(c.label||c.provider_id||'Provider');return `<article class="g15-credential-card"><div class="g15-credential-head"><div><b>${label}</b><small>Dados de mercado • ${esc(g15CredentialSourceLabel(c.source))}</small></div>${g15CredentialStatusBadge(c)}</div><div class="g15-credential-actions"><input id="g15-secret-${pid}" type="password" autocomplete="new-password" placeholder="${c.configured?'Novo token para substituir':'Cole o token da API'}" aria-label="Token ${label}"><button onclick="g15SaveCredential('${pid}')">${c.configured?'Substituir':'Cadastrar'}</button><button class="g15-secondary" onclick="g15RemoveCredential('${pid}')" ${c.configured?'':'disabled'}>Remover</button></div><p class="g15-help">O token não é exibido após o envio. Esta conexão não concede autoridade de negociação.</p></article>`}
function g15SettingsBaseCards(){return [moduleCard('Interface','Porquinho Experience V3.6.0 ativa.'),moduleCard('Dados','Nenhuma configuração financeira foi alterada por esta migração.'),moduleCard('Histórico','Importação e hidratação continuam disponíveis.','Abrir histórico','openImport()')].join('')}
function g15SettingsShell(){return `<div class="module-grid">${g15SettingsBaseCards()}</div><section class="g15-settings-section"><div class="g15-section-head"><div><span>CONFIGURAÇÕES • APIS E DADOS</span><h2>APIs e Dados</h2><p>Gerencie credenciais dos provedores de dados. Segredos ficam no Keychain do macOS e nunca são recarregados para esta tela.</p></div></div><div id="g15CredentialGrid" class="g15-credential-grid"><div class="muted">Carregando provedores…</div></div><article class="g15-security-card"><div><b>Segurança e autoridade</b><small>G1.5</small></div><p>Conectar um provedor de dados não habilita compras, vendas ou execução automática. A autoridade financeira permanece separada e bloqueada.</p></article></section>`}
async function g15LoadCredentials(){const grid=$('g15CredentialGrid');if(!grid)return;try{const j=await jsonFetch('/api/settings/credentials');if(!j?.ok)throw new Error(j?.error||'Falha ao carregar credenciais');const rows=Array.isArray(j.credentials)?j.credentials:[];grid.innerHTML=rows.map(g15CredentialCard).join('')||'<div class="muted">Nenhum provedor disponível.</div>'}catch(e){grid.innerHTML=`<article class="g15-security-card"><p>Falha ao carregar APIs e Dados: ${esc(e.message||String(e))}</p></article>`}}
async function g15SaveCredential(providerId){const input=document.getElementById('g15-secret-'+providerId),secret=String(input?.value||'').trim();if(!secret){toast('Informe o token antes de salvar.');return}try{const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(providerId),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({secret})});if(!j?.ok)throw new Error(j?.error||'Falha ao salvar credencial');if(input)input.value='';toast('Credencial salva com segurança.');await g15LoadCredentials()}catch(e){if(input)input.value='';toast('Falha ao salvar credencial: '+(e.message||e))}}
async function g15RemoveCredential(providerId){if(!confirm('Remover a credencial deste provedor do Keychain?'))return;try{const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(providerId),{method:'DELETE'});if(!j?.ok)throw new Error(j?.error||'Falha ao remover credencial');toast('Credencial removida.');await g15LoadCredentials()}catch(e){toast('Falha ao remover credencial: '+(e.message||e))}}
const _g15ShowExperienceView=showExperienceView;
showExperienceView=function(name,button){if(name==='settings'){_g15ShowExperienceView(name,button);$('viewContent').innerHTML=g15SettingsShell();g15LoadCredentials();return}return _g15ShowExperienceView(name,button)}

/* G1.5-r11.2 — Extensible provider management UI. */
function g15ProviderAdapterLabel(p){return p?.adapter_ready?(p.adapter||'Adaptador disponível'):'Adaptador necessário'}
function g15OpenProviderDialog(){
 if($('g15-provider-dialog'))return;
 const wrap=document.createElement('div'); wrap.id='g15-provider-dialog'; wrap.className='g15-modal-backdrop';
 wrap.innerHTML=`<div class="g15-modal" role="dialog" aria-modal="true" aria-labelledby="g15-provider-title">
  <div class="g15-modal-head"><div><span>APIS E DADOS</span><h2 id="g15-provider-title">Adicionar provedor</h2></div><button class="g15-icon-btn" onclick="g15CloseProviderDialog()" aria-label="Fechar">×</button></div>
  <p class="muted">Cadastre o provedor e o tipo de integração. A credencial será informada depois, diretamente no card.</p>
  <div class="g15-form-grid">
   <label>Identificador<input id="g15-p-id" placeholder="ex.: alphavantage"></label>
   <label>Nome<input id="g15-p-label" placeholder="ex.: Alpha Vantage"></label>
   <label>Categoria<select id="g15-p-kind"><option value="MARKET_DATA">Dados de mercado</option><option value="OTHER">Outro</option></select></label>
   <label>Adaptador<select id="g15-p-adapter"><option value="CUSTOM_REQUIRED">Personalizado — adaptador necessário</option><option value="GENERIC_JSON">JSON genérico</option></select></label>
   <label class="g15-form-wide">URL base HTTPS<input id="g15-p-url" placeholder="https://api.exemplo.com"></label>
   <label>Autenticação<select id="g15-p-auth"><option value="BEARER">Bearer token</option><option value="QUERY_APIKEY">API key em query</option><option value="NONE">Sem credencial</option></select></label>
  </div>
  <div class="g15-modal-note">Cadastrar não libera acesso de rede automaticamente. Provedores personalizados continuam sujeitos ao adapter e às regras de egress do Porquinho.</div>
  <div class="g15-modal-actions"><button class="g15-secondary" onclick="g15CloseProviderDialog()">Cancelar</button><button onclick="g15CreateProvider()">Cadastrar provedor</button></div>
 </div>`;
 wrap.addEventListener('click',e=>{if(e.target===wrap)g15CloseProviderDialog()}); document.body.appendChild(wrap);
}
function g15CloseProviderDialog(){const x=$('g15-provider-dialog');if(x)x.remove()}
async function g15CreateProvider(){
 const body={provider_id:$('g15-p-id')?.value,label:$('g15-p-label')?.value,kind:$('g15-p-kind')?.value,adapter:$('g15-p-adapter')?.value,base_url:$('g15-p-url')?.value,auth_method:$('g15-p-auth')?.value};
 try{const j=await jsonFetch('/api/settings/providers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!j?.ok)throw new Error(j?.error||'Falha ao cadastrar provedor');g15CloseProviderDialog();toast('Provedor cadastrado.');await g15LoadCredentials()}catch(e){toast('Falha ao cadastrar provedor: '+(e.message||e))}
}
async function g15DeleteProvider(providerId,label){
 if(!confirm(`Remover o provedor ${label}? A credencial associada também será removida do Keychain.`))return;
 try{const j=await jsonFetch('/api/settings/providers/'+encodeURIComponent(providerId),{method:'DELETE'});if(!j?.ok)throw new Error(j?.error||'Falha ao remover provedor');toast('Provedor removido.');await g15LoadCredentials()}catch(e){toast('Falha ao remover provedor: '+(e.message||e))}
}
const _g15CredentialCardR112=g15CredentialCard;
g15CredentialCard=function(c){
 const html=_g15CredentialCardR112(c);
 const extra=`<div class="g15-provider-meta"><span>${esc(g15ProviderAdapterLabel(c))}</span>${c.builtin?'<span>Integrado ao Porquinho</span>':`<button class="g15-text-danger" onclick="g15DeleteProvider('${esc(c.provider_id)}','${esc(c.label||c.provider_id)}')">Excluir provedor</button>`}</div>`;
 return html.replace('</article>',extra+'</article>');
}
const _g15SettingsShellR112=g15SettingsShell;
g15SettingsShell=function(){
 const html=_g15SettingsShellR112();
 return html.replace('<div id="g15CredentialGrid"',`<div class="g15-provider-toolbar"><div><b>Provedores</b><small>Integrações disponíveis e cadastradas</small></div><button onclick="g15OpenProviderDialog()">+ Adicionar provedor</button></div><div id="g15CredentialGrid"`);
}
/* G1.5-r14.6 Financial Connections — metadata/read-only; no execution authority. */
function g15ConnectionStateLabel(x){const m={CONNECTED:'Conectada',NOT_CONFIGURED:'Não configurada',DISCONNECTED:'Desconectada',ERROR:'Erro'};return m[String(x||'NOT_CONFIGURED')]||String(x||'Não configurada')}
function g15CapabilityLabel(x){const m={SUPPORTED:'Suportado',NOT_AUTHORIZED:'Não autorizado',NOT_AVAILABLE:'Indisponível',UNKNOWN:'Desconhecido'};return m[String(x||'UNKNOWN')]||String(x||'UNKNOWN')}
function g15ConnectionCard(c){const caps=c.capabilities||{},keys=[['accounts','Contas'],['balances','Saldos'],['positions','Posições'],['transactions','Transações'],['transfer','Transferir'],['buy','Comprar'],['sell','Vender'],['cancel_order','Cancelar ordem']];const ch=keys.map(([k,l])=>`<div><span>${l}</span><b>${esc(g15CapabilityLabel(caps[k]))}</b></div>`).join('');return `<article class="g15-connection-card"><div class="g15-credential-head"><div><b>${esc(c.label||c.connection_id||'Conexão')}</b><small>${esc(c.institution_type||'Instituição')} • ${esc(c.connector_id||'Connector')}</small></div><span class="g15-status ${c.state==='CONNECTED'?'is-ok':''}">${c.state==='CONNECTED'?'●':'○'} ${esc(g15ConnectionStateLabel(c.state))}</span></div><div class="g15-capability-grid">${ch}</div><div class="g15-authority-row"><span>Autoridade de execução</span><b>${c.execution_authorized?'HABILITADA':'BLOQUEADA'}</b></div></article>`}
async function g15LoadConnections(){
 console.info('[G15_CONN_DIAG] LOAD_STARTED');const grid=$('g15ConnectionGrid');if(!grid)return;try{const j=await (console.info('[G15_CONN_DIAG] REQUEST_STARTED'),jsonFetch('/api/settings/connections'));if(!j?.ok)throw new Error(j?.error||'Falha ao carregar conexões');const rows=Array.isArray(j.connections)?j.connections:[];grid.innerHTML=rows.map(g15ConnectionCard).join('')||'<div class="muted">Nenhuma conexão financeira cadastrada.</div>'}catch(e){console.info('[G15_CONN_DIAG] ERROR_PATH');grid.innerHTML=`<article class="g15-security-card"><p>Falha ao carregar Connections: ${esc(e.message||String(e))}</p></article>`}}
const _g15SettingsShellR146=g15SettingsShell;
g15SettingsShell=function(){const html=_g15SettingsShellR146();return html+`<section class="g15-settings-section"><div class="g15-section-head"><div><span>CONFIGURAÇÕES • CONNECTIONS</span><h2>Connections</h2><p>Bancos, corretoras, fintechs e exchanges. Capacidades técnicas são exibidas separadamente da autoridade financeira.</p></div></div><div class="g15-provider-toolbar"><div><b>Conexões financeiras</b><small>Cadastro e estado operacional</small></div><button onclick="g15OpenConnectionDialog()">+ Adicionar conexão</button></div><div id="g15ConnectionGrid" class="g15-credential-grid"><div class="muted">Carregando conexões…</div></div><article class="g15-security-card"><div><b>Separação de autoridade</b><small>G1.5</small></div><p>CONNECTED e BUY/SELL SUPPORTED não concedem autorização de negociação. A execução financeira permanece bloqueada e governada separadamente.</p></article></section>`}
function g15OpenConnectionDialog(){
 if($('g15-connection-dialog'))return;
 const wrap=document.createElement('div');
 wrap.id='g15-connection-dialog'; wrap.className='g15-modal-backdrop';
 wrap.innerHTML=`<div class="g15-modal" role="dialog" aria-modal="true"><div class="g15-modal-head"><div><span>CONNECTIONS</span><h2>Adicionar conexão</h2></div><button class="g15-icon-btn" onclick="g15CloseConnectionDialog()">X</button></div><p class="muted">Cadastre uma instituição financeira. Este fluxo não concede autoridade de negociação.</p><div class="g15-form-grid"><label>Instituição<input id="g15-c-name" value="XP Investimentos"></label><label>País<input id="g15-c-country" value="BR" maxlength="2"></label><label>Tipo<select id="g15-c-type"><option value="BROKER" selected>Corretora</option><option value="BANK">Banco</option><option value="FINTECH">Fintech</option><option value="EXCHANGE">Exchange</option><option value="OTHER">Outro</option></select></label><label>Connector ID<input id="g15-c-connector" value="xp"></label><label class="g15-form-wide">Nome exibido<input id="g15-c-label" value="XP Investimentos"></label></div><div class="g15-modal-note">Cadastro/configuração apenas. Nenhuma credencial é solicitada, nenhuma conexão de rede é iniciada e a autoridade de execução permanece bloqueada.</div><div class="g15-modal-actions"><button class="g15-secondary" onclick="g15CloseConnectionDialog()">Cancelar</button><button onclick="g15CreateConnection()">Cadastrar conexão</button></div></div>`;
 wrap.addEventListener('click',e=>{if(e.target===wrap)g15CloseConnectionDialog()}); document.body.appendChild(wrap);
}
function g15CloseConnectionDialog(){const x=$('g15-connection-dialog');if(x)x.remove()}
async function g15CreateConnection(){
 const body={institution_name:$('g15-c-name')?.value,country:$('g15-c-country')?.value,institution_type:$('g15-c-type')?.value,connector_id:$('g15-c-connector')?.value,label:$('g15-c-label')?.value};
 try{
  const r=await fetch('/api/settings/connections',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const j=await r.json(); if(!r.ok||!j?.ok)throw new Error(j?.error||'Falha ao cadastrar conexão');
  g15CloseConnectionDialog(); toast('Conexão cadastrada sem autoridade de negociação.'); await g15LoadConnections();
 }catch(e){toast('Falha ao cadastrar conexão: '+(e.message||e))}
}

const _g15LoadCredentialsR146=g15LoadCredentials;
g15LoadCredentials=async function(){
 const base=_g15LoadCredentialsR146();
 try{await g15LoadConnections()}catch(e){/* g15LoadConnections renders its own safe error state */}
 return await base
}
/* G1.5-r13.2.1 — Explicit provider connectivity test UI. Network only on user click. */
function g15ConnectivityLabel(status){
 const m={CONNECTED:'Conectado',CREDENTIAL_NOT_CONFIGURED:'Credencial não configurada',CREDENTIAL_INVALID:'Credencial inválida',RATE_LIMITED:'Limite atingido',PROVIDER_TIMEOUT:'Tempo limite excedido',PROVIDER_UNAVAILABLE:'Provedor indisponível',NETWORK_POLICY_BLOCKED:'Bloqueado pela política de rede',PROVIDER_RESPONSE_REJECTED:'Resposta do provedor rejeitada',PROVIDER_REJECTED:'Provedor rejeitou a consulta',PROVIDER_TEST_FAILED:'Falha no teste',ADAPTER_REQUIRED:'Adaptador necessário',GENERIC_EGRESS_NOT_IMPLEMENTED:'Egress genérico ainda não habilitado'};
 return m[status]||String(status||'Falha no teste');
}
async function g15TestProvider(providerId,button){
 if(button){button.disabled=true;button.dataset.oldText=button.textContent;button.textContent='Testando…'}
 try{
  const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(providerId)+'/test',{method:'POST'});
  if(!j?.ok)throw new Error(j?.error||'Falha no teste');
  const t=j.test||{},el=$('g15-test-'+providerId);
  if(el){el.textContent=g15ConnectivityLabel(t.status);el.className='g15-test-status '+(t.connected?'ok':'warn')}
  toast(t.connected?'Conexão validada.':g15ConnectivityLabel(t.status));
 }catch(e){
  const el=$('g15-test-'+providerId);if(el){el.textContent='Falha no teste';el.className='g15-test-status warn'}
  toast('Falha no teste de conexão: '+(e.message||e));
 }finally{if(button){button.disabled=false;button.textContent=button.dataset.oldText||'Testar conexão'}}
}
const _g15CredentialCardR1321=g15CredentialCard;
g15CredentialCard=function(c){
 let html=_g15CredentialCardR1321(c);
 const canTest=(c.adapter==='BRAPI'||c.adapter==='TWELVEDATA');
 const status=c.adapter==='CUSTOM_REQUIRED'?'Adaptador necessário':(c.adapter==='GENERIC_JSON'?'Bloqueado pela política de rede':'Não testado');
 const ctl=canTest
  ? `<div class="g15-test-row"><button class="g15-secondary g15-test-btn" onclick="g15TestProvider('${esc(c.provider_id)}',this)">Testar conexão</button><span id="g15-test-${esc(c.provider_id)}" class="g15-test-status">${status}</span></div>`
  : `<div class="g15-test-row"><button class="g15-secondary g15-test-btn" disabled>Testar conexão</button><span id="g15-test-${esc(c.provider_id)}" class="g15-test-status">${status}</span></div>`;
 return html.replace('<div class="g15-provider-meta">',ctl+'<div class="g15-provider-meta">');
}


/* G1.5-r16.2 — Open Finance provider vocabulary; no network/authentication. */
const _g15OpenProviderDialogR162=g15OpenProviderDialog;
g15OpenProviderDialog=function(){
 _g15OpenProviderDialogR162();
 const kind=$('g15-p-kind'),adapter=$('g15-p-adapter'),auth=$('g15-p-auth');
 if(kind&&!Array.from(kind.options).some(x=>x.value==='FINANCIAL_CONNECTIVITY'))kind.insertAdjacentHTML('beforeend','<option value="FINANCIAL_CONNECTIVITY">Conectividade financeira / Open Finance</option>');
 if(adapter&&!Array.from(adapter.options).some(x=>x.value==='OPEN_FINANCE_AGGREGATOR'))adapter.insertAdjacentHTML('beforeend','<option value="OPEN_FINANCE_AGGREGATOR">Agregador Open Finance</option>');
 if(auth&&!Array.from(auth.options).some(x=>x.value==='CLIENT_CREDENTIALS'))auth.insertAdjacentHTML('beforeend','<option value="CLIENT_CREDENTIALS">Client credentials</option>');
};

/* G1.5-r16.7 — Composite credential UI; no automatic network/authentication. */
function g15IsCompositeCredential(c){return c?.auth_method==='CLIENT_CREDENTIALS'||c?.provider_id==='pluggy'}
function g15CompositeCredentialCard(c){
 const pid=esc(c.provider_id||''),label=esc(c.label||c.provider_id||'Provider'),configured=!!c.configured;
 return `<article class="g15-credential-card g15-composite-card"><div class="g15-credential-head"><div><b>${label}</b><small>Conectividade financeira • Client credentials • Keychain do macOS</small></div>${g15CredentialStatusBadge(c)}</div><div class="g15-composite-fields"><label>Client ID<input id="g15-client-id-${pid}" type="password" autocomplete="new-password" placeholder="${configured?'Novo Client ID para substituir':'Informe o Client ID'}" aria-label="Client ID ${label}"></label><label>Client Secret<input id="g15-client-secret-${pid}" type="password" autocomplete="new-password" placeholder="${configured?'Novo Client Secret para substituir':'Informe o Client Secret'}" aria-label="Client Secret ${label}"></label></div><div class="g15-composite-actions"><button onclick="g15SaveCompositeCredential('${pid}')">${configured?'Substituir credenciais':'Cadastrar credenciais'}</button><button class="g15-secondary" onclick="g15RemoveCompositeCredential('${pid}')" ${configured?'':'disabled'}>Remover</button></div><p class="g15-help">Client ID e Client Secret não são exibidos após o envio. Esta conexão não concede autoridade de negociação.</p></article>`;
}
async function g15HydrateCompositeCredential(c){
 if(!g15IsCompositeCredential(c))return c;
 try{const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(c.provider_id)+'/composite');if(j?.ok&&j.credential)return Object.assign({},c,j.credential)}catch(e){}
 return Object.assign({},c,{configured:false,client_id_configured:false,client_secret_configured:false});
}
async function g15SaveCompositeCredential(providerId){
 const a=document.getElementById('g15-client-id-'+providerId),b=document.getElementById('g15-client-secret-'+providerId);
 const client_id=String(a?.value||'').trim(),client_secret=String(b?.value||'').trim();
 if(!client_id||!client_secret){toast('Informe Client ID e Client Secret antes de salvar.');return}
 try{const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(providerId)+'/composite',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id,client_secret})});if(!j?.ok)throw new Error(j?.error||'Falha ao salvar credenciais');if(a)a.value='';if(b)b.value='';toast('Credenciais salvas com segurança.');await g15LoadCredentials()}catch(e){if(a)a.value='';if(b)b.value='';toast('Falha ao salvar credenciais: '+(e.message||e))}
}
async function g15RemoveCompositeCredential(providerId){
 if(!confirm('Remover Client ID e Client Secret deste provedor do Keychain?'))return;
 try{const j=await jsonFetch('/api/settings/credentials/'+encodeURIComponent(providerId)+'/composite',{method:'DELETE'});if(!j?.ok)throw new Error(j?.error||'Falha ao remover credenciais');toast('Credenciais removidas.');await g15LoadCredentials()}catch(e){toast('Falha ao remover credenciais: '+(e.message||e))}
}
const _g15CredentialCardR167=g15CredentialCard;
g15CredentialCard=function(c){return g15IsCompositeCredential(c)?g15CompositeCredentialCard(c):_g15CredentialCardR167(c)}
g15LoadCredentials=async function(){
 // G1.5-r16.19.3: Connections has an independent read-only lifecycle.
 // Do not await it behind credential hydration.
 g15LoadConnections();
 const grid=$('g15CredentialGrid');if(!grid)return;
 try{
  const j=await jsonFetch('/api/settings/credentials');if(!j?.ok)throw new Error(j?.error||'Falha ao carregar credenciais');
  const rows=Array.isArray(j.credentials)?j.credentials:[],hydrated=await Promise.all(rows.map(g15HydrateCompositeCredential));
  grid.innerHTML=hydrated.map(g15CredentialCard).join('')||'<div class="muted">Nenhum provedor disponível.</div>';
 }catch(e){grid.innerHTML=`<article class="g15-security-card"><p>Falha ao carregar APIs e Dados: ${esc(e.message||String(e))}</p></article>`}
}


/* G1.5-r16.10.4 — Pluggy Sandbox Connect Widget; explicit user action only. */
async function g15OpenPluggySandbox(button){
 if(button){button.disabled=true;button.dataset.oldText=button.textContent;button.textContent='Abrindo Sandbox…'}
 try{
  if(typeof PluggyConnect!=='function')throw new Error('SDK Pluggy Connect indisponível');
  const j=await jsonFetch('/api/settings/credentials/pluggy/connect-token',{method:'POST'});
  if(!j?.ok||!j?.connect_token)throw new Error(j?.error||'Falha ao gerar Connect Token');
  const connectToken=j.connect_token;
  const widget=new PluggyConnect({
   connectToken,
   includeSandbox:true,
   allowConnectInBackground:false,
   onSuccess:(itemData)=>{
    const itemId=String(itemData?.item?.id||itemData?.id||'').trim();
    if(itemId){
     jsonFetch('/api/settings/providers/pluggy/items',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId})})
     .then((r)=>{
       const d=(r&&r.discovery)||{};
       const n=Number.isInteger(d.account_count)?d.account_count:0;
       const safe=(d.transactions_requested===false&&d.financial_data_persisted===false&&d.ledger_mutated===false);
       if(safe){
         toast(`Sandbox conectado • discovery OK • ${n} conta(s) descoberta(s) • transações não consultadas • dados financeiros não persistidos.`);
       }else{
         toast('Sandbox conectado, mas a evidência segura do discovery não pôde ser confirmada.');
       }
     })
     .catch(()=>toast('Sandbox conectado na Pluggy, mas o discovery seguro do Item não foi concluído.'));
    }else toast('Sandbox conectado; Item sem identidade utilizável e nenhum dado foi importado.');
   },
   onError:()=>toast('A conexão Sandbox da Pluggy não foi concluída.'),
   onClose:()=>{}
  });
  widget.init();
 }catch(e){toast('Falha ao abrir Pluggy Sandbox: '+(e.message||e))}
 finally{if(button){button.disabled=false;button.textContent=button.dataset.oldText||'Conectar Sandbox'}}
}

/* G1.6-r17.0.2 - Pluggy Item mapping preview UI */
let g16PluggyItems=[];
async function g16OpenPluggyMappingPicker(){
 try{
  const j=await jsonFetch('/api/settings/providers/pluggy/items');
  g16PluggyItems=Array.isArray(j?.items)?j.items:[];
  if(!g16PluggyItems.length){toast('Nenhum Item Pluggy registrado. Conecte o Sandbox primeiro.');return}
  if(g16PluggyItems.length===1)return g16OpenAccountMappingPreview(g16PluggyItems[0].item_id);
  const old=$('g16-item-picker');if(old)old.remove();
  const wrap=document.createElement('div');wrap.id='g16-item-picker';wrap.className='g15-modal-backdrop';
  const rows=g16PluggyItems.map((x,i)=>`<button class="g15-secondary" data-g16-item="${i}" style="width:100%;margin:5px 0">Item Pluggy ${i+1} • ${esc(x.state||'registrado')}</button>`).join('');
  wrap.innerHTML=`<div class="g15-modal"><div class="g15-modal-head"><div><span>PLUGGY • ITENS</span><h2>Escolher conexão para mapear</h2></div><button class="g15-icon-btn" id="g16-item-close">X</button></div><p class="muted">Foram encontrados ${g16PluggyItems.length} Items registrados. Escolha explicitamente qual deseja usar. Nenhum dado financeiro será importado.</p><div>${rows}</div></div>`;
  document.body.appendChild(wrap);
  $('g16-item-close').onclick=()=>wrap.remove();
  wrap.querySelectorAll('[data-g16-item]').forEach(b=>b.onclick=()=>{const x=g16PluggyItems[Number(b.dataset.g16Item)];wrap.remove();if(x?.item_id)g16OpenAccountMappingPreview(x.item_id)});

 }catch(e){toast('Não foi possível carregar os Items Pluggy.')}
}
/* G1.6-r17.1.3 - Controlled mapping commit UI */
let g16ActiveMappingItemId=null;
async function g16OpenAccountMappingPreview(itemId){
 g16ActiveMappingItemId=itemId;
 try{
  const r=await jsonFetch('/api/settings/providers/pluggy/account-mapping-preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId})});
  const accounts=Array.isArray(r?.accounts)?r.accounts:[];
  const old=$('g16-mapping-preview');if(old)old.remove();
  const wrap=document.createElement('div');wrap.id='g16-mapping-preview';wrap.className='g15-modal-backdrop';
  const rows=accounts.map((a,i)=>`<label style="display:flex;gap:10px;align-items:center;padding:8px 0"><input type="checkbox" data-g16-account="${i}"><span><strong>${esc(a.name||'Conta')}</strong> <small>${esc(a.account_type||'')} ${esc(a.currency||'')}</small></span></label>`).join('');
  wrap.innerHTML=`<div class="g15-modal"><div class="g15-modal-head"><div><span>ACCOUNT MAPPING</span><h2>Selecionar contas</h2></div><button class="g15-icon-btn" id="g16-map-close">X</button></div><p class="muted">Esta prévia ainda não salva o mapeamento.</p><div>${rows||'<p>Nenhuma conta disponível.</p>'}</div><div class="g15-modal-actions"><button class="g15-secondary" id="g16-map-cancel">Cancelar</button><button id="g16-map-continue" ${accounts.length?'':'disabled'}>Continuar</button></div></div>`;
  document.body.appendChild(wrap);
  $('g16-map-close').onclick=$('g16-map-cancel').onclick=()=>wrap.remove();
  $('g16-map-continue').onclick=async()=>{
   const selected=[...wrap.querySelectorAll('[data-g16-account]:checked')].map(el=>accounts[Number(el.dataset.g16Account)]?.provider_account_id).filter(Boolean);
   if(!selected.length){toast('Selecione pelo menos uma conta.');return}
   if(!confirm(`Confirmar vínculo de ${selected.length} conta(s) ao Porquinho em modo somente leitura (CONNECTED_READ)?\n\nNenhum saldo, transação ou posição será importado nesta etapa.`))return;
   const btn=$('g16-map-continue');if(btn){btn.disabled=true;btn.textContent='Salvando vínculo...'}
   try{
    const r=await jsonFetch('/api/settings/providers/pluggy/account-mapping-commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:g16ActiveMappingItemId,provider_account_ids:selected})});
if(r?.ok&&r?.mapping_persisted===true&&r?.management_mode==='CONNECTED_READ'&&r?.transactions_requested===false&&r?.ledger_mutated===false&&r?.execution_enabled===false){
       const mapped=Array.isArray(r.mapped_accounts)?r.mapped_accounts:[];
       if(mapped.length!==selected.length||mapped.some(x=>!x?.account_id||x?.management_mode!=='CONNECTED_READ'))throw new Error('SAFE_MAPPING_IDENTITY_MISSING');
       toast(`${r.selected_count||selected.length} conta(s) vinculada(s) em modo somente leitura.`);
       g17RenderEphemeralBalanceActions(wrap,mapped,selected,accounts,g16ActiveMappingItemId);
     }else{throw new Error('SAFE_COMMIT_EVIDENCE_MISSING')}
   }catch(e){
    if(btn){btn.disabled=false;btn.textContent='Continuar'}
    toast('Não foi possível salvar o vínculo seguro das contas.');
   }
  }
 }catch(e){
  const status=Number(e?.status||e?.response?.status||0);
  console.info('[G16_MAP_DIAG] PREVIEW_FAILED',status?('HTTP_'+status):'CLIENT_OR_NETWORK_ERROR');
  toast('Não foi possível preparar a seleção segura das contas.');
 }
}
const _g15CompositeCredentialCardR16104=g15CompositeCredentialCard;
g15CompositeCredentialCard=function(c){
 let html=_g15CompositeCredentialCardR16104(c);
 if(c?.provider_id!=='pluggy')return html;
 const disabled=c?.configured?'':' disabled';
 const sandbox=`<div class="g15-test-row"><button class="g15-secondary g15-test-btn" onclick="g15OpenPluggySandbox(this)"${disabled}>Conectar Sandbox</button><span class="g15-test-status">${c?.configured?'Somente teste • sem importação automática':'Cadastre as credenciais primeiro'}</span></div>`;
 const mapping=`<div class="g15-test-row"><button class="g15-secondary g15-test-btn" onclick="g16OpenPluggyMappingPicker()"${disabled}>Mapear contas</button><span class="g15-test-status">${c?.configured?'Seleção explícita • sem importação':'Cadastre as credenciais primeiro'}</span></div>`;
 return html.replace('<p class="g15-help">',sandbox+mapping+'<p class="g15-help">');
}


/* G1.7-r18.6.2 — Explicit ephemeral balance read. No automatic read, polling or persistence. */
function g17RenderEphemeralBalanceActions(wrap,mapped,selected,accounts,itemId){
 if(!wrap||!Array.isArray(mapped)||!mapped.length)return;
 const box=document.createElement('div'); box.id='g17-ephemeral-balance-actions';
 box.innerHTML='<div class="g15-modal-note"><b>Vínculo confirmado em modo somente leitura.</b><br>Consultar saldo é opcional e exige uma ação explícita. O valor será apenas exibido nesta janela e não será salvo no Porquinho.</div>';
 mapped.forEach((m,i)=>{
  const providerId=selected[i];
  const src=accounts.find(a=>a?.provider_account_id===providerId)||{};
  const row=document.createElement('div'); row.style.cssText='display:flex;gap:10px;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(127,127,127,.2)';
  const label=document.createElement('span');
  label.innerHTML='<strong>'+esc(src.name||'Conta mapeada')+'</strong> <small>'+esc(src.account_type||'')+' '+esc(src.currency||'')+'</small>';
  const controls=document.createElement('span');
  const result=document.createElement('span'); result.className='g15-test-status'; result.textContent='Saldo não consultado';
  const btn=document.createElement('button'); btn.className='g15-secondary g15-test-btn'; btn.textContent='Consultar saldo';
  btn.onclick=()=>g17ReadEphemeralBalance(itemId,m?.account_id,btn,result);
  const historyBtn=document.createElement('button'); historyBtn.className='g15-secondary g15-test-btn'; historyBtn.textContent='Histórico';
  historyBtn.onclick=()=>g181ShowObservationHistory(m?.account_id,row);
  const txBtn=document.createElement('button'); txBtn.className='g15-secondary g15-test-btn'; txBtn.textContent='Consultar transações';
  txBtn.onclick=()=>g19OpenEphemeralTransactions(itemId,m?.account_id,row);
  controls.appendChild(btn); controls.appendChild(document.createTextNode(' ')); controls.appendChild(historyBtn); controls.appendChild(document.createTextNode(' ')); controls.appendChild(txBtn); controls.appendChild(document.createTextNode(' ')); controls.appendChild(result);
  row.appendChild(label); row.appendChild(controls); box.appendChild(row);
 });
 const actions=wrap.querySelector('.g15-modal-actions');
 if(actions){actions.innerHTML='<button class="g15-secondary" id="g17-balance-close">Fechar</button>';actions.parentNode.insertBefore(box,actions);$('g17-balance-close').onclick=()=>wrap.remove()}
}
async function g17ReadEphemeralBalance(itemId,accountId,button,resultEl){
 if(!itemId||!accountId){toast('Identidade interna da conta indisponível. Nenhuma consulta foi realizada.');return}
 if(!confirm('Consultar agora o saldo desta conta no Pluggy?\n\nA leitura será somente leitura e efêmera. O saldo não será salvo, não atualizará patrimônio, ledger, posições ou Brain.'))return;
 if(button){button.disabled=true;button.textContent='Consultando…'}
 if(resultEl)resultEl.textContent='Consulta em andamento…';
 try{
  const r=await jsonFetch('/api/settings/providers/pluggy/ephemeral-balance',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId,account_id:accountId})});
  const x=r?.result;
  const safe=!!(r?.ok&&x&&x.observation_state==='EPHEMERAL_PROVIDER_BALANCE'&&x.balance_persisted===false&&x.transactions_requested===false&&x.positions_requested===false&&x.ledger_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.execution_enabled===false&&x.authority_changed===false);
  if(!safe)throw new Error('SAFE_EPHEMERAL_EVIDENCE_MISSING');
  if(typeof x.balance!=='number'||!Number.isFinite(x.balance)||!/^[A-Z]{3}$/.test(String(x.currency||'')))throw new Error('INVALID_EPHEMERAL_VALUE');
  if(resultEl)resultEl.textContent=new Intl.NumberFormat(undefined,{style:'currency',currency:x.currency}).format(x.balance)+' • temporário';
  g18OfferObservationSnapshot(itemId,accountId,resultEl);
  toast('Saldo consultado em modo somente leitura. O valor não foi persistido.');
 }catch(e){
  if(resultEl)resultEl.textContent='Saldo não disponível';
  toast('Não foi possível concluir a leitura efêmera do saldo.');
 }finally{if(button){button.disabled=false;button.textContent='Consultar saldo'}}
}


/* G1.9-r20.10.1 — Explicit ephemeral transaction read UI. */
function g19LocalDateISO(d){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
function g19OpenEphemeralTransactions(itemId,accountId,row){
 if(!itemId||!accountId){toast('Identidade interna da conta indisponível. Nenhuma transação foi consultada.');return}
 const old=row?.querySelector('.g19-transaction-panel'); if(old){old.remove();return}
 const panel=document.createElement('div'); panel.className='g19-transaction-panel';
 const end=new Date(),start=new Date(); start.setDate(end.getDate()-6);
 panel.innerHTML='<div class="g15-modal-note"><b>Transações temporárias • não importadas</b><br>Escolha um período de até 31 dias. Nada será salvo no ledger, patrimônio, posições ou Brain.</div>'+
 '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px"><label>De <input type="date" class="g19-start"></label><label>Até <input type="date" class="g19-end"></label><button class="g15-secondary g15-test-btn g19-read">Consultar período</button><span class="g15-test-status g19-status">Nenhuma transação consultada</span></div><div class="g19-results"></div>';
 row.appendChild(panel); panel.querySelector('.g19-start').value=g19LocalDateISO(start); panel.querySelector('.g19-end').value=g19LocalDateISO(end);
 panel.querySelector('.g19-read').onclick=()=>g19ReadEphemeralTransactions(itemId,accountId,panel);
}
/* G1.9-r20.10.2a - Sanitized diagnostic stage in UI. */
const G19_SAFE_DIAGNOSTIC_STAGES=new Set(['CANONICAL_GATE','AUTH','HTTP','SCHEMA','ACCOUNT_IDENTITY','PAGINATION','POSTCONDITION','STRUCT_GATE','STRUCT_AUTH','STRUCT_TRANSPORT','STRUCT_HTTP','STRUCT_PAGE_VALIDATION','STRUCT_PAGE_SCHEMA','STRUCT_PAGE_IDENTITY','STRUCT_PAGE_PAGINATION','STRUCT_PAGE_VALUE','STRUCT_PAGE_ENVELOPE','STRUCT_PAGE_CURSOR','STRUCT_ROW_SHAPE','STRUCT_ROW_FIELDS','STRUCT_ROW_VALUE','STRUCT_POSTCONDITION','UNKNOWN']);
function g19SafeDiagnosticStage(value){
 const stage=String(value||'').toUpperCase();
 return G19_SAFE_DIAGNOSTIC_STAGES.has(stage)?stage:'UNKNOWN';
}

/* G1.9-r20.10.3a - Preserve sanitized error stage. */
async function g19SafeJsonFetch(url,opts={}){
 const response=await fetch(url,opts);
 let body=null;
 try{body=await response.json()}catch(_e){body=null}
 if(response.ok)return body;
 return {ok:false,stage:g19SafeDiagnosticStage(body?.stage)};
}

async function g19ReadEphemeralTransactions(itemId,accountId,panel){
 const a=panel.querySelector('.g19-start')?.value,b=panel.querySelector('.g19-end')?.value,status=panel.querySelector('.g19-status'),host=panel.querySelector('.g19-results'),button=panel.querySelector('.g19-read');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(a||'')||!/^\d{4}-\d{2}-\d{2}$/.test(b||'')){toast('Selecione datas válidas.');return}
 const start=new Date(a+'T00:00:00Z'),end=new Date(b+'T23:59:59Z'),days=Math.floor((end-start)/86400000)+1;
 if(!Number.isFinite(days)||days<1||days>31){toast('O período deve ter entre 1 e 31 dias.');return}
 if(!confirm(`Consultar transações de ${a} até ${b}?\n\nA leitura será somente leitura e efêmera. As transações serão apenas exibidas nesta janela e não serão importadas para ledger, patrimônio, posições ou Brain.`))return;
 button.disabled=true; status.textContent='Consulta em andamento…'; host.innerHTML='';
 try{
  const r=await g19SafeJsonFetch('/api/settings/providers/pluggy/ephemeral-transactions',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId,account_id:accountId,start_at:a+'T00:00:00Z',end_at:b+'T23:59:59Z'})});
  if(!r?.ok){
   const stage=g19SafeDiagnosticStage(r?.stage);
   status.textContent=`Transações não disponíveis • diagnóstico: ${stage}`;
   toast(`Leitura efêmera não concluída • diagnóstico: ${stage}`);
   return;
  }
  const x=r?.result;
  const safe=!!(x&&x.observation_state==='EPHEMERAL_PROVIDER_TRANSACTIONS'&&x.transactions_persisted===false&&x.ledger_mutated===false&&x.portfolio_mutated===false&&x.positions_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.execution_enabled===false&&x.authority_changed===false&&Array.isArray(x.transactions));
  if(!safe)throw new Error('SAFE_EPHEMERAL_TRANSACTION_EVIDENCE_MISSING');
  const frag=document.createDocumentFragment();
  x.transactions.forEach(t=>{
   const d=document.createElement('div');d.className='g15-modal-note';
   const line=document.createElement('span');line.textContent=`${String(t.date||'')} • ${String(t.description||'')} • ${typeof t.amount==='number'&&Number.isFinite(t.amount)?t.amount:'—'}${t.status?' • '+String(t.status):''}`;d.appendChild(line);
   const ref=typeof t.selection_ref==='string'&&/^TXR:[A-F0-9]{32}$/.test(t.selection_ref)?t.selection_ref:'';
   const oid=typeof t.observation_id==='string'&&/^ATO:[A-F0-9]{24}$/.test(t.observation_id)?t.observation_id:'';
   if(ref){const save=document.createElement('button');save.className='g15-secondary g15-test-btn g110-save-observation';save.style.marginLeft='8px';if(oid){save.textContent='Validar observação';save.onclick=()=>g110ValidateTransactionObservation(itemId,accountId,a,b,oid,save)}else{save.textContent='Salvar observação';save.onclick=()=>g110SaveTransactionObservation(itemId,accountId,a,b,ref,save)}d.appendChild(save)}
   frag.appendChild(d)
  });
  host.appendChild(frag); status.textContent=`${x.transactions.length} transação(ões) • temporário • não importado`; toast('Transações consultadas em modo somente leitura. Nada foi persistido.');
 }catch(e){status.textContent='Transações não disponíveis';host.innerHTML='';toast('Não foi possível concluir a leitura efêmera das transações.')}
 finally{button.disabled=false}
}

/* G1.10-r21.4 — Explicit transaction observation consent UI. */
async function g110ValidateTransactionObservation(itemId,accountId,startDate,endDate,observationId,button){
 if(!itemId||!accountId||!/^\d{4}-\d{2}-\d{2}$/.test(startDate||'')||!/^\d{4}-\d{2}-\d{2}$/.test(endDate||'')||!/^ATO:[A-F0-9]{24}$/.test(observationId||'')){toast('Validação não disponível. Nenhum estado oficial foi alterado.');return}
 if(!confirm('Validar esta observação?\n\nO servidor fará uma nova leitura somente após esta confirmação e comparará o resultado com a observação salva. Esta validação é apenas observacional: não importa, não canonicaliza e não habilita execução.'))return;
 button.disabled=true;
 try{
  const r=await g19SafeJsonFetch('/api/settings/providers/pluggy/transaction-observation-reconciliation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId,account_id:accountId,start_at:startDate+'T00:00:00Z',end_at:endDate+'T23:59:59Z',observation_id:observationId})});
  const x=r?.result;
  const status=x?.validation_status;
  const safeStatus=status==='MATCHED'||status==='CHANGED'||status==='MISSING';
  const safe=!!(r?.ok&&x&&safeStatus&&x.provider_reread===true&&x.browser_financial_data_accepted===false&&x.authority==='OBSERVATIONAL_ONLY'&&x.ledger_semantics==='NONE'&&x.execution==='NONE'&&x.canonicalized===false&&x.imported===false&&x.ledger_mutated===false&&x.portfolio_mutated===false&&x.positions_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.authority_changed===false&&(status!=='MISSING'||x.missing_scope==='AUTHORIZED_WINDOW_ONLY'));
  if(!safe)throw new Error('SAFE_TRANSACTION_RECONCILIATION_EVIDENCE_MISSING');
  button.disabled=false;
  if(status==='MATCHED'){button.textContent='Validada: compatível';toast('Observação compatível com a releitura. Continua apenas observacional.');}
  else if(status==='CHANGED'){button.textContent='Validada: alterada';toast('A releitura difere da observação salva. Revisão necessária; nenhum estado oficial foi alterado.');}
  else{button.textContent='Validada: não encontrada';toast('Observação não encontrada na janela autorizada consultada. Isso não significa que a transação foi removida do banco.');}
 }catch(_e){button.disabled=false;toast('Não foi possível validar a observação. Nenhuma importação ou alteração de estado oficial foi realizada.')}
}

async function g110SaveTransactionObservation(itemId,accountId,startDate,endDate,selectionRef,button){
 if(!itemId||!accountId||!/^\d{4}-\d{2}-\d{2}$/.test(startDate||'')||!/^\d{4}-\d{2}-\d{2}$/.test(endDate||'')||!/^TXR:[A-F0-9]{32}$/.test(selectionRef||'')){toast('Observação não disponível. Nenhum dado foi salvo.');return}
 if(!confirm('Salvar esta transação como observação?\n\nO servidor fará uma nova leitura somente após esta confirmação para validar a transação. Isso não importa a transação para ledger, patrimônio, posições ou Brain e não habilita execução.'))return;
 button.disabled=true;
 try{
  const r=await g19SafeJsonFetch('/api/settings/providers/pluggy/transaction-observation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId,account_id:accountId,start_at:startDate+'T00:00:00Z',end_at:endDate+'T23:59:59Z',selection_ref:selectionRef})});
  const x=r?.result;
  const savedObservationId=x?.observation?.observation_id;
  const safe=!!(r?.ok&&x&&/^ATO:[A-F0-9]{24}$/.test(savedObservationId||'')&&x.observation_persisted===true&&x.authority==='OBSERVATIONAL_ONLY'&&x.ledger_semantics==='NONE'&&x.provider_reread===true&&x.browser_financial_data_accepted===false&&x.transactions_imported===false&&x.ledger_mutated===false&&x.portfolio_mutated===false&&x.positions_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.execution_enabled===false&&x.authority_changed===false);
  if(!safe)throw new Error('SAFE_TRANSACTION_OBSERVATION_EVIDENCE_MISSING');
  button.textContent='Validar observação';button.disabled=false;
  button.onclick=()=>g110ValidateTransactionObservation(itemId,accountId,startDate,endDate,savedObservationId,button);
  toast('Observação salva em camada observacional. A transação não foi importada.');
 }catch(_e){button.disabled=false;toast('Não foi possível salvar a observação. Nenhuma importação foi realizada.')}
}


/* G1.8-r19.4 EXPLICIT OBSERVATIONAL SNAPSHOT */
function g18OfferObservationSnapshot(itemId,accountId,resultEl){
 const old=document.getElementById('g18-observation-action'); if(old)old.remove();
 const host=resultEl?.parentNode; if(!host)return;
 const btn=document.createElement('button'); btn.id='g18-observation-action'; btn.className='g15-secondary g15-test-btn';
 btn.textContent='Salvar observação'; btn.onclick=()=>g18PersistObservation(itemId,accountId,btn,resultEl);
 host.appendChild(document.createTextNode(' ')); host.appendChild(btn);

}
async function g18PersistObservation(itemId,accountId,button,resultEl){
 if(!itemId||!accountId){toast('Identidade interna indisponível. Nenhuma observação foi salva.');return}
 if(!confirm('Salvar uma nova observação do saldo desta conta?\n\nO Porquinho fará uma nova leitura autorizada no Pluggy e salvará somente um snapshot observacional. Isso não altera patrimônio, ledger, posições, Brain ou autoridade de execução.'))return;
 if(button){button.disabled=true;button.textContent='Salvando observação…'}
 try{
  const r=await jsonFetch('/api/settings/providers/pluggy/balance-observation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({item_id:itemId,account_id:accountId})});
  const x=r?.result;
  const safe=!!(r?.ok&&x&&x.observation_persisted===true&&x.balance_returned===false&&x.authority==='OBSERVATIONAL_ONLY'&&x.transactions_requested===false&&x.portfolio_cash_mutated===false&&x.ledger_mutated===false&&x.positions_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.execution==='NONE'&&x.authority_changed===false);
  if(!safe)throw new Error('SAFE_OBSERVATION_EVIDENCE_MISSING');
  button.textContent='Observação salva'; toast('Observação de saldo salva separadamente do patrimônio e do ledger.');
 }catch(e){if(button){button.disabled=false;button.textContent='Salvar observação'} toast('Não foi possível salvar a observação de saldo.');}
}

/* G1.8.1-r19.9 READ-ONLY OBSERVATION HISTORY UI */
async function g181ShowObservationHistory(accountId,host){
 if(!accountId||!host){toast('Histórico indisponível.');return}
 let box=host.querySelector('.g181-history-box');
 if(box){box.remove();return}
 box=document.createElement('div'); box.className='g181-history-box'; box.textContent='Carregando histórico…'; host.appendChild(box);
 try{
  const r=await jsonFetch('/api/settings/account-balance-observations?account_id='+encodeURIComponent(accountId)+'&limit=20',{method:'GET'});
  const x=r?.result;
  const safe=!!(r?.ok&&x&&x.authority==='OBSERVATIONAL_ONLY'&&x.historical_only===true&&x.current_balance===false&&x.provider_called===false&&x.portfolio_cash_mutated===false&&x.ledger_mutated===false&&x.positions_mutated===false&&x.patrimony_mutated===false&&x.brain_mutated===false&&x.authority_changed===false&&Array.isArray(x.observations));
  if(!safe)throw new Error('SAFE_HISTORY_EVIDENCE_MISSING');
  box.textContent='';
  const title=document.createElement('div'); title.textContent='Histórico observacional • não é saldo atual'; box.appendChild(title);
  if(!x.observations.length){const e=document.createElement('div');e.textContent='Nenhuma observação salva.';box.appendChild(e);return}
  x.observations.forEach(o=>{
   if(o?.authority!=='OBSERVATIONAL_ONLY'||o?.historical_snapshot!==true||o?.current_balance!==false||typeof o?.balance!=='number'||!Number.isFinite(o.balance)||typeof o?.currency!=='string'||o.currency.length!==3||typeof o?.observed_at!=='string')throw new Error('INVALID_HISTORY_ROW');
   const row=document.createElement('div');
   const value=new Intl.NumberFormat(undefined,{style:'currency',currency:o.currency}).format(o.balance);
   let when=o.observed_at; try{when=new Intl.DateTimeFormat(undefined,{dateStyle:'short',timeStyle:'medium'}).format(new Date(o.observed_at))}catch(_e){}
   row.textContent=value+' • observado em '+when+' • histórico'; box.appendChild(row);
  });
 }catch(e){box.textContent='Não foi possível carregar o histórico observacional.'}
}

/* G1.8.1-r19.9.3 HISTORY BUTTON EXACT WIRING */

/* R21.205_CURRENCY_MANAGEMENT_UI */
function r21205CurrencyKindLabel(x){const m={FIAT:'Fiat',CRYPTO:'Cripto',OTHER:'Outra'};return m[String(x||'').toUpperCase()]||String(x||'—')}
function r21205CurrencyCard(c){return `<article class="g15-credential-card"><div class="g15-credential-head"><div><b>${esc(c.currency_code)}${c.symbol?' • '+esc(c.symbol):''}</b><small>${esc(c.name)} • ${esc(r21205CurrencyKindLabel(c.kind))} • precisão ${esc(c.precision)}</small></div><span class="g15-status ${c.active?'is-ok':''}">${c.active?'● Ativa':'○ Inativa'}</span></div><div class="g15-provider-meta"><span>Referência monetária</span><button class="g15-secondary" onclick="r21205OpenCurrencyDialog('${esc(c.currency_code)}')">Editar</button></div></article>`}
async function r21205LoadCurrencies(){const grid=$('r21205CurrencyGrid');if(!grid)return;try{const j=await jsonFetch('/api/currency-registry'),rows=Array.isArray(j.currencies)?j.currencies:[];grid.innerHTML=rows.map(r21205CurrencyCard).join('')||'<div class="muted">Nenhuma moeda cadastrada.</div>'}catch(e){grid.innerHTML=`<article class="g15-security-card"><p>Falha ao carregar moedas: ${esc(e.message||String(e))}</p></article>`}}
function r21205CurrencySection(){return `<section class="g15-settings-section"><div class="g15-section-head"><div><span>CONFIGURAÇÕES • MOEDAS</span><h2>Moedas</h2><p>Registro global de moedas do Porquinho. Moeda é independente de país e não implica conversão cambial.</p></div></div><div class="g15-provider-toolbar"><div><b>Moedas cadastradas</b><small>Referência usada por contas e universos</small></div><button onclick="r21205OpenCurrencyDialog()">+ Adicionar moeda</button></div><div id="r21205CurrencyGrid" class="g15-credential-grid"><div class="muted">Carregando moedas…</div></div><article class="g15-security-card"><div><b>Contrato financeiro</b><small>F8.1</small></div><p>Cadastrar ou editar moeda não movimenta caixa, não converte valores, não agrega moedas diferentes, não escreve ledger e não concede autoridade ao Brain.</p></article></section>`}
async function r21205OpenCurrencyDialog(code=''){try{const j=await jsonFetch('/api/currency-registry'),c=(j.currencies||[]).find(x=>x.currency_code===code)||null,edit=!!c;openModal(edit?'Editar moeda':'Adicionar moeda',`<div class="v38265-form">${v38265Field('Código',`<input id="r21205Code" value="${esc(c?.currency_code||'')}" placeholder="Ex.: USD" maxlength="12" ${edit?'readonly':''}>`)}${v38265Field('Nome',`<input id="r21205Name" value="${esc(c?.name||'')}" placeholder="Ex.: Dólar americano">`)}${v38265Field('Tipo',`<select id="r21205Kind">${['FIAT','CRYPTO','OTHER'].map(x=>`<option value="${x}" ${x===(c?.kind||'FIAT')?'selected':''}>${r21205CurrencyKindLabel(x)}</option>`).join('')}</select>`)}${v38265Field('Precisão',`<input id="r21205Precision" type="number" min="0" max="18" value="${esc(c?.precision??2)}">`)}${v38265Field('Símbolo',`<input id="r21205Symbol" value="${esc(c?.symbol||'')}" placeholder="Opcional">`)}${edit?v38265Field('Estado',`<select id="r21205Active"><option value="true" ${c.active?'selected':''}>Ativa</option><option value="false" ${!c.active?'selected':''}>Inativa</option></select>`):''}<p class="v38265-note">Dados de referência apenas. Nenhuma movimentação financeira será criada.</p><div class="modal-actions"><button onclick="closeModal()">Cancelar</button><button class="primary" onclick="r21205SaveCurrency('${edit?esc(c.currency_code):''}')">${edit?'Salvar alterações':'Cadastrar moeda'}</button></div></div>`)}catch(e){toast('Falha ao abrir moedas: '+(e.message||e))}}
async function r21205SaveCurrency(existing=''){const code=String($('r21205Code')?.value||'').trim().toUpperCase(),body={name:$('r21205Name')?.value,kind:$('r21205Kind')?.value,precision:Number($('r21205Precision')?.value),symbol:$('r21205Symbol')?.value||null};if(existing)body.active=$('r21205Active')?.value==='true';else body.currency_code=code;try{const url=existing?'/api/currency-registry/'+encodeURIComponent(existing):'/api/currency-registry',r=await fetch(url,{method:existing?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}),j=await r.json();if(!r.ok||!j?.ok)throw new Error(j?.error||'Falha ao salvar moeda');closeModal();toast(existing?'Moeda atualizada.':'Moeda cadastrada.');await r21205LoadCurrencies()}catch(e){toast('Falha ao salvar moeda: '+(e.message||e))}}
const _r21205SettingsShell=g15SettingsShell;
g15SettingsShell=function(){return _r21205SettingsShell()+r21205CurrencySection()}
const _r21205LoadCredentials=g15LoadCredentials;
g15LoadCredentials=async function(){r21205LoadCurrencies();return await _r21205LoadCredentials()}

/* V3.8.9.4.1-r3 — exact manual sell facts */
async function v38941EditPosition(asset){
 try{
  const j=await jsonFetch('/api/portfolio/position/'+encodeURIComponent(asset)),p=j.position||{};
  const sc=((lastStatus||{}).portfolio?.scores||[]).find(x=>String(x.asset).toUpperCase()===String(asset).toUpperCase())||{};
  const suggested=Number(sc.execution_fraction_pct||sc.realize_fraction_pct||sc.realize_pct||25);
  const basis=String(sc.execution_fraction_basis||sc.realize_fraction_basis||'').toUpperCase();
  const basisLabel=basis==='UNITS'?'das unidades de cripto':basis==='INVESTED_VALUE'?'do valor investido':'(base não informada)';
  const now=new Date(); const local=new Date(now.getTime()-now.getTimezoneOffset()*60000).toISOString().slice(0,16);
  openModal('Registrar venda executada • '+esc(asset),`<div style="display:grid;gap:10px">
   <div class="muted">Registro manual de uma venda já executada externamente. Nenhuma ordem será enviada à corretora.</div>
   <div>Recomendação do Brain: <b>${suggested.toFixed(2)}% ${basisLabel}</b>. Este percentual é explicativo e não determina a quantidade contabilizada.</div>
   <label>Quantidade de ${esc(asset)} efetivamente vendida<input id="peSoldQty" type="number" min="0" step="any" placeholder="Quantidade exata"></label>
   <label>Data e hora reais da venda<input id="peExecutedAt" type="datetime-local" value="${local}"></label>
   <label>Valor bruto recebido (€)<input id="peProceeds" type="number" min="0" step=".01"></label>
   <label>Taxa da venda (€)<input id="peFee" type="number" min="0" step=".01" value="0"></label>
   <p class="muted">Posição atual: ${esc(p.quantity)} ${esc(asset)} • custo contabilizado € ${esc(p.amount_eur)}</p>
   <button onclick="v38941Preview('${asset}')">Revisar venda registrada</button></div>`);
 }catch(e){toast(e.message)}
}
async function v38941Preview(asset){
 const sold=Number($('peSoldQty').value),pro=$('peProceeds').value,fee=$('peFee').value,dt=$('peExecutedAt').value;
 if(!(sold>0)){toast('Informe a quantidade exata vendida.');return}
 if(!dt){toast('Informe a data e hora reais da venda.');return}
 if(pro===''||fee===''){toast('Preencha valor bruto e taxa.');return}
 const j=await jsonFetch('/api/portfolio/position/'+encodeURIComponent(asset)),p=j.position||{},q=Number(p.quantity);
 if(sold>q){toast('A quantidade vendida não pode exceder a posição atual.');return}
 const sc=((lastStatus||{}).portfolio?.scores||[]).find(x=>String(x.asset).toUpperCase()===String(asset).toUpperCase())||{};
 const pct=Number(sc.execution_fraction_pct||sc.realize_fraction_pct||sc.realize_pct||25);
 const basis=String(sc.execution_fraction_basis||sc.realize_fraction_basis||'').toUpperCase();
 const basisLabel=basis==='UNITS'?'das unidades de cripto':basis==='INVESTED_VALUE'?'do valor investido':'(base não informada)',remain=q-sold,net=Number(pro)-Number(fee);
 openModal('Confirmar registro da venda • '+esc(asset),`<div style="display:grid;gap:9px"><b>Confira os fatos da execução</b>
 <div>Recomendação: <b>${pct.toFixed(2)}% ${basisLabel}</b> <span class="muted">(não usada para calcular unidades)</span></div>
 <div>Quantidade efetivamente vendida: <b>${sold.toFixed(8)}</b> ${esc(asset)}</div><div>Saldo esperado: <b>${remain.toFixed(8)}</b> ${esc(asset)}</div>
 <div>Momento da venda: <b>${esc(dt)}</b></div><div>Bruto: <b>€ ${Number(pro).toFixed(2)}</b> • Taxa: <b>€ ${Number(fee).toFixed(2)}</b> • Líquido: <b>€ ${net.toFixed(2)}</b></div>
 <div class="muted">Continuar cria uma revisão governada; ainda não altera o ledger.</div>
 <div style="display:flex;gap:8px"><button onclick="v38941EditPosition('${asset}')">Voltar</button><button onclick="v38941CommitRealize('${asset}',${sold},'${dt}',${Number(pro)},${Number(fee)},${pct},'${basis}')">Preparar revisão</button></div></div>`);
}
async function v38941CommitRealize(asset,sold,dt,pro,fee,pct,basis){
 const executedAt=new Date(dt).toISOString();
 try{
  const j=await jsonFetch('/api/portfolio/position',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({asset,mode:'REALIZE',percent:pct,percent_basis:basis,sold_quantity:sold,executed_at:executedAt,proceeds_eur:pro,fee_eur:fee,suggested_action:'REALIZE',suggested_percent:pct})});
  if(j.status!=='REVIEW_REQUIRED'||j.ledger_append!==false||!j.session_id||!j.sell_candidate_id)throw new Error('Resposta de revisão governada inesperada.');
  openModal('Aprovar revisão • '+esc(asset),`<div style="display:grid;gap:9px"><b>Venda preparada para revisão</b><div>Quantidade executada: <b>${sold.toFixed(8)} ${esc(asset)}</b></div><div>Momento executado: <b>${esc(dt)}</b></div><div class="muted">A aprovação prepara o plano governado; ainda não executa o commit live.</div><div style="display:flex;gap:8px"><button onclick="closeModal()">Cancelar</button><button onclick="v38941ApproveRealize('${asset}','${j.session_id}','${j.sell_candidate_id}','${j.fee_candidate_id||''}')">Aprovar revisão</button></div></div>`);
 }catch(e){toast(e.message)}
}

// R21.369J_UNIVERSE_SELECTOR_COMPATIBILITY

/* R21.376B_OVERVIEW_CANONICAL_CONSOLIDATION
   Experience-only overlay.
   Financial truth: /api/portfolio/live-projection.
   Human account identity: /api/investment-registry.
   No silent FX; no financial mutation.
*/
async function r21376bOverviewCanonical(){
  const title=document.getElementById('viewTitle');
  if(!title || String(title.textContent||'').trim()!=='Visão Geral') return false;
  let reg,live;
  try{
    [reg,live]=await Promise.all([
      jsonFetch('/api/investment-registry'),
      jsonFetch('/api/portfolio/live-projection')
    ]);
  }catch(e){ return false; }

  const proj=(live||{}).projection||{};
  const totals=proj.currency_totals||{};
  const institutions=reg.institutions||[],accounts=reg.accounts||[];
  const im=new Map(institutions.map(i=>[String(i.institution_id),i]));
  const am=new Map(accounts.map(a=>{
    const i=im.get(String(a.institution_id))||{};
    return [String(a.account_id),{
      institution_name:String(i.name||a.institution_id||'Instituição'),
      account_name:String(a.name||'Conta'),
      currency:String(a.currency||'').toUpperCase()
    }];
  }));

  const eur=totals.EUR||{};
  const eurMarket=eur.market_value==null?null:Number(eur.market_value);
  const eurCash=eur.cash==null?null:Number(eur.cash);
  const eurWealth=eur.wealth==null?((eurMarket!=null&&eurCash!=null)?eurMarket+eurCash:null):Number(eur.wealth);

  // Replace Overview headline metrics with the same canonical projection used elsewhere.
  const metrics=document.querySelectorAll('#viewContent .v38131-metric');
  if(metrics.length){
    metrics.forEach(m=>{
      const label=String(m.querySelector('small')?.textContent||'').trim();
      const b=m.querySelector('b');
      if(!b)return;
      if(label==='Patrimônio' && eurWealth!=null)b.textContent=money(eurWealth);
      if(label==='Caixa disponível' && eurCash!=null)b.textContent=money(eurCash);
    });
  }

  // Friendly identities in "Posições reais".
  document.querySelectorAll('#v38131Positions .v38131-pos').forEach(row=>{
    const span=row.querySelector('span'); if(!span)return;
    const aid=String(span.textContent||'').trim(),meta=am.get(aid);
    if(meta)span.textContent=meta.institution_name;
  });

  // Rebuild "Contas" from canonical live positions + Registry; never from legacy score account labels.
  const host=document.getElementById('v38131Accounts');
  if(host){
    const by=new Map();
    (proj.positions||[]).forEach(x=>{
      const aid=String(x.account_id||''); if(!aid)return;
      const cur=String(x.currency||'').toUpperCase();
      const mv=x.market_value;
      if(mv==null)return;
      const key=aid+'|'+cur;
      by.set(key,(by.get(key)||0)+Number(mv));
    });
    host.innerHTML=[...by.entries()].sort((a,b)=>b[1]-a[1]).map(([key,value])=>{
      const [aid,cur]=key.split('|'),meta=am.get(aid);
      const name=meta?.institution_name||'Conta não registrada';
      const sub=meta?`${meta.account_name} · ${cur}`:`${cur} · identidade ${aid}`;
      return `<div class="v38131-account"><div><b>${esc(name)}</b><small>${esc(sub)}</small></div><strong>${v38279r3Money(value,cur)}</strong></div>`;
    }).join('')||'<div class="v38131-empty">Nenhuma posição canônica.</div>';
  }
  return true;
}

const r21376bShowExperienceView=showExperienceView;
showExperienceView=function(name){
  const out=r21376bShowExperienceView(name);
  if(name==='overview') Promise.resolve().then(()=>r21376bOverviewCanonical());
  return out;
};

const r21376bLoadStatus=loadStatus;
loadStatus=async function(){
  const out=await r21376bLoadStatus.apply(this,arguments);
  const active=document.querySelector('.nav-item.active')?.dataset?.target;
  if(active==='overview')await r21376bOverviewCanonical();
  return out;
};

/* R21.376E_OVERVIEW_FRIENDLY_IDENTITY
   Fixes active v38131 DOM shape; presentation only. */
async function r21376eOverviewFriendlyIdentity(){
  const host=document.getElementById('v38131Accounts'), ph=document.getElementById('v38131Positions');
  if(!host&&!ph)return false;
  let reg; try{reg=await jsonFetch('/api/investment-registry')}catch(e){return false}
  const im=new Map((reg.institutions||[]).map(i=>[String(i.institution_id),i]));
  const am=new Map((reg.accounts||[]).map(a=>{const i=im.get(String(a.institution_id))||{};return [String(a.account_id),String(i.name||a.institution_id||a.name||'Conta')]}));
  document.querySelectorAll('#v38131Positions .v38131-pos span').forEach(el=>{const n=am.get(String(el.textContent||'').trim());if(n)el.textContent=n});
  document.querySelectorAll('#v38131Accounts .v38131-account').forEach(row=>{
    const b=row.querySelector('b'); if(!b)return; const aid=String(b.textContent||'').trim(),n=am.get(aid);
    if(n){b.textContent=n;const mark=row.querySelector('.v38131-bankmark');if(mark)mark.textContent=n.slice(0,2).toUpperCase()}
  });
  return true;
}
const r21376eLoadStatus=loadStatus;
loadStatus=async function(){const out=await r21376eLoadStatus.apply(this,arguments);await r21376eOverviewFriendlyIdentity();return out};
const r21376eShow=showExperienceView;
showExperienceView=function(){const out=r21376eShow.apply(this,arguments);Promise.resolve().then(()=>r21376eOverviewFriendlyIdentity());return out};


/* R21.376K_ANALYTICS_FRIENDLY_ACCOUNT_NAMES */
(function(){
 const M={"acct_3b29af505a7c40b2":"N26","acct_b057c5b290934b28":"Revolut"};
 function apply(){
   const root=document.getElementById("viewContent"); if(!root)return;
   root.querySelectorAll("*").forEach(el=>{
     if(el.children.length!==0)return;
     const t=(el.textContent||"").trim();
     if(M[t])el.textContent=M[t];
   });
 }
 let queued=false;
 const obs=new MutationObserver(()=>{if(queued)return;queued=true;queueMicrotask(()=>{queued=false;apply();});});
 function mount(){const r=document.getElementById("viewContent");if(r){obs.observe(r,{childList:true,subtree:true});apply();}}
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",mount);else mount();
 const oldShow=showExperienceView;
 showExperienceView=function(){const r=oldShow.apply(this,arguments);Promise.resolve().then(apply);return r;};
 const oldLoad=loadStatus;
 loadStatus=async function(){const r=await oldLoad.apply(this,arguments);apply();return r;};
})();


/* R21_386IO_OPPORTUNITY_READINESS_UI_START */
let R21386IO_READINESS={rows:[],summary:{}};
function r21386ioReadinessRow(symbol){
 const key=String(symbol||'').trim().toUpperCase();
 return (Array.isArray(R21386IO_READINESS.rows)?R21386IO_READINESS.rows:[]).find(x=>String(x?.symbol||'').trim().toUpperCase()===key)||null;
}
function r21386ioReadinessPanel(symbol){
 const x=r21386ioReadinessRow(symbol);
 if(!x)return `<div class="r21386io-readiness"><div class="r21386io-head"><b>Prontidão econômica</b><span class="blocked">INDISPONÍVEL</span></div><small>Readiness econômico não publicado para este ativo.</small></div>`;
 return `<div class="r21386io-readiness"><div class="r21386io-head"><b>Prontidão econômica</b><span class="blocked">COMPRA BLOQUEADA</span></div><div class="r21386io-gates">${(x.gates||[]).map(g=>`<span class="${g.status==='READY'?'ready':'blocked'}" title="${esc(g.detail||'')}">${g.status==='READY'?'✓':g.status==='UNVERIFIED'?'?':'○'} ${esc(g.label||g.code||'')}</span>`).join('')}</div><small>O Brain ainda não possui base econômica suficiente para dimensionar e propor esta compra.</small></div>`;
}
const _r21386ioBRCard=v38285BRCard;
v38285BRCard=function(d){
 const html=_r21386ioBRCard(d), panel=r21386ioReadinessPanel(d?.symbol), cut=html.lastIndexOf('</div>');
 return cut>=0?html.slice(0,cut)+panel+html.slice(cut):html+panel;
};
const _r21386ioOpportunities=v38285Opportunities;
v38285Opportunities=async function(button){
 try{const r=await jsonFetch('/api/opportunities/economic-readiness');R21386IO_READINESS=(r&&typeof r==='object')?r:{rows:[],summary:{}}}
 catch(_e){R21386IO_READINESS={rows:[],summary:{}}}
 return _r21386ioOpportunities(button);
};
/* R21_386IO_OPPORTUNITY_READINESS_UI_END */

/* R21_386IR_F85_SIZING_READINESS_UI_START */
let R21386IR_SIZING={rows:[],summary:{}};
function r21386irSizingRow(symbol){
 const k=String(symbol||'').trim().toUpperCase();
 return (Array.isArray(R21386IR_SIZING.rows)?R21386IR_SIZING.rows:[]).find(x=>String(x?.symbol||'').toUpperCase()===k)||null;
}
function r21386irSizingPanel(symbol){
 const x=r21386irSizingRow(symbol);
 if(!x)return `<div class="r21386ir-sizing"><b>Dimensionamento</b><small>Estado de sizing indisponível.</small></div>`;
 const structural=(x.gates||[]).filter(g=>!['TRANSACTION_COST_MODEL','FORWARD_RETURN'].includes(g.code));
 return `<div class="r21386ir-sizing"><div class="r21386ir-head"><b>Dimensionamento</b><span class="blocked">SEM VALOR SUGERIDO</span></div>
 <div class="r21386ir-gates">${structural.map(g=>`<span class="${g.status==='READY'?'ready':'blocked'}" title="${esc(g.detail||'')}">${g.status==='READY'?'✓':g.status==='UNVERIFIED'?'?':'○'} ${esc(g.label||g.code)}</span>`).join('')}</div>
 <small>${esc(x.currency||'—')} · Budget compatível: ${x.compatible_budget_count||0} · Planos: ${x.compatible_plan_count||0} · Contas vinculadas: ${x.compatible_account_count||0}. Custos e retorno prospectivo continuam obrigatórios antes do cálculo.</small></div>`;
}
const _r21386irPanel=r21386ioReadinessPanel;
r21386ioReadinessPanel=function(symbol){return _r21386irPanel(symbol)+r21386irSizingPanel(symbol)};
const _r21386irOpp=v38285Opportunities;
v38285Opportunities=async function(button){
 try{const r=await jsonFetch('/api/opportunities/sizing-readiness');R21386IR_SIZING=(r&&typeof r==='object')?r:{rows:[],summary:{}}}
 catch(_e){R21386IR_SIZING={rows:[],summary:{}}}
 return _r21386irOpp(button);
};
/* R21_386IR_F85_SIZING_READINESS_UI_END */

/* R21_386KX_FIRST_PAINT_FINAL_START
   Human-approved presentation-only finalizer.
   Canonical Universal -> Intelligence structure before async renderers settle.
   No financial/execution authority. */
function r21386kxEnsurePortfolioStructure(){
  const host=document.getElementById('portfolioPositionsV361'); if(!host)return false;
  const parent=host.parentElement; if(!parent)return false;
  let universal=document.getElementById('v38277UniversalBlock');
  if(!universal){
    universal=document.createElement('section');
    universal.id='v38277UniversalBlock'; universal.className='card'; universal.style.marginTop='14px';
    universal.innerHTML='<div class="card-head r21386ku-head"><div><b>Posições universais</b><small>Resumo universal</small></div><span>Sem conversão cambial silenciosa</span></div>';
    parent.appendChild(universal);
  }
  const intel=document.getElementById('v38284PortfolioIntel');
  if(intel && universal.nextElementSibling!==intel) universal.insertAdjacentElement('afterend',intel);
  return true;
}
function r21386kxCompactClass(p){
  const x=String(p?.asset_class||p?.position_domain||'').toUpperCase();
  if(x==='FIXED_INCOME')return 'Renda fixa';
  if(x==='EQUITY')return 'Ações';
  if(x==='ETF')return 'ETF';
  if(x==='CRYPTO')return 'Cripto';
  return r21386kuFriendly(x||'—');
}
function r21386kxCompactAccount(p){
  const n=String(p?.account_name||'').trim(); if(n && !/^acct_/i.test(n))return n;
  const id=String(p?.account_id||'').trim(); if(id && !/^acct_/i.test(id))return id;
  return '';
}
function r21386kxCompactStatus(p){
  const s=String(p?.valuation_status||'').toUpperCase();
  if(s.includes('OBSERVED'))return 'Observado';
  if(s==='AVAILABLE')return 'Disponível';
  if(!s || s==='UNAVAILABLE')return 'Indisponível';
  return r21386kuFriendly(s);
}
function r21386kxSummaryRow(p,i){
  const c=p.currency||p.valuation_currency||'';
  const value=p.current_gross_value??p.current_value??p.principal;
  const gain=p.gross_gain??p.net_gain;
  const meta=[r21386kxCompactClass(p),r21386kxCompactAccount(p),c].filter(Boolean).join(' · ');
  return `<button type="button" class="r21386ku-row" onclick="r21386kuOpenPosition(${i})" aria-label="Ver detalhes de ${esc(p.name||p.symbol||p.instrument_id||'posição')}">
    <span class="r21386ku-main"><b>${esc(p.name||p.symbol||p.instrument_id||'—')}</b><small>${esc(meta||'—')}</small></span>
    <span class="r21386ku-stat"><small>VALOR ATUAL</small><b>${r21386kuMoney(value,c)}</b></span>
    <span class="r21386ku-stat"><small>RESULTADO</small><b>${r21386kuGain(gain,c)}</b></span>
    <span class="r21386ku-status"><small>STATUS</small><b>${esc(r21386kxCompactStatus(p))}</b></span>
    <span class="r21386ku-chevron">›</span>
  </button>`;
}
r21386kuSummaryRow=r21386kxSummaryRow;
if(typeof renderPortfolioView==='function'){
  const r21386kxBasePortfolioView=renderPortfolioView;
  renderPortfolioView=function(...args){
    r21386kxEnsurePortfolioStructure();
    const r=r21386kxBasePortfolioView.apply(this,args);
    if(r && typeof r.then==='function') return r.then(async value=>{
      r21386kxEnsurePortfolioStructure();
      if(typeof r21386kuRenderCompactUniversalBlock==='function')await r21386kuRenderCompactUniversalBlock();
      if(typeof r21386ksReconcilePortfolioLayout==='function')r21386ksReconcilePortfolioLayout();
      return value;
    });
    r21386kxEnsurePortfolioStructure(); return r;
  };
}
document.addEventListener('DOMContentLoaded',()=>r21386kxEnsurePortfolioStructure());
/* R21_386KX_FIRST_PAINT_FINAL_END */

/* R21.386LF_SYSTEM_HISTORY_SINGLE_OWNER_UI */
const R21386LF_SYSTEM_OWNER='r21.386lf';
function r21386lfDate(v){if(!v)return '—';try{return new Date(v).toLocaleString()}catch(e){return String(v)}}
function r21386lfObjTitle(x,fallback){
 return x?.summary||x?.title||x?.incident_id||x?.event_id||x?.version||x?.id||fallback||'Registro';
}
function r21386lfDetail(title,obj){
 openModal(title,`<div class="technical-human"><pre style="white-space:pre-wrap;word-break:break-word;max-height:60vh;overflow:auto">${esc(JSON.stringify(obj,null,2))}</pre></div>`);
}
function r21386lfRows(rows,kind){
 if(!rows?.length)return '<div class="muted">Nenhum registro disponível.</div>';
 return `<div style="display:grid;gap:7px">${rows.slice().reverse().slice(0,12).map((x,i)=>{
   const t=r21386lfObjTitle(x,kind), st=x.status||x.validation?.status||x.result||'registrado';
   const dt=x.observed_at||x.created_at||x.updated_at||x.timestamp||x.recorded_at||'';
   return `<button style="text-align:left;padding:9px" onclick='r21386lfDetail(${JSON.stringify(kind+" • ").replace(/'/g,"&#39;")}+${JSON.stringify("${esc(t)}")},${JSON.stringify(x).replace(/'/g,"&#39;")})'><b>${esc(t)}</b><br><small>${esc(st)}${dt?' • '+esc(r21386lfDate(dt)):''}</small></button>`;
 }).join('')}</div>`;
}
async function r21386lfOpenOperational(){
 try{const x=await jsonFetch('/api/system/history/operational');
 openModal('Jobs e diagnóstico • histórico',`<div style="display:grid;gap:14px"><section><h3>Incidentes (${(x.incidents||[]).length})</h3>${r21386lfRows(x.incidents,'Incidente')}</section><section><h3>Diagnósticos (${(x.diagnostics||[]).length})</h3>${r21386lfRows(x.diagnostics,'Diagnóstico')}</section></div>`)}
 catch(e){toast('Falha ao carregar histórico operacional: '+e.message)}
}
async function r21386lfOpenPatchHistory(){
 try{const x=await jsonFetch('/api/system/history/patches');
 openModal('Patch Center • histórico',`<div style="display:grid;gap:14px"><section><h3>Aplicados / reparos (${(x.repairs||[]).length})</h3>${r21386lfRows(x.repairs,'Patch')}</section><section><h3>Registry (${(x.registry||[]).length})</h3>${r21386lfRows(x.registry,'Patch Registry')}</section><div><button onclick="closeModal();openPatches()">Ver patches disponíveis</button></div></div>`)}
 catch(e){toast('Falha ao carregar Patch Center: '+e.message)}
}
async function r21386lfSystem(button){
 document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));
 document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
 (button||document.querySelector('[data-target="system"]'))?.classList.add('active');
 const host=$('view-placeholder');host.classList.add('active-view');
 $('viewTitle').textContent='Sistema';
 $('viewDescription').textContent='Operação, históricos técnicos, patches e administração do Porquinho.';
 $('viewContent').innerHTML='<div class="muted">Carregando histórico operacional…</div>';
 try{
  const s=await jsonFetch('/api/system/history/summary');
  const c=s.counts||{};
  $('viewContent').innerHTML=`<div class="module-grid" data-owner="${R21386LF_SYSTEM_OWNER}">
   ${moduleCard('Jobs e diagnóstico',`${c.operational??0} incidentes • ${c.diagnostics??0} diagnósticos. Histórico técnico read-only.`,'Abrir histórico','r21386lfOpenOperational()')}
   ${moduleCard('Patch Center',`${c.repairs??0} reparos aplicados • ${c.patch_registry??0} registros no registry.`,'Abrir Patch Center','r21386lfOpenPatchHistory()')}
   ${moduleCard('Importações','Importação de histórico, hidratação 365d e importação financeira serão migradas aqui após validação desta fundação.')}
   ${moduleCard('Relatórios','Área preparada para futuras exportações CSV/Excel. Nenhum relatório fictício é gerado.')}
  </div>`;
 }catch(e){$('viewContent').innerHTML=`<div class="card"><b>Sistema indisponível</b><p class="loss">${esc(e.message)}</p></div>`}
 window.scrollTo({top:0,behavior:'smooth'});
}
const r21386lfBaseShowExperienceView=showExperienceView;
showExperienceView=function(name,button){
 if(name==='system'){r21386lfSystem(button);return}
 return r21386lfBaseShowExperienceView.apply(this,arguments);
};
/* /R21.386LF_SYSTEM_HISTORY_SINGLE_OWNER_UI */

/* R21.386LJ_SYSTEM_ADMIN_UX */
(function(){
 const E=v=>typeof esc==='function'?esc(v):String(v??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 const A=(x,ks)=>{if(Array.isArray(x))return x;for(const k of ks||[])if(Array.isArray(x?.[k]))return x[k];return []};
 function D(v){if(v==null||v==='')return '—';let d;if(typeof v==='number'||/^\d{10,13}$/.test(String(v))){let n=Number(v);if(n<1e12)n*=1000;d=new Date(n)}else d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('pt-PT')}
 function T(x){for(const k of ['observed_at','created_at','updated_at','finished_at','started_at','timestamp','time','ts','at','date'])if(x?.[k]!=null&&x[k]!=='')return D(x[k]);return '—'}
 function title(x){return String(x?.summary||x?.title||x?.message||x?.incident_id||x?.error_id||x?.id||x?.version||'Registro')}
 function status(x){return String(x?.status||x?.state||x?.result||'registrado')}
 async function F(urls){let e;for(const u of urls){try{const r=await fetch(u,{cache:'no-store'});if(!r.ok){e=Error(u+' HTTP '+r.status);continue}return await r.json()}catch(x){e=x}}throw e||Error('Fonte indisponível')}
 function detail(x){return '<div class="lj-detail">'+Object.entries(x||{}).map(([k,v])=>`<div><b>${E(k)}</b><pre>${E(v&&typeof v==='object'?JSON.stringify(v,null,2):v)}</pre></div>`).join('')+'</div>'}
 function listModal(name,rows,back){
   openModal(name,`${back?'<div class="lj-back"><button id="ljListBack">← Voltar</button></div>':''}<div class="lj-list">${rows.map((x,i)=>`<button class="lj-row" data-i="${i}"><span><b>${E(title(x))}</b><small>${E(status(x))} • ${E(T(x))}</small></span><em>Detalhes ›</em></button>`).join('')||'<div class="muted">Nenhum registro encontrado.</div>'}</div>`);
   setTimeout(()=>{if(back){const b=document.getElementById('ljListBack');if(b)b.onclick=back}document.querySelectorAll('.lj-row').forEach(b=>b.onclick=()=>{const x=rows[+b.dataset.i];openModal(name+' • detalhe',`<div class="lj-back"><button id="ljDetailBack">← Voltar</button></div>${detail(x)}`);setTimeout(()=>document.getElementById('ljDetailBack').onclick=()=>listModal(name,rows,back),0)})},0)
 }
 async function operational(){
   let inc=[],dia=[];
   try{const x=await F(['/api/system/history/operational']);inc=A(x,['incidents','operational','records','items']);dia=A(x?.diagnostics,['diagnostics','records','items','history']);if(!dia.length)dia=A(x,['diagnostics'])}catch(e){}
   if(!dia.length)try{const x=await F(['/api/system/history/diagnostics','/api/diagnostics']);dia=A(x,['diagnostics','records','items','history'])}catch(e){}
   return {inc,dia}
 }
 async function patches(){
   let rep=[],reg=[],av=[];
   try{const x=await F(['/api/system/history/patches']);rep=A(x?.repairs,['repairs','records','items']);reg=A(x?.registry,['registry','patches','records','items']);if(!rep.length)rep=A(x,['repairs']);if(!reg.length)reg=A(x,['registry','patch_registry'])}catch(e){}
   try{const x=await F(['/api/patches']);av=A(x,['patches','records','items']).filter(p=>String(p?.status||'').toUpperCase()==='AVAILABLE')}catch(e){}
   return {rep,reg,av}
 }
 function opsChooser(){openModal('Jobs e diagnóstico',`<div class="lj-choice"><button id="ljJobs"><b>Jobs</b><span>Execuções e tarefas operacionais registradas pelo sistema.</span></button><button id="ljDia"><b>Diagnósticos</b><span>Erros e diagnósticos persistidos, com histórico detalhado.</span></button></div><button id="ljInc">Incidentes operacionais</button>`);setTimeout(()=>{ljJobs.onclick=openJobs;ljDia.onclick=openDia;ljInc.onclick=openInc},0)}
 async function openJobs(){let a=[];try{const x=await F(['/api/jobs','/api/status']);a=A(x,['jobs','job_list','recent_jobs','items']);if(!a.length)a=A(x?.learning,['jobs'])}catch(e){}listModal('Jobs • histórico',a,opsChooser)}
 async function openDia(){const x=await operational();listModal('Diagnósticos • histórico',x.dia,opsChooser)}
 async function openInc(){const x=await operational();listModal('Incidentes • histórico',x.inc,opsChooser)}
 async function patchChooser(){const x=await patches();openModal('Patch Center',`<div class="lj-pchoice"><button id="ljRep"><b>Aplicados / reparos</b><span>${x.rep.length} registro(s)</span></button><button id="ljReg"><b>Registry</b><span>${x.reg.length} registro(s)</span></button><button id="ljAv"><b>Disponíveis</b><span>${x.av.length} aguardando decisão</span></button></div><p class="muted">Disponíveis abre o fluxo existente de decisão/aplicação.</p>`);setTimeout(()=>{ljRep.onclick=openRep;ljReg.onclick=openReg;ljAv.onclick=openAvail},0)}
 async function openRep(){const x=await patches();listModal('Patches aplicados / reparos',x.rep,patchChooser)}
 async function openReg(){const x=await patches();listModal('Patch Registry',x.reg,patchChooser)}
 function openAvail(){return typeof openPatches==='function'?openPatches():toast('Patch Center indisponível.')}
 async function countAvail(){try{const x=await F(['/api/patches']);return A(x,['patches','records','items']).filter(p=>String(p?.status||'').toUpperCase()==='AVAILABLE').length}catch(e){return 0}}
 function mount(){
   const c=document.getElementById('viewContent');if(!c)return;
   c.innerHTML=`<div class="lj-grid">
    <article class="module-card lj-card"><div><b>Jobs e diagnóstico</b><p>Acompanhe execuções operacionais, incidentes e diagnósticos persistidos.</p></div><div class="lj-actions two"><button onclick="r21386ljJobs()">Jobs</button><button onclick="r21386ljDia()">Diagnósticos</button></div></article>
    <article class="module-card lj-card"><div><b>Patch Center</b><p>Histórico de reparos, Registry e patches disponíveis para decisão humana.</p></div><div class="lj-actions three"><button onclick="r21386ljRep()">Aplicados / reparos</button><button onclick="r21386ljReg()">Registry</button><button onclick="r21386ljAvail()">Disponíveis <span id="ljCnt">—</span></button></div></article>
    <article class="module-card lj-card"><div><b>Importações</b><p>Importação e consolidação de histórico, hidratação 365d e migração administrativa progressiva.</p></div><!-- R21.386LT_SYSTEM_IMPORTS_FUNCTIONAL_MIGRATION --><div class="lj-actions"><button onclick="openImport()">Importação e consolidação</button><button onclick="hydrate()">Hidratação 365d</button><button onclick="showExperienceView('financial-import')">Importação financeira</button></div></article>
    <article class="module-card lj-card"><div><b>Relatórios</b><p>Área administrativa para relatórios e futuras exportações CSV/Excel usando dados reais.</p></div><span class="muted">Estrutura preservada para a próxima etapa.</span></article>
   </div>`;
   countAvail().then(n=>{const e=document.getElementById('ljCnt');if(e)e.textContent='('+n+')'})
 }
 window.r21386ljJobs=openJobs;window.r21386ljDia=openDia;window.r21386ljRep=openRep;window.r21386ljReg=openReg;window.r21386ljAvail=openAvail;
 /* R21.386LM_SYSTEM_SINGLE_OWNER_FIX */
/* R21.386LQ_SYSTEM_NAVIGATION_OWNERSHIP_REPAIR_V2 */
if(typeof showExperienceView==='function'){
  const old=showExperienceView;
  showExperienceView=function(n,b){
    if(n==='system'){
      document.querySelectorAll('.experience-view').forEach(x=>x.classList.remove('active-view'));
      document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));

      const view=document.getElementById('view-placeholder');
      if(!view){
        console.error('r21.386lq: view-placeholder ausente');
        return;
      }
      view.classList.add('active-view');

      const navButton=b||document.querySelector('[data-target="system"]');
      if(navButton) navButton.classList.add('active');

      const t=document.getElementById('viewTitle');
      const d=document.getElementById('viewDescription');
      if(t)t.textContent='Sistema';
      if(d)d.textContent='Administração operacional, históricos, patches, importações e relatórios.';

      mount();
      window.scrollTo({top:0,behavior:'smooth'});
      return;
    }
    return old(n,b);
  }
}
 const st=document.createElement('style');st.id='r21386lj-style';st.textContent=`
 .lj-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.lj-card{min-height:220px;display:flex;flex-direction:column;justify-content:space-between;gap:18px}
 .lj-actions{display:grid;gap:9px}.lj-actions.two{grid-template-columns:repeat(2,minmax(0,1fr))}.lj-actions.three{grid-template-columns:repeat(3,minmax(0,1fr))}
 .lj-choice{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-bottom:12px}.lj-choice button,.lj-pchoice button{display:flex;flex-direction:column;align-items:flex-start;text-align:left;gap:6px;padding:15px;min-height:92px}.lj-choice span,.lj-pchoice span{font-size:12px;opacity:.72}
 .lj-pchoice{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.lj-list{display:grid;gap:8px}.lj-row{width:100%;display:flex;justify-content:space-between;align-items:center;text-align:left;padding:13px}.lj-row span{display:grid;gap:4px}.lj-row small{opacity:.72}.lj-row em{font-style:normal;opacity:.7}.lj-back{margin-bottom:12px}
 .lj-detail{display:grid;gap:8px}.lj-detail>div{display:grid;grid-template-columns:160px 1fr;gap:12px;padding:10px;border:1px solid rgba(0,239,169,.18);border-radius:10px}.lj-detail pre{white-space:pre-wrap;word-break:break-word;margin:0;font:inherit}
 @media(max-width:900px){.lj-grid,.lj-choice,.lj-pchoice{grid-template-columns:1fr}.lj-actions.three{grid-template-columns:1fr}}
 `;document.head.appendChild(st)
})();


/* r21.386ls19a — manual external trade UI foundation.
   Local-human credentials stay in process memory only. */
const R21386LS19A={security:null,accountId:null,review:null,authorized:null};
async function r21386ls19aJson(url,opt){
 const r=await fetch(url,opt||{});let d={};try{d=await r.json()}catch(_){}
 if(!r.ok)throw Error(d.error||('HTTP '+r.status));return d;
}
async function r21386ls19aSecurity(){
 if(R21386LS19A.security?.session_id&&R21386LS19A.security?.mutation_token)return R21386LS19A.security;
 const d=await r21386ls19aJson('/api/security/local-human/bootstrap');
 if(!d.session_id||!d.mutation_token)throw Error('LOCAL_HUMAN_BOOTSTRAP_INCOMPLETE');
 R21386LS19A.security={session_id:d.session_id,mutation_token:d.mutation_token};return R21386LS19A.security;
}
async function r21386ls19aMutationHeaders(){
 const s=await r21386ls19aSecurity();
 return {'Content-Type':'application/json','X-Porquinho-Session':s.session_id,'X-Porquinho-Mutation-Token':s.mutation_token};
}
async function r21386ls19aOpenManualTrade(accountId){
 R21386LS19A.accountId=accountId;R21386LS19A.review=null;R21386LS19A.authorized=null;
 try{
  const [reg,accountsReg]=await Promise.all([r21386ls19aJson('/api/instruments'),r21386ls19aJson('/api/investment-registry')]);
  const account=(Array.isArray(accountsReg.accounts)?accountsReg.accounts:[]).find(x=>x&&x.account_id===accountId);
  const accountCurrency=String(account?.currency||'').trim().toUpperCase();
  if(!account||!accountCurrency)throw Error('ACCOUNT_CURRENCY_UNAVAILABLE');
  const instruments=(Array.isArray(reg.instruments)?reg.instruments:[]).filter(x=>x&&x.instrument_id);
  const opts=instruments.map(x=>`<option value="${esc(x.instrument_id)}">${esc(x.symbol||x.name||x.instrument_id)}${x.name&&x.symbol?' · '+esc(x.name):''}</option>`).join('');
  openModal('Registrar investimento',`<div class="v38265-form">
   <div class="muted">Compra já executada fora do Porquinho. Nenhuma ordem será enviada à corretora.</div>
   <label>Instrumento<select id="r21386ls19aInstrument">${opts}</select></label>
   <button type="button" onclick="v38272OpenInstrumentOnboarding()">+ Cadastrar instrumento</button>
   <div class="muted">O cadastro adiciona somente a identidade ao catálogo; não cria posição ou compra.</div>
   <label>Quantidade<input id="r21386ls19aQty" type="number" min="0.00000001" step="any"></label>
   <label>Preço unitário<input id="r21386ls19aPrice" type="number" min="0.00000001" step="any"></label>
   <label>Total<input id="r21386ls19aGross" type="number" min="0.01" step="any"></label>
   <label>Moeda<input id="r21386ls19aCurrency" value="${esc(accountCurrency)}" readonly></label>
   <label>Data/hora<input id="r21386ls19aExecuted" type="datetime-local"></label>
   <label>Taxa<input id="r21386ls19aFee" type="number" min="0" step="any" value="0"></label>
   <label>Origem dos recursos<select id="r21386ls19aFunding"><option value="REGISTERED_ACCOUNT_CASH">Saldo registrado</option><option value="EXTERNAL_CAPITAL">Capital externo / não rastreado</option></select></label>
   <div class="muted">Troca de ativo e outras origens permanecem bloqueadas.</div>
   <div id="r21386ls30bStage" style="display:none;margin:10px 0"></div><button id="r21386ls30eReviewButton" onclick="r21386ls19aReview()">Revisar investimento</button></div>`);
 }catch(e){toast('Não foi possível abrir o registro: '+(e.message||String(e)))}
}
function r21386ls19aPayload(){
 const q=Number($('r21386ls19aQty')?.value),p=Number($('r21386ls19aPrice')?.value),g=Number($('r21386ls19aGross')?.value),f=Number($('r21386ls19aFee')?.value||0);
 const instrument_id=$('r21386ls19aInstrument')?.value,c=$('r21386ls19aCurrency')?.value,raw=$('r21386ls19aExecuted')?.value;
 if(!instrument_id||!(q>0)||!(p>0)||!(g>0)||!c||!raw)throw Error('Preencha todos os campos obrigatórios.');
 if(Math.abs(q*p-g)>Math.max(.01,Math.abs(g)*.000001))throw Error('Quantidade × preço não corresponde ao total.');
 if(f<0)throw Error('Taxa inválida.');
 return {transaction_type:'BUY',funding_source:$('r21386ls19aFunding')?.value,account_id:R21386LS19A.accountId,instrument_id,transaction_currency:c,quantity:String(q),unit_price:String(p),gross_amount:String(g),executed_at:new Date(raw).toISOString(),fee_amount:String(f),fee_currency:c,funding_details:{source:'MANUAL_UI'}};
}

function r21386ls30bEsc(v){
 return String(v??'').replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]});
}
function r21386ls30bEconomic(d){
 const e=d?.review?.economic_payload;
 if(!e||typeof e!=='object')throw Error('SEALED_REVIEW_ECONOMIC_PAYLOAD_REQUIRED');
 return e;
}
function r21386ls30eAccount(e){
 const rows=Array.isArray(R21375B_ACCOUNTS)?R21375B_ACCOUNTS:[];
 return rows.find(a=>String(a.account_id||'')===String(e.account_id||''))||null;
}
function r21386ls30eInstrumentLabel(e){
 const id=String(e.instrument_id||''),ident=e.instrument_identity||{};
 const symbol=String(ident.symbol||id.split(':').pop()||'Instrumento');
 const name=String(ident.name||'');
 return name&&name.toUpperCase()!==symbol.toUpperCase()?symbol+' · '+name:symbol;
}
function r21386ls30eMoney(v,c){
 const n=Number(v);if(!Number.isFinite(n))return String(v??'')+' '+String(c||'');
 try{return new Intl.NumberFormat('pt-PT',{style:'currency',currency:String(c||'EUR')}).format(n)}
 catch(_){return String(v??'')+' '+String(c||'')}
}
function r21386ls30eLocalDate(v){
 const d=new Date(v);if(!Number.isFinite(d.getTime()))return String(v||'');
 try{return new Intl.DateTimeFormat('pt-PT',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).format(d)}
 catch(_){return String(v||'')}
}
function r21386ls30bRenderReview(d){
 try{
  const e=r21386ls30bEconomic(d),fee=e.fee_amount??'0',feeCur=e.fee_currency||e.transaction_currency||'';
  const box=document.getElementById('r21386ls30bStage');if(!box)throw Error('REVIEW_STAGE_CONTAINER_MISSING');
  const account=r21386ls30eAccount(e),cur=e.transaction_currency||e.account_currency||'';
  const gross=Number(e.gross_amount),feeN=Number(fee),sameFeeCurrency=!feeCur||String(feeCur)===String(cur);
  const totalOut=(Number.isFinite(gross)&&Number.isFinite(feeN)&&sameFeeCurrency)?gross+feeN:null;
  const cash=account?.canonical_cash;
  const cashAmount=cash&&String(cash.currency||account?.currency||'')===String(cur)?Number(cash.amount):NaN;
  const projected=(Number.isFinite(cashAmount)&&totalOut!==null)?cashAmount-totalOut:null;
  const accountLabel=account?String(account.institution_name||'Instituição')+' · '+String(account.account_name||'Conta'):String(e.account_id||'');
  const fundingLabel=String(e.funding_source||'')==='REGISTERED_ACCOUNT_CASH'?'Saldo registrado':String(e.funding_source||'');
  const reviewButton=document.getElementById('r21386ls30eReviewButton');if(reviewButton)reviewButton.style.display='none';
  box.innerHTML=`<div style="display:grid;gap:10px">
   <div><b>Compra externa pronta para confirmação</b></div>
   <div class="muted">REVIEWED — nenhuma autoridade criada e nenhuma alteração financeira realizada.</div>
   <div><b>Instrumento:</b> ${r21386ls30bEsc(r21386ls30eInstrumentLabel(e))}</div>
   <div><b>Conta:</b> ${r21386ls30bEsc(accountLabel)}</div>
   <div><b>Quantidade:</b> ${r21386ls30bEsc(e.quantity)} ${r21386ls30bEsc(String(e.instrument_id||'').split(':').pop()||'')}</div>
   <div><b>Preço unitário:</b> ${r21386ls30bEsc(r21386ls30eMoney(e.unit_price,cur))}</div>
   <div><b>Valor da compra:</b> ${r21386ls30bEsc(r21386ls30eMoney(e.gross_amount,cur))}</div>
   <div><b>Taxa:</b> ${r21386ls30bEsc(r21386ls30eMoney(fee,feeCur))}</div>
   ${totalOut===null?'':`<div><b>Saída total prevista:</b> ${r21386ls30bEsc(r21386ls30eMoney(totalOut,cur))}</div>`}
   <div><b>Origem:</b> ${r21386ls30bEsc(fundingLabel)}</div>
   ${Number.isFinite(cashAmount)?`<div><b>Saldo canônico atual:</b> ${r21386ls30bEsc(r21386ls30eMoney(cashAmount,cur))}</div>`:''}
   ${projected!==null?`<div><b>Saldo previsto após registro:</b> ${r21386ls30bEsc(r21386ls30eMoney(projected,cur))}</div>`:''}
   <div><b>Data/hora local:</b> ${r21386ls30bEsc(r21386ls30eLocalDate(e.executed_at))}</div>
   <details><summary class="muted">Detalhes técnicos selados</summary>
    <div class="muted">account_id: ${r21386ls30bEsc(e.account_id)}</div>
    <div class="muted">instrument_id: ${r21386ls30bEsc(e.instrument_id)}</div>
    <div class="muted">review_sha256: ${r21386ls30bEsc(d.review_sha256)}</div>
   </details>
   <div style="display:flex;gap:8px;flex-wrap:wrap">
    <button type="button" onclick="r21386ls30bBackToEdit()">Voltar e editar</button>
    <button type="button" onclick="r21386ls19aConfirm()">Confirmar compra externa</button>
   </div></div>`;
  box.style.display='block';
 }catch(e){toast('Não foi possível apresentar a revisão: '+(e.message||String(e)))}
}

function r21386ls30bBackToEdit(){
 R21386LS19A.review=null;R21386LS19A.authorized=null;
 const box=document.getElementById('r21386ls30bStage');if(box){box.innerHTML='';box.style.display='none'}
 const reviewButton=document.getElementById('r21386ls30eReviewButton');if(reviewButton)reviewButton.style.display='';
}

function r21386ls30bRenderAuthorized(d){
 try{
  const box=document.getElementById('r21386ls30bStage');if(!box)throw Error('REVIEW_STAGE_CONTAINER_MISSING');
  const reviewButton=document.getElementById('r21386ls30eReviewButton');if(reviewButton)reviewButton.style.display='none';
  box.innerHTML=`<div style="display:grid;gap:10px">
   <div><b>AUTHORIZED — autorização durável criada; ledger ainda não alterado.</b></div>
   <div class="muted">A próxima ação é a mutação financeira real. Não feche ou reinicie o Porquinho entre estas etapas.</div>
   <details><summary class="muted">Detalhes técnicos da autorização</summary><div class="muted">sequence_id: ${r21386ls30bEsc(d.sequence_id)}</div></details>
   <button type="button" onclick="r21386ls19aExecute()">Gravar no ledger canônico</button>
  </div>`;box.style.display='block';
 }catch(e){toast('Não foi possível apresentar a autorização: '+(e.message||String(e)))}
}

async function r21386ls19aReview(){
 try{
  const d=await r21386ls19aJson('/api/manual-external-trade/review',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(r21386ls19aPayload())});
  if(!d.session_id||!d.review_sha256)throw Error('REVIEW_INCOMPLETE');R21386LS19A.review=d;
  r21386ls30bRenderReview(d);return;
  await r21386ls19aConfirm();
 }catch(e){toast('Não foi possível revisar: '+(e.message||String(e)))}
}
async function r21386ls19aConfirm(){
 try{
  const h=await r21386ls19aMutationHeaders(),sid=R21386LS19A.review?.session_id;if(!sid)throw Error('REVIEW_REQUIRED');
  const d=await r21386ls19aJson('/api/manual-external-trade/confirm/'+encodeURIComponent(sid),{method:'POST',headers:h,body:JSON.stringify({explicit_confirmation:true})});
  if(!d.sequence_id||d.authority_issued!==true)throw Error('CONFIRM_INCOMPLETE');R21386LS19A.authorized=d;
  r21386ls30bRenderAuthorized(d);return;
  await r21386ls19aExecute();
 }catch(e){toast('Não foi possível autorizar: '+(e.message||String(e)))}
}
async function r21386ls19aExecute(){
 try{
  const h=await r21386ls19aMutationHeaders(),seq=R21386LS19A.authorized?.sequence_id;if(!seq)throw Error('AUTHORIZATION_REQUIRED');
  const d=await r21386ls19aJson('/api/manual-external-trade/execute/'+encodeURIComponent(seq),{method:'POST',headers:h,body:'{}'});
  if(!d.ok)throw Error(d.error||'EXECUTION_FAILED');toast('Investimento registrado com sucesso.');closeModal();
 }catch(e){toast('Não foi possível executar: '+(e.message||String(e)))}
}



/* PORQUINHO_A8_GOVERNED_SHADOW_UI — read-only, fail-closed */
function a8Projection(){
 const x=lastStatus?.economic_decision_ui_projection;
 if(!x||x.schema!=='porquinho.a6-shadow-ui-transport/1.0'||x.status!=='EXPERIMENTAL_DECISION_AVAILABLE'||x.canonical_decision_available!==false||x.canonical_investment_recommendation!==null||x.execution_authorized!==false)return null;
 const p=x.experimental_brain_proposal;
 const actions=new Set(['KEEP','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE','ABSTAIN','ABSTAIN_INSUFFICIENT_EVIDENCE','NO_ALLOCATION']);
 if(!p||p.asterisk_required!==true||p.canonical_recommendation!==false||p.authority_status!=='EXPERIMENTAL_NOT_CANONICAL'||!actions.has(p.action)||!p.account_id||!p.currency)return null;
 return p;
}
function a8IdentityMatch(row,p){
 if(!row||!p)return false;
 const id=String(row.canonical_instrument_id||row.instrument_id||'').trim();
 const account=String(row.account_id||'').trim(),currency=String(row.currency||'').trim();
 if(!id||!account||!currency||account!==String(p.account_id)||currency!==String(p.currency))return false;
 const refs=[p.instrument_id,p.source_instrument_id,p.destination_instrument_id].filter(x=>typeof x==='string'&&x.trim());
 return refs.length>0&&refs.includes(id);
}
function a8ExperimentalBadge(row){
 const p=a8Projection();if(!a8IdentityMatch(row,p))return '';
 const labels={KEEP:'MANTER',DEPLOY_CASH:'APLICAR SALDO',INCREASE:'AUMENTAR',REDUCE:'REDUZIR',SELL:'VENDER',REALLOCATE:'REALOCAR',ABSTAIN:'ABSTER-SE',ABSTAIN_INSUFFICIENT_EVIDENCE:'ABSTER-SE',NO_ALLOCATION:'NÃO ALOCAR'};
 return `<span class="action-badge watch" title="Brain experimental; não constitui decisão canônica ou ordem">${esc('EXPERIMENTAL · '+labels[p.action])}</span>`;
}
function a8EvidencePanel(){
 const p=a8Projection();if(!p)return a24AbstentionPanel();
 const labels={KEEP:'MANTER',DEPLOY_CASH:'APLICAR SALDO',INCREASE:'AUMENTAR',REDUCE:'REDUZIR',SELL:'VENDER',REALLOCATE:'REALOCAR',ABSTAIN:'ABSTER-SE',ABSTAIN_INSUFFICIENT_EVIDENCE:'ABSTER-SE',NO_ALLOCATION:'NÃO ALOCAR'};
 const z=p.governed_sizing_evidence;
 const sizing=z&&z.account_id===p.account_id&&z.currency===p.currency&&z.action===p.action&&p.sizing_verified_for_observed_identity===true&&z.alternative_id===p.alternative_id&&z.comparison_id===p.comparison_id&&z.horizon_unit===p.horizon_unit&&z.horizon_value===p.horizon_value;
 const amount=sizing&&typeof z.suggested_amount==='number'&&Number.isFinite(z.suggested_amount)&&z.suggested_amount>=0?`${z.suggested_amount.toLocaleString('pt-PT')} ${esc(z.currency)}`:'sem valor dimensionado verificável';
 return `<div class="card" data-a8-shadow="1"><b>Brain — proposta experimental *</b><p><span class="action-badge watch">${esc('EXPERIMENTAL · '+labels[p.action])}</span> Conta: ${esc(p.account_id)} · Moeda: ${esc(p.currency)} · Dimensionamento: ${amount}</p><small>Somente evidência observada; não é recomendação canônica nem autorização de execução. Não associar a ativos sem identidade econômica completa.</small></div>`;
}
function a24AbstentionPanel(){
 const x=lastStatus?.economic_decision_ui_projection,a=x?.economic_abstention;
 if(x?.schema!=='porquinho.a6-shadow-ui-transport/1.0'||x.canonical_decision_available!==false||x.canonical_investment_recommendation!==null||x.execution_authorized!==false||a?.action!=='ABSTAIN'||a.authority!=='NONE'||a.execution_authorized!==false)return '';
 const messages={
 GOVERNED_ALTERNATIVES_NOT_SUPPLIED:'Ainda não há alternativas com evidências econômicas validadas.',
 EVIDENCE_NOT_VALIDATED:'As evidências disponíveis ainda não foram validadas para comparação.',
 RESEARCH_ONLY_EVIDENCE:'As estimativas disponíveis são apenas de pesquisa.',
 CROSS_ACCOUNT_OR_CURRENCY_COMPARISON:'As alternativas pertencem a contas ou moedas diferentes.',
 COMPARISON_HORIZON_MISMATCH:'As alternativas possuem horizontes diferentes.',
 EVIDENCE_SCOPE_MISMATCH:'A evidência não corresponde à conta ou moeda da alternativa.',
 READY_GOVERNED_SIZING_NOT_AVAILABLE_FOR_OBSERVED_DECISION:'Não há dimensionamento verificado para esta decisão.'};
 const reasons=Array.isArray(a.reasons)?a.reasons:[];
 const message=reasons.map(r=>messages[r]).find(Boolean)||'Faltam evidências econômicas compatíveis para recomendar uma ação.';
 return `<div class="card" data-a8-shadow="1"><b>Publicação canônica — indisponível</b><p>${esc(message)}</p><small>As leituras analíticas existentes continuam nas linhas da interface. Aguardando conclusão das evidências para publicação canônica; nenhuma autorização de operação foi emitida.</small></div>`;
}
function a8Mount(host){if(!host)return;host.querySelectorAll('[data-a8-shadow]').forEach(x=>x.remove());const html=a8EvidencePanel();if(html)host.insertAdjacentHTML('afterbegin',html)}
const a8PriorBadge=v366252ActionBadge;
v366252ActionBadge=function(row){const original=a8PriorBadge(row),extra=a8ExperimentalBadge(row);return extra?original+' '+extra:original};
const a8PriorMarket=renderMarketView;
renderMarketView=function(...args){const result=a8PriorMarket.apply(this,args);a8Mount(document.getElementById('marketUniverse')?.parentElement);return result};
const a8PriorPortfolio=renderPortfolioView;
renderPortfolioView=function(...args){const result=a8PriorPortfolio.apply(this,args);a8Mount(document.getElementById('portfolioPositionsV361')?.parentElement);return result};
const a8PriorOpp=v38285Opportunities;
v38285Opportunities=async function(...args){const result=await a8PriorOpp.apply(this,args);a8Mount(document.getElementById('viewContent'));return result};
/* /PORQUINHO_A8_GOVERNED_SHADOW_UI */

/* A24_POSITION_MONITOR_VISIBILITY — observation only; canonical badges unchanged. */
let a24MonitorData=null,a24MonitorAttempt=0,a24MonitorPending=false,a24MonitorFailed=false,a24PortfolioRendering=false;
function a24MonitorTime(x){return x?.at&&Number.isFinite(Date.parse(x.at))?new Date(x.at).toLocaleString('pt-PT'):'não informado'}
function a24MonitorHealthText(m){if(m?.state==='SCHEDULER_ERROR')return 'O monitor informou falha no agendamento.';if(!m?.heartbeat_recent)return 'Sinal recente não confirmado.';return ({WAITING_FOR_CURRENT_WORKER:'Aguardando o ciclo em execução.',REFRESH_QUEUED:'Ciclo de acompanhamento em fila.',WAITING_FOR_CADENCE:'No intervalo habitual entre ciclos.'})[m.state]||'Sinal recente; não comprova decisão.'}
function a24MonitorReason(code){return ({SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS:'A publicação de recomendações canônicas ainda não está integrada.',CANONICAL_CONTRACT_REQUIRES_REVIEW:'A integração da recomendação precisa de verificação.',IDENTITY_CONTEXT_REQUIRED:'Falta identificar instrumento, conta e moeda desta posição.',AMBIGUOUS_POSITION_CONTEXT:'Há mais de um contexto para esta posição; a ligação precisa de revisão.',EXPLICIT_SOURCE_BINDING_REQUIRED:'A identidade desta posição ainda não tem uma fonte vinculada nesta moeda.',SOURCE_SELECTION_REQUIRED:'Há mais de uma fonte; é necessário selecionar a correspondência.',CAPTURE_OBSERVED_TODAY:'Captura de pesquisa registrada hoje nesta moeda.',AWAITING_NORMAL_CAPTURE_TODAY:'Fonte vinculada; aguardando captura do ciclo normal de hoje.',SOURCE_INSPECTION_UNAVAILABLE:'Não foi possível conferir a fonte ou o registro de pesquisa.'})[code]||'Estado de acompanhamento ainda não confirmado.'}
function a24MonitorKey(row){
 const iid=row?.canonical_instrument_id||row?.instrument_id,aid=row?.account_id,q=row?.currency;
 return [iid,aid,q].every(x=>typeof x==='string'&&x&&x===x.trim())?[iid,aid,q]:null;
}
function a24MonitorRowMessage(key){
 if(a24MonitorFailed)return 'Diagnóstico indisponível; confira a última atualização do acompanhamento.';
 const data=a24MonitorData;if(!data||data.schema!=='porquinho.monitor-consolidation-a24/1.0')return 'Aguardando diagnóstico do acompanhamento.';
 const canonical=a24MonitorReason(data.canonical?.reason);
 if(!key)return 'Identidade, conta ou moeda ainda não ligadas à UI. '+canonical;
 const rows=(Array.isArray(data.positions)?data.positions:[]).filter(x=>x.instrument_id===key[0]&&x.account_id===key[1]&&x.currency===key[2]);
 if(rows.length!==1)return 'Correspondência desta posição ainda não confirmada na UI. '+canonical;
 return a24MonitorReason(rows[0].research_status)+' '+canonical;
}
function a24MonitorNotice(row){const key=a24MonitorKey(row);return `<small data-a24-position-context="${esc(JSON.stringify(key))}" style="display:block;max-width:330px;font-size:11px;line-height:1.4;margin-top:5px;color:#b9c9c3">${esc(a24MonitorRowMessage(key))}</small>`}
function a24EconomicSeriesMessage(d){
 const s=d?.research_economic_series;
 if(!s||s.schema!=='porquinho.research-economic-series-a24/1.0')return 'Séries globais de pesquisa: aguardando leitura.';
 if(s.status==='RESEARCH_SERIES_INSPECTION_UNAVAILABLE')return 'Séries globais de pesquisa: leitura indisponível; nenhuma evidência econômica foi validada.';
 if(!Number.isInteger(s.series_count)||s.series_count<0||!Number.isInteger(s.realized_label_count)||s.realized_label_count<0||s.horizon_unit!=='OBSERVATIONS'||s.horizon_value!==30)return 'Séries globais de pesquisa: contrato não confirmado.';
 return `Pesquisa global: ${s.series_count} séries separadas por instrumento, fonte e moeda; ${s.realized_label_count} retornos observados em janelas de 30 observações. Cada janela exige 31 registros. Não equivale aos ciclos canônicos de 30/60/90 dias nem comprova retorno esperado, modelo validado ou recomendação.`;
}
function a24ScopedEconomicMessage(d){
 const x=d?.scoped_economic_comparison_summary;
 if(!x||x.schema!=='porquinho.scoped-economic-comparisons-a24/1.0')return 'Comparação por contexto: aguardando o resultado do ciclo normal.';
 const n=x.comparison_set_count,a=x.sets_with_accepted_comparison_inputs,z=x.sets_with_matched_sizing;
 if(![n,a,z].every(v=>Number.isInteger(v)&&v>=0)||z>a||a>n||n>64||x.execution_authorized!==false||x.canonical_publication_authorized!==false)return 'Comparação por contexto: contrato não confirmado.';
 if(n===0)return 'Comparação por contexto: nenhum conjunto econômico explícito disponível. Cotações e retornos observados não substituem os modelos e custos necessários.';
 return `Comparação por contexto: ${n} conjuntos; ${a} com insumos aceitos; ${z} com dimensionamento correspondente. Cada conjunto mantém conta, moeda e horizonte próprios. Sem recomendação canônica ou operação autorizada.`;
}
function a24EconomicProducerMessage(d){
 const p=d?.economic_set_producer_diagnostic;
 if(!p||p.schema!=='porquinho.economic-component-set-producer-a24/1.0')return 'Montagem econômica: aguardando o resultado do ciclo normal.';
 const n=p.input_set_count,a=p.produced_set_count,b=p.blocked_set_count;
 if(![n,a,b].every(v=>Number.isInteger(v)&&v>=0)||a+b!==n||n>64||p.models_certified_by_assembler!==false||p.execution_authorized!==false||p.canonical_publication_authorized!==false)return 'Montagem econômica: contrato não confirmado.';
 if(p.status==='COMPONENT_SOURCE_REJECTED')return 'Montagem econômica: fonte recusada; nenhum modelo foi certificado pelo montador.';
 if(p.status==='ECONOMIC_COMPONENT_SETS_NOT_SUPPLIED')return 'Montagem econômica: os produtores ainda não forneceram pacotes explícitos de retorno esperado, custo, risco, contrafactual e utilidade. Isso não significa perda do aprendizado anterior.';
 return `Montagem econômica: ${n} conjuntos recebidos; ${a} montados; ${b} bloqueados por evidência incompleta ou incompatível. O montador não certifica modelos e não autoriza operações.`;
}
function a24GlobalHistoryMessage(d){
 const h=d?.global_history_source;
 if(!h||h.schema!=='porquinho.global-history-source-a24/1.0')return 'Histórico global por fonte: aguardando leitura.';
 if(h.status==='GLOBAL_HISTORY_INSPECTION_UNAVAILABLE')return 'Histórico global por fonte: leitura indisponível; nenhuma validação foi concedida.';
 const n=h.source_pair_count,p=h.latest_source_observation_count;
 if(![n,p].every(v=>Number.isInteger(v)&&v>=0)||h.model_validation_proven!==false)return 'Histórico global por fonte: contrato não confirmado.';
 const failed=h.attempt_outcome_counts?.HISTORY_SOURCE_UNAVAILABLE||0;
 return `Histórico global por fonte: ${n} pares com ${p} observações históricas nos pacotes mais recentes. ${failed} tentativas indisponíveis hoje (UTC). Coleta separada, uma requisição histórica por ciclo normal. Dados adquiridos agora não comprovam previsões passadas ou validação de modelos.`;
}
function a24GlobalLabPanel(d){
 const h=d?.global_research_lab;
 if(!h||h.schema!=='porquinho.global-research-lab-a24/1.0')return '<p>Laboratório global: aguardando leitura.</p>';
 if(h.status==='GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE')return '<p>Laboratório global: leitura indisponível; nenhum resultado confirmado.</p>';
 if(h.model_validation_proven!==false||h.canonical_publication_authorized!==false||h.execution_authorized!==false||!Number.isInteger(h.context_count)||!Number.isInteger(h.forecast_count)||h.context_count<0||h.forecast_count<0||h.forecast_count>h.context_count||!Array.isArray(h.contexts)||h.contexts.length!==h.context_count)return '<p>Laboratório global: contrato não confirmado.</p>';
 const labels={AWAITING_GLOBAL_HISTORY:'Aguardando histórico da fonte',AWAITING_GLOBAL_RESEARCH_PROCESSING:'Aguardando processamento',STALE_SOURCE_NO_CURRENT_FORECAST:'Fonte desatualizada; previsão indisponível',INSUFFICIENT_HISTORY_FOR_RESEARCH_FIT:'Histórico insuficiente',RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED:'Previsão experimental calculada; não validada'};
 const rows=h.contexts.map(c=>{
  if(!Number.isInteger(c.observation_count)||c.observation_count<0||!Number.isInteger(c.evaluation_fold_count)||c.evaluation_fold_count<0)return '<li>Contexto com contagens não confirmadas.</li>';
  return `<li>${esc(c.instrument_id)} · ${esc(c.quote_currency)} · ${esc(c.provider)} / ${esc(c.provider_id)}: ${esc(labels[c.status]||'Estado não confirmado')}. ${c.observation_count} observações; ${c.evaluation_fold_count} avaliações retrospectivas.</li>`;
 }).join('');
 return `<p>Laboratório global: ${h.forecast_count} previsões experimentais em ${h.context_count} contextos de fonte/moeda. Horizonte: 30 observações. Avaliação retrospectiva com resultados de treino anteriores a cada origem; períodos de avaliação podem se sobrepor. Não certifica modelos nem recomenda operações.</p><ul>${rows}</ul>`;
}
function a24ResearchComponentsMessage(d){
 const c=d?.research_economic_components;
 if(!c||c.schema!=='porquinho.research-economic-components-a24/1.0')return 'Componentes econômicos de pesquisa: aguardando leitura.';
 if(c.status==='RESEARCH_COMPONENT_INSPECTION_UNAVAILABLE')return 'Componentes econômicos de pesquisa: leitura indisponível; nenhuma prontidão confirmada.';
 const n=c.account_context_count,p=c.packet_count,a=c.available_component_count,m=c.missing_component_count;
 if(![n,p,a,m].every(v=>Number.isInteger(v)&&v>=0)||p>n||a!==3*p||m!==5*n-a||c.comparison_authorized!==false||c.model_validation_proven!==false||c.canonical_publication_authorized!==false||c.execution_authorized!==false)return 'Componentes econômicos de pesquisa: contrato não confirmado.';
 return `Componentes econômicos de pesquisa: ${p} pacotes em ${n} contextos financiados de conta/moeda; ${a} componentes descritivos ou experimentais disponíveis, ${m} ainda ausentes. Retorno experimental, risco histórico e referência de retorno não são componentes validados. Custos reais da conta/execução e política de utilidade continuam necessários; custo ausente não é zero. Nenhuma recomendação liberada.`;
}
function a24AccountCostMessage(d){
 const c=d?.account_cost_evidence;
 if(!c||c.schema!=='porquinho.account-cost-evidence-a24/1.0')return 'Custos por conta: aguardando leitura.';
 if(c.status==='ACCOUNT_COST_INSPECTION_UNAVAILABLE')return 'Custos por conta: leitura indisponível; nenhum custo confirmado.';
 const n=c.reviewed_evidence_count,a=c.active_review_count,k=c.complete_active_review_count;
 if(![n,a,k].every(v=>Number.isInteger(v)&&v>=0)||k>a||a>n||c.model_validation_proven!==false||c.comparison_authorized!==false||c.execution_authorized!==false)return 'Custos por conta: contrato não confirmado.';
 return `Custos por conta: ${n} evidências revisadas; ${a} vigentes nos contextos financiados, ${k} com todos os componentes explícitos. A estimativa exige conta, instrumento, moeda, ambiente de execução, compra/venda e valor exatos. Taxas passadas não definem tarifas futuras. Evidência revisada não é modelo validado nem custo de execução confirmado; ausência não significa custo zero.`;
}
function a24ObservedCostsMessage(d){
 const c=d?.observed_manual_trade_costs;
 if(!c||c.schema!=='porquinho.observed-trade-costs-a24/1.0')return 'Custos realizados: aguardando leitura dos registros existentes.';
 if(c.status==='OBSERVED_COST_INSPECTION_UNAVAILABLE')return 'Custos realizados: leitura indisponível; nenhum custo confirmado.';
 if(c.status==='EXISTING_LEDGER_NOT_PRESENT')return 'Custos realizados: ledger não disponível; nenhuma taxa presumida.';
 const n=c.trade_event_count,a=c.observed_trade_cost_count,f=c.linked_fee_event_count,z=c.assetless_fee_event_count;
 if(![n,a,f,z].every(v=>Number.isInteger(v)&&v>=0)||a>n||z>f||c.future_costs_validated!==false||c.comparison_authorized!==false||c.canonical_publication_authorized!==false||c.execution_authorized!==false)return 'Custos realizados: contrato não confirmado.';
 return `Custos realizados: ${a} operações existentes com ${f} eventos de taxa vinculados; ${z} taxas sem identidade de ativo reaproveitadas por vínculo explícito. Sem recadastrar transações. Custos observados não são tarifas futuras e não comprovam cobertura de spread, slippage ou impostos. Nenhuma recomendação liberada.`;
}
function a24MonitorPanel(){
 const d=a24MonitorData,valid=d?.schema==='porquinho.monitor-consolidation-a24/1.0';
 if(!valid)return '<div class="card" data-a24-monitor-panel="1"><b>Acompanhamento das posições</b><p>'+esc(a24MonitorFailed?'Diagnóstico indisponível. A interface pode precisar da ativação do código atualizado.':'Aguardando leitura do acompanhamento.')+'</p><button onclick="a24FetchMonitor(true)">Verificar acompanhamento</button></div>';
 const m=d.monitor||{},b=d.brain||{},r=d.research_capture||{},count=Number.isInteger(r.verified_records_today)?r.verified_records_today:'não confirmado';
 return `<div class="card" data-a24-monitor-panel="1"><b>Acompanhamento das posições</b><p>${a24MonitorFailed?'Última leitura indisponível. ':''}${esc(a24MonitorReason(d.canonical?.reason))}</p><div style="display:flex;flex-wrap:wrap;gap:18px"><span>Último sinal do monitor<br><b>${esc(a24MonitorTime(m.heartbeat))}</b><br><small>${esc(a24MonitorHealthText(m))}</small></span><span>Snapshot<br><b>${esc(a24MonitorTime(m.snapshot))}</b></span><span>Resultado do laboratório<br><b>${esc(a24MonitorTime(b.lab_result))}</b><br><small>${b.global_reader_contract_present?'Leitor global identificado.':'Contrato global ainda não observado.'}</small></span><span>Capturas de pesquisa hoje (UTC)<br><b>${esc(count)}</b><br><small>${esc(r.day_utc||'')}</small></span></div><p>${esc(a24EconomicSeriesMessage(d))}</p><p>${esc(a24ScopedEconomicMessage(d))}</p><p>${esc(a24EconomicProducerMessage(d))}</p><p>${esc(a24GlobalHistoryMessage(d))}</p>${a24GlobalLabPanel(d)}<p>${esc(a24ResearchComponentsMessage(d))}</p><p>${esc(a24AccountCostMessage(d))}</p><p>${esc(a24ObservedCostsMessage(d))}</p><p style="font-size:12px">Captura diária de pesquisa não é cotação de execução. Alvo e risco exibidos na tabela não comprovam dimensionamento ou recomendação canônica; alvo de 0% não é ordem de venda.</p><button onclick="a24FetchMonitor(true)">Verificar acompanhamento</button>${a24ReallocationPanel(d)}</div>`;
}
function a24MarketSignalActions(row){
 const reading=a24OperationalReading(row);
 const result=reading?[reading.action]:[];
 if(typeof vP2BrainProposal==='function'){
  const p=vP2BrainProposal(row);if(p&&typeof p.action==='string')result.push(p.action.toUpperCase());
 }
 if(typeof a8Projection==='function'&&typeof a8IdentityMatch==='function'){
  const p=a8Projection();if(a8IdentityMatch(row,p))result.push(p.action);
 }
 return [...new Set(result)];
}
function a24MarketContextTable(d){
 const h=d?.global_research_lab;
 if(!h||h.schema!=='porquinho.global-research-lab-a24/1.0')return '<p>Aguardando contextos globais de pesquisa.</p>';
 if(h.status==='GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE')return '<p>Contextos globais indisponíveis nesta leitura.</p>';
 if(!Number.isInteger(h.context_count)||h.context_count<0||!Number.isInteger(h.forecast_count)||h.forecast_count<0||h.forecast_count>h.context_count||!Array.isArray(h.contexts)||h.contexts.length!==h.context_count||h.model_validation_proven!==false||h.canonical_publication_authorized!==false||h.execution_authorized!==false)return '<p>Contextos globais: contrato não confirmado.</p>';
 const labels={AWAITING_GLOBAL_HISTORY:'Aguardando histórico',AWAITING_GLOBAL_RESEARCH_PROCESSING:'Aguardando processamento',STALE_SOURCE_NO_CURRENT_FORECAST:'Fonte desatualizada',INSUFFICIENT_HISTORY_FOR_RESEARCH_FIT:'Histórico insuficiente',RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED:'Experimental; não validada'};
 if(!h.context_count)return '<p>Nenhum contexto global disponível nesta leitura.</p>';
 const rows=h.contexts.map(c=>{
  if(!Number.isInteger(c.observation_count)||c.observation_count<0||!Number.isInteger(c.evaluation_fold_count)||c.evaluation_fold_count<0)return '<tr><td colspan="6">Contexto com contagens não confirmadas.</td></tr>';
  const label=c.display_label_evidence==='EXACT_CATALOG_METADATA'&&typeof c.display_label==='string'?c.display_label:c.instrument_id;
  return `<tr><td title="${esc(c.instrument_id)}">${esc(label)}</td><td>${esc(c.quote_currency)}</td><td>${esc(c.provider)} · ${esc(c.provider_id)}</td><td>${c.observation_count}</td><td>${esc(labels[c.status]||'Estado não confirmado')}</td><td>${c.evaluation_fold_count}</td></tr>`;
 }).join('');
 return `<p>${h.forecast_count} previsões experimentais em ${h.context_count} contextos de fonte e moeda. Horizonte: 30 observações, distinto dos ciclos canônicos de 30/60/90 dias. Avaliações retrospectivas podem se sobrepor; não certificam modelos.</p><div class="table-wrap"><table class="v361-table"><thead><tr><th>Ativo</th><th>Moeda de cotação</th><th>Fonte</th><th>Observações</th><th>Previsão de pesquisa</th><th>Avaliações</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function a24ModelEvaluationTable(d){
 const a=d?.global_model_evaluation;
 if(!a||a.schema!=='porquinho.global-model-evaluation-a24/1.0'||a.status!=='GLOBAL_MODEL_ASSESSMENT_INSPECTED'||a.model_validation_proven!==false||a.canonical_publication_authorized!==false||a.execution_authorized!==false||!Number.isInteger(a.assessed_context_count)||!Array.isArray(a.contexts))return '<p>Avaliação comparativa dos modelos indisponível nesta leitura.</p>';
 const number=v=>typeof v==='number'&&Number.isFinite(v)?(v*100).toFixed(3):'—';
 const result=v=>v==='LOWER_MAE_THAN_BASELINE'?'Erro menor':v==='HIGHER_MAE_THAN_BASELINE'?'Erro maior':v==='EQUAL_MAE_TO_BASELINE'?'Erro equivalente':'Sem amostras';
 const cell=m=>m&&Number.isInteger(m.sample_count)?`${esc(m.sample_count)} janelas; ${esc(number(m.model_mae))} / ${esc(number(m.baseline_mae))} p.p.; ${esc(result(m.result))}`:'Pendente';
 const rows=a.contexts.map(c=>{const name=c.display_label_evidence==='EXACT_CATALOG_METADATA'?c.display_label:c.instrument_id;return `<tr><td>${esc(name)}</td><td>${esc(c.quote_currency)}</td><td>${esc(c.provider)} · ${esc(c.provider_id)}</td><td>${cell(c.all_windows)}</td><td>${cell(c.disjoint_windows)}</td><td>${cell(c.recent_half_windows)}</td></tr>`;}).join('');
 return `<details data-a24-disclosure="model-evaluation"><summary>Avaliação dos modelos contra a referência — ${esc(a.assessed_context_count)} contextos avaliados</summary><p>Erro absoluto médio (MAE): modelo / referência, em pontos percentuais de retorno. A referência é a média dos retornos já maturados no conjunto de treino de cada janela. Erro menor é um resultado descritivo, sem aprovação automática.</p><p>As janelas completas se sobrepõem. A seleção sem sobreposição começa na primeira origem e exige que a próxima origem seja posterior ao alvo anterior; isso não comprova independência. O período recente corresponde à última metade cronológica das janelas.</p><table><thead><tr><th>Ativo</th><th>Moeda</th><th>Fonte</th><th>Todas as janelas</th><th>Sem sobreposição</th><th>Metade recente</th></tr></thead><tbody>${rows}</tbody></table><p>Histórico obtido agora não comprova previsões emitidas no passado. Permanecem separadas a validação prospectiva e a avaliação econômica de custos, risco e utilidade. Nenhuma recomendação ou autorização de operação é criada por esta avaliação.</p></details>`;
}
function a24ExistingLabTable(d){
 const a=d?.global_existing_lab;
 if(!a||a.schema!=='porquinho.global-existing-lab-a24/1.0'||a.status!=='EXISTING_GLOBAL_LAB_INSPECTED'||a.canonical_publication_authorized!==false||a.model_validation_proven!==false||a.execution_authorized!==false||!Array.isArray(a.experiments))return '<p>Reaproveitamento do laboratório existente: leitura indisponível.</p>';
 const number=v=>typeof v==='number'&&Number.isFinite(v)?v.toLocaleString('pt-PT',{maximumFractionDigits:3}):'—';
 const rows=a.experiments.map(x=>`<tr><td>${esc(x.algorithm)}</td><td>${esc(x.quote_currency)}</td><td>${x.status==='AWAITING_ISOLATED_RESEARCH_FIT'?'Aguardando processamento isolado':'Pesquisa; sem certificação'}</td><td>${esc(x.evaluation?.sample_count??'—')}</td><td>${esc(number(x.evaluation?.model_mae_pp))} / ${esc(number(x.evaluation?.baseline_mae_pp))}</td></tr>`).join('');
 return `<details data-a24-disclosure="existing-lab"><summary>Laboratório existente no modelo global — ${esc(a.completed_experiment_count)} de ${esc(a.planned_experiment_count)} experimentos processados</summary><p>Reutiliza as características e os estimadores do laboratório anterior em novas experiências com fonte e moeda explícitas. Histórico e aprendizado anteriores preservados. Cada moeda tem sua própria população de treino e teste; as métricas não são agregadas entre moedas.</p><p>Comparação pareada: erro absoluto médio do modelo / referência em pontos percentuais de retorno, nas mesmas amostras retrospectivas. A referência usa a média dos rótulos maturados da população de treino. Nenhum campeão ou ensemble novo é selecionado automaticamente; resultados não autorizam operações.</p><div class="table-wrap"><table class="v361-table"><thead><tr><th>Algoritmo</th><th>Moeda</th><th>Estado</th><th>Amostras</th><th>MAE modelo / referência (p.p.)</th></tr></thead><tbody>${rows}</tbody></table></div><p>Horizonte de 30 observações. As amostras podem se sobrepor. Histórico adquirido agora não comprova previsões emitidas no passado nem certifica decisão econômica.</p></details>`;
}
function a24ProspectivePolicyMessage(d){
 const p=d?.prospective_allocation_policy;
 if(!p||p.schema!=='porquinho.prospective-allocation-policy-a24/1.0'||!['AWAITING_FIRST_NORMAL_CYCLE_POLICY_CAPTURE','PROSPECTIVE_POLICY_TRIALS_INSPECTED'].includes(p.status)||p.execution_authorized!==false||p.policy_validation_proven!==false||p.automatic_promotion!==false||p.training_requested!==false)return 'Acompanhamento prospectivo das políticas indisponível nesta leitura.';
 const count=v=>Number.isSafeInteger(v)&&v>=0;
 if(![p.issue_count,p.stored_outcome_count,p.candidate_trial_count,p.pending_issue_count,p.matured_issue_count,p.maximum_common_future_observations].every(count)||p.stored_outcome_count>p.matured_issue_count||p.pending_issue_count+p.matured_issue_count!==p.issue_count)return 'Acompanhamento prospectivo das políticas indisponível nesta leitura.';
 return `Políticas em acompanhamento prospectivo — ${p.issue_count} registros diários, ${p.candidate_trial_count} hipóteses acompanhadas, ${p.pending_issue_count} registros aguardando observações e ${p.stored_outcome_count} resultados brutos persistidos. Maior progresso: ${p.maximum_common_future_observations} de 31 pontos comuns necessários para medir 30 intervalos. Registra a primeira versão disponível por moeda e dia UTC no ciclo normal, com data atual. A avaliação começa na primeira observação comum de um dia posterior ao registro e mantém as parcelas iniciais fixas; não mede o erro da previsão original. Usa as capturas diárias de pesquisa existentes, sem importar histórico anterior ao registro. As capturas não comprovam preços simultâneos ou executáveis na corretora. Taxas e juros do cash não estão incluídos; registros sobrepostos não são amostras independentes. Isso não certifica políticas nem altera os ciclos canônicos de 30/60/90 dias, a aprendizagem anterior ou autorizações de operação.`;
}
function a24CostCoverageMessage(d){
 const c=d?.learned_policy_economic_basis?.cost_context_summary?.coverage;
 if(!c||c.schema!=='porquinho.cost-coverage-reconciliation-a24/1.0'||c.status!=='REALIZED_COST_COVERAGE_RECONCILED'||c.execution_authorized!==false||c.comparison_authorized!==false||c.historical_fee_is_future_tariff!==false)return 'Cobertura das taxas históricas indisponível nesta leitura.';
 const reasons={INSTRUMENT_NOT_IN_CURRENT_CASH_DISTRIBUTIONS:'ativo ausente das distribuições atuais de cash',OTHER_ACCOUNT_IN_CURRENT_CASH_DISTRIBUTIONS:'conta diferente nas distribuições atuais de cash',OTHER_CURRENCY_IN_CURRENT_CASH_DISTRIBUTIONS:'moeda diferente nas distribuições atuais de cash',OTHER_TRADE_SIDE_IN_CURRENT_CASH_DISTRIBUTIONS:'lado da operação diferente nas distribuições atuais de cash'};
 const excluded=Object.entries(c.historical_trade_scope_reason_counts||{}).filter(([k])=>reasons[k]).map(([k,v])=>`${v}: ${reasons[k]}`).join('; ');
 const full=c.full_action_evidence_status==='VERIFIED_SAME_REALIZED_EVENT_POPULATION'?`${c.historical_trades_in_full_action_evidence} transações reutilizadas em ${c.full_action_alternatives_with_historical_evidence} alternativas econômicas`:'cobertura das alternativas econômicas indisponível';
 return `Histórico de taxas: ${c.historical_trade_population_count} transações verificadas; ${full}. Dessas transações, ${c.historical_trades_in_current_cash_distributions} correspondem às distribuições atuais para aplicar cash. ${excluded?`Demais contextos — ${excluded}. `:''}Ausência nessa seleção não comprova perda de histórico. Nenhuma associação entre contas, moedas ou identidades foi ampliada; taxas passadas não comprovam custos futuros.`;
}
function a24LearnedEconomicMessage(d){
 const e=d?.learned_policy_economic_basis;
 if(!e||e.schema!=='porquinho.learned-policy-economic-basis-a24/1.0'||e.status!=='COMMON_RESEARCH_BASIS_ASSESSED_NOT_ECONOMICALLY_VALIDATED'||e.execution_authorized!==false||e.net_utility_created!==false||e.grouping_selects_winner!==false)return 'Base econômica das candidatas indisponível nesta leitura.';
 return `Comparação das candidatas — ${e.scenario_count} cenários em ${e.common_basis_group_count} bases separadas por conta, moeda, orçamento, plano, capital, data e horizonte; ${e.current_distribution_group_count} grupos de distribuição atual e ${e.observed_behavior_group_count} grupos de distribuições nos períodos avaliados. Os grupos não são evidências independentes e não eliminam modelos ou escolhem uma vencedora. Projeções brutas de pesquisa não incluem juros do cash ou custos desconhecidos; ${e.net_comparable_scenario_count} cenários possuem comparação econômica líquida disponível. Nenhuma ordem ou recomendação é criada. ${e.cost_context_summary?.status==='CANDIDATE_COST_CONTEXTS_LINKED_RESEARCH_ONLY'?`Custos dos cenários para aplicar cash: ${e.cost_context_summary.legs_with_realized_fee_evidence} parcelas com taxas históricas e ${e.cost_context_summary.legs_with_reviewed_quote_candidates} com cotações revisadas compatíveis. Taxas passadas não são tarifas futuras; locais de negociação não foram selecionados.`:'Ligação dos custos às candidatas indisponível nesta leitura.'} ${a24CostCoverageMessage(d)}`;
}
function a24LearnedAccountMessage(d){
 const s=d?.learned_policy_account_context;
 if(!s||s.schema!=='porquinho.learned-policy-account-context-a24/1.0'||s.status!=='LEARNED_CASH_POLICY_CONTEXTS_PROJECTED_RESEARCH_ONLY'||s.execution_authorized!==false||s.policy_validation_proven!==false)return 'Ligação das políticas às contas indisponível nesta leitura.';
 return `Políticas e orçamentos — ${s.scenario_count} cenários de pesquisa em ${s.budget_plan_context_count} contextos de orçamento e plano; ${s.source_request_compatible_leg_count} correspondências de fonte e alternativa sem conflito de identidade. Cada cenário descreve somente o cash do respectivo orçamento, não a carteira inteira. Candidatas são alternativas entre si; seus valores não são somados. Fontes bloqueadas não são redistribuídas automaticamente. Não há valor de ordem, venda por alvo zero ou realocação inferida.`;
}
function a24LearnedPolicyMessage(d){
 const p=d?.learned_allocation_policy;
 if(!p||p.schema!=='porquinho.learned-allocation-policy-a24/1.0'||p.status!=='LEARNED_POLICY_RESEARCH_INSPECTED'||p.execution_authorized!==false||p.policy_validation_proven!==false)return 'Aprendizado de políticas de alocação indisponível nesta leitura.';
 const rows=(p.contexts||[]).map(r=>`${r.quote_currency}: ${r.retained_candidate_count||0} candidatas, ${r.training_period_count||0} períodos de ajuste e ${r.held_out_period_count||0} períodos posteriores separados`);
 return `Políticas candidatas produzidas pelo Brain — ${rows.length?rows.join('; '):'aguardando experimentos globais existentes'}. Hipótese de distribuir parcelas iguais entre fontes com previsão positiva, com quantidade selecionada aprendida nos dados anteriores. Avaliação bruta, sem custos ou juros do cash; não é distribuição recomendada da conta. Risco, liquidez, elegibilidade, utilidade e validação prospectiva continuam necessários. Nenhuma ordem ou recomendação canônica é criada.`;
}
function a24ActionPolicyMessage(d){
 const p=d?.economic_action_policy;
 if(!p||p.schema!=='porquinho.economic-action-policy-a24/1.0'||p.status!=='ACTION_POLICY_GATES_ASSESSED_SHADOW_ONLY'||p.execution_authorized!==false||p.comparison_authorized!==false||p.plan_strategy_converted_to_threshold!==false)return 'Avaliação das políticas indisponível nesta leitura.';
 const registry=p.reusable_policy_registry;
 const reusable=registry?` ${registry.current_policy_count} políticas reutilizáveis vigentes, em ${registry.version_count} versões preservadas; ${p.reusable_policy_match_count} correspondências por conta, moeda, plano e horizonte. Política cadastrada não valida o modelo.`:'';
 const names={risk:'risco',liquidity:'liquidez',concentration:'concentração'};
 const parts=Object.entries(names).map(([key,label])=>{const a=p.dimensions?.[key];return a?`${label}: ${a.acceptable_count} cenários aceitos, ${a.blocked_count} bloqueados e ${a.unavailable_count} sem declaração ou evidência compatível`:`${label}: indisponível`;});
 return `Políticas por contexto — ${parts.join('; ')}. Foram recebidas ${p.input_count} declarações pelo contrato de políticas.${reusable} Ausência permanece desconhecida, sem limite padrão. Aceitação de um cenário não define valor de ordem nem autoriza operação; retorno, custos, utilidade e sizing continuam separados.`;
}
function a24ActionEvidenceMessage(d){
 const e=d?.economic_action_evidence;
 if(!e||e.schema!=='porquinho.economic-action-evidence-a24/1.0'||e.status!=='ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY'||e.execution_authorized!==false||e.comparison_authorized!==false||e.historical_fees_used_as_future_tariff!==false)return 'Ligação das evidências existentes indisponível nesta leitura.';
 return `${e.distinct_historical_trades_reused} operações anteriores reaproveitadas por identidade, conta e moeda; ${e.alternatives_with_historical_trade_count} alternativas com referências a esse histórico. ${e.cases_with_book_cost_basis} contextos com custo de aquisição e ${e.cases_with_active_plan} com plano ativo. ${e.no_transaction_leg_alternative_count} alternativas não criam pernas de negociação: custo de execução não aplicável, sem afirmar custo de manutenção zero. ${e.legs_with_reviewed_cost_scenarios} pernas possuem cenários de custo revisados, ainda sem selecionar valor ou local de execução. Estratégia do plano não foi convertida em política de utilidade; taxas históricas não foram extrapoladas.`;
}
function a24EconomicActionPlan(d){
 const a=d?.economic_action_plan;
 if(!a||a.schema!=='porquinho.economic-action-plan-a24/1.0'||a.status!=='ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY'||a.execution_authorized!==false||a.recommendation_created!==false||a.comparison_authorized!==false||!Number.isInteger(a.case_count))return '<p>Montagem das alternativas econômicas: leitura indisponível.</p>';
 const labels={KEEP:'Manter',NO_ALLOCATION:'Preservar cash',DEPLOY_CASH:'Aplicar saldo',INCREASE:'Aumentar',REDUCE:'Reduzir',SELL:'Vender',REALLOCATE:'Realocar'};
 const actions=Object.entries(a.action_counts||{}).map(([k,n])=>`<li>${esc(labels[k]||k)}: ${esc(n)} alternativas em análise</li>`).join('');
 return `<details data-a24-disclosure="economic-action-plan"><summary>Montagem das alternativas econômicas — ${esc(a.case_count)} contextos</summary><p>${esc(a.position_case_count)} contextos de posição e ${esc(a.cash_case_count)} de cash, lidos dos registros existentes.</p><ul>${actions}</ul><p>Modo manual universal: qualquer conta pode registrar compras e vendas de qualquer ativo com identidade explícita, na moeda cadastrada nessa conta. O banco não restringe a classe de ativo no Porquinho. Orçamento e plano continuam delimitando as propostas de investimento; custos não são presumidos e a execução automática exige integração e autorização próprias.</p><p>São alternativas de comparação, sem recomendação ou ordem. Realocar exige origem e destino distintos na mesma conta e moeda; não representa transferência bancária ou conversão cambial. Não exige cash livre para enumerar a possibilidade.</p><p>${esc(a.funded_case_with_capital_ceiling_count)} contextos possuem limite de capital do orçamento existente. Esse limite é compartilhado entre alternativas e não é valor de ordem nem reserva de saldo.</p><p>${esc(a24ActionEvidenceMessage(d))}</p><p>${esc(a24ActionPolicyMessage(d))}</p><p>${esc(a24LearnedPolicyMessage(d))}</p><p>${esc(a24ProspectivePolicyMessage(d))}</p><p>${esc(a24LearnedAccountMessage(d))}</p><p>${esc(a24LearnedEconomicMessage(d))}</p><p>Valores, quantidades propostas e utilidade não foram preenchidos por suposição. Tarifas passadas permanecem evidência histórica; não são tarifas futuras. Ainda são necessárias evidências validadas, elegibilidade, custos aplicáveis, política de utilidade e dimensionamento.</p></details>`;
}
function a24ReallocationPanel(d){
 const a=d?.reallocation_analysis;
 if(!a||a.schema!=='porquinho.reallocation-analysis-a24/1.0'||a.status!=='REALLOCATION_COMPARISONS_INSPECTED'||a.execution_authorized!==false||a.recommendation_created!==false||!Array.isArray(a.rows))return '<p>Realocação entre ativos: comparação indisponível nesta leitura.</p>';
 const labels={HISTORICAL_RISK_UNAVAILABLE:'Vantagem bruta projetada; risco histórico pareado indisponível',GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING:'Vantagem bruta nos modelos disponíveis; custos e dimensão pendentes',NO_GROSS_ADVANTAGE_IN_AVAILABLE_MODELS:'Sem vantagem bruta nos modelos disponíveis',MODEL_DISAGREEMENT_OR_RISK_TRADEOFF:'Divergência entre modelos ou maior risco histórico',AWAITING_COMPARABLE_FORECASTS:'Aguardando previsões comparáveis'};
 const reasons={ACTIVE_MANUAL_INVESTMENT_PLAN_REQUIRED:'plano de investimento ativo',DESTINATION_OUTSIDE_ACTIVE_PLAN_CLASSES:'destino fora das classes do plano ativo',EXPLICIT_POSITION_QUANTITY_REQUIRED:'quantidade explícita da posição',TWO_LEG_CURRENT_COSTS_REQUIRED:'custos atuais da venda e compra',ACTION_SPECIFIC_SIZING_NOT_PRODUCED:'valor a negociar ainda não dimensionado',EXACT_CURRENT_FINANCIAL_VALUATION_REQUIRED:'avaliação financeira exata da posição',SOURCE_OR_DESTINATION_FORECAST_MISSING_OR_AMBIGUOUS:'previsão de origem/destino ausente ou ambígua',COMMON_FORECAST_ORIGIN_REQUIRED:'mesma data de análise',CURRENT_FORECAST_REQUIRED:'previsões atuais',INVALID_LONG_ONLY_RETURN_FORECAST:'previsão incompatível com posição comprada',PAIRED_HISTORICAL_RISK_UNAVAILABLE:'risco histórico pareado',COMMON_MODEL_ORIGIN_REQUIRED:'mesma data entre modelos',EXECUTION_ROUTE_SELECTION_REQUIRED:'seleção do cenário de execução',ONGOING_COSTS_AND_LIQUIDITY_REQUIRED:'custos de manutenção e liquidez'};
 const num=x=>x!==null&&x!==undefined&&Number.isFinite(Number(x))?Number(x).toLocaleString('pt-PT',{maximumFractionDigits:3}):'indisponível';
 if(![a.pair_count,a.compared_pair_count,a.gross_candidate_count].every(x=>Number.isInteger(x)&&x>=0)||a.rows.length!==a.pair_count||a.compared_pair_count>a.pair_count||a.gross_candidate_count>a.compared_pair_count)return '<p>Realocação entre ativos: contrato não confirmado.</p>';
 const rows=a.rows.filter(r=>Array.isArray(r.models)&&r.models.length);
 const blocked=a.rows.filter(r=>!r.models.length).map(r=>`<li>${esc(r.source_display_label||r.source_instrument_id)} → ${esc(r.destination_display_label||r.destination_instrument_id)} · ${esc(r.currency)} · conta ${esc(r.account_id)}: ${r.missing_reasons.map(x=>esc(reasons[x]||x)).join('; ')}</li>`).join('');
 const table=rows.map(r=>{
  const models=r.models.map(m=>`<tr><td>${esc(m.algorithm)}</td><td>${esc(m.origin)}</td><td>${esc(num(m.source_return_pct))}%</td><td>${esc(num(m.destination_return_pct))}%</td><td>${esc(num(m.gross_uplift_pp))} p.p.</td><td>${esc(num(m.source_historical_downside_rms_pct))} / ${esc(num(m.destination_historical_downside_rms_pct))} p.p.; ${esc(m.paired_matured_fold_count)} janelas</td><td>${m.gross_uplift_amount===null?'indisponível':esc(num(m.gross_uplift_amount))+' '+esc(r.currency)}</td></tr>`).join('');
  const costs=(r.reviewed_two_leg_cost_scenarios||[]).map(c=>`<p>Cenário de custos revisados ${esc(c.sell_evidence_id)} / ${esc(c.buy_evidence_id)}: venda ${esc(c.sell_execution_venue_id)}, compra ${esc(c.buy_execution_venue_id)}. Diferença após esses custos, por modelo: ${c.models.map(m=>esc(m.algorithm)+': '+esc(num(m.execution_cost_adjusted_uplift_amount))+' '+esc(r.currency)).join('; ')}. Cenário não selecionado; manutenção e liquidez pendentes.</p>`).join('');
  return `<details data-a24-disclosure="reallocation-${esc(r.alternative_id)}"><summary>REALOCAR EM ANÁLISE: ${esc(r.source_display_label||r.source_instrument_id)} → ${esc(r.destination_display_label||r.destination_instrument_id)} · ${esc(r.currency)} · conta ${esc(r.account_id)}</summary><p>${esc(labels[r.status]||'Estado não confirmado')}. ${r.research_alias_used?'Correspondência de pesquisa revisada; não é vínculo financeiro para uma ordem.':''}</p><p>Capital da posição inteira no cenário: ${r.reference_capital===null?'indisponível':esc(num(r.reference_capital))+' '+esc(r.currency)}. Este é o capital de comparação, não um valor recomendado para negociar.</p><div style="overflow-x:auto"><table><thead><tr><th>Modelo</th><th>Data da previsão</th><th>Manter origem</th><th>Destino</th><th>Diferença bruta</th><th>Risco histórico origem / destino</th><th>Diferença no capital comparado</th></tr></thead><tbody>${models}</tbody></table></div>${costs}<p>Pendente: ${r.missing_reasons.map(x=>esc(reasons[x]||x)).join('; ')}.</p></details>`;
 }).join('');
 return `<details data-a24-disclosure="reallocation-analysis"><summary>Realocação entre ativos — ${esc(a.compared_pair_count)} pares comparados de ${esc(a.pair_count)} possibilidades</summary><p>Comparação efetiva de manter a origem versus trocar pelo destino na mesma conta e moeda, usando previsões já produzidas pelo laboratório. Horizonte: 30 observações, sem aguardar os ciclos de 30/60/90 dias. ${esc(a.gross_candidate_count)} pares apresentam vantagem bruta sem maior risco histórico em todos os modelos disponíveis.</p><p>Os modelos não são votos independentes. O risco é a raiz da média dos retornos negativos ao quadrado nas mesmas janelas maturadas; não é risco futuro certificado. Janelas podem se sobrepor. Retornos são estimativas de pesquisa, não garantias. Custos ausentes não são zero; nenhuma ordem ou tamanho de negociação foi criado.</p>${blocked?'<details data-a24-disclosure="reallocation-blocked"><summary>Pares sem comparação disponível</summary><ul>'+blocked+'</ul></details>':''}${table||'<p>Nenhum par tem previsões atuais comparáveis. As leituras individuais existentes continuam disponíveis.</p>'}<p>${esc(a.pair_count-a.compared_pair_count)} pares ainda sem previsões comparáveis; nenhuma escolha foi feita por ticker ou moeda inferida.</p></details>`;
}
function a24MarketContextPanel(){
 const d=a24MonitorData;
 if(!d||d.schema!=='porquinho.monitor-consolidation-a24/1.0')return '<div class="card" data-a24-monitor-panel="1"><b>Acompanhamento global</b><p>'+esc(a24MonitorFailed?'Leitura indisponível; nenhuma decisão confirmada.':'Aguardando leitura do acompanhamento global.')+'</p></div>';
 const m=d.monitor||{};
 return `<div class="card" data-a24-monitor-panel="1"><b>Acompanhamento global</b><p>${a24MonitorFailed?'Última leitura indisponível. ':''}${esc(a24MonitorHealthText(m))} Último sinal: ${esc(a24MonitorTime(m.heartbeat))}.</p><p>${esc(a24MonitorReason(d.canonical?.reason))}</p><p>Os preços e indicadores da lista abaixo pertencem à visão de referência existente. Os contextos de pesquisa por fonte e moeda são apresentados separadamente; seus registros não são unidos por símbolo.</p>${a24MarketContextTable(d)}${a24ModelEvaluationTable(d)}${a24ExistingLabTable(d)}${a24EconomicActionPlan(d)}${a24ReallocationPanel(d)}<p>${esc(a24ObservedCostsMessage(d))}</p><details data-a24-disclosure="economic-pending"><summary>Pendências da comparação econômica</summary><p>${esc(a24EconomicProducerMessage(d))}</p><p>${esc(a24ScopedEconomicMessage(d))}</p></details><button onclick="a24FetchMonitor(true)">Verificar acompanhamento</button></div>`;
}
const a24DisclosureState=new Map();
function a24RememberDisclosures(){
 for(const id of ['marketUniverse','portfolioPositionsV361']){
  const host=document.getElementById(id)?.parentElement;
  if(!host)continue;
  host.querySelectorAll('details[data-a24-disclosure]').forEach(node=>{
   const key=node.getAttribute('data-a24-disclosure');
   if(key)a24DisclosureState.set(id+':'+key,node.open===true);
  });
 }
}
function a24RestoreDisclosures(host,id){
 host.querySelectorAll('details[data-a24-disclosure]').forEach(node=>{
  const key=id+':'+node.getAttribute('data-a24-disclosure');
  if(a24DisclosureState.has(key))node.open=a24DisclosureState.get(key);
 });
}
function a24MountMonitor(){
 a24RememberDisclosures();
 for(const id of ['portfolioPositionsV361','marketUniverse']){
  const host=document.getElementById(id)?.parentElement;if(!host)continue;
  host.querySelectorAll('[data-a24-monitor-panel]').forEach(x=>x.remove());host.insertAdjacentHTML('afterbegin',id==='marketUniverse'?a24MarketContextPanel():a24MonitorPanel());
  a24RestoreDisclosures(host,id);
  host.querySelectorAll('[data-a24-position-context]').forEach(node=>{let key=null;try{key=JSON.parse(node.getAttribute('data-a24-position-context'))}catch(_){}node.textContent=a24MonitorRowMessage(key)});
 }
}
async function a24FetchMonitor(force=false){
 if(a24MonitorPending||(!force&&Date.now()-a24MonitorAttempt<30000))return;
 a24MonitorPending=true;a24MonitorAttempt=Date.now();
 try{const d=await jsonFetch('/api/research/monitor-consolidation');if(d?.schema!=='porquinho.monitor-consolidation-a24/1.0')throw Error('diagnóstico inválido');a24MonitorData=d;a24MonitorFailed=false}catch(_){a24MonitorFailed=true}finally{a24MonitorPending=false;a24MountMonitor()}
}
const a24MonitorPriorBadge=v366252ActionBadge;
v366252ActionBadge=function(row){return a24MonitorPriorBadge(row)+(a24PortfolioRendering?a24MonitorNotice(row):'')};
const a24MonitorPriorPortfolio=renderPortfolioView;
renderPortfolioView=function(...args){a24PortfolioRendering=true;let result;try{result=a24MonitorPriorPortfolio.apply(this,args)}finally{a24PortfolioRendering=false}a24MountMonitor();void a24FetchMonitor();return result};
/* /A24_POSITION_MONITOR_VISIBILITY */
/* A24: legacy execution text must not override missing or mismatched canonical publication. */
function a24OperationalReading(row){
 if(!row||typeof row!=='object'||Array.isArray(row))return null;
 const action=typeof row.action==='string'?row.action.trim().toUpperCase():'';
 const labels={COMPRE:'COMPRE',VENDA:'VENDA',REALIZE:'REALIZAR PARTE',MANTENHA:'MANTER',ACOMPANHE:'ACOMPANHAR',KEEP:'MANTER',DEPLOY_CASH:'APLICAR SALDO',INCREASE:'AUMENTAR',REDUCE:'REDUZIR',SELL:'VENDER',REALLOCATE:'REALOCAR',ABSTAIN:'ABSTER-SE',ABSTAIN_INSUFFICIENT_EVIDENCE:'ABSTER-SE',NO_ALLOCATION:'NÃO ALOCAR'};
 if(!Object.prototype.hasOwnProperty.call(labels,action))return null;
 let label=labels[action];
 if(action==='REALIZE'){
  const fraction=row.execution_fraction_pct;
  label=String(row.execution_state||'').toUpperCase()==='EXECUTE'&&typeof fraction==='number'&&Number.isFinite(fraction)&&fraction>0&&fraction<=100?'REALIZAR '+fraction+'%':'REALIZAÇÃO EM REVISÃO';
 }
 const status=typeof lastStatus==='object'&&lastStatus?lastStatus:{};
 const own=row.observed_at||row.timestamp||row.generated_at;
 const stamp=own||status.snapshot?.timestamp||status.portfolio?.timestamp;
 const time=typeof stamp==='string'&&Number.isFinite(Date.parse(stamp))?new Date(stamp).toLocaleString('pt-PT'):'não informada';
 const key=a24MonitorKey(row),quote=row.quote_currency;
 const context=key&&(!quote||quote===key[2])?'Contexto declarado na linha; não certifica a fonte ou a cotação.':'Leitura de referência; contexto global de instrumento, conta e moeda não confirmado.';
 return {action,label,source:row.experimental===true?'sinal experimental explícito desta linha':'sinal analítico existente nesta linha',time,timeSource:own?'Data da linha':'Data do snapshot',context,execution_authorized:false};
}
function a24OperationalBadge(row){
 const reading=a24OperationalReading(row);
 if(!reading)return '<span class="action-badge watch" title="Nenhum sinal analítico reconhecido nesta linha">LEITURA INDISPONÍVEL</span>';
 return `<span class="action-badge watch" title="${esc(reading.source+'. '+reading.timeSource+': '+reading.time+'. '+reading.context+' Leitura analítica; não é publicação canônica ou autorização automática.')}" >${esc('LEITURA · '+reading.label)}</span><small data-a24-reading-time="1" style="display:block;font-size:11px">${esc(reading.timeSource+': '+reading.time)}${reading.context.startsWith('Leitura de referência')?' · referência; contexto não confirmado':''}</small>`;
}
function a24VerifiedCanonicalPublication(row){
 const a=lastStatus?.canonical_decision_availability,p=a?.canonical,k=a24MonitorKey(row);
 const actions=new Set(['KEEP','DEPLOY_CASH','INCREASE','REDUCE','SELL','REALLOCATE','ABSTAIN_INSUFFICIENT_EVIDENCE','NO_ALLOCATION']);
 if(a?.status!=='AVAILABLE'||p?.authority!=='CANONICAL_RECOMMENDATION'||!k||p.instrument_ref!==k[0]||p.account_id!==k[1]||p.currency!==k[2]||!actions.has(p.action))return null;
 return p;
}
const a24MonitorPriorInstruction=v366252Instruction;
v366252Instruction=function(row){
 const publication=a24VerifiedCanonicalPublication(row);
 if(publication)return a24MonitorPriorInstruction({...row,action:publication.action});
 const reading=a24OperationalReading(row);
 if(!reading)return {text:'LEITURA INDISPONÍVEL',detail:'Nenhum sinal analítico reconhecido nesta linha. A maturação não é requisito para exibir uma análise existente.',pulse:''};
 return {text:'LEITURA · '+reading.label,detail:reading.source+'. '+reading.timeSource+': '+reading.time+'. '+reading.context+' Esta leitura não depende de maturação de 30/60/90 dias; publicação canônica e autorização de execução permanecem separadas.',pulse:''};
};

/* A24_MARKET_GLOBAL_VISIBILITY: reuse the existing read-only diagnostic request. */
if(typeof renderMarketView==='function'){
 const a24MonitorPriorMarket=renderMarketView;
 renderMarketView=function(...args){a24RememberDisclosures();const result=a24MonitorPriorMarket.apply(this,args);a24MountMonitor();void a24FetchMonitor();return result};
}
