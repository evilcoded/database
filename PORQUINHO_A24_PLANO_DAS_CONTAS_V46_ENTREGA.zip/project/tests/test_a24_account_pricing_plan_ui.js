const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=process.argv[2]||'.',src=fs.readFileSync(root+'/static/app.js','utf8');
const ids={},ctx={console,JSON,Map,Number,Set,document:{getElementById:id=>ids[id]},$:id=>ids[id],esc:s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])),toast(){},closeModal(){},v38240Accounts:async()=>{},openModal:(t,h)=>{ctx.html=h},jsonFetch:async(u,o)=>{ctx.sent={u,body:JSON.parse(o.body)}},v38265Registry:async()=>ctx.registry,v38265Currencies:async()=>({currencies:[{active:true,currency_code:'JPY',name:'Yen'}]})};
vm.createContext(ctx);
for(const name of ['v38265Field','v38265OpenAccount','v38265SaveAccount','v382691EditAccount','v382691SaveAccount']){
 const line=src.split('\n').find(l=>l.startsWith('function '+name+'(')||l.startsWith('async function '+name+'('));assert.ok(line,name);vm.runInContext(line,ctx);
}
let count=0;function test(name,f){f();count++;console.log('PASS '+name)}
(async()=>{
 ctx.registry={institutions:[{institution_id:'arbitrary',name:'Arbitrary Institution',country:'ZZ'}],accounts:[{account_id:'a',name:'Account',account_type:'BANK',currency:'JPY',pricing_plan:'<script>alert(1)</script>'}]};
 await ctx.v38265OpenAccount();test('create form has free optional plan',()=>{assert.ok(ctx.html.includes('v38265AccPlan'));assert.ok(ctx.html.includes('maxlength="120"'));assert.ok(!ctx.html.includes('<option>Standard'));});
 await ctx.v382691EditAccount('a');test('edit restores and escapes saved plan',()=>{assert.ok(ctx.html.includes('&lt;script&gt;'));assert.ok(!ctx.html.includes('<script>'));});
 for(const [key,value] of Object.entries({v38265AccInst:'arbitrary',v38265AccName:'Account',v38265AccType:'BANK',v38265AccCurrency:'JPY',v38265AccOwner:'UNSPECIFIED',v38265AccPlan:' Custom Plan '}))ids[key]={value};
 await ctx.v38265SaveAccount();test('create sends plan in existing endpoint',()=>{assert.equal(ctx.sent.u,'/api/investment-registry/account');assert.equal(ctx.sent.body.pricing_plan,'Custom Plan');assert.equal(ctx.sent.body.currency,'JPY')});
 for(const [key,value] of Object.entries({v382691AccName:'Account',v382691AccType:'BANK',v382691AccCurrency:'JPY',v382691AccOwner:'PF',v382691AccPlan:' Updated Plan '}))ids[key]={value};
 await ctx.v382691SaveAccount('a');test('edit sends plan without changing route',()=>{assert.equal(ctx.sent.u,'/api/investment-registry/account/a');assert.equal(ctx.sent.body.pricing_plan,'Updated Plan')});
 ids.v382691AccPlan.value='';await ctx.v382691SaveAccount('a');test('blank explicitly clears plan',()=>assert.equal(ctx.sent.body.pricing_plan,null));
 ctx.registry.accounts[0].pricing_plan=null;await ctx.v382691EditAccount('a');test('legacy plan is blank without inferred default',()=>{assert.ok(ctx.html.includes('id="v382691AccPlan" maxlength="120" value=""'));assert.ok(!ctx.html.includes('value="Standard"'))});
 console.log('ACCOUNT_PLAN_UI_TESTS_PASSED='+count);
})().catch(e=>{console.error(e);process.exit(1)});
