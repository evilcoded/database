import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from flask import Flask
from universal_portfolio.institution_accounts import InstitutionAccountRegistry,RegistryError
from universal_portfolio.account_cost_evidence_a24 import current_scope,CostError
import test_a24_funded_currency_research as funding
from universal_portfolio.funded_currency_research_a24 import project
from webapp import br_equity_position_api_v38264 as api

class RegistryFixture(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.path=self.root/'data/institution_accounts.json';self.registry=InstitutionAccountRegistry(self.path)
  self.bank=self.registry.add_institution('Arbitrary Institution','ZZ');self.account=self.registry.add_account(self.bank.institution_id,'Account','INVESTMENT','CHF')
 def edit(self,**kw):return self.registry.update_account(self.account.account_id,'Account','INVESTMENT','CHF',**kw)

class PlanTests(RegistryFixture):
 def test_legacy_account_without_field_reads_without_migration(self):
  obj=json.loads(self.path.read_bytes());obj['accounts'][0].pop('pricing_plan');self.path.write_text(json.dumps(obj));before=self.path.read_bytes();self.assertIsNone(self.registry.list_accounts()[0].pricing_plan);self.assertEqual(before,self.path.read_bytes())
 def test_create_arbitrary_plan(self):
  a=self.registry.add_account(self.bank.institution_id,'Other','BANK','JPY',pricing_plan='  Custom Annual Plan  ');self.assertEqual(a.pricing_plan,'Custom Annual Plan')
 def test_update_changes_only_plan(self):
  before=json.loads(self.path.read_bytes());self.edit(pricing_plan='Arbitrary Plan');after=json.loads(self.path.read_bytes());before['accounts'][0]['pricing_plan']='Arbitrary Plan';self.assertEqual(before,after)
 def test_omitted_plan_is_preserved(self):
  self.edit(pricing_plan='Premium');self.assertEqual(self.edit().pricing_plan,'Premium')
 def test_blank_and_null_explicitly_clear(self):
  for value in ('',None,'   '):
   self.edit(pricing_plan='Plan');self.assertIsNone(self.edit(pricing_plan=value).pricing_plan)
 def test_invalid_plan_never_writes(self):
  for value in (1,True,{},[], 'x'*121,'bad\nplan','bad\x00plan'):
   before=self.path.read_bytes()
   with self.assertRaises(RegistryError):self.edit(pricing_plan=value)
   self.assertEqual(before,self.path.read_bytes())
 def test_no_other_account_or_institution_changes(self):
  other=self.registry.add_account(self.bank.institution_id,'Other','BANK','USD',pricing_plan='Other Plan');self.edit(pricing_plan='New');rows={r.account_id:r for r in self.registry.list_accounts()};self.assertEqual(rows[other.account_id],other);self.assertEqual(self.registry.list_institutions()[0],self.bank)
 def test_financial_files_remain_byte_identical(self):
  sentinels=[]
  for rel in ('transaction_ledger.jsonl','snapshots/a.json','models/learned.bin','history/a.json'):
   p=self.root/'data'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'unchanged');sentinels.append(p)
  self.edit(pricing_plan='Plan');self.assertTrue(all(p.read_bytes()==b'unchanged' for p in sentinels))
 def test_cost_plan_must_match_current_account(self):
  q={'account_id':'a','institution_id':'b','institution_country':'ZZ','currency':'CHF','pricing_plan':'Standard'};a={'a':{'institution_id':'b','_institution_country':'ZZ','currency':'CHF','pricing_plan':'Standard'}};current_scope(q,a);a['a']['pricing_plan']='Other'
  with self.assertRaisesRegex(CostError,'PRICING_PLAN_MISMATCH'):current_scope(q,a)
 def test_missing_current_plan_does_not_guess(self):
  with self.assertRaisesRegex(CostError,'PRICING_PLAN_MISMATCH'):current_scope({'account_id':'a','institution_id':'b','institution_country':'ZZ','currency':'CHF','pricing_plan':'Standard'},{'a':{'institution_id':'b','_institution_country':'ZZ','currency':'CHF'}})
 def test_legacy_exact_quote_scope_is_preserved(self):
  current_scope({'account_id':'a','institution_id':'b','institution_country':'ZZ','currency':'CHF'},{'a':{'institution_id':'b','_institution_country':'ZZ','currency':'CHF','pricing_plan':'Plan'}})
 def test_plan_does_not_reidentify_research_requests(self):
  registry=funding.registry();kwargs=dict(cash=[{'account_id':'account','currency':'BRL','amount':'100'}],registry=registry,candidates=funding.CANDIDATES)
  before=project(**kwargs);registry['accounts'][0]['pricing_plan']='An arbitrary plan';self.assertEqual(before,project(**kwargs))

class PlanApiTests(RegistryFixture):
 # Separate API checks, using actual Flask routes with an isolated synthetic registry.
 def setUp(self):
  super().setUp();app=Flask(__name__);app.register_blueprint(api.bp);self.client=app.test_client()
  a=patch.object(api,'registry',return_value=self.registry);a.start();self.addCleanup(a.stop)
  a=patch.object(api,'require_active_currency',side_effect=lambda code:code);a.start();self.addCleanup(a.stop)
 def body(self,**kw):return dict(name='Account',account_type='INVESTMENT',currency='CHF',**kw)
 def test_api_add_and_get_round_trip(self):
  r=self.client.post('/api/investment-registry/account',json={**self.body(pricing_plan='Custom'),'institution_id':self.bank.institution_id});self.assertEqual(r.status_code,201);iid=r.json['account']['account_id'];rows=self.client.get('/api/investment-registry').json['accounts'];self.assertEqual(next(a for a in rows if a['account_id']==iid)['pricing_plan'],'Custom')
 def test_api_edit_omit_and_clear(self):
  url='/api/investment-registry/account/'+self.account.account_id
  for body,expected in [(self.body(pricing_plan='Standard'),'Standard'),(self.body(),'Standard'),(self.body(pricing_plan=None),None)]:
   r=self.client.put(url,json=body);self.assertEqual(r.status_code,200);self.assertEqual(r.json['account']['pricing_plan'],expected)
 def test_api_rejects_invalid_type_without_writes(self):
  before=self.path.read_bytes();r=self.client.put('/api/investment-registry/account/'+self.account.account_id,json=self.body(pricing_plan=['invalid']));self.assertEqual(r.status_code,400);self.assertEqual(before,self.path.read_bytes())
