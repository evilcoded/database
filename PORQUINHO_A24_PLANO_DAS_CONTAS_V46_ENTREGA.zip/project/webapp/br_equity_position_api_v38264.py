from flask import Blueprint, jsonify, request
from pathlib import Path
import json
from universal_portfolio.institution_accounts import InstitutionAccountRegistry, RegistryError
from universal_portfolio.currency_registry import CurrencyRegistry, CurrencyRegistryError, bootstrap_defaults
from unified.br_equity_position_registration import register, RegistrationError
from unified.br_equity_position_adapter import main as refresh_positions
from unified.br_equity_brain_adapter import build as build_brain

bp=Blueprint("br_equity_position_v38264",__name__)
ROOT=Path(__file__).resolve().parents[1]
REG=ROOT/"data/institution_accounts.json"
CURRENCY_REG=ROOT/"data/currency_registry.json"

# R21.201_CURRENCY_REGISTRY_INTEGRATION
def currency_registry():
    r=CurrencyRegistry(CURRENCY_REG)
    bootstrap_defaults(r)
    return r

def require_active_currency(code):
    return currency_registry().require(code,active=True).currency_code

def registry(): return InstitutionAccountRegistry(REG)

@bp.get("/api/currency-registry")
def get_currency_registry():
    r=currency_registry()
    return jsonify({"ok":True,"currencies":[x.__dict__ for x in r.list()],"contract":{"reference_data_only":True,"financial_state_write":False,"ledger_write":False,"cross_currency_aggregation":False,"silent_fx":False}})

@bp.post("/api/currency-registry")
def add_currency_registry():
    x=request.get_json(silent=True) or {}
    try:
        row=currency_registry().register(x.get("currency_code"),x.get("name"),x.get("kind","FIAT"),x.get("precision",2),symbol=x.get("symbol"),active=x.get("active",True),source="MANUAL_UI")
        return jsonify({"ok":True,"currency":row.__dict__}),201
    except (CurrencyRegistryError,ValueError,TypeError) as e:
        return jsonify({"ok":False,"error":str(e)}),400

# R21.205_CURRENCY_UPDATE_API
@bp.put("/api/currency-registry/<currency_code>")
def update_currency_registry(currency_code):
    x=request.get_json(silent=True) or {}
    try:
        row=currency_registry().update(currency_code,name=x.get("name"),kind=x.get("kind"),precision=x.get("precision"),symbol=x.get("symbol"),active=x.get("active"))
        return jsonify({"ok":True,"currency":row.__dict__})
    except (CurrencyRegistryError,ValueError,TypeError) as e:
        return jsonify({"ok":False,"error":str(e)}),400

@bp.get("/api/investment-registry")
def get_registry():
    r=registry()
    return jsonify({"ok":True,"institutions":[x.__dict__ for x in r.list_institutions()],
                    "accounts":[x.__dict__ for x in r.list_accounts()]})

@bp.post("/api/investment-registry/institution")
def add_institution():
    x=request.get_json(silent=True) or {}
    try:
        row=registry().add_institution(x.get("name"),x.get("country"),x.get("institution_type","BANK"),source="MANUAL")
        return jsonify({"ok":True,"institution":row.__dict__}),201
    except (RegistryError,ValueError,TypeError) as e:
        return jsonify({"ok":False,"error":str(e)}),400

@bp.post("/api/investment-registry/account")
def add_account():
    x=request.get_json(silent=True) or {}
    try:
        currency=require_active_currency(x.get("currency"))
        row=registry().add_account(x.get("institution_id"),x.get("name"),x.get("account_type","INVESTMENT"),currency,management_mode="MANUAL",connector_id=None,owner_profile=x.get("owner_profile","UNSPECIFIED"),pricing_plan=x.get("pricing_plan"))
        return jsonify({"ok":True,"account":row.__dict__}),201
    except (RegistryError,CurrencyRegistryError,ValueError,TypeError) as e:
        return jsonify({"ok":False,"error":str(e)}),400

# V382691_EDIT_API
@bp.put("/api/investment-registry/institution/<institution_id>")
def edit_institution(institution_id):
    x=request.get_json(silent=True) or {}
    try:
        row=registry().update_institution(institution_id,x.get('name'),x.get('country'),x.get('institution_type','BANK'))
        return jsonify({'ok':True,'institution':row.__dict__})
    except (RegistryError,ValueError,TypeError) as e:
        return jsonify({'ok':False,'error':str(e)}),400

@bp.put("/api/investment-registry/account/<account_id>")
def edit_account(account_id):
    x=request.get_json(silent=True) or {}
    try:
        currency=require_active_currency(x.get("currency"))
        row=registry().update_account(account_id,x.get("name"),x.get("account_type"),currency,owner_profile=x.get("owner_profile"),**({"pricing_plan":x["pricing_plan"]} if "pricing_plan" in x else {}))
        return jsonify({"ok":True,"account":row.__dict__})
    except (RegistryError,CurrencyRegistryError,ValueError,TypeError) as e:
        return jsonify({"ok":False,"error":str(e)}),400

@bp.get("/api/br-equity/instruments")
def instruments():
    d=json.loads((ROOT/"data/unified_br_equity_features_latest.json").read_text(encoding="utf-8"))
    rows=[{"instrument_id":x.get("instrument_id"),"symbol":x.get("symbol"),
           "currency":x.get("currency"),"asset_class":x.get("asset_class")}
          for x in d.get("assets",[])]
    return jsonify({"ok":True,"instruments":rows})

@bp.get("/api/br-equity/positions")
def positions():
    p=ROOT/"data/br_equity_positions/verified_positions_latest.json"
    d=json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"positions":[]}
    return jsonify({"ok":True,"positions":d.get("positions",[])})

@bp.post("/api/br-equity/positions")
def add_position():
    x=request.get_json(silent=True) or {}
    try:
        row=register(x)
        snap=refresh_positions()
        brain=build_brain()
        # build() is intentionally not persisted here: API registration only refreshes position projection.
        return jsonify({"ok":True,"position":row,"verified_summary":snap.get("summary"),
                        "brain_preview_verified_positions":brain.get("summary",{}).get("verified_positions"),
                        "execution":"NONE","ledger_write":False}),201
    except RegistrationError as e:
        return jsonify({"ok":False,"error":str(e)}),400

# V38269_ACCOUNT_RECONCILIATION_READ_MODEL
@bp.get("/api/investment-registry/reconciliation")
def reconciliation():
    r=registry()
    institutions=[x.__dict__ for x in r.list_institutions()]
    accounts=[x.__dict__ for x in r.list_accounts()]
    vp=ROOT/"data/br_equity_positions/verified_positions_latest.json"
    vd=json.loads(vp.read_text(encoding="utf-8")) if vp.exists() else {"positions":[]}
    positions=vd.get("positions",[])
    by={}
    for p in positions:
        by.setdefault(p.get("account_id"),[]).append(p)
    return jsonify({"ok":True,"institutions":institutions,"accounts":accounts,
                    "positions":positions,"positions_by_account":by,
                    "contract":{"known_instrument_is_not_owned_position":True,
                                "one_position_exists_once":True,
                                "explicit_user_confirmation_required":True,
                                "legacy_auto_migration":False,
                                "cash_account_inference":False,
                                "execution":False}})
