from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
import json, os, re, tempfile, uuid
from datetime import datetime, timezone

SCHEMA="porquinho.institution-account-registry/1.0"

class RegistryError(ValueError): pass

_PLAN_UNSET = object()
def _pricing_plan(value):
    if value is None: return None
    if not isinstance(value, str) or len(value)>120 or any(ord(c)<32 or ord(c)==127 for c in value):
        raise RegistryError('pricing_plan must be plain text up to 120 characters')
    return value.strip() or None


class ManagementMode(str, Enum):
    MANUAL="MANUAL"
    CONNECTED_READ="CONNECTED_READ"
    CONNECTED_EXECUTE="CONNECTED_EXECUTE"

class InstitutionType(str, Enum):
    BANK="BANK"
    BROKER="BROKER"
    FINTECH="FINTECH"
    EXCHANGE="EXCHANGE"
    OTHER="OTHER"

def _now(): return datetime.now(timezone.utc).isoformat()

def _slug(v):
    s=re.sub(r"[^a-z0-9]+","-",str(v).strip().lower()).strip("-")
    return s or uuid.uuid4().hex[:10]

@dataclass(frozen=True)
class Institution:
    institution_id: str
    name: str
    country: str
    institution_type: str
    source: str="MANUAL"
    created_at: Optional[str]=None

@dataclass(frozen=True)
class AccountRegistration:
    account_id: str
    institution_id: str
    name: str
    account_type: str
    currency: str
    management_mode: str=ManagementMode.MANUAL.value
    connector_id: Optional[str]=None
    external_id: Optional[str]=None
    execution_enabled: bool=False
    owner_profile: str="UNSPECIFIED"
    created_at: Optional[str]=None
    pricing_plan: Optional[str]=None

class InstitutionAccountRegistry:
    """
    User-data registry. Institutions/accounts are data, never source-code.
    A connector is optional. Manual accounts are first-class citizens.
    EXECUTE is explicit and cannot be inferred merely from CONNECTED status.
    """
    def __init__(self,path:Path):
        self.path=Path(path)

    def _empty(self): return {"schema":SCHEMA,"institutions":[],"accounts":[]}

    def _load(self):
        if not self.path.exists(): return self._empty()
        obj=json.loads(self.path.read_text(encoding="utf-8"))
        if obj.get("schema")!=SCHEMA: raise RegistryError("unsupported registry schema")
        return obj

    def _save(self,obj):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix=self.path.name+".",dir=str(self.path.parent))
        try:
            with os.fdopen(fd,"w",encoding="utf-8") as f:
                json.dump(obj,f,ensure_ascii=False,indent=2,sort_keys=True); f.flush(); os.fsync(f.fileno())
            os.replace(tmp,self.path)
        except Exception:
            try: os.unlink(tmp)
            except Exception: pass
            raise

    def add_institution(self,name,country,institution_type="BANK",source="MANUAL"):
        if not str(name).strip(): raise RegistryError("institution name required")
        if not str(country).strip(): raise RegistryError("country required")
        typ=str(institution_type).upper()
        if typ not in {x.value for x in InstitutionType}: raise RegistryError("invalid institution_type")
        obj=self._load()
        key=(str(name).strip().casefold(),str(country).strip().upper())
        for row in obj["institutions"]:
            if (row["name"].casefold(),row["country"].upper())==key:
                return Institution(**row)
        row=Institution("inst_"+_slug(name)+"_"+_slug(country),str(name).strip(),
                        str(country).strip().upper(),typ,str(source),_now())
        obj["institutions"].append(asdict(row)); self._save(obj); return row

    def add_account(self,institution_id,name,account_type,currency,
                    management_mode="MANUAL",connector_id=None,external_id=None,
                    execution_enabled=False,owner_profile="UNSPECIFIED",pricing_plan=None):
        obj=self._load()
        if institution_id not in {x["institution_id"] for x in obj["institutions"]}:
            raise RegistryError("unknown institution_id")
        mode=str(management_mode).upper()
        if mode not in {x.value for x in ManagementMode}: raise RegistryError("invalid management_mode")
        if mode=="MANUAL" and connector_id:
            raise RegistryError("manual account cannot require connector")
        if execution_enabled and mode!="CONNECTED_EXECUTE":
            raise RegistryError("execution requires CONNECTED_EXECUTE mode")
        if mode=="CONNECTED_EXECUTE" and not connector_id:
            raise RegistryError("CONNECTED_EXECUTE requires connector_id")
        owner=str(owner_profile or "UNSPECIFIED").strip().upper()
        if owner not in {"UNSPECIFIED","PF","PJ"}: raise RegistryError("invalid owner_profile")
        row=AccountRegistration(
            "acct_"+uuid.uuid4().hex[:16],institution_id,str(name).strip(),
            str(account_type).strip().upper(),str(currency).strip().upper(),mode,
            connector_id,external_id,bool(execution_enabled),owner,_now(),_pricing_plan(pricing_plan)
        )
        obj["accounts"].append(asdict(row)); self._save(obj); return row

    # V382691_SAFE_EDITS
    def update_institution(self,institution_id,name,country,institution_type):
        obj=self._load(); typ=str(institution_type).upper()
        if not str(name).strip(): raise RegistryError('institution name required')
        if not str(country).strip(): raise RegistryError('country required')
        if typ not in {x.value for x in InstitutionType}: raise RegistryError('invalid institution_type')
        row=next((x for x in obj['institutions'] if x['institution_id']==institution_id),None)
        if row is None: raise RegistryError('unknown institution_id')
        row['name']=str(name).strip(); row['country']=str(country).strip().upper(); row['institution_type']=typ
        self._save(obj); return Institution(**row)

    def update_account(self,account_id,name,account_type,currency,owner_profile=None,pricing_plan=_PLAN_UNSET):
        obj=self._load(); row=next((x for x in obj['accounts'] if x['account_id']==account_id),None)
        if row is None: raise RegistryError('unknown account_id')
        if not str(name).strip(): raise RegistryError('account name required')
        if not str(account_type).strip(): raise RegistryError('account_type required')
        if not str(currency).strip(): raise RegistryError('currency required')
        row['name']=str(name).strip(); row['account_type']=str(account_type).strip().upper(); row['currency']=str(currency).strip().upper()
        if owner_profile is not None:
            owner=str(owner_profile or 'UNSPECIFIED').strip().upper()
            if owner not in {'UNSPECIFIED','PF','PJ'}: raise RegistryError('invalid owner_profile')
            row['owner_profile']=owner
        if pricing_plan is not _PLAN_UNSET: row['pricing_plan']=_pricing_plan(pricing_plan)
        self._save(obj); return AccountRegistration(**row)

    def list_institutions(self): return [Institution(**x) for x in self._load()["institutions"]]
    def list_accounts(self): return [AccountRegistration(**x) for x in self._load()["accounts"]]
