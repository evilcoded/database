"""Read-only operational visibility. Never emits or promotes investment decisions."""
import datetime as dt,json
from decimal import Decimal,InvalidOperation
from pathlib import Path
from .explicit_market_bindings_a24 import local,load,text
SCHEMA='porquinho.monitor-consolidation-a24/1.0'

def instant(value):
 try:
  result=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
  return result.astimezone(dt.timezone.utc) if result.tzinfo and result.utcoffset() is not None else None
 except (ValueError,TypeError,AttributeError):return None

def stamp(value,now):
 t=instant(value)
 return {'at':t.isoformat() if t else None,'age_seconds':max(0,int((now-t).total_seconds())) if t and t<=now else None,'time_status':'FUTURE' if t and t>now else 'PRESENT' if t else 'UNKNOWN'}

def context(row):
 iid=row.get('canonical_instrument_id') or row.get('instrument_id');aid=row.get('account_id');reference=row.get('account_reference')
 nested=reference.get('value') if isinstance(reference,dict) else None
 if aid and nested and aid!=nested:return None
 if not aid:aid=nested
 q=row.get('currency')
 if not all(text(x) for x in (iid,aid,q)) or not q.isascii() or not q.isalpha() or not q.isupper():return None
 if row.get('canonical_instrument_id') and row.get('instrument_id') and row['canonical_instrument_id']!=row['instrument_id']:return None
 return iid,aid,q

def project(positions,bindings,observations,*,canonical_reason):
 def nonzero(pos):
  quantity=pos.get('quantity')
  if quantity is None:return True
  try:return Decimal(str(quantity))!=0
  except (InvalidOperation,ValueError):return True
 positions=[pos for pos in positions if nonzero(pos)]
 counts={};keys={}
 for pos in positions:
  key=context(pos)
  if key:keys[key]=keys.get(key,0)+1
 rows=[]
 for pos in positions:
  quantity=pos.get('quantity')
  if quantity is not None:
   try:
    if Decimal(str(quantity)).is_finite() and Decimal(str(quantity))==0:continue
   except (InvalidOperation,ValueError):pass
  key=context(pos);row={'instrument_id':key[0] if key else None,'account_id':key[1] if key else None,'currency':key[2] if key else None,
   'canonical_status':'UNAVAILABLE','canonical_reason':canonical_reason,'execution_authorized':False,'recommendation':None}
  if not key:row.update(identity_status='INCOMPLETE_OR_CONFLICTING',research_status='IDENTITY_CONTEXT_REQUIRED')
  elif keys[key]!=1:row.update(identity_status='DUPLICATE_CONTEXT',research_status='AMBIGUOUS_POSITION_CONTEXT')
  else:
   row['identity_status']='EXACT_POSITION_CONTEXT'
   sources=[b for b in bindings if (b['instrument_id'],b['quote_currency'])==(key[0],key[2])]
   if not sources:row['research_status']='EXPLICIT_SOURCE_BINDING_REQUIRED'
   elif len(sources)!=1:row['research_status']='SOURCE_SELECTION_REQUIRED'
   else:
    b=sources[0];quotes=[q for q in observations if (q['instrument_id'],q['provider'].lower(),q['provider_id'],q['quote_currency'])==(key[0],b['provider'].lower(),b['provider_id'],key[2])]
    row['research_status']='CAPTURE_OBSERVED_TODAY' if quotes else 'AWAITING_NORMAL_CAPTURE_TODAY'
    if quotes:row['captured_at']=max(q['fetched_at'] for q in quotes)
  counts[row['research_status']]=counts.get(row['research_status'],0)+1;rows.append(row)
 return rows,counts

def inspect(root,*,now=None,runtime_reader=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 if now.tzinfo is None or now.utcoffset() is None:raise ValueError('AWARE_TIME_REQUIRED')
 now=now.astimezone(dt.timezone.utc);root=Path(root).resolve(strict=True);issues=[]
 def document(rel):
  try:
   p=local(root,rel)
   if not p.exists():return {}
   stat=p.stat()
   if stat.st_size>64*1024*1024:raise ValueError('SIZE_LIMIT')
   value=json.loads(p.read_bytes())
   if p.stat().st_mtime_ns!=stat.st_mtime_ns or p.stat().st_size!=stat.st_size:raise ValueError('CHANGED_DURING_READ')
   if not isinstance(value,dict):raise ValueError('MAPPING_REQUIRED')
   return value
  except Exception as exc:issues.append({'source':rel,'error_type':type(exc).__name__});return {}
 health=document('results/auto_cycle_health.json');snapshot=document('results/latest.json');lab=document('results/prediction_lab.json')
 from .universal_runtime_composition import contract_payload
 contract=contract_payload();reason='SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS' if contract.get('canonical_recommendation_snapshots_expected')==0 and contract.get('runtime_wiring') is False else 'CANONICAL_CONTRACT_REQUIRES_REVIEW'
 registry_ok=journal_ok=positions_ok=False;bindings=[];observations=[];positions=[]
 try:bindings=load(root)['bindings'];registry_ok=True
 except Exception as exc:issues.append({'source':'explicit_bindings','error_type':type(exc).__name__})
 try:
  from .research_quote_acquisition_a24 import read_records
  observations=read_records(root,day=now.date());journal_ok=True
 except Exception as exc:issues.append({'source':'daily_research_journal','error_type':type(exc).__name__})
 try:
  if runtime_reader is None:
   from .canonical_runtime_read_model import build
   runtime_reader=build
  runtime=runtime_reader(root)
  if runtime.get('authority')!='NONE' or runtime.get('ledger_write') is not False:raise ValueError('READ_MODEL_CONTRACT_REQUIRED')
  positions=runtime['positions']
  if not isinstance(positions,(list,tuple)) or any(not isinstance(p,dict) for p in positions):raise ValueError('POSITIONS_REQUIRED')
  positions_ok=True
 except Exception as exc:positions=[];issues.append({'source':'runtime_positions','error_type':type(exc).__name__})
 rows,counts=project(positions,bindings,observations,canonical_reason=reason)
 if not registry_ok or not journal_ok:
  for row in rows:row['research_status']='SOURCE_INSPECTION_UNAVAILABLE'
  counts={'SOURCE_INSPECTION_UNAVAILABLE':len(rows)} if rows else {}
 heartbeat=stamp(health.get('at'),now);snapshot_time=stamp(snapshot.get('timestamp',snapshot.get('generated_at')),now);model_time=stamp(lab.get('trained_at'),now)
 raw_contract=lab.get('input_contract');global_reader=bool(isinstance(raw_contract,dict) and raw_contract.get('schema')=='porquinho.global-market-reader-a24/1.0' and raw_contract.get('historical_row_attestation') is False and raw_contract.get('canonical_publication_authorized') is False)
 return {'schema':SCHEMA,'status':'PARTIAL_READ_ONLY_OBSERVATION' if issues else 'READ_ONLY_OBSERVATION','observed_at':now.isoformat(),
  'monitor':{'heartbeat':heartbeat,'heartbeat_recent':heartbeat['age_seconds'] is not None and heartbeat['age_seconds']<=1800,'state':health.get('state') if health.get('state') in ('WAITING_FOR_CURRENT_WORKER','WAITING_FOR_CADENCE','REFRESH_QUEUED','SCHEDULER_ERROR') else 'UNKNOWN','snapshot':snapshot_time},
  'brain':{'lab_result':model_time,'global_reader_contract_present':global_reader,'model_certified':False},
  'research_capture':{'day_utc':now.date().isoformat(),'binding_count':len(bindings) if registry_ok else None,'verified_records_today':len(observations) if journal_ok else None,'status':'PRESENT' if observations and journal_ok else 'NO_RECORDS_TODAY' if journal_ok else 'INSPECTION_UNAVAILABLE','sampling':'FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE'},
  'canonical':{'status':'UNAVAILABLE','reason':reason,'recommendation':None,'execution_authorized':False},'position_inspection_available':positions_ok,'positions':rows,'position_research_counts':counts,'issues':issues,
  'financial_mutation':False,'history_write_performed':False,'execution_authorized':False,'canonical_publication_authorized':False}
