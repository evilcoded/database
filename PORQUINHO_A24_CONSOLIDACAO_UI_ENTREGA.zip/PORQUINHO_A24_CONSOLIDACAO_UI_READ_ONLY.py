import sys,os,json
from pathlib import Path
root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root))
def guard(event,args):
 if event=='open':
  mode,flags=args[1:3]
  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
 if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
sys.addaudithook(guard)
try:
 from universal_portfolio.monitor_consolidation_a24 import inspect
 data=inspect(root)
 print(json.dumps({'validation':'A24_POSITION_CONSOLIDATION_READ_ONLY','status':data['status'],'monitor':data['monitor'],'brain':data['brain'],
  'research_capture':data['research_capture'],'position_research_counts':data['position_research_counts'],'canonical':data['canonical'],'issues':data['issues'],
  'runtime_activation_proven':False,'history_write_performed':False,'financial_mutation':False},indent=2))
except Exception as exc:print(json.dumps({'validation':'A24_POSITION_CONSOLIDATION_READ_ONLY','status':'INSPECTION_NOT_COMPLETED','error_type':type(exc).__name__,'history_write_performed':False,'financial_mutation':False},indent=2))
