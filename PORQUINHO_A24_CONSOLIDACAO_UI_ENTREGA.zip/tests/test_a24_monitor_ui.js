const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(process.argv[2]||require('path').join(__dirname,'../static/app.js'),'utf8');
const marker='/* A24_POSITION_MONITOR_VISIBILITY';const code=source.slice(source.indexOf(marker));
let calls=[],oldBadge='<span>SEM DECISÃO CANÔNICA</span>';
const context={console,Date,Number,JSON,Set,lastStatus:{},v366252Instruction:row=>({text:row.action}),document:{getElementById:()=>null},esc:s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x])),jsonFetch:async url=>{calls.push(url);return {schema:'porquinho.monitor-consolidation-a24/1.0',positions:[],canonical:{reason:'SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS'}}},v366252ActionBadge:()=>oldBadge,renderPortfolioView:()=>{return context.v366252ActionBadge({})}};
vm.createContext(context);vm.runInContext(code,context);let count=0;
function run(expr){return vm.runInContext(expr,context)}
function test(name,fn){fn();count++;console.log('PASS '+name)}
const data={schema:'porquinho.monitor-consolidation-a24/1.0',monitor:{heartbeat:{at:'2026-10-16T10:00:00Z'},heartbeat_recent:true,state:'WAITING_FOR_CADENCE',snapshot:{at:'2026-10-16T09:59:00Z'}},brain:{lab_result:{at:'2026-10-16T09:58:00Z'},global_reader_contract_present:true},research_capture:{verified_records_today:12,day_utc:'2026-10-16'},canonical:{reason:'SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS'},positions:[{instrument_id:'EXACT:ID',account_id:'account',currency:'BRL',research_status:'CAPTURE_OBSERVED_TODAY'}]};
function setData(value){context.fixture=value;run('a24MonitorData=fixture;a24MonitorFailed=false')}
setData(data);
test('canonical badge preserved',()=>assert.equal(run('v366252ActionBadge({})'),oldBadge));
test('monitor and canonical availability separate',()=>{const html=run('a24MonitorPanel()');assert.ok(html.includes('ainda não está integrada'));assert.ok(html.includes('12'));assert.ok(!html.includes('recomendação disponível'))});
test('exact identity account quote matches',()=>assert.ok(run("a24MonitorRowMessage(['EXACT:ID','account','BRL'])").includes('registrada hoje')));
test('different account rejected',()=>assert.ok(run("a24MonitorRowMessage(['EXACT:ID','other','BRL'])").includes('não confirmada')));
test('different currency rejected',()=>assert.ok(run("a24MonitorRowMessage(['EXACT:ID','account','EUR'])").includes('não confirmada')));
test('different identity rejected despite same asset label',()=>assert.ok(run("a24MonitorRowMessage(['OTHER:ID','account','BRL'])").includes('não confirmada')));
test('missing identity not guessed from symbol',()=>assert.equal(run("a24MonitorKey({asset:'BTC',account_id:'account',currency:'BRL'})"),null));
test('target zero is not a sell recommendation',()=>assert.ok(run('a24MonitorPanel()').includes('alvo de 0% não é ordem de venda')));
test('capture is not an execution quote',()=>assert.ok(run('a24MonitorPanel()').includes('não é cotação de execução')));
test('scheduler error is visible despite recent heartbeat',()=>assert.ok(run("a24MonitorHealthText({state:'SCHEDULER_ERROR',heartbeat_recent:true})").includes('falha')));
test('html input escaped',()=>{const copy=JSON.parse(JSON.stringify(data));copy.research_capture.day_utc='<img onerror=bad()>';setData(copy);assert.ok(!run('a24MonitorPanel()').includes('<img'));setData(data)});
test('duplicate contexts not chosen',()=>{const copy=JSON.parse(JSON.stringify(data));copy.positions.push(copy.positions[0]);setData(copy);assert.ok(run("a24MonitorRowMessage(['EXACT:ID','account','BRL'])").includes('não confirmada'));setData(data)});
test('unavailable diagnostic is explicit',()=>{run('a24MonitorFailed=true');assert.ok(run('a24MonitorRowMessage(null)').includes('indisponível'));run('a24MonitorFailed=false')});
test('row notices stay scoped to portfolio rendering',()=>{const html=run('renderPortfolioView()');assert.ok(html.startsWith(oldBadge));assert.ok(html.includes('data-a24-position-context'));assert.equal(run('v366252ActionBadge({})'),oldBadge)});
test('legacy sell text is blocked without canonical publication',()=>{const x=run("v366252Instruction({action:'VENDA',execution_state:'EXECUTE'})");assert.equal(x.text,'RECOMENDAÇÃO INDISPONÍVEL');assert.equal(x.pulse,'')});
test('canonical instruction uses published action rather than conflicting legacy action',()=>{run("lastStatus={canonical_decision_availability:{status:'AVAILABLE',canonical:{authority:'CANONICAL_RECOMMENDATION',instrument_ref:'EXACT:ID',account_id:'account',currency:'BRL',action:'KEEP'}}}");assert.equal(run("v366252Instruction({instrument_id:'EXACT:ID',account_id:'account',currency:'BRL',action:'VENDA'}).text"),'KEEP');run('lastStatus={}')});
(async()=>{await new Promise(resolve=>setImmediate(resolve));calls=[];run('a24MonitorAttempt=0');await run('a24FetchMonitor()');assert.deepEqual(calls,['/api/research/monitor-consolidation']);count++;console.log('PASS single GET only');await run('a24FetchMonitor()');assert.equal(calls.length,1);count++;console.log('PASS existing render cadence throttled');console.log('UI_TESTS_PASSED='+count)})().catch(e=>{console.error(e);process.exitCode=1});
