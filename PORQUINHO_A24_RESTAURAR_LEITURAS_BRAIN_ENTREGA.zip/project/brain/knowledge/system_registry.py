from pathlib import Path
import json, hashlib, time
SCHEMA="porquinho.system-knowledge-registry/1.0"

class SystemKnowledgeRegistry:
    """Descriptive system architecture knowledge; never mutates production code."""
    def __init__(self, root):
        self.root=Path(root)
        self.path=self.root/"data/brain/system_knowledge/registry.json"

    def _hash(self, rel):
        p=self.root/rel
        return hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() and p.is_file() else None

    def _components(self):
        return [
          {"id":"institution_account_authority","aliases":["contas","bancos","conta","banco","instituicao","instituicoes","cadastro de contas","cadastro de bancos","contas e bancos","onboarding de contas","reconciliacao de posicoes","vincular ativo a conta","editar conta","editar banco","editar instituicao","bandeira da conta","logo do banco","branding bancario","layout de contas","cartoes de bancos","cards de contas","duas colunas","vincular posicao na conta"],"role":"Universal institution/account identity authority","code":["universal_portfolio/institution_accounts.py","webapp/br_equity_position_api_v38264.py"],"ui":["templates/index.html","static/app.js","static/app.css"],"data":["data/institution_accounts.json"],"authority":"InstitutionAccountRegistry","limits":["identity authority, not balance/position authority","no automatic execution"]},
          {"id":"legacy_account_metadata","aliases":["metadados de conta","contas legadas","identidade de conta legada"],"role":"Legacy account identity metadata retained without inferred migration","code":[],"ui":["static/app.js"],"data":["data/account_entities.json"],"authority":"IDENTITY_METADATA_ONLY","limits":["not financial authority","do not auto-migrate"]},
          {"id":"position_domain","aliases":["posicao","posicoes","carteira","ativos em carteira","acao brasileira","acoes brasileiras","posicao b3","posicoes b3"],"role":"Universal position contract with verified-source adapters","code":["universal_portfolio/contracts.py","unified/br_equity_position_registration.py","unified/br_equity_position_adapter.py"],"ui":["templates/index.html","static/app.js"],"data":["data/br_equity_positions/manual_positions.json"],"authority":"universal_portfolio.contracts.Position","limits":["no invented positions","missing means unavailable, not empty","BR REALIZE disabled until specialized realization contract"]},
          {"id":"universal_instrument_catalog","aliases":["catalogo universal","catálogo universal","catalogo de ativos","catálogo de ativos","instrumentos conhecidos","ativos conhecidos","onde os instrumentos são armazenados","onde os instrumentos sao armazenados","onde ficam os instrumentos","classificação explícita de instrumentos","classificacao explicita de instrumentos","como diferencia ação etf e bdr","como diferencia acao etf e bdr","ETF","BDR","cadastro manual de instrumento","instrumento manual"],"role":"Universal reusable instrument identity/reference catalog with explicit classification and manual identity registration; never ownership","code":["unified/universal_instrument_catalog.py","unified/manual_instrument_registry.py","webapp/universal_instrument_catalog_api_v38270.py"],"ui":["static/app.js","static/app.css"],"data":["data/unified_instrument_identity_contract.json","data/instruments/classification_registry.json","data/instruments/manual_instruments.json"],"authority":"UNIVERSAL_INSTRUMENT_IDENTITY_REFERENCE + EXPLICIT_CLASSIFICATION_REGISTRY + EXPLICIT_USER_INSTRUMENT_IDENTITY","limits":["known instrument is not owned position","symbol is not global identity","no ticker suffix classification","classification requires explicit evidence","manual identity requires jurisdiction+market+asset_class+symbol+currency+provenance","fixed-income learning ledger is not instrument authority","fixed-income explicit product identity may omit ticker","fixed-income position terms remain separate from catalog identity","Ativos is universal instrument onboarding surface","no execution or scoring","missing identity remains unavailable"]},
          {"id":"instrument_identity","aliases":["ativo","ativos","instrumento","instrumentos","identidade do ativo","ticker"],"role":"Universal instrument identity; symbol is display key, not global identity","code":["unified/br_equity_market_adapter.py"],"ui":["static/app.js"],"data":["data/unified_instrument_identity_contract.json"],"authority":"unified instrument identity contract","limits":["no ticker-suffix inference for asset class","jurisdiction+market+asset_class+symbol identity"]},
          {"id":"br_equity_intelligence","aliases":["brasil","b3","acoes brasileiras","mercado brasileiro","inteligencia b3","brain b3"],"role":"Specialized B3 equity market/features/Brain/episode/outcome pipeline","code":["unified/br_equity_market_adapter.py","unified/br_equity_feature_model.py","unified/br_equity_brain_adapter.py","unified/br_equity_episode_engine.py"],"ui":["templates/index.html","static/app.js"],"data":["data/unified_br_equity_market_latest.json","data/unified_br_equity_features_latest.json","data/br_equity_brain_experimental_latest.json"],"authority":"specialized BR equity intelligence stack","limits":["do not reuse crypto model blindly","manual execution only"]},
          {"id":"opportunity_domain","aliases":["oportunidade","oportunidades","oportunidades universais","caixa disponivel","competicao de capital"],"role":"Universal opportunity surface over specialized market models","code":[],"ui":["templates/index.html","static/app.js"],"data":[],"authority":"UNIVERSAL_OPPORTUNITY_CONTRACT_TARGET","limits":["models remain market/asset-class specialized","currency/account/cash compatibility must be explicit","cash may remain unallocated"]},
          {"id":"brain_self_diagnosis","aliases":["brain","diagnostico","reparo","corrigir erro","patch","auto diagnostico","autodiagnostico"],"role":"Evidence-first self diagnosis and controlled repair proposal flow","code":["brain/core/self_model.py","brain/diagnostics.py","brain/inspection.py","brain/repair_agent.py","brain/repair_worker.py","brain/recursive_repair_reasoner.py","brain/technical_solution_planner.py","brain/patches.py"],"ui":[],"data":["results/diagnostics.json","results/patches.json"],"authority":"PorquinhoBrain + RepairAgent + PatchRegistry","limits":["candidate/sandbox first","no autonomous production mutation","human-controlled patch application"]},
          {"id":"learning_experience","aliases":["aprendizado","aprendizagem","conhecimento do sistema","aprendizado de mercado","learning"],"role":"Learning experience separates financial learning from descriptive system knowledge","code":["brain/core/brain.py","brain/core/self_model.py","brain/knowledge/system_registry.py"],"ui":["templates/index.html","static/app.js","static/app.css"],"data":[],"authority":"PorquinhoBrain + SystemKnowledgeRegistry","limits":["system knowledge is not market evidence","install/runtime gates do not increase financial confidence","no automatic policy promotion"]},
          {"id":"porquinho_ia_experience","aliases":["porquinho ia","chat ia","conversa com brain","assistente","perguntar ao porquinho"],"role":"Conversational interface to Brain investigation, system knowledge and controlled repair flow","code":["brain/core/brain.py","brain/core/self_model.py"],"ui":["templates/index.html","static/app.js","static/app.css"],"data":[],"authority":"PorquinhoBrain","limits":["no silent production mutation","repair candidates remain human-controlled","financial confidence remains evidence-based"]},
          {"id":"transaction_domain","aliases":["transacoes","transacao","compras","vendas","realizacoes","depositos","resgates","transferencias","proventos"],"role":"Operational transaction and history domain","code":["universal_portfolio/contracts.py"],"ui":["templates/index.html","static/app.js"],"data":[],"authority":"universal_portfolio.contracts.Transaction","limits":["execution remains manual/controlled","no invented transaction semantics","ledger commit requires explicit controlled flow"]},
          {"id":"analytics_experience","aliases":["analytics","performance","risco","drawdown","contribuicao","graficos"],"role":"Quantitative investigation and portfolio performance experience","code":[],"ui":["templates/index.html","static/app.js","static/app.css"],"data":[],"authority":"READ_ONLY_ANALYTIC_PROJECTION","limits":["projection only","does not own positions","does not alter Brain decisions"]},
          {"id":"financial_import_domain","aliases":["importacao financeira","ofx","extrato","importar extrato","reconciliacao"],"role":"Financial import, review and controlled commit workflow","code":[],"ui":["templates/index.html","static/app.js"],"data":[],"authority":"FINANCIAL_IMPORT_CONTROLLED_WORKFLOW","limits":["read-only until explicit approval","unsupported/unavailable is not empty","no automatic buy/sell execution"]},
          {"id":"system_experience","aliases":["sistema","status do sistema","patch center","jobs","configuracoes"],"role":"Operational system health, diagnostics and human-controlled patch surface","code":["brain/diagnostics.py","brain/patches.py"],"ui":["templates/index.html","static/app.js"],"data":["results/patches.json"],"authority":"Diagnostics + PatchRegistry","limits":["system status is not financial evidence","patch application remains explicit","no secret values in system knowledge"]}
        ]

    def build(self):
        comps=self._components()
        for c in comps:
            c["tracked"]=[{"path":rel,"sha256":self._hash(rel)} for rel in c["code"]+c["ui"]+c["data"]]
        return {"schema":SCHEMA,"generated_at":time.time(),"principles":["NO_REGION_IS_THE_BASE","OPPORTUNITIES_UNIVERSAL_MODELS_SPECIALIZED","DESCRIPTIVE_SYSTEM_KNOWLEDGE_ONLY","NO_SECRET_VALUES_OR_CREDENTIALS","AUTONOMOUS_PRODUCTION_CODE_MUTATION_FORBIDDEN","HUMAN_CONTROLLED_PATCH_APPLICATION"],"development_objectives":{"current_analysis_visible_before_horizon_maturity":True,"programming_knowledge_for_code_self_optimization":True,"code_evolution_path":"LEARN_PROPOSE_SANDBOX_TEST_REVIEW_ROLLBACK","autonomous_production_deployment_enabled":False,"future_autonomy_requires_scoped_authorization":True},"components":comps}

    def refresh(self):
        d=self.build()
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8")
        tmp.replace(self.path)
        return d

    def load(self):
        if not self.path.exists(): return self.build()
        try:return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:return self.build()

    def verify(self):
        stale=[]
        for c in self.load().get("components",[]):
            for t in c.get("tracked",[]):
                now=self._hash(t["path"])
                if now != t.get("sha256"):
                    stale.append({"component":c["id"],"path":t["path"],"recorded":t.get("sha256"),"current":now})
        return {"schema":SCHEMA,"stale":stale,"stale_count":len(stale),"current":len(stale)==0}

    def query(self,text):
        import unicodedata
        def norm(v):
            import re
            v=v or ""
            v=re.sub(r"(?<=[a-z0-9])(?=[A-Z])"," ",v)
            v=unicodedata.normalize("NFKD",v.lower())
            v="".join(ch for ch in v if not unicodedata.combining(ch))
            for ch in "/_-.,:;()[]{}?":
                v=v.replace(ch," ")
            return " ".join(v.split())
        stop={"onde","fica","ficam","como","esta","estao","implementado","implementada","cadastro","cadastrar","registro","registrar","sistema","porquinho"}
        toks=[x for x in norm(text).split() if len(x)>2 and x not in stop]
        scored=[]
        for c in self.load().get("components",[]):
            hay=norm(json.dumps(c,ensure_ascii=False))
            authority=norm(c.get("authority",""))
            score=sum((4 if t in authority else 1) for t in toks if t in hay)
            if score: scored.append((score,c))
        scored.sort(key=lambda x:(-x[0],x[1]["id"]))
        return [c for _,c in scored[:8]]
