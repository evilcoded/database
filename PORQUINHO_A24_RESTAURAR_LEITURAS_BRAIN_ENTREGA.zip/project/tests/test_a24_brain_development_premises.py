import tempfile
import unittest
from pathlib import Path
from brain.knowledge.system_registry import SystemKnowledgeRegistry

class Premises(unittest.TestCase):
    def test_programming_self_optimization_goal_preserves_current_deployment_boundary(self):
        with tempfile.TemporaryDirectory() as folder:
            body=SystemKnowledgeRegistry(Path(folder)).build();goals=body['development_objectives']
            self.assertTrue(goals['programming_knowledge_for_code_self_optimization']);self.assertTrue(goals['current_analysis_visible_before_horizon_maturity']);self.assertFalse(goals['autonomous_production_deployment_enabled']);self.assertIn('SANDBOX',goals['code_evolution_path']);self.assertIn('ROLLBACK',goals['code_evolution_path'])
    def test_readonly_knowledge_does_not_create_or_reset_memory(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'data').mkdir();memory=root/'data/memory.sqlite3';memory.write_bytes(b'PRESERVED')
            before={str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()};SystemKnowledgeRegistry(root).build()
            self.assertEqual(before,{str(p.relative_to(root)):p.read_bytes() for p in root.rglob('*') if p.is_file()})
