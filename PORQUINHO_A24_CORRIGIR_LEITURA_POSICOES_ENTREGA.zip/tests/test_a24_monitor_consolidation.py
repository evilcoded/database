import ast,copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import monitor_consolidation_a24 as m
from universal_portfolio import research_quote_acquisition_a24 as q
from universal_portfolio import explicit_market_bindings_a24 as b
from universal_portfolio import universal_runtime_composition as composition
NOW=dt.datetime(2026,10,16,12,tzinfo=dt.timezone.utc)
IID='EXACT:GLOBAL:IDENTITY'
class Monitor(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve()
 def position(self,**kw):
  row={'instrument_id':IID,'account_id':'account','currency':'BRL','quantity':'1'};row.update(kw);return row
 def binding(self,**kw):
  row={'instrument_id':IID,'provider':'CoinGecko','provider_id':'exact-id','quote_currency':'BRL'};row.update(kw);return row
 def observation(self,**kw):
  row={**self.binding(),'fetched_at':NOW.isoformat()};row.update(kw);return row
 def project(self,positions=None,bindings=None,observations=None):return m.project(positions or [self.position()],bindings or [],observations or [],canonical_reason='SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS')
 def inspect(self,**kw):
  return m.inspect(self.root,now=NOW,runtime_reader=kw.pop('runtime_reader',lambda root:{'positions':[self.position()],'authority':'NONE','ledger_write':False}),**kw)
 def write(self,rel,obj):
  p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj));return p
 def test_active_heartbeat_never_creates_canonical_decision(self):
  self.write('results/auto_cycle_health.json',{'at':NOW.isoformat(),'state':'REFRESH_QUEUED'});out=self.inspect();self.assertTrue(out['monitor']['heartbeat_recent']);self.assertEqual(out['canonical']['status'],'UNAVAILABLE');self.assertIsNone(out['canonical']['recommendation'])
 def test_exact_source_quote_matches(self):
  rows,_=self.project(bindings=[self.binding()],observations=[self.observation()]);self.assertEqual(rows[0]['research_status'],'CAPTURE_OBSERVED_TODAY');self.assertFalse(rows[0]['execution_authorized'])
 def test_same_symbol_different_id_not_joined(self):
  rows,_=self.project(bindings=[self.binding(instrument_id='OTHER:IDENTITY')],observations=[self.observation(instrument_id='OTHER:IDENTITY')]);self.assertEqual(rows[0]['research_status'],'EXPLICIT_SOURCE_BINDING_REQUIRED')
 def test_wrong_currency_not_joined(self):
  rows,_=self.project(bindings=[self.binding(quote_currency='EUR')],observations=[self.observation(quote_currency='EUR')]);self.assertEqual(rows[0]['research_status'],'EXPLICIT_SOURCE_BINDING_REQUIRED')
 def test_binding_without_capture_is_waiting(self):
  rows,_=self.project(bindings=[self.binding()]);self.assertEqual(rows[0]['research_status'],'AWAITING_NORMAL_CAPTURE_TODAY')
 def test_other_provider_capture_not_substituted(self):
  rows,_=self.project(bindings=[self.binding()],observations=[self.observation(provider='Other')]);self.assertEqual(rows[0]['research_status'],'AWAITING_NORMAL_CAPTURE_TODAY')
 def test_missing_account_never_inferred_from_position_name(self):
  rows,_=self.project(positions=[self.position(account_id=None,account='Friendly name')]);self.assertEqual(rows[0]['identity_status'],'INCOMPLETE_OR_CONFLICTING')
 def test_nested_explicit_account_reference_supported(self):
  rows,_=self.project(positions=[self.position(account_id=None,account_reference={'value':'account'})]);self.assertEqual(rows[0]['account_id'],'account')
 def test_conflicting_account_reference_not_selected(self):
  rows,_=self.project(positions=[self.position(account_reference={'value':'other'})]);self.assertEqual(rows[0]['identity_status'],'INCOMPLETE_OR_CONFLICTING')
 def test_duplicate_position_context_not_arbitrarily_selected(self):
  rows,_=self.project(positions=[self.position(),self.position()]);self.assertTrue(all(r['research_status']=='AMBIGUOUS_POSITION_CONTEXT' for r in rows))
 def test_multiple_sources_require_selection(self):
  rows,_=self.project(bindings=[self.binding(),self.binding(provider='Other')]);self.assertEqual(rows[0]['research_status'],'SOURCE_SELECTION_REQUIRED')
 def test_stale_and_future_heartbeats_not_recent(self):
  for when in (NOW-dt.timedelta(hours=1),NOW+dt.timedelta(seconds=5)):
   self.write('results/auto_cycle_health.json',{'at':when.isoformat()});self.assertFalse(self.inspect()['monitor']['heartbeat_recent'])
 def test_no_snapshot_or_model_timestamp_invented(self):
  out=self.inspect();self.assertIsNone(out['monitor']['snapshot']['at']);self.assertIsNone(out['brain']['lab_result']['at'])
 def test_partial_journal_inspection_preserves_other_sections(self):
  self.write('results/latest.json',{'timestamp':NOW.isoformat()})
  with patch.object(q,'read_records',side_effect=ValueError('corrupt')):out=self.inspect()
  self.assertEqual(out['status'],'PARTIAL_READ_ONLY_OBSERVATION');self.assertIsNone(out['research_capture']['verified_records_today']);self.assertEqual(out['positions'][0]['research_status'],'SOURCE_INSPECTION_UNAVAILABLE');self.assertIsNotNone(out['monitor']['snapshot']['at'])
 def test_runtime_failure_does_not_fallback_to_legacy_positions(self):
  self.write('results/latest.json',{'scores':[{'asset':'ETH','quantity':1}]})
  def broken(root):raise ValueError('unavailable')
  out=self.inspect(runtime_reader=broken);self.assertEqual(out['positions'],[]);self.assertFalse(out['position_inspection_available'])
 def test_changed_runtime_contract_does_not_unblock_canonical(self):
  with patch.object(composition,'contract_payload',return_value={'runtime_wiring':True,'canonical_recommendation_snapshots_expected':1}):out=self.inspect()
  self.assertEqual(out['canonical']['reason'],'CANONICAL_CONTRACT_REQUIRES_REVIEW');self.assertEqual(out['canonical']['status'],'UNAVAILABLE')
 def test_read_does_not_write_or_make_network_calls(self):
  p=self.write('results/latest.json',{'timestamp':NOW.isoformat(),'price_eur':100});before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  with patch('socket.socket.connect',side_effect=AssertionError('network')),patch('subprocess.Popen',side_effect=AssertionError('process')):out=self.inspect()
  self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()});self.assertFalse(out['history_write_performed']);self.assertNotIn('price_eur',json.dumps(out))
 def test_get_only_actual_route(self):
  from flask import Flask,jsonify
  source=Path(__file__).resolve().parents[1]/'webapp/server.py';node=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='a24_monitor_consolidation');app=Flask('monitor');exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_route','exec'),{'app':app,'jsonify':jsonify,'ROOT':self.root})
  with patch.object(m,'inspect',return_value={'schema':m.SCHEMA,'execution_authorized':False}):
   client=app.test_client();self.assertEqual(client.get('/api/research/monitor-consolidation').status_code,200);self.assertEqual(client.post('/api/research/monitor-consolidation').status_code,405)
 def test_capture_clock_is_current_utc_day(self):
  with patch.object(q,'read_records',return_value=[]) as read:self.inspect()
  self.assertEqual(read.call_args.kwargs['day'],NOW.date())
 def test_arbitrary_currency_and_no_financial_values_projected(self):
  rows,_=self.project(positions=[self.position(currency='JPY',principal='999',current_value='1000')],bindings=[self.binding(quote_currency='JPY')],observations=[self.observation(quote_currency='JPY',price='1')]);self.assertEqual(rows[0]['research_status'],'CAPTURE_OBSERVED_TODAY');self.assertNotIn('999',json.dumps(rows));self.assertNotIn('"price"',json.dumps(rows))

 def test_actual_daily_journal_count_and_exact_position_are_read_only(self):
  import test_a24_research_quote_acquisition as f
  fixture=f.Acquisition();fixture.setUp();self.addCleanup(fixture.doCleanups);fixture.save([fixture.rows()]);fixture.collect()
  root=fixture.root;before={p:p.read_bytes() for p in root.rglob('*') if p.is_file()}
  out=m.inspect(root,now=f.NOW,runtime_reader=lambda root:{'positions':[{'instrument_id':f.IID,'account_id':'account-BRL','currency':'BRL','quantity':'1'}],'authority':'NONE','ledger_write':False})
  self.assertEqual(out['research_capture']['verified_records_today'],1);self.assertEqual(out['positions'][0]['research_status'],'CAPTURE_OBSERVED_TODAY');self.assertEqual(before,{p:p.read_bytes() for p in root.rglob('*') if p.is_file()})

 def test_closed_zero_position_does_not_make_active_context_ambiguous(self):
  rows,_=self.project(positions=[self.position(),self.position(quantity='0')]);self.assertEqual(len(rows),1);self.assertEqual(rows[0]['identity_status'],'EXACT_POSITION_CONTEXT')

 def seeded(self,**kw):
  from universal_portfolio.opening_seeded_derivation import SeededPosition
  row={'account_reference':'account','account_status':'CANONICAL_POSITION_IDENTITY_BINDING','portfolio_id':'portfolio','instrument_id':IID,'currency':'BRL','quantity':'1','cost_basis':'100','principal':None};row.update(kw);return SeededPosition(**row)
 def test_actual_seeded_position_dataclass_shape_is_supported(self):
  out=self.inspect(runtime_reader=lambda root:{'positions':(self.seeded(),),'authority':'NONE','ledger_write':False});self.assertTrue(out['position_inspection_available']);self.assertFalse(any(x['source']=='runtime_positions' for x in out['issues']));self.assertEqual(out['positions'][0]['account_id'],'account')
 def test_canonical_string_account_reference_is_preserved_exactly(self):
  values=m.position_records([self.seeded(account_reference='exact-account')]);self.assertEqual(m.context(values[0]),(IID,'exact-account','BRL'))
 def test_unresolved_account_label_is_not_promoted(self):
  values=m.position_records([self.seeded(account_reference='Friendly bank',account_status='UNRESOLVED')]);self.assertIsNone(m.context(values[0]))
 def test_mixed_explicit_dict_and_seeded_records(self):
  values=m.position_records([self.position(),self.seeded(account_reference='other-account')]);self.assertEqual(len(values),2);self.assertEqual(m.context(values[1])[1],'other-account')
 def test_unknown_dataclass_is_refused_not_guessed(self):
  from dataclasses import dataclass
  @dataclass
  class Other:
   instrument_id:str=IID
  with self.assertRaisesRegex(ValueError,'UNSUPPORTED_POSITION_RECORD'):m.position_records([Other()])
 def test_seeded_and_mapping_sources_not_mutated_or_financial_values_exported(self):
  from dataclasses import asdict
  seeded=self.seeded();mapped=self.position(account_id=None,account_reference='account',account_status='CANONICAL_POSITION_IDENTITY_BINDING');before=copy.deepcopy(mapped)
  normalized=m.position_records([seeded,mapped]);m.project(normalized,[],[],canonical_reason='SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS');self.assertEqual(mapped,before);self.assertEqual(asdict(seeded)['account_reference'],'account');out=self.inspect(runtime_reader=lambda root:{'positions':(seeded,),'authority':'NONE','ledger_write':False});self.assertNotIn('cost_basis',json.dumps(out));self.assertNotIn('principal',json.dumps(out))
