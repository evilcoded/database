"""Global quote/identity transport; synthetic data and temporary journals only."""
import ast
import datetime as dt
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import numpy as np
import pandas as pd
from brain.evolution.global_market_frame_a24 import prepare
from brain.evolution import prediction_lab as lab
from brain.evolution import p35e_prospective_issuance as issuance
from brain.evolution import p35h_capture_provenance as provenance
from brain.evolution.p35f_outcome_reconciliation import read_journal, inspect, JOURNAL

ROOT=Path(__file__).resolve().parents[1]

def source_frame(iid='global:a', quote='USD', provider_id='source-a', n=210):
    i=np.arange(n)
    return pd.DataFrame({'date':pd.date_range('2025-01-01',periods=n),
      'asset':'SAME','price':100*np.exp(.001*i+.03*np.sin(i/8)),
      'volume':10000+i*2,'market_cap':1000000+i*100,
      'instrument_id':iid,'provider':'Provider','provider_id':provider_id,
      'quote_currency':quote,'identity_source_ref':'explicit-test-binding'})

def fetch_function(mock):
    tree=ast.parse((ROOT/'tools/fetch_history.py').read_text())
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fetch_daily')
    ns={'pd':pd,'_get':mock}
    exec(compile(ast.Module(body=[node],type_ignores=[]),'fetch_daily','exec'),ns)
    return ns['fetch_daily']

def result(predictions):
    return {'status':'OK','target':'forward_30d_return_pct',
            'champion':{'algorithm':'Ridge'},'predictions':predictions}

class GlobalIdentityTests(unittest.TestCase):
    def test_source_frame_is_unchanged(self):
        raw=source_frame();before=raw.copy(deep=True);lab._features(raw)
        pd.testing.assert_frame_equal(raw,before)

    def test_same_symbol_distinct_instruments_do_not_mix_targets(self):
        a=source_frame();b=source_frame('global:b','JPY','source-b');b['price']*=100
        x,_=lab._features(pd.concat([a,b],ignore_index=True))
        self.assertEqual(x['_a24_series_key'].nunique(),2)
        for iid in ['global:a','global:b']:
            row=x[(x.instrument_id==iid)&(x.date==pd.Timestamp('2025-03-01'))].iloc[0]
            raw=a if iid=='global:a' else b
            expected=(raw.iloc[89].price/raw.iloc[59].price-1)*100
            self.assertAlmostEqual(row.forward_30d,expected)
            self.assertEqual(row.target_maturity_date,pd.Timestamp('2025-03-31'))

    def test_same_identity_different_quotes_are_separate_series(self):
        a=source_frame();b=source_frame(quote='JPY');b.price*=140
        x=prepare(pd.concat([a,b],ignore_index=True))
        self.assertEqual(x['_a24_series_key'].nunique(),2)

    def test_currency_cohorts_do_not_change_each_others_features(self):
        a=source_frame();b=source_frame('global:b','JPY','source-b');b.price=np.exp(np.arange(len(b))*.06)
        one,f=lab._features(a);both,_=lab._features(pd.concat([a,b],ignore_index=True))
        other=both[both.instrument_id=='global:a']
        pd.testing.assert_frame_equal(one[f].reset_index(drop=True),other[f].reset_index(drop=True))

    def test_legacy_does_not_infer_currency_or_identity(self):
        a=source_frame().rename(columns={'price':'price_eur','volume':'volume_eur','market_cap':'market_cap_eur'})
        a=a.drop(columns=['instrument_id','provider','provider_id','quote_currency','identity_source_ref'])
        x,_=lab._features(a)
        self.assertTrue(x.instrument_id.isna().all());self.assertTrue(x.quote_currency.isna().all())
        self.assertEqual(set(x.price_unit_status),{'LEGACY_COLUMN_PRICE_UNIT_UNVERIFIED'})
        pred=lab._current_prediction(x,lab._features(a)[1],'Ridge').to_dict('records')[0]
        self.assertIsNone(pred['quote_currency']);self.assertIsNone(pred['instrument_id'])

    def test_new_metadata_never_backfills_legacy_history(self):
        a=source_frame(n=50);legacy=a.iloc[:40].copy()
        legacy=legacy.rename(columns={'price':'price_eur','volume':'volume_eur','market_cap':'market_cap_eur'})
        legacy=legacy.drop(columns=['instrument_id','provider','provider_id','quote_currency','identity_source_ref'])
        x,_=lab._features(pd.concat([legacy,a.iloc[40:]],ignore_index=True))
        self.assertTrue(x.instrument_id.isna().all()) # new series has only 10 observations, lacks mature features
        self.assertTrue(x.target_maturity_date.isna().all())

    def test_partial_origin_rejected(self):
        a=source_frame();a.loc[0,'quote_currency']=None
        with self.assertRaisesRegex(ValueError,'PARTIAL'):prepare(a)

    def test_neutral_price_without_origin_rejected(self):
        a=source_frame().drop(columns=['provider','provider_id','quote_currency'])
        with self.assertRaisesRegex(ValueError,'EXPLICIT_PROVIDER'):prepare(a)

    def test_invalid_quote_rejected(self):
        for quote in ['usd',' USD','€UR']:
            with self.subTest(quote=quote),self.assertRaises(ValueError):prepare(source_frame(quote=quote))

    def test_no_fixed_currency_whitelist(self):
        self.assertEqual(set(prepare(source_frame(quote='XAU')).quote_currency),{'XAU'})

    def test_duplicate_source_date_rejected(self):
        a=source_frame(n=2)
        with self.assertRaisesRegex(ValueError,'DUPLICATE'):prepare(pd.concat([a,a.iloc[:1]],ignore_index=True))

    def test_conflicting_provider_binding_rejected(self):
        a=source_frame(n=2);b=source_frame('global:b',n=2)
        with self.assertRaisesRegex(ValueError,'CONFLICTING_CANONICAL'):prepare(pd.concat([a,b],ignore_index=True))

    def test_current_and_ensemble_preserve_source_fields_and_purge(self):
        raw=pd.concat([source_frame(),source_frame('global:b','JPY','source-b')],ignore_index=True)
        x,f=lab._features(raw);latest,train=lab._prediction_frames(x)
        self.assertTrue((train.target_maturity_date<latest.date.min()).all())
        current=lab._current_prediction(x,f,'Ridge')
        rows=[{'algorithm':a,'mae':1,'model_score':50} for a in ['Ridge','LinearRegression','ElasticNet']]
        ensemble,names=lab._ensemble_prediction(x,f,rows)
        for predictions in (current,ensemble):
            self.assertEqual(set(predictions.instrument_id),{'global:a','global:b'})
            self.assertEqual(set(predictions.quote_currency),{'USD','JPY'})
            self.assertEqual(set(predictions.provider_id),{'source-a','source-b'})
            self.assertTrue(np.isfinite(predictions.prediction_30d_pct).all())

    def test_collector_uses_actual_quote_and_never_eur_alias_for_other_quotes(self):
        calls=[];contexts=[]
        def get(s,path,params,*args,**kw):
            calls.append((path,params));kw['provenance_sink']({'acquisition_mode':'NETWORK','fetched_at':dt.datetime.now(dt.timezone.utc).isoformat(),'cache_saved_at':None})
            return {'prices':[[1735689600000,100]],'market_caps':[[1735689600000,1000]],'total_volumes':[[1735689600000,20]]}
        fetch=fetch_function(get)
        a=fetch(None,'SAME','source-a',quote_currency='JPY',canonical_instrument_id='global:a',identity_source_ref='declared',acquisition_sink=contexts.append)
        self.assertEqual(calls[0][1]['vs_currency'],'jpy');self.assertNotIn('price_eur',a)
        self.assertEqual(a.iloc[0]['quote_currency'],'JPY');self.assertEqual(a.iloc[0]['instrument_id'],'global:a')
        self.assertEqual(contexts[0]['quote_currency'],'JPY');self.assertEqual(a.iloc[0]['price'],100)
        legacy=fetch(None,'SAME','source-a');self.assertEqual(legacy.iloc[0]['price_eur'],100)
        self.assertNotIn('instrument_id',legacy);self.assertEqual(calls[-1][1]['vs_currency'],'eur')

    def test_collector_rejects_implicit_identity_binding(self):
        fetch=fetch_function(lambda *a,**k:self.fail('network must not be requested'))
        with self.assertRaisesRegex(ValueError,'BINDING'):fetch(None,'SAME','source-a',quote_currency='USD',canonical_instrument_id='global:a')

    def test_full_acquisition_to_issuance_context_and_no_legacy_join(self):
        def get(s,path,params,*args,**kw):
            kw['provenance_sink']({'acquisition_mode':'NETWORK','fetched_at':dt.datetime.now(dt.timezone.utc).isoformat(),'cache_saved_at':None})
            data=source_frame()
            # Provider contract is milliseconds; pandas may store ns or us internally.
            ms=[(day.date()-dt.date(1970,1,1)).days*86400000 for day in pd.to_datetime(data.date)]
            return {name:list(zip(ms,data[col].tolist())) for name,col in [('prices','price'),('market_caps','market_cap'),('total_volumes','volume')]}
        raw=fetch_function(get)(None,'SAME','source-a',quote_currency='USD',canonical_instrument_id='global:a',identity_source_ref='explicit-test-binding')
        x,f=lab._features(raw);pred=lab._current_prediction(x,f,'Ridge').to_dict('records')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'results').mkdir();(root/'data/database').mkdir(parents=True);(root/'brain/evolution').mkdir(parents=True)
            # First append an old unresolved record, then confirm byte preservation.
            old=result([{'asset':'OLD','date':'2025-01-01','prediction_30d_pct':1.0}])
            issuance.capture(old,root=root);path=root/'results'/JOURNAL;before=path.read_bytes()
            raw.assign(price_eur=999).to_csv(root/'data/database/market_daily.csv',index=False)
            (root/'brain/evolution/prediction_lab.py').write_bytes((ROOT/'brain/evolution/prediction_lab.py').read_bytes())
            start=dt.datetime.now(dt.timezone.utc).isoformat();out=result(pred)
            out['p35e_capture']=issuance.capture(out,root=root)
            self.assertEqual(out['p35e_capture']['recorded'],1)
            self.assertTrue(path.read_bytes().startswith(before))
            records=read_journal(path);new=records[-1]
            for key in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref'):
                self.assertEqual(new[key],pred[0][key])
            self.assertIsNone(new['currency']);self.assertIsNone(new['account_id'])
            self.assertEqual(new['authority'],'RESEARCH_ONLY');self.assertFalse(new['independent_archive_verified'])
            self.assertEqual(issuance.capture(out,root=root)['recorded'],0)
            context=provenance.capture_context(out,root=root,started_at=start)
            self.assertEqual(context['status'],'CAPTURE_CONTEXT_RECORDED_UNATTESTED')
            body=json.loads((root/'results'/provenance.SIDE).read_text())['body']
            self.assertEqual(body['forecast_quote_context'][new['forecast_id']]['quote_currency'],'USD')
            self.assertFalse(body['account_currency_resolved'])
            item=next(r for r in inspect(root)['records'] if r['forecast_id']==new['forecast_id'])
            self.assertEqual(item['state'],'BLOCKED_SOURCE_QUOTE_RECONCILIATION_REQUIRED');self.assertIsNone(item['actual_pct'])

    def test_acquisition_fixture_preserves_dates_for_ns_and_us_storage(self):
        for unit in ('ns','us'):
            with self.subTest(unit=unit):
                data=source_frame(n=100)
                data['date']=data['date'].astype('datetime64['+unit+']')
                def get(s,path,params,*args,**kw):
                    kw['provenance_sink']({'acquisition_mode':'NETWORK'})
                    ms=[(day.date()-dt.date(1970,1,1)).days*86400000 for day in pd.to_datetime(data.date)]
                    return {name:list(zip(ms,data[col].tolist())) for name,col in [('prices','price'),('market_caps','market_cap'),('total_volumes','volume')]}
                raw=fetch_function(get)(None,'SAME','source-a',quote_currency='USD')
                self.assertEqual(raw.date.tolist(),[day.date().isoformat() for day in pd.to_datetime(data.date)])
                self.assertEqual(raw.date.nunique(),100)
                features,_=lab._features(raw)
                self.assertFalse(features.empty)

    def test_legacy_forecast_key_is_unchanged(self):
        p={'asset':'OLD','date':'2025-01-01','prediction_30d_pct':1.0}
        row=issuance._rows(result([p]),'2026-10-15T00:00:00+00:00')[0]
        key={'asset_id':'OLD','observation_date':'2025-01-01','forecast_kind':'champion','model':'Ridge'}
        self.assertEqual(row['forecast_id'],hashlib.sha256(issuance._canonical(key).encode()).hexdigest())
        self.assertNotIn('quote_currency',row)

    def test_forecast_keys_distinguish_quotes_and_provider(self):
        p={'asset':'SAME','date':'2025-01-01','prediction_30d_pct':1.0,'provider':'Provider','provider_id':'a','quote_currency':'USD'}
        rows=issuance._rows(result([p,dict(p,quote_currency='JPY'),dict(p,provider_id='b')]),'2026-10-15T00:00:00+00:00')
        self.assertEqual(len({r['forecast_id'] for r in rows}),3)

    def test_partial_forecast_metadata_cannot_be_downgraded(self):
        p={'asset':'SAME','date':'2025-01-01','prediction_30d_pct':1.0,'provider':'Provider'}
        self.assertEqual(issuance._rows(result([p]),'2026-10-15T00:00:00+00:00'),[])

if __name__=='__main__':unittest.main()
