from __future__ import annotations
import json,time,os,hashlib
from pathlib import Path
from datetime import datetime,timezone,timedelta
import requests,pandas as pd
import sys
# V3829R18_CANONICAL_RUNTIME_ALIGNMENT
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
# R21.9_INCIDENT_CACHE_ROOT_FIX
# Runtime paths must exist regardless of whether ROOT was already present in sys.path.
DB=ROOT/'data'/'database'
CACHE=ROOT/'cache'/'history_api'
CACHE.mkdir(parents=True,exist_ok=True)
DB.mkdir(parents=True,exist_ok=True)
BASE='https://api.coingecko.com/api/v3'
def _session():
 s=requests.Session(); s.headers.update({'accept':'application/json','user-agent':'Porquinho-History/3.2.4'}); key=os.getenv('COINGECKO_API_KEY');
 if key:s.headers['x-cg-demo-api-key']=key
 return s
# V3829R13_COINGECKO_RATE_LIMIT_RESILIENCE
# V3829R25_DEADLINE_AWARE_RETRY_CONTRACT
class DeadlineBudgetExceeded(RuntimeError):
    pass

class RateLimitedError(RuntimeError):
 pass

def _get(s,path,params,wait=1.2,max_attempts=3,deadline=None,provenance_sink=None):
 key=path.replace('/','_')+'_'+json.dumps(params,sort_keys=True); cf=CACHE/(hashlib.sha1(key.encode()).hexdigest()+'.json')
 if cf.exists():
  try:
   j=json.loads(cf.read_text())
   if time.time()-j.get('saved_at',0)<21600:
    if provenance_sink is not None:
          saved=j.get('saved_at')
          try:
           if isinstance(saved,bool) or not isinstance(saved,(int,float)) or not (0 < float(saved) < time.time()+60): raise ValueError('INVALID_CACHE_TIMESTAMP')
           cache_origin=datetime.fromtimestamp(float(saved),timezone.utc).isoformat()
          except (ValueError,TypeError,OverflowError,OSError):
           cache_origin=None
          provenance_sink({'acquisition_mode':'CACHE','cache_saved_at':cache_origin,'fetched_at':None})
    return j['data']
  except Exception:pass
 last=None
 for attempt in range(max_attempts):
  if deadline is not None:
   remaining=deadline-time.monotonic()
   if remaining<=1.0:
    raise DeadlineBudgetExceeded('history refresh deadline reached before request')
  initial_wait=wait if attempt==0 else 0
  if initial_wait:
   if deadline is not None and time.monotonic()+initial_wait>=deadline:
    raise DeadlineBudgetExceeded('history refresh deadline reached before pacing wait')
   time.sleep(initial_wait)
  r=s.get(BASE+path,params=params,timeout=40)
  if r.status_code==429:
   last=r
   retry_after=r.headers.get('Retry-After')
   try: delay=float(retry_after) if retry_after is not None else min(4.0*(2**attempt),16.0)
   except (TypeError,ValueError): delay=min(4.0*(2**attempt),16.0)
   if attempt+1<max_attempts:
    retry_sleep=max(1.0,min(delay,30.0))
    if deadline is not None:
     remaining=deadline-time.monotonic()
     if remaining<=1.0 or retry_sleep>=max(0.0,remaining-1.0):
      raise DeadlineBudgetExceeded('history refresh deadline reached before 429 retry')
    time.sleep(retry_sleep)
    continue
   raise RateLimitedError(f'429 Too Many Requests after {max_attempts} attempts for {r.url}')
  r.raise_for_status()
  d=r.json(); acquired_at=datetime.now(timezone.utc).isoformat(); cf.write_text(json.dumps({'saved_at':time.time(),'data':d}))
  if provenance_sink is not None: provenance_sink({'acquisition_mode':'NETWORK','fetched_at':acquired_at,'cache_saved_at':None})
  return d
 raise RateLimitedError(f'429 Too Many Requests for {getattr(last,"url",BASE+path)}')
def _provider_identity_map(s,symbols):
 wanted=[]
 for value in symbols:
  symbol=str(value or "").upper().strip()
  if symbol and symbol not in wanted:wanted.append(symbol)
 if not wanted:return {}
 try:
  rows=_get(s,'/coins/list',{'include_platform':'false'},wait=.5)
 except Exception:
  return {}
 candidates={symbol:[] for symbol in wanted}
 for row in rows if isinstance(rows,list) else []:
  if not isinstance(row,dict):continue
  symbol=str(row.get('symbol') or '').upper().strip(); provider_id=str(row.get('id') or '').strip()
  if symbol in candidates and provider_id and provider_id not in candidates[symbol]:
   candidates[symbol].append(provider_id)
 return {symbol:ids[0] for symbol,ids in candidates.items() if len(ids)==1}

def _assets(s):
 from universal_portfolio.runtime_read_shadow import held_assets
 held=sorted(held_assets(ROOT))
 try:
  rows=_get(s,'/coins/markets',{'vs_currency':'eur','order':'market_cap_desc','per_page':20,'page':1,'sparkline':'false','price_change_percentage':'1d'},wait=.5)
  ids={str(x.get('symbol','')).upper():str(x.get('id') or '').strip() for x in rows if isinstance(x,dict)}
 except Exception:
  ids={}
 missing=[a for a in held if not ids.get(a)]
 ids.update(_provider_identity_map(s,missing))
 out=[]
 for a in held+[str(x).upper() for x in ids]:
  provider_id=ids.get(a)
  if provider_id and a not in [x[0] for x in out]:out.append((a,provider_id))
 return out
def _merge(path,new,keys):
 old=pd.read_csv(path) if path.exists() else pd.DataFrame()
 if old.empty:out=new.drop_duplicates(keys,keep='first')
 else:
  old2=old.copy(); new2=new.copy();
  for k in keys:old2[k]=old2[k].astype(str); new2[k]=new2[k].astype(str)
  existing=set(map(tuple,old2[keys].itertuples(index=False,name=None))); seen=set(); mask=[]
  for r in new2[keys].itertuples(index=False,name=None):keep=r not in existing and r not in seen; mask.append(keep); seen.add(r)
  out=pd.concat([old2,new2.loc[mask]],ignore_index=True)
 # A2: keep the union of existing and prospective fields; no retrospective attribution.
 # A2_PROTECTED_MARKET_WRITER_V1
 # Preserve the original CSV when a refresh adds no new dates.
 # This prevents schema churn and avoids claiming historical provenance.
 added=len(out)-len(old) if not old.empty else len(out)
 # New observations may carry genuine provider origin; legacy stays blank.
 origin=('provider','provider_id','quote_currency')
 if any(k in new.columns for k in origin):
  if not all(k in new.columns for k in origin):
   raise ValueError('FAIL_CLOSED: PARTIAL_PROVIDER_ORIGIN_COLUMNS')
  for _,r in new.iterrows():
   values=[str(r[k]).strip() if pd.notna(r[k]) else '' for k in origin]
   if any(values) and not all(values):
    raise ValueError('FAIL_CLOSED: PARTIAL_PROVIDER_ORIGIN_ROW')
   if all(values) and (len(values[2])!=3 or not values[2].isalpha() or values[2]!=values[2].upper()):
    raise ValueError('FAIL_CLOSED: INVALID_QUOTE_CURRENCY')
 if added<=0:return 0
 # A legacy observation for the same date/asset is never overwritten or
 # retrospectively attested by this collector.
 out.to_csv(path,index=False)
 return added
def fetch_daily(s,asset,cid,deadline=None,acquisition_sink=None,*,quote_currency=None,
                canonical_instrument_id=None,identity_source_ref=None):
 # A24: optional explicit global quote; old callers retain their documented request.
 legacy_call=quote_currency is None
 quote='EUR' if legacy_call else quote_currency
 if not isinstance(quote,str) or not quote.isascii() or not quote.isalpha() or not quote.isupper():
  raise ValueError('EXPLICIT_QUOTE_CURRENCY_REQUIRED')
 if canonical_instrument_id is not None:
  if (not isinstance(canonical_instrument_id,str) or not canonical_instrument_id
      or canonical_instrument_id!=canonical_instrument_id.strip()
      or not isinstance(identity_source_ref,str) or not identity_source_ref.strip()):
   raise ValueError('EXPLICIT_CANONICAL_BINDING_REFERENCE_REQUIRED')
 # P35N10B_TRANSPORT_AWARE_SHADOW_V1
 transport=[]
 d=_get(s,f'/coins/{cid}/market_chart',{'vs_currency':quote.lower(),'days':365,'interval':'daily'},1.0,provenance_sink=transport.append); p=pd.DataFrame(d.get('prices',[]),columns=['ms','price']); c=pd.DataFrame(d.get('market_caps',[]),columns=['ms','market_cap']); v=pd.DataFrame(d.get('total_volumes',[]),columns=['ms','volume']);
 if p.empty:return pd.DataFrame()
 x=p.merge(c,on='ms',how='left').merge(v,on='ms',how='left'); x['date']=pd.to_datetime(x.ms,unit='ms',utc=True).dt.date.astype(str); x['asset']=asset
 # V3829R10_PRICE_PROVENANCE_WRITER_FIX
 # Provenance is attached at acquisition time; historical rows are not retroactively inferred.
 x['source']='coingecko'
 # A2: prospective provider-origin metadata, never a canonical identity claim.
 # The provider id comes from the actual /coins/{cid}/market_chart request.
 x['provider']='CoinGecko'
 x['provider_id']=str(cid)
 x['quote_currency']=quote
 if canonical_instrument_id is not None:
  x['instrument_id']=canonical_instrument_id;x['identity_source_ref']=identity_source_ref
 # Aliases belong only to the existing legacy request, never another quote.
 if legacy_call:
  x['price_eur']=x['price'];x['market_cap_eur']=x['market_cap'];x['volume_eur']=x['volume']
 columns=['date','asset','price','market_cap','volume','source','provider','provider_id','quote_currency']
 if legacy_call:columns+=['price_eur','market_cap_eur','volume_eur']
 if canonical_instrument_id is not None:columns+=['instrument_id','identity_source_ref']
 out=x[columns]
 # P35N20B_EXPLICIT_CONTEXT_V1: caller opt-in; no persistence and no implicit capture.
 # A detached snapshot prevents the recipient from changing the market response.
 if acquisition_sink is not None:
  try:
   if not callable(acquisition_sink): raise TypeError('ACQUISITION_SINK_NOT_CALLABLE')
   if len(transport)!=1 or transport[0].get('acquisition_mode') not in ('NETWORK','CACHE'):
    raise ValueError('TRANSPORT_CONTEXT_NOT_UNIQUE')
   import copy as _p35n20b_copy
   context={'response':_p35n20b_copy.deepcopy(d),
            'transport':_p35n20b_copy.deepcopy(transport[0]),
            'provider_id':cid,'asset':asset,'quote_currency':quote,
            'endpoint':f'/coins/{cid}/market_chart',
            'request_params':{'vs_currency':quote.lower(),'days':365,'interval':'daily'}}
   acquisition_sink(context)
  except Exception as _p35n20b_exc:
   out.attrs['p35n20b_context_error']=type(_p35n20b_exc).__name__

 # Shadow only; never infer canonical identity or independent availability.
 try:
  from brain.evolution.p35n10a_market_provenance_shadow_adapter import inspect_acquisition
  meta=transport[0] if len(transport)==1 else {}
  out.attrs['p35n10b_provenance_shadow']=[inspect_acquisition(asset=asset,provider_id=cid,instrument_id=canonical_instrument_id,observation_date=str(row.date),price=float(row.price),quote_currency=quote,acquisition_mode=meta.get('acquisition_mode'),observed_at=None,fetched_at=meta.get('fetched_at'),available_at=None,cache_saved_at=meta.get('cache_saved_at'),endpoint=f'/coins/{cid}/market_chart',request_params={'vs_currency':quote.lower(),'days':365,'interval':'daily'}) for row in out.itertuples(index=False)]
  # P35N14_PROSPECTIVE_EVIDENCE_SHADOW_V1 — ephemeral; original ms, no inferred availability.
  from brain.evolution.p35n13_acquisition_evidence_contract import inspect as inspect_evidence
  if len(x)!=len(out): raise ValueError('P35N14_ROW_ALIGNMENT_MISMATCH')
  evidence=[inspect_evidence(provider='CoinGecko',provider_id=cid,asset=asset,
      quote_currency=quote,endpoint=f'/coins/{cid}/market_chart',
      request_params={'vs_currency':quote.lower(),'days':365,'interval':'daily'},
      observation_timestamp_ms=int(ms),price=float(price),
      acquisition_mode=meta.get('acquisition_mode'),fetched_at=meta.get('fetched_at'),
      cache_saved_at=meta.get('cache_saved_at'),instrument_id=canonical_instrument_id,
      observed_at=None,available_at=None)
      for ms,price in zip(x['ms'].tolist(),out['price'].tolist())]
  if any(row.get('status')!='FAIL_CLOSED' or row.get('authority')!='RESEARCH_ONLY'
      or row.get('economic_comparison_status')!='NOT_VALIDATED'
      or row.get('persisted') is not False for row in evidence):
   raise ValueError('P35N14_AUTHORITY_GUARD')
  out.attrs['p35n14_prospective_evidence_shadow']=evidence
 except Exception as exc:
  out.attrs['p35n10b_provenance_shadow_error']=type(exc).__name__
 return out
def fetch_intraday(s,asset,cid,deadline=None):
 end=datetime.now(timezone.utc); start=end-timedelta(hours=48); d=_get(s,f'/coins/{cid}/market_chart/range',{'vs_currency':'eur','from':int(start.timestamp()),'to':int(end.timestamp())},1.0,deadline=deadline); p=pd.DataFrame(d.get('prices',[]),columns=['ms','price_eur']);
 if p.empty:return pd.DataFrame()
 x=p; x['timestamp']=pd.to_datetime(x.ms,unit='ms',utc=True); x=x.set_index('timestamp')[['price_eur']].resample('10min').mean().interpolate(limit=3).ffill().bfill().reset_index(); x['asset']=asset; x['source']='coingecko_resampled_10m'; return x[['timestamp','asset','price_eur','source']]
# V3829R20_PROGRESSIVE_HISTORY_REFRESH
# V3829R23_INTRADAY_SCHEMA_BUDGET_HARDENING
def main():
 import time as _time
 s=_session(); assets=_assets(s); daily=[]; intra=[]
 report={'assets':[],'daily_added':0,'intraday_added':0,'errors':[],'fetched_at':datetime.now(timezone.utc).isoformat(),'scheduler':{'contract':'PROGRESSIVE_DAILY_FIRST_V1','daily_priority':True,'wall_clock_budget_seconds':120,'budget_semantics':'DEADLINE_AWARE_RETRY_NO_INFLIGHT_CANCEL','consecutive_429_breaker':3,'cursor_persistence':True}}
 state_path=ROOT/'brain'/'reports'/'history_refresh_scheduler.json'; state={'cursor':0}
 try:
  if state_path.exists():
   raw=json.loads(state_path.read_text(encoding='utf-8'))
   if isinstance(raw,dict): state.update(raw)
 except Exception: pass
 n=len(assets); cursor=int(state.get('cursor',0) or 0)%max(n,1); ordered=assets[cursor:]+assets[:cursor]
 report['scheduler'].update({'start_cursor':cursor,'asset_count':n})
 started=_time.monotonic(); deadline=started+120.0; call_reserve_seconds=18.0; rate_streak=0; processed_daily=0
 status={a:{'asset':a,'id':cid,'daily_ok':False,'intraday_ok':False,'errors':[]} for a,cid in ordered}
 for asset,cid in ordered:
  if _time.monotonic()+call_reserve_seconds>=deadline: break
  item=status[asset]
  try:
   x=fetch_daily(s,asset,cid,deadline=deadline)
   if not x.empty: daily.append(x)
   item['daily_ok']=True; rate_streak=0
  except DeadlineBudgetExceeded as e:
   report['scheduler']['budget_stop']='DAILY_DEADLINE'
   break
  except RateLimitedError as e:
   item['errors'].append('daily: '+str(e)); report['errors'].append({'asset':asset,'endpoint':'daily','error':str(e)}); rate_streak+=1
  except Exception as e:
   item['errors'].append('daily: '+str(e)); report['errors'].append({'asset':asset,'endpoint':'daily','error':str(e)}); rate_streak=0
  processed_daily+=1
  if rate_streak>=3:
   report['scheduler']['breaker']='CONSECUTIVE_429'; break
 next_cursor=(cursor+processed_daily)%max(n,1)
 report['scheduler'].update({'processed_daily':processed_daily,'next_cursor':next_cursor})
 if rate_streak<3:
  for asset,cid in ordered:
   if _time.monotonic()+call_reserve_seconds>=deadline: break
   item=status[asset]
   try:
    _time.sleep(1.0); y=fetch_intraday(s,asset,cid,deadline=deadline)
    if not y.empty: intra.append(y)
    item['intraday_ok']=True; rate_streak=0
   except DeadlineBudgetExceeded as e:
    report['scheduler']['budget_stop']='INTRADAY_DEADLINE'
    break
   except RateLimitedError as e:
    item['errors'].append('intraday: '+str(e)); report['errors'].append({'asset':asset,'endpoint':'intraday','error':str(e)}); rate_streak+=1
   except Exception as e:
    item['errors'].append('intraday: '+str(e)); report['errors'].append({'asset':asset,'endpoint':'intraday','error':str(e)}); rate_streak=0
   if rate_streak>=3:
    report['scheduler']['breaker']='CONSECUTIVE_429'; break
 for asset,cid in ordered:
  item=status[asset]
  if item['daily_ok'] and item['intraday_ok']: item['status']='OK'
  elif item['daily_ok'] or item['intraday_ok']: item['status']='PARTIAL'
  elif item['errors'] and all('429 Too Many Requests' in e for e in item['errors']): item['status']='RATE_LIMITED'
  elif item['errors']: item['status']='ERROR'
  else: item['status']='DEFERRED'
  if not item['errors']: item.pop('errors',None)
  report['assets'].append(item)
 if daily: report['daily_added']=_merge(ROOT/'data'/'database'/'market_daily.csv',pd.concat(daily,ignore_index=True),['date','asset'])
 if intra: report['intraday_added']=_merge(ROOT/'data'/'database'/'market_intraday_10m.csv',pd.concat(intra,ignore_index=True),['timestamp','asset'])
 try:
  state_path.parent.mkdir(parents=True,exist_ok=True)
  state_path.write_text(json.dumps({'cursor':next_cursor,'updated_at':datetime.now(timezone.utc).isoformat(),'contract':'PROGRESSIVE_DAILY_FIRST_V1'},indent=2,ensure_ascii=False),encoding='utf-8')
 except Exception as e: report['scheduler']['state_warning']=str(e)
 report['scheduler']['elapsed_seconds']=round(_time.monotonic()-started,3)
 try:
  from porquinho import hydrate_portfolio_daily_from_market_history
  report['portfolio_daily']=hydrate_portfolio_daily_from_market_history()
 except Exception as e: report['portfolio_daily_warning']=str(e)
 (ROOT/'brain'/'reports'/'history_fetch.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2)); return report

if __name__=='__main__':
 main()
