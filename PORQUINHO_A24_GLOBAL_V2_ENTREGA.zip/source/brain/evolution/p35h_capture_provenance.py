"""P3.5h: research-only capture-time provenance; never issuance/source attestation.

Hashes identify local bytes *at capture*, not the exact data/model at training time.
No backfill; pre-existing P3.5e records remain unchanged and un-attested.
"""
from __future__ import annotations
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
from brain.evolution.p35f_outcome_reconciliation import read_journal, JOURNAL

SCHEMA='P35H_CAPTURE_CONTEXT_V1'
SIDE='p35h_capture_context.jsonl'

def canonical(v):
    return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def hash_file(p):
    if not p.is_file() or p.is_symlink(): return None
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def _time(s):
    try:
        t=dt.datetime.fromisoformat(s.replace('Z','+00:00'))
        if t.tzinfo is None or t.utcoffset() is None: return None
        return t.astimezone(dt.timezone.utc)
    except (TypeError,ValueError,AttributeError): return None

def capture_context(result, *, root, started_at):
    root=Path(root)
    captured=dt.datetime.now(dt.timezone.utc)
    start=_time(started_at)
    if start is None or start>captured: return {'status':'FAIL_CLOSED_INVALID_CAPTURE_WINDOW','recorded':0,'authority':'RESEARCH_ONLY'}
    if not isinstance(result,dict) or (result.get('p35e_capture') or {}).get('status')!='RESEARCH_FORECASTS_RECORDED':
        return {'status':'NO_NEW_P35E_ISSUANCE','recorded':0,'authority':'RESEARCH_ONLY'}
    records=read_journal(root/'results'/JOURNAL)
    candidates=[r for r in records if (t:=_time(r.get('issued_at'))) is not None and start<=t<=captured]
    expected=result['p35e_capture'].get('recorded')
    if not isinstance(expected,int) or expected<1 or len(candidates)!=expected:
        return {'status':'FAIL_CLOSED_ISSUANCE_WINDOW_MISMATCH','recorded':0,'authority':'RESEARCH_ONLY'}
    source=root/'data/database/market_daily.csv'
    model=root/'brain/evolution/prediction_lab.py'
    source_hash=hash_file(source); model_hash=hash_file(model)
    if not source_hash or not model_hash:
        return {'status':'FAIL_CLOSED_SOURCE_MISSING','recorded':0,'authority':'RESEARCH_ONLY'}
    # Preserve the issuance-time canonical binding in the capture context.
    # A legacy record remains explicitly unbound; never infer identity from asset_id.
    canonical_bindings={}
    legacy_ids=[]
    for record in candidates:
        fid=record.get('forecast_id')
        cid=record.get('instrument_id')
        if not isinstance(fid,str) or not fid:
            return {'status':'FAIL_CLOSED_INVALID_FORECAST_ID','recorded':0,'authority':'RESEARCH_ONLY'}
        if cid is None:
            legacy_ids.append(fid)
        elif isinstance(cid,str) and cid and cid==cid.strip():
            canonical_bindings[fid]=cid
        else:
            return {'status':'FAIL_CLOSED_INVALID_CANONICAL_BINDING','recorded':0,'authority':'RESEARCH_ONLY'}
    if len(set(canonical_bindings).union(legacy_ids))!=len(candidates):
        return {'status':'FAIL_CLOSED_DUPLICATE_FORECAST_CONTEXT','recorded':0,'authority':'RESEARCH_ONLY'}
    body={'schema':SCHEMA,'captured_at':captured.isoformat(),
          'source_path':'data/database/market_daily.csv','source_sha256_at_capture':source_hash,
          'prediction_lab_sha256_at_capture':model_hash,
          'forecast_ids':sorted(r['forecast_id'] for r in candidates),
          'forecast_count':len(candidates),
          'canonical_forecast_instrument_ids':canonical_bindings,
          'legacy_unbound_forecast_ids':sorted(legacy_ids),
          'forecast_quote_context':{
              r['forecast_id']:{k:r.get(k) for k in
                  ('provider','provider_id','quote_currency','price_unit_status','identity_source_ref')}
              for r in candidates if all(isinstance(r.get(k),str) and r[k].strip()
                  for k in ('provider','provider_id','quote_currency'))},
          'canonical_binding_source':'P35E_ISSUANCE_UNATTESTED',
          'source_availability_attested':False,
          'training_input_identity_attested':False,'independent_archive_verified':False,
          'issued_before_outcome':False,'account_currency_resolved':False,
          'economic_comparison_status':'NOT_VALIDATED','authority':'RESEARCH_ONLY'}
    path=root/'results'/SIDE
    if not path.parent.is_dir() or path.is_symlink():
        return {'status':'FAIL_CLOSED_SIDECAR_PATH','recorded':0,'authority':'RESEARCH_ONLY'}
    fd=os.open(str(path),os.O_RDWR|os.O_CREAT,0o600)
    with os.fdopen(fd,'r+',encoding='utf-8') as f:
        fcntl.flock(f,fcntl.LOCK_EX)
        previous='GENESIS';seen=set()
        for line in f:
            if not line.endswith('\n'): raise ValueError('PARTIAL_SIDECAR_LINE')
            obj=json.loads(line); b=obj['body']
            if obj['previous_hash']!=previous or obj['hash']!=hashlib.sha256((previous+'|'+canonical(b)).encode()).hexdigest():
                raise ValueError('BROKEN_SIDECAR_CHAIN')
            seen.update(b['forecast_ids']);previous=obj['hash']
        if seen.intersection(body['forecast_ids']):
            return {'status':'FAIL_CLOSED_DUPLICATE_CONTEXT','recorded':0,'authority':'RESEARCH_ONLY'}
        digest=hashlib.sha256((previous+'|'+canonical(body)).encode()).hexdigest()
        f.seek(0,os.SEEK_END)
        f.write(canonical({'previous_hash':previous,'hash':digest,'body':body})+'\n')
        f.flush();os.fsync(f.fileno())
    return {'status':'CAPTURE_CONTEXT_RECORDED_UNATTESTED','recorded':len(candidates),
            'authority':'RESEARCH_ONLY','economic_comparison_status':'NOT_VALIDATED',
            'independent_archive_verified':False}
