"""Source-preserving research frame. No identity resolution, FX or attestation."""
import json
import math
import pandas as pd

META = ('instrument_id', 'provider', 'provider_id', 'quote_currency', 'identity_source_ref')


def _text(value):
    if value is None or pd.isna(value): return None
    if not isinstance(value, str) or not value or value != value.strip():
        raise ValueError('SOURCE_IDENTITY_TEXT_INVALID')
    return value


def prepare(frame):
    out = frame.copy(deep=True).reset_index(drop=True)
    if not {'asset','date'}.issubset(out.columns): raise ValueError('MARKET_LABEL_AND_DATE_REQUIRED')
    identities=[];series=[];cohorts=[];prices=[];volumes=[];caps=[];statuses=[]
    metadata={k:[] for k in META}
    for row in out.to_dict('records'):
        fields={k:_text(row.get(k)) for k in META}
        iid,p,pid,quote=(fields[k] for k in ('instrument_id','provider','provider_id','quote_currency'))
        if any((p,pid,quote)) and not all((p,pid,quote)):
            raise ValueError('PARTIAL_PROVIDER_QUOTE_CONTEXT')
        if quote and (not quote.isascii() or not quote.isalpha() or not quote.isupper()):
            raise ValueError('QUOTE_CURRENCY_CODE_INVALID')
        neutral = pd.notna(row.get('price')) if row.get('price') is not None else False
        if neutral and not all((p,pid,quote)):
            raise ValueError('NEUTRAL_PRICE_EXPLICIT_PROVIDER_AND_QUOTE_REQUIRED')
        if neutral:
            price=row['price'];volume=row.get('volume');cap=row.get('market_cap')
            status='EXPLICIT_QUOTE_NEUTRAL_VALUES_SOURCE_UNATTESTED'
        else:
            # Compatibility lane only. Do not infer a quote from these names.
            price=row.get('price_eur');volume=row.get('volume_eur');cap=row.get('market_cap_eur')
            status='LEGACY_COLUMN_PRICE_UNIT_UNVERIFIED'
        try:
            value=float(price)
            if isinstance(price,bool) or not math.isfinite(value) or value<=0:raise ValueError()
        except (TypeError,ValueError):raise ValueError('POSITIVE_FINITE_SOURCE_PRICE_REQUIRED')
        label=_text(row.get('asset'))
        if label is None:raise ValueError('PRESENTATION_LABEL_REQUIRED')
        # The series key is internal grouping metadata, never an instrument ID.
        origin=(p.lower(),pid,quote) if p else ('UNRESOLVED_LEGACY_SOURCE',)
        key=('SOURCE',iid,*origin,status) if iid else ('UNBOUND',label,*origin,status)
        series.append(json.dumps(key,separators=(',',':')))
        cohorts.append(json.dumps(('QUOTE',quote,status) if quote else ('UNRESOLVED_LEGACY_UNITS',),separators=(',',':')))
        prices.append(value);volumes.append(volume);caps.append(cap);statuses.append(status)
        identities.append(iid)
        for k in META:metadata[k].append(fields[k])
    for k in META:out[k]=pd.Series(metadata[k],index=out.index,dtype=object)
    out['_a24_series_key']=series;out['_a24_quote_cohort']=cohorts
    out['_a24_price']=prices;out['_a24_volume']=pd.to_numeric(pd.Series(volumes,index=out.index),errors='coerce')
    out['_a24_market_cap']=pd.to_numeric(pd.Series(caps,index=out.index),errors='coerce')
    out['price_unit_status']=statuses
    canonical=out[out['instrument_id'].notna()]
    if canonical.groupby('instrument_id')['asset'].nunique().gt(1).any():
        raise ValueError('CANONICAL_IDENTITY_ASSET_CONFLICT')
    # Source-bound observations must not be silently chosen or deduplicated.
    bound=out[out['provider'].notna()]
    dates=pd.to_datetime(bound['date'],errors='coerce').dt.normalize()
    if bound.assign(_day=dates).duplicated(['_a24_series_key','_day']).any():
        raise ValueError('DUPLICATE_SOURCE_SERIES_DATE')
    origins=canonical[canonical['provider'].notna()]
    origins=origins.assign(provider=origins['provider'].str.lower())
    if origins.groupby(['provider','provider_id'])['instrument_id'].nunique().gt(1).any():
        raise ValueError('PROVIDER_BOUND_TO_CONFLICTING_CANONICAL_IDENTITIES')
    return out


def prediction_columns(latest):
    cols=[k for k in (*META,'price_unit_status') if k in latest.columns]
    result=latest[[*cols,'asset','date','prediction_30d_pct']].copy()
    for key in cols:
        result[key]=result[key].astype(object).where(pd.notna(result[key]),None)
    return result
