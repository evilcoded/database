"""P3.5f read-only prospective outcome inspection; never validates forecasts.

Uses the exact 30th subsequent observation per asset from the legacy market_daily
CSV. Price unit and identity are unverified; all results are research-only.
"""
from __future__ import annotations
import csv, datetime as dt, hashlib, json, math
from pathlib import Path

STATUS='NOT_VALIDATED'
JOURNAL='p35e_research_forecast_issuance.jsonl'

def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def _date(s):
    try: return dt.date.fromisoformat(s)
    except (TypeError,ValueError): return None

def _finite_positive(s):
    try:
        n=float(s)
        return n if math.isfinite(n) and n>0 else None
    except (TypeError,ValueError): return None

def read_journal(path):
    previous='GENESIS'; bodies=[]; ids=set()
    if not path.is_file(): return bodies
    with path.open(encoding='utf-8') as f:
        for line in f:
            if not line.endswith('\\n') and not line.endswith('\n'):
                raise ValueError('PARTIAL_JOURNAL_LINE')
            item=json.loads(line); body=item.get('body'); digest=item.get('hash')
            if not isinstance(body,dict) or item.get('previous_hash')!=previous:
                raise ValueError('BROKEN_JOURNAL_CHAIN')
            expected=hashlib.sha256((previous+'|'+canonical(body)).encode()).hexdigest()
            if digest!=expected: raise ValueError('INVALID_JOURNAL_HASH')
            if body.get('forecast_id') in ids: raise ValueError('DUPLICATE_FORECAST_ID')
            ids.add(body.get('forecast_id'));bodies.append(body);previous=digest
    return bodies

def inspect(root, *, as_of=None):
    root=Path(root)
    out={'status':STATUS,'authority':'RESEARCH_ONLY','comparator_promotion':False,
         'execution_performed':False,'independent_archive_verified':False,
         'economic_comparison_status':'NOT_VALIDATED','records':[], 'counts':{},
         'source':'data/database/market_daily.csv','limitations':[
          'LEGACY_PRICE_EUR_UNVERIFIED_CURRENCY','LOCAL_JOURNAL_NOT_INDEPENDENT_ARCHIVE',
          'ACCOUNT_AND_CURRENCY_UNRESOLVED','NO_FORWARD_RETURN_PROMOTION']}
    try:
        journal=read_journal(root/'results'/JOURNAL)
    except (ValueError,TypeError,KeyError,UnicodeError,json.JSONDecodeError) as e:
        out['counts']={'FAIL_CLOSED_JOURNAL':1};out['error']=type(e).__name__;return out
    if not journal:
        out['counts']={'NO_ISSUED_FORECASTS':1};return out
    price_file=root/'data'/'database'/'market_daily.csv'
    if not price_file.is_file():
        out['counts']={'NO_MARKET_HISTORY':len(journal)};return out
    try:
        if as_of is None: as_of=dt.datetime.now(dt.timezone.utc).date()
        elif isinstance(as_of,str): as_of=_date(as_of)
        if not isinstance(as_of,dt.date): raise ValueError('INVALID_AS_OF')
        grouped={}; duplicates=set(); canonical_grouped={}; canonical_duplicates=set()
        with price_file.open(newline='',encoding='utf-8') as f:
            reader=csv.DictReader(f)
            if not {'asset','date','price_eur'}.issubset(set(reader.fieldnames or [])):
                raise ValueError('MARKET_SCHEMA_MISMATCH')
            for row in reader:
                asset=row.get('asset');date=_date(row.get('date'))
                if not asset or date is None or date>as_of: continue
                # Keep an independent canonical index; legacy ticker grouping is research-only.
                cid=row.get('instrument_id')
                if isinstance(cid,str) and cid.strip() and cid==cid.strip():
                    ckey=(cid,date)
                    if ckey in canonical_duplicates: continue
                    canonical_grouped.setdefault(cid,{})
                    if date in canonical_grouped[cid]:
                        canonical_duplicates.add(ckey)
                        canonical_grouped[cid].pop(date,None)
                    else:
                        canonical_grouped[cid][date]=_finite_positive(row.get('price_eur'))
                key=(asset,date)
                if key in duplicates: continue
                grouped.setdefault(asset,{})
                if date in grouped[asset]:
                    duplicates.add(key);grouped[asset].pop(date,None)
                    continue
                grouped[asset][date]=_finite_positive(row.get('price_eur'))
        counts={}
        for body in journal:
            fid=body.get('forecast_id');asset=body.get('asset_id');date=_date(body.get('observation_date'))
            item={'forecast_id':fid,'asset_id':asset,'observation_date':body.get('observation_date'),
                  'state':'BLOCKED','actual_pct':None,'maturity_date':None,
                  'issued_before_outcome':False,'identity_status':'UNRESOLVED',
                  'authority':'RESEARCH_ONLY'}
            # The original 30-observation prediction is immutable; these partial-horizon
            # signals are trajectory diagnostics, NEVER final forecast accuracy.
            predicted=body.get('prediction_pct')
            if isinstance(predicted,(int,float)) and not isinstance(predicted,bool) and math.isfinite(predicted):
                item['issued_prediction_30_observations_pct']=float(predicted)
            else:
                try:
                    predicted=float(predicted)
                    item['issued_prediction_30_observations_pct']=predicted if math.isfinite(predicted) else None
                except (TypeError,ValueError,OverflowError):
                    item['issued_prediction_30_observations_pct']=None
            item['provisional_direction_agreement']=None
            item['provisional_direction_status']='NOT_OBSERVED_OR_UNCOMPARABLE'
            instrument_id=body.get('instrument_id')
            canonical_issued=isinstance(instrument_id,str) and bool(instrument_id.strip())
            item['instrument_id']=instrument_id if canonical_issued else None
            item['identity_status']='CANONICAL_SOURCE_UNATTESTED' if canonical_issued else 'UNRESOLVED'
            # A canonical forecast must never fall back to legacy symbol-only prices.
            prices=canonical_grouped.get(instrument_id) if canonical_issued else grouped.get(asset)
            if body.get('schema')!='P35E_RESEARCH_ISSUANCE_V1' or body.get('horizon_observations')!=30 or not isinstance(asset,str) or date is None:
                item['state']='INVALID_FORECAST_METADATA'
            elif not isinstance(body.get('issued_at'),str) or not body['issued_at']:
                item['state']='INVALID_ISSUANCE_TIME'
            elif any(body.get(k) is not None for k in ('provider','provider_id','quote_currency')):
                # A24: the legacy reconciler reads price_eur without source/quote binding.
                # Never join an explicit global forecast to that legacy price lane.
                item['state']='BLOCKED_SOURCE_QUOTE_RECONCILIATION_REQUIRED'
                item['quote_currency']=body.get('quote_currency')
            elif canonical_issued and (not prices or date not in prices):
                item['state']='NO_EXACT_CANONICAL_START_OBSERVATION'
            elif not prices or date not in prices:
                item['state']='NO_EXACT_START_OBSERVATION'
            else:
                dates=sorted(prices); pos=dates.index(date)
                # Evaluate every available subsequent observation, never overwrite the
                # original 30-observation target. Recompute from immutable inputs:
                # historical gaps can be reconstructed without backdating issuance.
                elapsed=min(max(len(dates)-pos-1,0),30)
                item['observations_elapsed']=elapsed
                item['remaining_observations']=30-elapsed
                item['provisional_return_pct']=None
                item['provisional_error_pct']=None
                item['provisional_as_of']=None
                item['maturity_status']='PENDING'
                start_p=prices[date]
                if start_p is None:
                    item['state']='INVALID_PRICE'
                elif elapsed:
                    # Require every intermediate price to be valid; do not silently
                    # bridge missing prices or pretend the observation is reliable.
                    observed_dates=dates[pos+1:pos+elapsed+1]
                    if any(prices[d] is None for d in observed_dates):
                        item['state']='INVALID_INTERMEDIATE_PRICE'
                    else:
                        end=observed_dates[-1]
                        partial=round((prices[end]/start_p-1)*100,10)
                        item['provisional_return_pct']=partial
                        issued=item['issued_prediction_30_observations_pct']
                        if issued is not None and math.isfinite(partial):
                            # Zero is neutral; never claim a directional hit on zero.
                            if issued == 0 or partial == 0:
                                item['provisional_direction_status']='NEUTRAL_DIRECTION'
                            else:
                                item['provisional_direction_agreement']=(issued > 0)==(partial > 0)
                                item['provisional_direction_status']='PARTIAL_HORIZON_DIAGNOSTIC_ONLY'

                        item['provisional_as_of']=end.isoformat()
                        try:
                            predicted=float(body.get('prediction_pct'))
                            if math.isfinite(predicted):
                                # Descriptive difference only: a 30-observation target
                                # is NOT an equivalent short-horizon forecast.
                                item['provisional_error_pct']=round(partial-predicted,10)
                        except (TypeError,ValueError,OverflowError): pass
                        if elapsed==30:
                            item['state']='RESEARCH_OUTCOME_OBSERVED_UNATTESTED'
                            item['maturity_status']='MATURED_UNATTESTED'
                            item['actual_pct']=partial
                            item['maturity_date']=end.isoformat()
                        else:
                            item['state']='PROVISIONAL_OBSERVED_UNATTESTED'
                            item['maturity_status']='MATURING'
                else:
                    item['state']='PENDING_30_OBSERVATIONS'
            counts[item['state']]=counts.get(item['state'],0)+1
            out['records'].append(item)
        out['counts']=counts
    except (OSError,ValueError,UnicodeError,csv.Error) as e:
        out['records']=[];out['counts']={'FAIL_CLOSED_MARKET':1};out['error']=type(e).__name__
    return out

def main():
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--as-of')
    args=p.parse_args();r=inspect(args.root,as_of=args.as_of)
    # Display a bounded, read-only summary; no runtime writes.
    print(json.dumps({k:v for k,v in r.items() if k!='records'},ensure_ascii=False,indent=2))
    for row in r['records'][:10]: print(json.dumps(row,ensure_ascii=False))
    if len(r['records'])>10: print('ADDITIONAL_RECORDS_OMITTED:',len(r['records'])-10)
if __name__=='__main__':main()
