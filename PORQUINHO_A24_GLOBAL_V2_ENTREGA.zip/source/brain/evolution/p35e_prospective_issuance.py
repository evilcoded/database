"""P3.5e research forecast issuance journal; never financial authority.

Local hash-chain is tamper-evident only, NOT an independent immutable archive.
Unresolved account/currency remain unresolved; never infer from symbol/price_eur.
"""
from __future__ import annotations
import datetime as dt
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path

SCHEMA='P35E_RESEARCH_ISSUANCE_V1'

def _canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def _utc_now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def _finite(v):
    return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(float(v))

def _rows(result, issued_at):
    if not isinstance(result,dict) or result.get('status')!='OK' or result.get('target')!='forward_30d_return_pct':
        return []
    champ=result.get('champion') or {}
    candidates=[('champion',result.get('predictions'),str(champ.get('algorithm') or '')),
                ('ensemble',result.get('ensemble_predictions'),','.join(result.get('ensemble_models') or []))]
    out=[]
    for kind,predictions,model in candidates:
        if not isinstance(predictions,list) or not model: continue
        for pred in predictions:
            if not isinstance(pred,dict): continue
            asset=pred.get('asset'); observation_date=pred.get('date'); value=pred.get('prediction_30d_pct')
            if not isinstance(asset,str) or not asset.strip() or not isinstance(observation_date,str) or not _finite(value): continue
            try:
                d=dt.date.fromisoformat(observation_date)
                if d>dt.date.fromisoformat(issued_at[:10]): continue
            except ValueError: continue
            # Canonical identity is carried from the prediction, never inferred from a ticker.
            instrument_id=pred.get('instrument_id')
            if instrument_id is not None:
                if not isinstance(instrument_id,str) or not instrument_id.strip() or instrument_id != instrument_id.strip():
                    continue  # reject malformed identity; do not downgrade to symbol-only
            core={'schema':SCHEMA,'asset_id':asset,'observation_date':observation_date,
                  'issued_at':issued_at,'horizon_observations':30,'prediction_pct':float(value),
                  'forecast_kind':kind,'model':model,'target':'forward_30d_return_pct',
                  'account_id':None,'currency':None,'identity_status':'UNRESOLVED',
                  'baseline_prediction_pct':0.0,'baseline_status':'RESEARCH_ZERO_RETURN_REFERENCE',
                  'issued_before_outcome':False,'independent_archive_verified':False,
                  'economic_comparison_status':'NOT_VALIDATED','authority':'RESEARCH_ONLY'}
            if instrument_id is not None:
                core['instrument_id']=instrument_id
                core['identity_status']='CANONICAL_SOURCE_UNATTESTED'
            # A24: preserve explicit source quote/provider metadata; market quote
            # is never an operational account currency or an attestation.
            provider=pred.get('provider');provider_id=pred.get('provider_id');quote=pred.get('quote_currency')
            present=lambda v:isinstance(v,str) and bool(v) and v==v.strip()
            if any(v is not None for v in (provider,provider_id,quote)):
                if not all(present(v) for v in (provider,provider_id,quote)):
                    continue
                if not quote.isascii() or not quote.isalpha() or not quote.isupper():
                    continue
                core.update(provider=provider,provider_id=provider_id,quote_currency=quote,
                            price_unit_status=pred.get('price_unit_status') or 'UNVERIFIED')
            ref=pred.get('identity_source_ref')
            if ref is not None:
                if not present(ref):continue
                core['identity_source_ref']=ref
            # Same instrument, observation, model and kind cannot be silently overwritten.
            key={'asset_id':asset,'observation_date':observation_date,'forecast_kind':kind,'model':model}
            if instrument_id is not None:
                key['instrument_id']=instrument_id
            if all(present(v) for v in (provider,provider_id,quote)):
                key.update(provider=provider.lower(),provider_id=provider_id,quote_currency=quote,
                           price_unit_status=core['price_unit_status'])
            core['forecast_id']=hashlib.sha256(_canonical(key).encode()).hexdigest()
            out.append(core)
    return out

def capture(result, *, root):
    """Append forecasts to research-only sidecar; never modify market data or portfolio.
    Reject corrupted journals and conflicting reissues; returns an explicit status.
    """
    issued_at=_utc_now(); rows=_rows(result,issued_at)
    if not rows: return {'status':'NO_ELIGIBLE_FORECASTS','recorded':0,'authority':'RESEARCH_ONLY'}
    path=Path(root)/'results'/'p35e_research_forecast_issuance.jsonl'
    if not path.parent.is_dir(): return {'status':'NO_RESULTS_DIRECTORY','recorded':0,'authority':'RESEARCH_ONLY'}
    # Existing journal is not trusted as independent immutable evidence.
    fd=os.open(str(path),os.O_RDWR|os.O_CREAT,0o600)
    try:
        with os.fdopen(fd,'r+',encoding='utf-8') as f:
            fcntl.flock(f,fcntl.LOCK_EX)
            seen={}; previous='GENESIS'; count=0
            f.seek(0)
            for line in f:
                if not line.endswith('\n'): raise ValueError('PARTIAL_JOURNAL_LINE')
                item=json.loads(line)
                body=item.get('body'); digest=item.get('hash')
                if not isinstance(body,dict) or item.get('previous_hash')!=previous: raise ValueError('BROKEN_CHAIN')
                expected=hashlib.sha256((previous+'|'+_canonical(body)).encode()).hexdigest()
                if digest!=expected: raise ValueError('INVALID_HASH')
                previous=digest; count+=1
                fid=body.get('forecast_id')
                if fid in seen: raise ValueError('DUPLICATE_EXISTING_FORECAST')
                seen[fid]=body
            pending=[]
            for body in rows:
                fid=body['forecast_id']
                if fid in seen: continue
                if any(p['forecast_id']==fid for p in pending): raise ValueError('DUPLICATE_BATCH_FORECAST')
                pending.append(body)
            if not pending: return {'status':'ALREADY_CAPTURED','recorded':0,'authority':'RESEARCH_ONLY'}
            f.seek(0,os.SEEK_END)
            for body in pending:
                digest=hashlib.sha256((previous+'|'+_canonical(body)).encode()).hexdigest()
                f.write(_canonical({'previous_hash':previous,'hash':digest,'body':body})+'\n')
                previous=digest
            f.flush();os.fsync(f.fileno())
            return {'status':'RESEARCH_FORECASTS_RECORDED','recorded':len(pending),
                    'identity_status':'UNRESOLVED','authority':'RESEARCH_ONLY',
                    'independent_archive_verified':False,'economic_comparison_status':'NOT_VALIDATED'}
    except Exception:
        raise
