"""Review/import explicit local provider bindings; no acquisition or financial calls."""
import argparse,datetime as dt,json,os,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from universal_portfolio.explicit_market_bindings_a24 import REGISTRY,SCHEMA,BindingError,canonical,digest,identities,load,local,read,validate

def plan(root):
 document=load(root)
 return {'status':'BINDINGS_PRESENT' if document['bindings'] else 'AWAITING_EXPLICIT_BINDINGS',
         'known_identity_count':len(identities(root)),'binding_count':len(document['bindings']),
         'registry_digest':digest(document),'schema':SCHEMA,'authority':'RESEARCH_ONLY',
         'independent_attestation':False,'canonical_publication_authorized':False}

def apply(document,*,root,review_digest,expected_registry_digest,now=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 document=validate(document,root=root,now=now)
 if review_digest!=digest(document):raise BindingError('REVIEW_DIGEST_MISMATCH')
 old=load(root)
 if digest(old)!=expected_registry_digest:raise BindingError('REGISTRY_CHANGED_SINCE_REVIEW')
 old_by={(r['provider'].lower(),r['provider_id'],r['quote_currency']):r for r in old['bindings']}
 new_by={(r['provider'].lower(),r['provider_id'],r['quote_currency']):r for r in document['bindings']}
 if any(new_by.get(k)!=v for k,v in old_by.items()):raise BindingError('EXISTING_BINDINGS_CANNOT_BE_REMOVED_OR_REWRITTEN')
 if old==document:return {**plan(root),'status':'ALREADY_APPLIED'}
 for key,row in new_by.items():
  if key not in old_by and (dt.date.fromisoformat(row['effective_from'])<now.date() or dt.datetime.fromisoformat(row['confirmed_at'].replace('Z','+00:00')).astimezone(dt.timezone.utc).date()!=now.date()):
   raise BindingError('NEW_BINDING_REQUIRES_CURRENT_CONFIRMATION_NO_BACKDATING')
 p=local(root,REGISTRY)
 if not p.parent.is_dir():raise BindingError('EXISTING_INSTRUMENT_DIRECTORY_REQUIRED')
 # Exclusive creation lock; no stale lock removal or overwrite by this tool.
 lock=p.with_suffix('.lock');fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 tmp=None
 try:
  os.close(fd)
  if digest(load(root))!=expected_registry_digest:raise BindingError('REGISTRY_CHANGED_SINCE_REVIEW')
  if p.exists():
   backup=p.with_name(p.name+'.backup_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%f'))
   with os.fdopen(os.open(backup,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600),'wb') as f:f.write(p.read_bytes())
  fd,tmp=tempfile.mkstemp(prefix='.a24_bindings_',dir=p.parent)
  with os.fdopen(fd,'w',encoding='utf-8') as f:f.write(canonical(document)+'\n');f.flush();os.fsync(f.fileno())
  os.chmod(tmp,0o600);os.replace(tmp,p);tmp=None
 finally:
  if tmp is not None:os.unlink(tmp)
  lock.unlink()
 return {'status':'EXPLICIT_BINDINGS_RECORDED','binding_count':len(document['bindings']),'registry_digest':digest(document),
         'authority':'RESEARCH_ONLY','independent_attestation':False,'financial_mutation':False}

def template(root,output,instrument_id=None):
 root=Path(root).resolve(strict=True);output=Path(output).expanduser().resolve()
 if output.is_relative_to(root):raise BindingError('REVIEW_TEMPLATE_MUST_BE_OUTSIDE_PROJECT')
 known=identities(root)
 if instrument_id is not None and instrument_id not in known:raise BindingError('INSTRUMENT_NOT_IN_EXISTING_CATALOG')
 existing=load(root)['bindings'];bound={r['instrument_id'] for r in existing}
 choices=[instrument_id] if instrument_id is not None else sorted(known-bound)
 rows=existing+[{'instrument_id':iid,'provider':'','provider_id':'','quote_currency':'','identity_source_ref':'','confirmed_by':'','confirmed_at':'','effective_from':''} for iid in choices]
 with output.open('x',encoding='utf-8') as f:json.dump({'schema':SCHEMA,'bindings':rows},f,ensure_ascii=False,indent=2);f.write('\n')
 return {'status':'UNFILLED_REVIEW_TEMPLATE_CREATED','identity_count':len({r['instrument_id'] for r in rows}),'review_row_count':len(rows),'no_bindings_created':True,'path':str(output)}

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',default=str(ROOT))
 sub=parser.add_subparsers(dest='command',required=True);sub.add_parser('status')
 draft=sub.add_parser('template');draft.add_argument('--output',required=True);draft.add_argument('--instrument-id')
 check=sub.add_parser('validate');check.add_argument('--file',required=True)
 write=sub.add_parser('apply');write.add_argument('--file',required=True);write.add_argument('--review-digest',required=True);write.add_argument('--expected-registry-digest',required=True)
 args=parser.parse_args();root=Path(args.root).resolve(strict=True)
 if args.command=='status':result=plan(root)
 elif args.command=='template':result=template(root,args.output,instrument_id=args.instrument_id)
 else:
  document=validate(read(Path(args.file)),root=root)
  if args.command=='validate':result={'status':'VALID_FOR_LOCAL_RESEARCH_ONLY','review_digest':digest(document),'current_registry_digest':digest(load(root)),'binding_count':len(document['bindings']),'independent_attestation':False}
  else:result=apply(document,root=root,review_digest=args.review_digest,expected_registry_digest=args.expected_registry_digest)
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
