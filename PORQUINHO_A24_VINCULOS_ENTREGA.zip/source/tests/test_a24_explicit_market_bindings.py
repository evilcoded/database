"""Explicit review lifecycle and real acquisition/merge integration in temp roots."""
import ast,datetime as dt,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import pandas as pd
from universal_portfolio import explicit_market_bindings_a24 as b
from tools import market_provider_bindings_a24 as cli

ROOT=Path(__file__).resolve().parents[1]
NOW=dt.datetime(2026,10,15,12,tzinfo=dt.timezone.utc)
ID='GLOBAL:MARKET:CLASS:EXPLICIT'
ID5='GLOBAL:MARKET:CLASS:PRODUCT:SERIES'

def row(**kw):
 return dict({'instrument_id':ID,'provider':'Provider','provider_id':'source-id','quote_currency':'USD',
              'identity_source_ref':'explicit-source-reference','confirmed_by':'local-reviewer',
              'confirmed_at':NOW.isoformat(),'effective_from':'2026-10-15'},**kw)
def doc(rows):return {'schema':b.SCHEMA,'bindings':rows}

class ExplicitBindings(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)/'project';self.root.mkdir()
  (self.root/'data/instruments').mkdir(parents=True)
  (self.root/'data/universal_instrument_catalog.json').write_text(json.dumps({'instruments':[{'instrument_id':ID},{'instrument_id':ID5}]}))
 def apply(self,d):return cli.apply(d,root=self.root,review_digest=b.digest(d),expected_registry_digest=b.digest(b.load(self.root)),now=NOW)
 def save(self,d):b.local(self.root,b.REGISTRY).write_text(b.canonical(d))
 def frame(self,date='2026-10-15',**extra):
  return pd.DataFrame([dict({'date':date,'asset':'LABEL','provider':'Provider','provider_id':'source-id','quote_currency':'USD','price':10},**extra)])
 def test_absent_registry_never_created_by_status_or_bind(self):
  self.assertEqual(cli.plan(self.root)['status'],'AWAITING_EXPLICIT_BINDINGS')
  frame=b.bind_frame(self.frame(),root=self.root);self.assertNotIn('instrument_id',frame);self.assertFalse(b.local(self.root,b.REGISTRY).exists())
 def test_four_and_five_component_id_preserved(self):
  for iid in (ID,ID5):self.assertEqual(b.validate(doc([row(instrument_id=iid)]),root=self.root,now=NOW)['bindings'][0]['instrument_id'],iid)
 def test_unknown_instrument_not_constructed(self):
  with self.assertRaisesRegex(b.BindingError,'NOT_IN_EXISTING'):b.validate(doc([row(instrument_id='OTHER')]),root=self.root)
 def test_missing_review_fields_rejected(self):
  for key in row():
   r=row();r.pop(key)
   with self.subTest(key=key),self.assertRaises(b.BindingError):b.validate(doc([r]),root=self.root)
 def test_no_attestation_or_authority_flag_can_be_imported(self):
  with self.assertRaises(b.BindingError):b.validate(doc([row(attested=True)]),root=self.root)
 def test_conflicting_identity_for_same_provider_rejected(self):
  with self.assertRaisesRegex(b.BindingError,'CONFLICTING'):b.validate(doc([row(),row(instrument_id=ID5,quote_currency='JPY')]),root=self.root)
 def test_same_identity_multi_quote_supported(self):
  self.assertEqual(len(b.validate(doc([row(),row(quote_currency='JPY')]),root=self.root)['bindings']),2)
 def test_duplicate_key_rejected_case_insensitively_for_provider(self):
  with self.assertRaisesRegex(b.BindingError,'DUPLICATE'):b.validate(doc([row(),row(provider='PROVIDER')]),root=self.root)
 def test_quote_not_silently_normalized(self):
  for quote in ('usd',' USD','€UR'):
   with self.subTest(quote=quote),self.assertRaises(b.BindingError):b.validate(doc([row(quote_currency=quote)]),root=self.root)
 def test_no_currency_whitelist(self):
  self.assertEqual(b.validate(doc([row(quote_currency='XAU')]),root=self.root)['bindings'][0]['quote_currency'],'XAU')
 def test_future_confirmation_rejected(self):
  with self.assertRaises(b.BindingError):b.validate(doc([row(confirmed_at='2099-01-01T00:00:00+00:00')]),root=self.root)
 def test_naive_confirmation_rejected(self):
  with self.assertRaises(b.BindingError):b.validate(doc([row(confirmed_at='2026-10-15T00:00:00')]),root=self.root)
 def test_effect_cannot_precede_confirmation(self):
  with self.assertRaisesRegex(b.BindingError,'RETROACTIVE'):b.validate(doc([row(effective_from='2026-10-14')]),root=self.root)
 def test_apply_old_confirmation_not_accepted_as_new(self):
  d=doc([row(confirmed_at='2025-01-01T00:00:00+00:00',effective_from='2025-01-01')])
  with self.assertRaisesRegex(b.BindingError,'NO_BACKDATING'):self.apply(d)
 def test_digest_refuses_changed_review(self):
  d=doc([row()])
  with self.assertRaisesRegex(b.BindingError,'REVIEW_DIGEST'):cli.apply(d,root=self.root,review_digest='wrong',expected_registry_digest=b.digest(b.load(self.root)),now=NOW)
 def test_registry_change_refused(self):
  d=doc([row()])
  with self.assertRaisesRegex(b.BindingError,'REGISTRY_CHANGED'):cli.apply(d,root=self.root,review_digest=b.digest(d),expected_registry_digest='wrong',now=NOW)
 def test_apply_then_repeat_idempotent(self):
  d=doc([row()]);self.assertEqual(self.apply(d)['status'],'EXPLICIT_BINDINGS_RECORDED')
  before=b.local(self.root,b.REGISTRY).read_bytes();self.assertEqual(self.apply(d)['status'],'ALREADY_APPLIED');self.assertEqual(before,b.local(self.root,b.REGISTRY).read_bytes())
 def test_addition_backs_up_old_registry(self):
  self.apply(doc([row()]));before=b.local(self.root,b.REGISTRY).read_bytes()
  self.apply(doc([row(),row(quote_currency='JPY')]))
  backups=list((self.root/'data/instruments').glob('*.backup_*'));self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),before)
 def test_existing_binding_cannot_be_rewritten_or_removed(self):
  self.apply(doc([row()]))
  for d in (doc([]),doc([row(instrument_id=ID5)])):
   with self.assertRaisesRegex(b.BindingError,'CANNOT_BE_REMOVED'):self.apply(d)
 def test_explicit_origin_matches_exactly(self):
  self.save(doc([row()]));out=b.bind_frame(self.frame(),root=self.root)
  self.assertEqual(out.iloc[0]['instrument_id'],ID);self.assertEqual(out.attrs['a24_binding']['authority'],'RESEARCH_ONLY');self.assertFalse(out.attrs['a24_binding']['independent_archive_verified'])
 def test_wrong_origin_or_quote_does_not_bind(self):
  self.save(doc([row()]))
  for fields in ({'provider':'other'},{'provider_id':'SOURCE-ID'},{'quote_currency':'JPY'}):
   with self.subTest(fields=fields):self.assertNotIn('instrument_id',b.bind_frame(self.frame(**fields),root=self.root))
 def test_old_date_not_backfilled(self):
  self.save(doc([row()]));self.assertNotIn('instrument_id',b.bind_frame(self.frame('2026-10-14'),root=self.root))
 def test_conflicting_input_identity_rejected(self):
  self.save(doc([row()]))
  with self.assertRaisesRegex(b.BindingError,'ACQUISITION_IDENTITY_CONFLICT'):b.bind_frame(self.frame(instrument_id=ID5),root=self.root)
 def test_frame_input_unchanged(self):
  self.save(doc([row()]));f=self.frame();before=f.copy(deep=True);b.bind_frame(f,root=self.root);pd.testing.assert_frame_equal(f,before)
 def test_template_is_blank_and_outside_project(self):
  output=Path(self.tmp.name)/'review.json';cli.template(self.root,output,instrument_id=ID5)
  d=json.loads(output.read_text());self.assertEqual(d['bindings'][0]['instrument_id'],ID5);self.assertEqual(d['bindings'][0]['provider_id'],'')
  self.assertFalse(b.local(self.root,b.REGISTRY).exists())
  with self.assertRaises(FileExistsError):cli.template(self.root,output)
  with self.assertRaises(b.BindingError):cli.template(self.root,self.root/'review.json')
 def test_template_keeps_existing_bindings_for_case_by_case_review(self):
  self.save(doc([row()]));output=Path(self.tmp.name)/'review.json';cli.template(self.root,output,instrument_id=ID5)
  d=json.loads(output.read_text());self.assertEqual(d['bindings'][0],row());self.assertEqual(len(d['bindings']),2)
 def test_collector_and_new_date_merge_use_explicit_binding(self):
  # Execute actual functions without importing the collector's directory creation.
  tree=ast.parse((ROOT/'tools/fetch_history.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('fetch_daily','_merge')]
  def get(s,path,params,*a,**kw):
   kw['provenance_sink']({'acquisition_mode':'NETWORK','fetched_at':NOW.isoformat(),'cache_saved_at':None})
   ms=[int(dt.datetime(2026,10,day,tzinfo=dt.timezone.utc).timestamp()*1000) for day in (14,15)]
   return {'prices':[[ms[0],10],[ms[1],11]],'market_caps':[[v,1000] for v in ms],'total_volumes':[[v,100] for v in ms]}
  ns={'pd':pd,'ROOT':self.root,'_get':get};exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual_collector','exec'),ns)
  self.save(doc([row(provider='CoinGecko',quote_currency='EUR')]))
  path=self.root/'market.csv';pd.DataFrame([{'date':'2026-10-14','asset':'LABEL','price_eur':9}]).to_csv(path,index=False)
  observed=ns['fetch_daily'](None,'LABEL','source-id');self.assertIsNone(observed.iloc[0].instrument_id);self.assertEqual(observed.iloc[1].instrument_id,ID)
  self.assertEqual(ns['_merge'](path,observed,['date','asset']),1)
  persisted=pd.read_csv(path);self.assertEqual(persisted.iloc[0].price_eur,9);self.assertTrue(pd.isna(persisted.iloc[0].instrument_id));self.assertEqual(persisted.iloc[1].instrument_id,ID)
  before=path.read_bytes();self.assertEqual(ns['_merge'](path,observed,['date','asset']),0);self.assertEqual(path.read_bytes(),before)
 def test_corrupt_registry_does_not_silently_fall_back(self):
  self.save({'schema':'WRONG','bindings':[]})
  with self.assertRaises(b.BindingError):b.bind_frame(self.frame(),root=self.root)
if __name__=='__main__':unittest.main()
