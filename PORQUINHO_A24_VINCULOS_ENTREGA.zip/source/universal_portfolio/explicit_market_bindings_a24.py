"""Locally confirmed provider bindings for research. Never independent attestation."""
import datetime as dt
import hashlib,json
from pathlib import Path

SCHEMA='porquinho.explicit-market-bindings-a24/1.0'
REGISTRY='data/instruments/market_provider_bindings_a24.json'
CATALOGS=('data/universal_instrument_catalog.json','data/instruments/manual_instruments.json')
class BindingError(ValueError):pass

def text(v):return isinstance(v,str) and bool(v) and v==v.strip()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def digest(v):return hashlib.sha256(canonical(v).encode()).hexdigest()
def local(root,rel):
 root=Path(root).resolve(strict=True);p=root/rel
 if p.is_symlink() or any(a.is_symlink() for a in p.parents if a!=root.parent):raise BindingError('SYMLINK_REFUSED')
 if not p.resolve().is_relative_to(root):raise BindingError('OUTSIDE_PROJECT')
 return p

def read(path):
 if path.stat().st_size>8*1024*1024:raise BindingError('BINDING_INPUT_TOO_LARGE')
 return json.loads(path.read_text(encoding='utf-8'))

def identities(root):
 ids=set()
 for rel in CATALOGS:
  p=local(root,rel)
  if not p.exists():continue
  obj=read(p)
  for row in obj.get('instruments',[]):
   if isinstance(row,dict) and text(row.get('instrument_id')):ids.add(row['instrument_id'])
 return ids

def validate(document,*,root,now=None):
 if not isinstance(document,dict) or set(document)!={'schema','bindings'} or document.get('schema')!=SCHEMA:raise BindingError('BINDING_SCHEMA_REQUIRED')
 rows=document.get('bindings')
 if not isinstance(rows,list) or len(rows)>10000:raise BindingError('BINDING_ROWS_INVALID')
 known=identities(root);keys=set();origins={};out=[]
 now=now or dt.datetime.now(dt.timezone.utc)
 fields={'instrument_id','provider','provider_id','quote_currency','identity_source_ref','confirmed_by','confirmed_at','effective_from'}
 for row in rows:
  if not isinstance(row,dict) or set(row)!=fields or not all(text(row[k]) for k in fields):raise BindingError('EXPLICIT_BINDING_FIELDS_REQUIRED')
  iid,p,pid,q=(row[k] for k in ('instrument_id','provider','provider_id','quote_currency'))
  if iid not in known:raise BindingError('INSTRUMENT_NOT_IN_EXISTING_CATALOG')
  if not q.isascii() or not q.isalpha() or not q.isupper():raise BindingError('QUOTE_CURRENCY_INVALID')
  try:
   confirmed=dt.datetime.fromisoformat(row['confirmed_at'].replace('Z','+00:00'))
   effective=dt.date.fromisoformat(row['effective_from'])
   if confirmed.tzinfo is None or confirmed.utcoffset() is None:raise ValueError()
   confirmed=confirmed.astimezone(dt.timezone.utc)
   if confirmed>now or effective<confirmed.date():raise ValueError()
  except (ValueError,TypeError):raise BindingError('BINDING_TIME_OR_RETROACTIVE_EFFECT_INVALID')
  key=(p.lower(),pid,q);origin=key[:2]
  if key in keys:raise BindingError('DUPLICATE_PROVIDER_QUOTE_BINDING')
  if origin in origins and origins[origin]!=iid:raise BindingError('CONFLICTING_PROVIDER_IDENTITY')
  keys.add(key);origins[origin]=iid;out.append(dict(row))
 return {'schema':SCHEMA,'bindings':out}

def load(root):
 p=local(root,REGISTRY)
 if not p.exists():return {'schema':SCHEMA,'bindings':[]}
 return validate(read(p),root=root)

def bind_frame(frame,*,root):
 """Enrich only returned acquisition rows on/after explicit effective date.

 Persistence still uses the collector's new-date-only merge. Existing rows are
 never filled in. Missing or invalid registries do not fabricate identities.
 """
 document=load(root);lookup={(r['provider'].lower(),r['provider_id'],r['quote_currency']):r for r in document['bindings']}
 out=frame.copy(deep=True);ids=[];refs=[];matched=0
 for row in out.to_dict('records'):
  iid=row.get('instrument_id');ref=row.get('identity_source_ref')
  # pandas missing values must remain absent rather than becoming 'nan' text.
  iid=iid if text(iid) else None;ref=ref if text(ref) else None
  p,pid,q=(row.get(k) for k in ('provider','provider_id','quote_currency'))
  binding=lookup.get((p.lower(),pid,q)) if all(text(v) for v in (p,pid,q)) else None
  try:day=dt.date.fromisoformat(str(row.get('date')))
  except ValueError:day=None
  if binding and day and day>=dt.date.fromisoformat(binding['effective_from']):
   if iid is not None and iid!=binding['instrument_id']:raise BindingError('ACQUISITION_IDENTITY_CONFLICT')
   iid=binding['instrument_id'];ref=binding['identity_source_ref'];matched+=1
  ids.append(iid);refs.append(ref)
 if matched or 'instrument_id' in out.columns:
  import pandas as pd
  out['instrument_id']=pd.Series(ids,index=out.index,dtype=object)
  out['identity_source_ref']=pd.Series(refs,index=out.index,dtype=object)
 out.attrs['a24_binding']={'status':'LOCALLY_CONFIRMED_SOURCE_UNATTESTED' if matched else 'NO_APPLICABLE_EXPLICIT_BINDING',
                         'matched_rows':matched,'independent_archive_verified':False,'authority':'RESEARCH_ONLY'}
 return out
