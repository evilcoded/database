import copy,json,unittest
from unittest.mock import patch
import test_a24_research_quote_acquisition as fixture
import test_a24_binding_review_queue as base
from universal_portfolio import binding_review_queue_a24 as review
from universal_portfolio import explicit_market_bindings_a24 as bindings
from tools import review_funded_bindings_a24 as cli
class Flow(unittest.TestCase):
 def setUp(self):
  self.fx=fixture.Acquisition();self.fx.setUp();self.addCleanup(self.fx.doCleanups);self.root=self.fx.root
 def candidate(self,**changes):
  row={'instrument_id':fixture.IID,'symbol':'EXAMPLE','source':'EXISTING_OBSERVATIONAL_SOURCE','identity_provenance':'DOMAIN_METADATA_PLUS_PROVIDER_SYMBOL','currency':'EUR','metadata':{'provider_id':'source-id'}};row.update(changes);return row
 def queue(self,candidates=None,demand=None):return review.build(self.root,demand or self.fx.demand(),now=fixture.NOW,candidates=candidates or [])
 def decisions(self,q):return base.Review.decisions(self,q)
 def test_existing_exact_candidate_claim_is_shown_unconfirmed(self):
  q=self.queue([self.candidate()]);claim=q['rows'][0]['observed_source_claims'][0];self.assertEqual(claim['provider_id'],'source-id');self.assertIsNone(claim['provider_declared']);self.assertFalse(claim['quote_verified']);self.assertFalse(claim['identity_binding_created']);self.assertEqual(q['rows'][0]['status'],'AWAITING_CASE_REVIEW')
 def test_matching_symbol_different_identity_does_not_link(self):
  q=self.queue([self.candidate(instrument_id='DIFFERENT:EXAMPLE')]);self.assertEqual(q['rows'][0]['observed_source_claims'],[])
 def test_source_currency_not_transferred_to_requested_currency(self):
  q=self.queue([self.candidate()],self.fx.demand(('BRL','JPY')));self.assertEqual({r['quote_currency'] for r in q['rows']},{'BRL','JPY'})
  for row in q['rows']:
   claim=row['observed_source_claims'][0];self.assertNotIn('quote_currency',claim);self.assertFalse(claim['quote_verified'])
 def test_no_provider_id_fabricated_from_symbol(self):
  q=self.queue([self.candidate(metadata={})]);self.assertEqual(q['rows'][0]['observed_source_claims'],[])
 def test_duplicate_observation_claims_deduplicated(self):
  c=self.candidate();q=self.queue([c,c]);self.assertEqual(len(q['rows'][0]['observed_source_claims']),1)
 def test_multiple_source_claims_not_arbitrarily_selected(self):
  q=self.queue([self.candidate(),self.candidate(metadata={'provider_id':'another'})]);self.assertEqual(len(q['rows'][0]['observed_source_claims']),2)
 def test_untrusted_claim_cannot_supply_missing_user_fields(self):
  q=self.queue([self.candidate()]);d=self.decisions(q);d['decisions'][0]['provider_id']=''
  with self.assertRaisesRegex(bindings.BindingError,'FIELDS_REQUIRED'):review.prepare(self.root,q,d,now=fixture.NOW)
 def test_apply_only_confirmed_case_no_history_writes(self):
  q=self.queue([self.candidate()]);d=self.decisions(q);p=self.root/'data/snapshots/history.json';p.parent.mkdir(parents=True);p.write_bytes(b'original')
  with patch.object(cli,'current',return_value=q),patch('socket.socket.connect',side_effect=AssertionError('network')):out=cli.apply_review(self.root,d,now=fixture.NOW)
  self.assertEqual(out['status'],'EXPLICIT_BINDINGS_RECORDED');self.assertEqual(bindings.validate(bindings.read(bindings.local(self.root,bindings.REGISTRY)),root=self.root,now=fixture.NOW)['bindings'][0]['instrument_id'],fixture.IID);self.assertEqual(p.read_bytes(),b'original');self.assertFalse(out['canonical_publication_authorized'])
 def test_existing_binding_preserved_and_backed_up_on_new_quote(self):
  old=self.fx.rows(quote_currency='EUR');self.fx.save([old]);before=bindings.local(self.root,bindings.REGISTRY).read_bytes();q=self.queue();d=self.decisions(q)
  with patch.object(cli,'current',return_value=q):cli.apply_review(self.root,d,now=fixture.NOW)
  self.assertEqual(bindings.validate(bindings.read(bindings.local(self.root,bindings.REGISTRY)),root=self.root,now=fixture.NOW)['bindings'][0],old);backups=list((self.root/'data/instruments').glob('*.backup_*'));self.assertEqual(len(backups),1);self.assertEqual(backups[0].read_bytes(),before)
 def test_stale_review_cannot_overwrite_new_registry(self):
  q=self.queue();d=self.decisions(q);self.fx.save([self.fx.rows(quote_currency='EUR')]);before=bindings.local(self.root,bindings.REGISTRY).read_bytes()
  with patch.object(cli,'current',return_value=q):
   with self.assertRaisesRegex(bindings.BindingError,'REGISTRY_CHANGED'):cli.apply_review(self.root,d,now=fixture.NOW)
  self.assertEqual(bindings.local(self.root,bindings.REGISTRY).read_bytes(),before)
 def test_unconfirmed_review_does_not_create_registry(self):
  q=self.queue([self.candidate()]);d=self.decisions(q);d['decisions'][0]['confirmed']=False
  with patch.object(cli,'current',return_value=q):
   with self.assertRaisesRegex(bindings.BindingError,'CONFIRMATION_REQUIRED'):cli.apply_review(self.root,d,now=fixture.NOW)
  self.assertFalse(bindings.local(self.root,bindings.REGISTRY).exists())
 def test_unknown_catalog_case_stays_blocked_with_observed_claim(self):
  d=self.fx.demand();d['research_requests'][0]['instrument_id']='MISSING:ORIGINAL';q=self.queue([self.candidate(instrument_id='MISSING:ORIGINAL')],d)
  self.assertEqual(q['rows'][0]['status'],'IDENTITY_NOT_IN_BINDING_CATALOG');self.assertTrue(q['rows'][0]['observed_source_claims'])
  with self.assertRaisesRegex(bindings.BindingError,'NOT_ELIGIBLE'):review.prepare(self.root,q,self.decisions(q),now=fixture.NOW)
 def test_claim_content_escaped_in_offline_html(self):
  q=self.queue([self.candidate(metadata={'provider_id':'</script><script>bad()'})]);html=review.html(q);self.assertNotIn('</script><script>',html);self.assertIn('\\u003c/script',html)
 def test_existing_dom_input_not_silently_overwritten(self):
  q=self.queue([self.candidate()]);h=review.html(q);self.assertIn('O campo já está preenchido e foi preservado.',h);self.assertIn("e.inputs.provider_id.value=claim.provider_id",h)
