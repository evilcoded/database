import sys,os,json,hashlib
from pathlib import Path
root=Path(sys.argv[1]).resolve(strict=True)
sys.path.insert(0,str(root))

def guard(event,args):
    if event=='open':
        mode=args[1];flags=args[2]
        if (isinstance(mode,str) and any(x in mode for x in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):
            raise RuntimeError('READ_ONLY_WRITE_REFUSED')
    if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:
        raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
sys.addaudithook(guard)
from brain.evolution.p35f_outcome_reconciliation import inspect, JOURNAL
paths=[root/'data/database/market_daily.csv',root/'results'/JOURNAL]
def digests():
    out=[]
    for path in paths:
        if not path.exists():out.append(None);continue
        h=hashlib.sha256()
        with path.open('rb') as f:
            for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
        out.append(h.hexdigest())
    return out
try:
    before=digests();result=inspect(root);stable=before==digests()
    global_rows=[row for row in result['records'] if row.get('reconciliation_binding')=='EXACT_GLOBAL_SOURCE_QUOTE_UNATTESTED']
    counts={}
    for row in global_rows:counts[row['state']]=counts.get(row['state'],0)+1
    print(json.dumps({'validation':'A24_GLOBAL_RECONCILIATION_READ_ONLY',
      'status':'INSPECTED_NOT_CERTIFIED' if stable else 'SOURCE_CHANGED_DURING_READ_RETRY_REQUIRED',
      'counts':result['counts'] if stable else {},'global_counts':counts if stable else {},
      'source_files_stable_during_read':stable,'financial_mutation':False,
      'history_write_performed':False,'services_restarted':False,'runtime_activation_proven':False,
      'economic_comparison_status':'NOT_VALIDATED','canonical_publication_authorized':False},indent=2))
except Exception as exc:
    print(json.dumps({'validation':'A24_GLOBAL_RECONCILIATION_READ_ONLY','status':'INSPECTION_FAILED_CLOSED','error':type(exc).__name__,'financial_mutation':False,'services_restarted':False,'canonical_publication_authorized':False},indent=2))
