"""Read-only integration tests with exact source/quote and immutable temp journals."""
import csv,datetime as dt,hashlib,json,tempfile,unittest
from pathlib import Path
from brain.evolution.p35e_prospective_issuance import _rows, _canonical
from brain.evolution.p35f_outcome_reconciliation import inspect, JOURNAL
from brain.evolution.global_outcome_index_a24 import UNIT

START=dt.date(2025,1,1)
ORIGIN={'instrument_id':'global:market:class:one','provider':'Provider',
        'provider_id':'provider-one','quote_currency':'USD'}


def forecast(**changes):
    pred=dict(ORIGIN,asset='SAME',date=START.isoformat(),prediction_30d_pct=25.0,price_unit_status=UNIT)
    body=_rows({'status':'OK','target':'forward_30d_return_pct','champion':{'algorithm':'Ridge'},'predictions':[pred]},'2025-01-01T12:00:00+00:00')[0]
    body.update(changes)
    return body


def history(n=31,step=1,**changes):
    return [dict(ORIGIN,asset='SAME',date=(START+dt.timedelta(days=i*step)).isoformat(),price=100+i,**{})|changes for i in range(n)]


class GlobalReconciliationTests(unittest.TestCase):
    def run_inspection(self,rows,body=None,as_of='2025-06-01'):
        body=forecast() if body is None else body
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'results').mkdir();(root/'data/database').mkdir(parents=True)
            digest=hashlib.sha256(('GENESIS|'+_canonical(body)).encode()).hexdigest()
            journal=root/'results'/JOURNAL
            journal.write_text(_canonical({'previous_hash':'GENESIS','hash':digest,'body':body})+'\n')
            market=root/'data/database/market_daily.csv'
            fields=sorted(set().union(*(set(row) for row in rows)))
            with market.open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(rows)
            before={p.relative_to(root):p.read_bytes() for p in root.rglob('*') if p.is_file()}
            result=inspect(root,as_of=as_of)
            after={p.relative_to(root):p.read_bytes() for p in root.rglob('*') if p.is_file()}
            self.assertEqual(before,after)
            self.assertEqual(result['authority'],'RESEARCH_ONLY')
            self.assertEqual(result['economic_comparison_status'],'NOT_VALIDATED')
            self.assertFalse(result['comparator_promotion']);self.assertFalse(result['execution_performed'])
            self.assertEqual(len(result['records']),1,result)
            return result['records'][0]

    def test_exact_neutral_price_matures_and_ignores_eur_alias(self):
        item=self.run_inspection(history(price_eur=999))
        self.assertEqual(item['state'],'RESEARCH_OUTCOME_OBSERVED_UNATTESTED')
        self.assertAlmostEqual(item['actual_pct'],30)
        self.assertEqual(item['maturity_date'],'2025-01-31')
        self.assertFalse(item['issued_before_outcome'])
        self.assertEqual(item['quote_currency'],'USD')

    def test_observations_not_calendar_days(self):
        item=self.run_inspection(history(step=2))
        self.assertEqual(item['maturity_date'],'2025-03-02');self.assertEqual(item['actual_pct'],30)

    def test_partial_horizon_does_not_become_final(self):
        item=self.run_inspection(history(n=10))
        self.assertEqual(item['state'],'PROVISIONAL_OBSERVED_UNATTESTED')
        self.assertEqual(item['provisional_return_pct'],9);self.assertIsNone(item['actual_pct'])
        self.assertEqual(item['observations_elapsed'],9);self.assertEqual(item['remaining_observations'],21)

    def test_as_of_excludes_future_observations(self):
        item=self.run_inspection(history(),as_of='2025-01-11')
        self.assertEqual(item['observations_elapsed'],10);self.assertIsNone(item['actual_pct'])

    def test_same_symbol_other_identity_cannot_supply_prices(self):
        item=self.run_inspection(history(instrument_id='another:identity'))
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_other_quote_cannot_supply_prices(self):
        item=self.run_inspection(history(quote_currency='JPY'))
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_other_provider_cannot_supply_prices(self):
        item=self.run_inspection(history(provider='OtherProvider'))
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_other_provider_id_cannot_supply_prices(self):
        item=self.run_inspection(history(provider_id='another-id'))
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_same_identity_two_quotes_do_not_mix(self):
        rows=history()+history(quote_currency='JPY',price=999)
        self.assertEqual(self.run_inspection(rows)['actual_pct'],30)

    def test_same_symbol_distinct_sources_do_not_mix(self):
        rows=history()+history(instrument_id='other',provider_id='other-id',price=999)
        self.assertEqual(self.run_inspection(rows)['actual_pct'],30)

    def test_provider_case_is_normalized(self):
        self.assertEqual(self.run_inspection(history(provider='PROVIDER'))['actual_pct'],30)

    def test_provider_id_is_case_sensitive(self):
        item=self.run_inspection(history(provider_id='PROVIDER-ONE'))
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_conflicting_provider_identity_binding_is_blocked(self):
        rows=history()+history(n=1,instrument_id='conflict')
        self.assertEqual(self.run_inspection(rows)['state'],'BLOCKED_GLOBAL_SOURCE_IDENTITY_CONFLICT')

    def test_missing_forecast_identity_never_falls_back_to_symbol(self):
        item=self.run_inspection(history(),forecast(instrument_id=None))
        self.assertEqual(item['state'],'BLOCKED_GLOBAL_IDENTITY_OR_ORIGIN_REQUIRED')

    def test_partial_or_invalid_forecast_origin_rejected(self):
        for changes in ({'provider':None},{'provider_id':''},{'quote_currency':'usd'}):
            with self.subTest(changes=changes):
                self.assertEqual(self.run_inspection(history(),forecast(**changes))['state'],'BLOCKED_GLOBAL_IDENTITY_OR_ORIGIN_REQUIRED')

    def test_unverified_price_unit_not_promoted(self):
        item=self.run_inspection(history(),forecast(price_unit_status='LEGACY_COLUMN_PRICE_UNIT_UNVERIFIED'))
        self.assertEqual(item['state'],'BLOCKED_GLOBAL_PRICE_UNIT_UNVERIFIED')

    def test_eur_suffix_never_substitutes_for_neutral_price(self):
        rows=history()
        for row in rows:row['price_eur']=row.pop('price')
        item=self.run_inspection(rows)
        self.assertEqual(item['state'],'INVALID_PRICE');self.assertIsNone(item['actual_pct'])

    def test_start_date_must_match_exactly(self):
        item=self.run_inspection(history()[1:])
        self.assertEqual(item['state'],'NO_EXACT_GLOBAL_START_OBSERVATION')

    def test_duplicate_start_is_ambiguous(self):
        rows=history();rows.append(dict(rows[0]))
        item=self.run_inspection(rows);self.assertEqual(item['state'],'AMBIGUOUS_GLOBAL_START_OBSERVATION')

    def test_duplicate_intermediate_not_removed_from_observation_clock(self):
        rows=history(n=32);rows.append(dict(rows[10]))
        item=self.run_inspection(rows)
        self.assertEqual(item['state'],'INVALID_INTERMEDIATE_PRICE');self.assertIsNone(item['actual_pct'])

    def test_invalid_intermediate_price_does_not_get_skipped(self):
        for value in ('NaN',0,-1,'inf','garbage',''):
            rows=history();rows[10]['price']=value
            with self.subTest(value=value):
                item=self.run_inspection(rows)
                self.assertEqual(item['state'],'INVALID_INTERMEDIATE_PRICE');self.assertIsNone(item['actual_pct'])

    def test_future_conflict_and_duplicate_do_not_poison_as_of(self):
        rows=history();extra=history(n=1,instrument_id='other')[0];extra['date']='2026-01-01'
        rows+=[extra,dict(extra)]
        self.assertEqual(self.run_inspection(rows)['actual_pct'],30)

    def test_issuance_requires_aware_valid_time(self):
        for value in ('bad','2025-01-01T12:00:00','2024-12-31T12:00:00+00:00','2026-01-01T12:00:00+00:00'):
            with self.subTest(value=value):
                self.assertEqual(self.run_inspection(history(),forecast(issued_at=value))['state'],'INVALID_GLOBAL_ISSUANCE_TIME')

    def test_legacy_research_lane_still_works(self):
        body=forecast()
        for k in ('provider','provider_id','quote_currency','instrument_id','price_unit_status'):body.pop(k,None)
        rows=[{'asset':'SAME','date':r['date'],'price_eur':r['price']} for r in history()]
        self.assertEqual(self.run_inspection(rows,body)['actual_pct'],30)

    def test_explicit_quotes_never_feed_legacy_symbol_only_join(self):
        body=forecast()
        for k in ('provider','provider_id','quote_currency','instrument_id','price_unit_status'):body.pop(k,None)
        item=self.run_inspection(history(price_eur=999),body)
        self.assertEqual(item['state'],'NO_EXACT_START_OBSERVATION')

    def test_nonfinite_return_blocked(self):
        rows=history();rows[0]['price']=1e-308;rows[30]['price']=1e308
        item=self.run_inspection(rows)
        self.assertEqual(item['state'],'NONFINITE_OBSERVED_RETURN');self.assertIsNone(item['actual_pct'])

    def test_mature_global_reconciliation_does_not_require_account_currency(self):
        body=forecast();self.assertIsNone(body['currency']);self.assertIsNone(body['account_id'])
        item=self.run_inspection(history(),body)
        self.assertEqual(item['actual_pct'],30);self.assertNotIn('currency',item)
        self.assertEqual(item['identity_status'],'CANONICAL_SOURCE_UNATTESTED')

if __name__=='__main__':unittest.main()
