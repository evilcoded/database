"""Exact source/quote daily observation index, for unvalidated research only.

No identity resolution, FX, persistence, calendar-day target or authority changes.
Duplicate dates remain invalid observations instead of disappearing from the clock.
"""
import datetime as dt
import math

UNIT='EXPLICIT_QUOTE_NEUTRAL_VALUES_SOURCE_UNATTESTED'
ORIGIN=('instrument_id','provider','provider_id','quote_currency')


def _text(v):
    return isinstance(v,str) and bool(v) and v==v.strip()


def binding(row):
    if not all(_text(row.get(k)) for k in ORIGIN):return None
    quote=row['quote_currency']
    if not quote.isascii() or not quote.isalpha() or not quote.isupper():return None
    return (row['instrument_id'],row['provider'].lower(),row['provider_id'],quote)


def explicit_origin(row,*,forecast=False):
    if forecast:return any(row.get(k) is not None for k in ('provider','provider_id','quote_currency'))
    return any(row.get(k) not in (None,'') for k in ('provider','provider_id','quote_currency'))


class GlobalObservationIndex:
    def __init__(self):
        self.series={}
        self.duplicates=set()
        self.bindings={}

    def add(self,row,date):
        key=binding(row)
        if key is None:return
        self.bindings.setdefault(key[1:3],set()).add(key[0])
        prices=self.series.setdefault(key,{})
        if date in prices:
            self.duplicates.add((key,date));prices[date]=None;return
        try:
            value=float(row.get('price'))
            if not math.isfinite(value) or value<=0: value=None
        except (TypeError,ValueError,OverflowError):value=None
        # Never substitute price_eur, another source, or another quote.
        prices[date]=value

    def select(self,forecast,date,as_of):
        key=binding(forecast)
        if key is None:return None,'BLOCKED_GLOBAL_IDENTITY_OR_ORIGIN_REQUIRED'
        if forecast.get('price_unit_status')!=UNIT:
            return None,'BLOCKED_GLOBAL_PRICE_UNIT_UNVERIFIED'
        try:
            issued=dt.datetime.fromisoformat(forecast.get('issued_at','').replace('Z','+00:00'))
            if issued.tzinfo is None or issued.utcoffset() is None:raise ValueError()
            issued_date=issued.astimezone(dt.timezone.utc).date()
            if issued_date<date or issued_date>as_of:raise ValueError()
        except (TypeError,ValueError,AttributeError):return None,'INVALID_GLOBAL_ISSUANCE_TIME'
        if len(self.bindings.get(key[1:3],()))>1:
            return None,'BLOCKED_GLOBAL_SOURCE_IDENTITY_CONFLICT'
        prices=self.series.get(key)
        if not prices or date not in prices:return None,'NO_EXACT_GLOBAL_START_OBSERVATION'
        if (key,date) in self.duplicates:return None,'AMBIGUOUS_GLOBAL_START_OBSERVATION'
        return prices,None
