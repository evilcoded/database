import csv,hashlib,importlib.util,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('preflight',Path(__file__).parent/'PORQUINHO_A24_PREFLIGHT_ORIGEM_GLOBAL.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Origin(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
 def put(self,rel,v):
  p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v));return p
 def test_missing_is_not_invented(self):
  out=m.inspect(self.root);self.assertEqual(out['candidate_sources'][m.SOURCES[0]]['status'],'MISSING');self.assertFalse(out['identity_binding_created'])
 def test_explicit_metadata_counted_without_certification(self):
  row={'instrument_id':'GLOBAL:M:C:S','metadata':{'provider':'Provider','provider_id':'id','quote_currency':'USD','provider_binding_attested':True}}
  out,claims=m.survey_source({'instruments':[row]});self.assertEqual(out['counts']['complete_identity_origin_quote_claims'],1);self.assertEqual(out['instrument_id_component_counts'],{'4':1});self.assertEqual(claims[0][2],row['instrument_id'])
 def test_currency_does_not_become_quote(self):
  out,_=m.survey_source({'instrument_id':'a:b:c','provider':'p','provider_id':'id','currency':'EUR'})
  self.assertNotIn('complete_identity_origin_quote_claims',out['counts']);self.assertEqual(out['counts']['currency_present_without_quote_currency'],1)
 def test_legacy_reference_does_not_get_attestation(self):
  out,_=m.survey_source({'instrument_id':'GLOBAL:CRYPTO:CRYPTO:LEGACY','status':'KNOWN_LEGACY_REFERENCE','currency':'EUR'})
  self.assertEqual(out['counts']['complete_provider_claims_declaring_attestation'],0)
 def test_conflicts_across_sources_are_reported(self):
  self.put(m.SOURCES[0],{'instruments':[{'instrument_id':'a:b:c','provider':'p','provider_id':'id'}]})
  self.put(m.SOURCES[1],{'instruments':[{'instrument_id':'a:b:c:d','provider':'P','provider_id':'id'}]})
  self.assertEqual(m.inspect(self.root)['cross_source_claims']['conflicting_provider_keys'],1)
 def test_symlinks_are_not_followed(self):
  p=self.root/m.SOURCES[0];p.parent.mkdir(parents=True);p.symlink_to('/etc/passwd')
  self.assertEqual(m.inspect(self.root)['candidate_sources'][m.SOURCES[0]]['status'],'UNREADABLE_OR_CHANGED')
 def test_does_not_export_individuals(self):
  self.put(m.SOURCES[0],{'instruments':[{'instrument_id':'PRIVATE-ID','provider':'PRIVATE-PROVIDER','provider_id':'PRIVATE-SOURCE','balance':1234567}]})
  out=json.dumps(m.inspect(self.root));self.assertNotIn('PRIVATE-',out);self.assertNotIn('1234567',out)
 def test_project_bytes_preserved(self):
  self.put('brain/reports/history_fetch.json',{'daily_added':0,'errors':[{'secret':'PRIVATE'}]})
  before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};m.inspect(self.root)
  self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_only_existing_source_proves_cadence(self):
  self.put('brain/reports/history_fetch.json',{'daily_added':0})
  p=self.root/'webapp/server.py';p.parent.mkdir();p.write_text('unknown code')
  out=m.inspect(self.root,now=10**10);self.assertFalse(out['history_refresh']['cadence_source_hash_verified']);self.assertIsNone(out['history_refresh']['due_by_existing_mtime_gate'])
 def test_full_command_read_only(self):
  script=Path(__file__).parent/'PORQUINHO_A24_PREFLIGHT_ORIGEM_GLOBAL.command'
  env=dict(os.environ,PORQUINHO_ROOT=str(self.root));r=subprocess.run(['/bin/bash',str(script)],env=env,text=True,capture_output=True,check=True)
  self.assertEqual(json.loads(r.stdout)['status'],'PREFLIGHT_COMPLETE');self.assertFalse(list(self.root.iterdir()))
 def test_audit_guard_rejects_write(self):
  code=(Path(__file__).parent/'PORQUINHO_A24_PREFLIGHT_ORIGEM_GLOBAL.py').read_text()+"\n(Path(sys.argv[1])/'blocked.txt').write_text('bad')\n"
  r=subprocess.run([sys.executable,'-I','-B','-c',code,str(self.root)],text=True,capture_output=True)
  self.assertNotEqual(r.returncode,0);self.assertIn('READ_ONLY_WRITE_REFUSED',r.stderr);self.assertFalse((self.root/'blocked.txt').exists())
if __name__=='__main__':unittest.main()
