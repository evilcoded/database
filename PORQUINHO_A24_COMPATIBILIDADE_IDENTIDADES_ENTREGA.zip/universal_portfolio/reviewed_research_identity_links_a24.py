"""Explicit local research compatibility; never changes financial identities/history."""
import json,os
from .explicit_market_bindings_a24 import local,text
SCHEMA='porquinho.reviewed-research-identity-links-a24/1.0'
PATH='data/instruments/research_identity_links_a24.json'

def index(links):
 if not isinstance(links,(list,tuple)) or len(links)>10000:raise ValueError('RESEARCH_LINK_ROWS_REQUIRED')
 result={};targets=set()
 for row in links:
  if not isinstance(row,dict) or set(row)!={'position_instrument_id','research_instrument_id','evidence_ref'}:raise ValueError('EXPLICIT_RESEARCH_IDENTITY_LINK_REQUIRED')
  source,target,evidence=(row[k] for k in ('position_instrument_id','research_instrument_id','evidence_ref'))
  if not all(text(v) for v in (source,target,evidence)) or source==target or source in result or target in targets:raise ValueError('AMBIGUOUS_RESEARCH_IDENTITY_LINK')
  result[source]=dict(row);targets.add(target)
 if set(result)&targets:raise ValueError('CHAINED_RESEARCH_IDENTITY_LINK_REFUSED')
 return result

def load(root):
 p=local(root,PATH)
 if not p.exists():return []
 stat=p.stat()
 if stat.st_size>2*1024*1024:raise ValueError('RESEARCH_LINK_SIZE_LIMIT')
 raw=p.read_bytes()
 if p.stat().st_mtime_ns!=stat.st_mtime_ns or p.stat().st_size!=stat.st_size:raise ValueError('RESEARCH_LINK_CHANGED_DURING_READ')
 d=json.loads(raw)
 if not isinstance(d,dict) or set(d)!={'schema','scope','links'} or d.get('schema')!=SCHEMA or d.get('scope')!='CURRENT_RESEARCH_VIEW_ONLY':raise ValueError('RESEARCH_LINK_CONTRACT_REQUIRED')
 return list(index(d['links']).values())

def apply(root,links):
 """Record explicitly supplied links, requiring exact current positions and bindings."""
 from .canonical_runtime_read_model import build
 from .explicit_market_bindings_a24 import load as bindings
 from .monitor_consolidation_a24 import position_records,context
 links=list(index(links).values())
 if not links:raise ValueError('EMPTY_RESEARCH_LINK_REVIEW')
 runtime=build(root)
 if runtime.get('authority')!='NONE' or runtime.get('ledger_write') is not False:raise ValueError('READ_MODEL_CONTRACT_REQUIRED')
 positions=position_records(runtime['positions']);sources=bindings(root)['bindings']
 for link in links:
  matched=[p for p in positions if p.get('instrument_id')==link['position_instrument_id'] and context(p)]
  if not matched:raise ValueError('REVIEWED_POSITION_NOT_PRESENT')
  for p in matched:
   if not any(b['instrument_id']==link['research_instrument_id'] and b['quote_currency']==p['currency'] for b in sources):raise ValueError('CONFIRMED_TARGET_QUOTE_BINDING_REQUIRED')
 p=local(root,PATH);p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  if load(root)!=links:raise ValueError('EXISTING_RESEARCH_LINKS_DIFFER_PRESERVED')
  return {'status':'REVIEWED_RESEARCH_LINKS_ALREADY_PRESENT','count':len(links)}
 raw=(json.dumps({'schema':SCHEMA,'scope':'CURRENT_RESEARCH_VIEW_ONLY','links':links},ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
 fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
 except BaseException:
  p.unlink(missing_ok=True);raise
 return {'status':'REVIEWED_RESEARCH_LINKS_RECORDED','count':len(links),'historical_identity_rewritten':False,'financial_authority_created':False}
