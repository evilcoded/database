import copy,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import monitor_consolidation_a24 as m
from universal_portfolio import reviewed_research_identity_links_a24 as l
OLD='OLD:EXACT:INSTRUMENT';NEW='GLOBAL:EXACT:INSTRUMENT'
LINK={'position_instrument_id':OLD,'research_instrument_id':NEW,'evidence_ref':'explicit-case-review'}
class Compatibility(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve()
 def pos(self,**kw):
  d={'instrument_id':OLD,'account_id':'account','currency':'JPY','quantity':'1'};d.update(kw);return d
 def binding(self,**kw):
  d={'instrument_id':NEW,'provider':'provider','provider_id':'exact','quote_currency':'JPY'};d.update(kw);return d
 def project(self,positions=None,bindings=None,observations=None,links=None):return m.project(positions or [self.pos()],bindings or [self.binding()],observations or [],identity_links=[LINK] if links is None else links,canonical_reason='SHADOW')
 def test_explicit_link_matches_preserving_source(self):
  rows,_=self.project(observations=[{**self.binding(),'fetched_at':'now'}]);r=rows[0];self.assertEqual(r['instrument_id'],OLD);self.assertEqual(r['research_instrument_id'],NEW);self.assertEqual(r['research_status'],'CAPTURE_OBSERVED_TODAY');self.assertIsNone(r['recommendation']);self.assertFalse(r['execution_authorized'])
 def test_no_link_no_format_inference(self):self.assertEqual(self.project(links=[])[0][0]['research_status'],'EXPLICIT_SOURCE_BINDING_REQUIRED')
 def test_wrong_quote_refused(self):self.assertEqual(self.project(bindings=[self.binding(quote_currency='USD')])[0][0]['research_status'],'EXPLICIT_SOURCE_BINDING_REQUIRED')
 def test_other_provider_not_joined(self):self.assertEqual(self.project(observations=[{**self.binding(provider_id='other'),'fetched_at':'now'}])[0][0]['research_status'],'AWAITING_NORMAL_CAPTURE_TODAY')
 def test_other_identity_same_suffix_not_joined(self):self.assertEqual(self.project(positions=[self.pos(instrument_id='OTHER:EXACT:INSTRUMENT')])[0][0]['research_status'],'EXPLICIT_SOURCE_BINDING_REQUIRED')
 def test_two_sources_not_selected(self):self.assertEqual(self.project(bindings=[self.binding(),self.binding(provider='other')])[0][0]['research_status'],'SOURCE_SELECTION_REQUIRED')
 def test_direct_old_binding_conflicts(self):self.assertEqual(self.project(bindings=[self.binding(),self.binding(instrument_id=OLD)])[0][0]['research_status'],'SOURCE_SELECTION_REQUIRED')
 def test_old_and_new_same_account_refuse_double_context(self):self.assertTrue(all(r['research_status']=='AMBIGUOUS_POSITION_CONTEXT' for r in self.project(positions=[self.pos(),self.pos(instrument_id=NEW)])[0]))
 def test_separate_accounts_stay_separate(self):self.assertEqual(len(self.project(positions=[self.pos(),self.pos(instrument_id=NEW,account_id='second')])[0]),2)
 def test_decimal_zero_excluded(self):self.assertEqual(len(self.project(positions=[self.pos(),self.pos(instrument_id=NEW,quantity='0.000')])[0]),1)
 def test_inputs_not_mutated(self):
  p=[self.pos()];before=copy.deepcopy(p);self.project(positions=p);self.assertEqual(p,before)
 def test_chain_refused(self):
  with self.assertRaises(ValueError):l.index([LINK,{**LINK,'position_instrument_id':NEW,'research_instrument_id':'THIRD'}])
 def test_duplicate_source_refused(self):
  with self.assertRaises(ValueError):l.index([LINK,LINK])
 def test_duplicate_target_refused(self):
  with self.assertRaises(ValueError):l.index([LINK,{**LINK,'position_instrument_id':'OTHER'}])
 def test_self_link_refused(self):
  with self.assertRaises(ValueError):l.index([{**LINK,'research_instrument_id':OLD}])
 def test_missing_evidence_refused(self):
  with self.assertRaises(ValueError):l.index([{**LINK,'evidence_ref':''}])
 def projected(self,accounts):
  p=self.pos(account_id=None,account_reference='account',account_status='CANONICAL_ACCOUNT_ID_AS_PROJECTED');return m.projected_account_records([p],{'accounts':accounts})[0]
 def test_projected_account_requires_registry(self):self.assertIsNone(m.context(self.projected([])))
 def test_exact_projected_account_supported(self):self.assertEqual(m.context(self.projected([{'account_id':'account','currency':'JPY'}])),(OLD,'account','JPY'))
 def test_wrong_registry_currency_refused(self):self.assertIsNone(m.context(self.projected([{'account_id':'account','currency':'USD'}])))
 def test_duplicate_registry_account_refused(self):self.assertIsNone(m.context(self.projected([{'account_id':'account','currency':'JPY'}]*2)))
 def test_registry_does_not_promote_unresolved_label(self):
  p=self.pos(account_id=None,account_reference='account',account_status='UNRESOLVED');self.assertIsNone(m.context(m.projected_account_records([p],{'accounts':[{'account_id':'account','currency':'JPY'}]})[0]))
 def apply(self,links=None,positions=None,bindings=None):
  from universal_portfolio import canonical_runtime_read_model as runtime,explicit_market_bindings_a24 as b
  with patch.object(runtime,'build',return_value={'authority':'NONE','ledger_write':False,'positions':positions or [self.pos()]}),patch.object(b,'load',return_value={'bindings':bindings or [self.binding()]}):return l.apply(self.root,[LINK] if links is None else links)
 def test_apply_and_repeat_preserve_history(self):
  p=self.root/'history';p.write_bytes(b'original');self.assertEqual(self.apply()['status'],'REVIEWED_RESEARCH_LINKS_RECORDED');self.assertEqual(l.load(self.root),[LINK]);self.assertEqual(self.apply()['status'],'REVIEWED_RESEARCH_LINKS_ALREADY_PRESENT');self.assertEqual(p.read_bytes(),b'original')
 def test_apply_missing_position_refused(self):
  with self.assertRaisesRegex(ValueError,'POSITION_NOT_PRESENT'):self.apply(positions=[self.pos(instrument_id='OTHER')])
 def test_apply_missing_confirmed_quote_refused(self):
  with self.assertRaisesRegex(ValueError,'TARGET_QUOTE'):self.apply(bindings=[self.binding(quote_currency='USD')])
 def test_existing_review_preserved(self):
  self.apply();p=self.root/l.PATH;before=p.read_bytes()
  with self.assertRaisesRegex(ValueError,'DIFFER_PRESERVED'):self.apply(links=[{**LINK,'evidence_ref':'changed'}])
  self.assertEqual(p.read_bytes(),before)
 def test_malformed_local_review_refused(self):
  p=self.root/l.PATH;p.parent.mkdir(parents=True);p.write_text('{}')
  with self.assertRaises(ValueError):l.load(self.root)
 def test_symlink_local_review_refused(self):
  p=self.root/l.PATH;p.parent.mkdir(parents=True);outside=self.root/'other';outside.write_text('{}');p.symlink_to(outside)
  with self.assertRaises(ValueError):l.load(self.root)
 def test_read_absent_does_not_write(self):self.assertEqual(l.load(self.root),[]);self.assertEqual(list(self.root.iterdir()),[])

 def test_read_model_registry_integration_excludes_decimal_zero(self):
  p=self.root/'data/institution_accounts.json';p.parent.mkdir();p.write_text(json.dumps({'accounts':[{'account_id':'account','currency':'JPY'}]}))
  positions=[self.pos(account_id=None,account_reference='account',account_status='CANONICAL_ACCOUNT_ID_AS_PROJECTED'),self.pos(quantity='0.000')]
  out=m.inspect(self.root,runtime_reader=lambda root:{'authority':'NONE','ledger_write':False,'positions':positions})
  self.assertEqual(out['position_record_count'],2);self.assertEqual(out['excluded_zero_position_count'],1);self.assertEqual(out['positions'][0]['account_id'],'account')
 def test_corrupt_local_link_makes_diagnostic_partial(self):
  p=self.root/l.PATH;p.parent.mkdir(parents=True);p.write_text('{}')
  out=m.inspect(self.root,runtime_reader=lambda root:{'authority':'NONE','ledger_write':False,'positions':[self.pos()]})
  self.assertEqual(out['status'],'PARTIAL_READ_ONLY_OBSERVATION');self.assertEqual(out['positions'][0]['research_status'],'SOURCE_INSPECTION_UNAVAILABLE');self.assertTrue(any(i['source']=='reviewed_research_identity_links' for i in out['issues']))
 def test_generic_multi_instrument_multi_currency_view(self):
  pairs=[{'position_instrument_id':'LEGACY:'+str(i),'research_instrument_id':'UNIVERSAL:'+str(i),'evidence_ref':'case:'+str(i)} for i in range(4)]
  positions=[self.pos(instrument_id=x['position_instrument_id']) for x in pairs]+[self.pos(instrument_id='ALREADY:GLOBAL',currency='CHF'),self.pos(instrument_id='CLOSED',quantity='0.00')]
  bindings=[self.binding(instrument_id=x['research_instrument_id']) for x in pairs]+[self.binding(instrument_id='ALREADY:GLOBAL',quote_currency='CHF')]
  observations=[{**b,'fetched_at':'now'} for b in bindings]
  rows,counts=m.project(positions,bindings,observations,canonical_reason='SHADOW',identity_links=pairs)
  self.assertEqual(counts,{'CAPTURE_OBSERVED_TODAY':5});self.assertEqual([r['instrument_id'] for r in rows],[p['instrument_id'] for p in positions[:-1]]);self.assertTrue(all(r['recommendation'] is None for r in rows))
