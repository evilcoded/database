"""Pure tariff arithmetic for research; no network, store, order or authority."""
from decimal import Decimal, localcontext
from urllib.parse import urlsplit
from .account_cost_evidence_a24 import COMPONENTS, SCOPE, CostError, number, timestamp

SCHEMA = 'porquinho.official-tariff-provision-a24/1.0'

def provision(contract, query, *, now):
    if not isinstance(contract, dict) or contract.get('schema') != SCHEMA:
        raise CostError('OFFICIAL_TARIFF_CONTRACT_REQUIRED')
    if contract.get('applicability_confirmed') is not True:
        raise CostError('ACCOUNT_PLAN_PRODUCT_CHANNEL_APPLICABILITY_REQUIRED')
    if not isinstance(query, dict) or query.get('side') not in ('BUY', 'SELL'):
        raise CostError('EXPLICIT_BUY_OR_SELL_SIDE_REQUIRED')
    scope = (*[k for k in SCOPE if k != 'reference_amount'], 'pricing_plan', 'product', 'channel')
    for key in scope:
        v = query.get(key)
        if not isinstance(v, str) or not v.strip() or contract.get(key) != v:
            raise CostError('EXACT_TARIFF_SCOPE_REQUIRED:' + key)
    currency = query['currency']
    if not currency.isascii() or not currency.isalpha() or not currency.isupper() or len(currency) > 16:
        raise CostError('EXPLICIT_UPPERCASE_CURRENCY_REQUIRED')
    source = contract.get('source', {})
    try:
        url = urlsplit(source['url'])
        valid_url = url.scheme == 'https' and url.hostname and not url.username and not url.password
    except (KeyError, TypeError, ValueError):
        valid_url = False
    if not valid_url or source.get('kind') != 'OFFICIAL_BANK_TARIFF' or source.get('official_source_verified') is not True:
        raise CostError('VERIFIED_OFFICIAL_HTTPS_SOURCE_REQUIRED')
    for field in ('document_sha256',):
        value = source.get(field)
        if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise CostError('SOURCE_DOCUMENT_SHA256_REQUIRED')
    start, end = timestamp(contract.get('effective_from')), timestamp(contract.get('effective_until'))
    observed = timestamp(source.get('observed_at'))
    if not start <= now < end or observed > now:
        raise CostError('CURRENT_TARIFF_VALIDITY_REQUIRED')
    raw = contract.get('components')
    if not isinstance(raw, dict) or set(raw) != set(COMPONENTS):
        raise CostError('ALL_COST_COMPONENT_STATUSES_REQUIRED')
    principal = number(query.get('reference_amount'), True)
    result = {}
    with localcontext() as ctx:
        ctx.prec = 200
        for name in COMPONENTS:
            rule = raw[name]
            if not isinstance(rule, dict) or rule.get('currency') != currency:
                raise CostError('TARIFF_COMPONENT_CURRENCY_MISMATCH')
            status = rule.get('status')
            if status not in ('KNOWN', 'UNKNOWN', 'NOT_APPLICABLE'):
                raise CostError('COST_COMPONENT_STATUS_REQUIRED')
            if status != 'UNKNOWN' and not isinstance(rule.get('evidence_ref'), str):
                raise CostError('COMPONENT_APPLICABILITY_EVIDENCE_REQUIRED')
            if status != 'UNKNOWN' and not rule['evidence_ref'].strip():
                raise CostError('COMPONENT_APPLICABILITY_EVIDENCE_REQUIRED')
            if status != 'KNOWN':
                if any(rule.get(k) is not None for k in ('fixed_amount', 'rate_pct', 'minimum_amount', 'maximum_amount')):
                    raise CostError('UNKNOWN_OR_INAPPLICABLE_FORMULA_FORBIDDEN')
                result[name] = {'status': status, 'amount': None}
                continue
            if rule.get('formula') != 'FIXED_PLUS_PERCENT_THEN_CLAMP':
                raise CostError('EXPLICIT_TARIFF_FORMULA_REQUIRED')
            fixed, rate = number(rule.get('fixed_amount')), number(rule.get('rate_pct'))
            low = number(rule['minimum_amount']) if rule.get('minimum_amount') is not None else None
            high = number(rule['maximum_amount']) if rule.get('maximum_amount') is not None else None
            if low is not None and high is not None and low > high:
                raise CostError('TARIFF_MINIMUM_EXCEEDS_MAXIMUM')
            value = fixed + principal * rate / Decimal('100')
            if low is not None: value = max(value, low)
            if high is not None: value = min(value, high)
            result[name] = {'status': status, 'amount': str(value), 'evidence_ref': rule['evidence_ref']}
        subtotal = sum((Decimal(r['amount']) for r in result.values() if r['status'] == 'KNOWN'), Decimal(0))
    missing = [k for k, v in result.items() if v['status'] == 'UNKNOWN']
    return {'schema': SCHEMA, 'status': 'PARTIAL_OFFICIAL_TARIFF_PROVISION' if missing else 'OFFICIAL_TARIFF_PROVISION_NOT_EXECUTION_QUOTE',
            'currency': currency, 'reference_amount': str(principal), 'components': result,
            'known_cost_subtotal': str(subtotal), 'total_cost': None if missing else str(subtotal),
            'missing_components': missing, 'source_url': source['url'], 'source_document_sha256': source['document_sha256'],
            'actual_fill_cost': False, 'bank_quote_obtained': False, 'independent_attestation': False,
            'recommendation_created': False, 'sizing_created': False, 'execution_authorized': False,
            'financial_mutation': False, 'history_write_performed': False, 'training_requested': False}
