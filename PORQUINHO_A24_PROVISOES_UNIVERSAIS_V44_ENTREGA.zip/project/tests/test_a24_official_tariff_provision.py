import copy
import datetime as dt
import unittest
from universal_portfolio.official_tariff_provision_a24 import provision, SCHEMA
from universal_portfolio.account_cost_evidence_a24 import COMPONENTS, CostError

class TariffTests(unittest.TestCase):
    def setUp(self):
        self.now=dt.datetime(2026,10,19,tzinfo=dt.timezone.utc)
        self.query=dict(account_id='account-fixture',institution_id='institution-fixture',institution_country='ZZ',instrument_id='arbitrary-instrument',currency='JPY',execution_venue_id='venue-fixture',side='BUY',reference_amount='200',pricing_plan='plan-fixture',product='product-fixture',channel='app')
        self.contract={**self.query,'schema':SCHEMA,'applicability_confirmed':True,'effective_from':'2026-10-01T00:00:00+00:00','effective_until':'2026-11-01T00:00:00+00:00',
        'source':{'url':'https://example.invalid/tariff','kind':'OFFICIAL_BANK_TARIFF','official_source_verified':True,'document_sha256':'a'*64,'observed_at':'2026-10-18T00:00:00+00:00'},
        'components':{k:{'status':'NOT_APPLICABLE','currency':'JPY','evidence_ref':'synthetic-evidence'} for k in COMPONENTS}}
        self.contract['components']['brokerage']={'status':'KNOWN','currency':'JPY','evidence_ref':'synthetic-evidence','formula':'FIXED_PLUS_PERCENT_THEN_CLAMP','fixed_amount':'1','rate_pct':'2','minimum_amount':'3','maximum_amount':'8'}
    def run_case(self):return provision(self.contract,self.query,now=self.now)
    def test_fixed_plus_percent(self):self.assertEqual(self.run_case()['total_cost'],'5')
    def test_minimum(self):
        self.query['reference_amount']='1';self.assertEqual(self.run_case()['total_cost'],'3')
    def test_maximum(self):
        self.query['reference_amount']='10000';self.assertEqual(self.run_case()['total_cost'],'8')
    def test_unknown_spread_keeps_total_unknown(self):
        self.contract['components']['spread']={'status':'UNKNOWN','currency':'JPY'}
        r=self.run_case();self.assertIsNone(r['total_cost']);self.assertEqual(r['known_cost_subtotal'],'5');self.assertEqual(r['missing_components'],['spread'])
    def test_no_mutation_or_authority(self):
        before=copy.deepcopy((self.contract,self.query));r=self.run_case();self.assertEqual(before,(self.contract,self.query))
        for key in ('bank_quote_obtained','recommendation_created','sizing_created','execution_authorized','financial_mutation','history_write_performed','training_requested'):self.assertIs(r[key],False)
    def test_every_scope_field_matters(self):
        for key in ('account_id','institution_id','institution_country','instrument_id','currency','execution_venue_id','side','pricing_plan','product','channel'):
            with self.subTest(key=key):
                c=copy.deepcopy(self.contract);c[key]='other'
                with self.assertRaises(CostError):provision(c,self.query,now=self.now)
    def test_expired_and_future_sources(self):
        self.contract['effective_until']='2026-10-19T00:00:00+00:00'
        with self.assertRaises(CostError):self.run_case()
        self.contract['effective_until']='2026-11-01T00:00:00+00:00';self.contract['source']['observed_at']='2026-10-20T00:00:00+00:00'
        with self.assertRaises(CostError):self.run_case()
    def test_unverified_source_refused(self):
        self.contract['source']['official_source_verified']=False
        with self.assertRaises(CostError):self.run_case()
    def test_no_implicit_plan_applicability(self):
        self.contract['applicability_confirmed']=False
        with self.assertRaises(CostError):self.run_case()
    def test_bad_source_urls(self):
        for url in ('http://example.invalid','https://user:pass@example.invalid','not a url'):
            self.contract['source']['url']=url
            with self.assertRaises(CostError):self.run_case()
    def test_invalid_rates_and_limits(self):
        for value in ('NaN','Infinity','-1',True):
            self.contract['components']['brokerage']['rate_pct']=value
            with self.assertRaises(CostError):self.run_case()
        self.contract['components']['brokerage']['rate_pct']='2';self.contract['components']['brokerage']['minimum_amount']='9'
        with self.assertRaises(CostError):self.run_case()
    def test_missing_component_is_not_zero(self):
        del self.contract['components']['slippage']
        with self.assertRaises(CostError):self.run_case()
    def test_universal_currency_and_identity(self):
        for currency in ('BRL','EUR','USD','CHF','XAU'):
            q={**self.query,'currency':currency,'instrument_id':'universal:'+currency};c=copy.deepcopy(self.contract);c.update(q)
            for r in c['components'].values():r['currency']=currency
            self.assertEqual(provision(c,q,now=self.now)['total_cost'],'5')
    def test_unknown_cannot_hide_explicit_zero(self):
        self.contract['components']['slippage']={'status':'UNKNOWN','currency':'JPY','fixed_amount':'0'}
        with self.assertRaises(CostError):self.run_case()
    def test_decimal_precision(self):
        self.query['reference_amount']='0.1';r=self.contract['components']['brokerage'];r.update(fixed_amount='0',rate_pct='0.1',minimum_amount=None,maximum_amount=None)
        self.assertEqual(self.run_case()['total_cost'],'0.0001')
if __name__=='__main__':unittest.main()
