"""Read-only simulation of an explicitly reviewed official tariff contract."""
import datetime as dt
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from universal_portfolio.official_tariff_provision_a24 import provision
from universal_portfolio.account_cost_evidence_a24 import accounts, current_scope

def main():
    if len(sys.argv) != 4:
        raise SystemExit('Uso: python tools/simulate_official_tariff_a24.py ROOT CONTRATO.json CONSULTA.json')
    root = Path(sys.argv[1]).resolve()
    def read(path):
        p = Path(path)
        if p.is_symlink() or p.stat().st_size > 1024 * 1024: raise ValueError('INPUT_REFUSED')
        return json.loads(p.read_bytes())
    contract, query = read(sys.argv[2]), read(sys.argv[3])
    registered, _ = accounts(root)
    current_scope(query, registered)
    result = provision(contract, query, now=dt.datetime.now(dt.timezone.utc))
    print(json.dumps(result, ensure_ascii=False, indent=2))
if __name__ == '__main__': main()
