import importlib.util,json,tempfile,unittest,datetime as dt,sys
from pathlib import Path
from unittest.mock import patch
sys.path[:0]=['/workspace/porquinho-a24/project','/workspace/porquinho-a24/project/tests']
from universal_portfolio import explicit_market_bindings_a24 as b
from universal_portfolio import binding_review_queue_a24 as queue
from universal_portfolio import funded_currency_research_a24 as funding
spec=importlib.util.spec_from_file_location('verified_registration',Path(__file__).with_name('PORQUINHO_A24_VERIFICAR_CADASTRAR_FONTES.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
NOW=dt.datetime.now(dt.timezone.utc)
IID='ANY:UNCHANGED:IDENTITY'
class Transport:
 def __init__(self):self.calls=[];self.response={'exact-provider-id':{'brl':10,'eur':2,'last_updated_at':int(NOW.timestamp())}}
 def get_json(self,path,params,timeout):self.calls.append((path,params));return ['brl','eur','jpy'] if path.endswith('supported_vs_currencies') else self.response
class Verified(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();(self.root/'data/instruments').mkdir(parents=True);(self.root/'data/universal_instrument_catalog.json').write_text(json.dumps({'instruments':[{'instrument_id':IID}]}));self.transport=Transport()
  self.doc={'schema':m.SCHEMA,'confirmed':True,'provider':'CoinGecko','instruments':[{'instrument_id':IID,'provider_id':'exact-provider-id','quote_currencies':['BRL','EUR']}]}
 def current(self,root):
  d=funding.project(cash=[{'account_id':'a'+q,'currency':q,'amount':'100'} for q in ['BRL','EUR','JPY']],registry={'accounts':[{'account_id':'a'+q,'institution_id':'bank','currency':q} for q in ['BRL','EUR','JPY']],'institutions':[{'institution_id':'bank','country':'ANY'}]},candidates=[{'instrument_id':IID,'asset_class':'ANY_CLASS'}])
  return queue.build(root,d,now=NOW)
 def run_verify(self,**kwargs):
  args={'transport':self.transport,'now':NOW,'queue_reader':self.current};args.update(kwargs);return m.verify_and_apply(self.root,self.doc,**args)
 def registry(self):return b.load(self.root)['bindings']
 def test_two_confirmed_quotes_append_only_after_two_gets(self):
  out=self.run_verify();self.assertEqual(out['new_binding_count'],2);self.assertEqual(len(self.registry()),2);self.assertEqual(len(self.transport.calls),2);self.assertEqual({x['quote_currency'] for x in self.registry()},{'BRL','EUR'})
 def test_missing_price_prevents_entire_batch(self):
  self.transport.response['exact-provider-id'].pop('eur')
  with self.assertRaisesRegex(m.VerificationError,'PRICE_NOT_AVAILABLE'):self.run_verify()
  self.assertFalse((self.root/b.REGISTRY).exists())
 def test_unsupported_currency_no_price_request(self):
  self.doc['instruments'][0]['quote_currencies']=['CHF']
  # Pair must also have a current demand before the provider is queried.
  with self.assertRaisesRegex(m.VerificationError,'FUNDED_DEMAND'):self.run_verify()
  self.assertFalse(self.transport.calls)
 def test_supported_arbitrary_currency_no_fixed_list(self):
  self.doc['instruments'][0]['quote_currencies']=['JPY'];self.transport.response['exact-provider-id']['jpy']=99;out=self.run_verify();self.assertEqual(out['new_binding_count'],1)
 def test_identity_absent_from_current_demand_refused_before_get(self):
  self.doc['instruments'][0]['instrument_id']='DIFFERENT:ID'
  with self.assertRaisesRegex(m.VerificationError,'FUNDED_DEMAND'):self.run_verify()
  self.assertFalse(self.transport.calls)
 def test_unconfirmed_document_refused(self):
  self.doc['confirmed']=False
  with self.assertRaisesRegex(m.VerificationError,'CONFIRMATION'):self.run_verify()
  self.assertFalse(self.transport.calls)
 def test_invalid_or_injected_provider_id_refused(self):
  self.doc['instruments'][0]['provider_id']='one,two'
  with self.assertRaisesRegex(m.VerificationError,'PROVIDER_ID'):self.run_verify()
 def test_invalid_prices_refused(self):
  for value in (True,0,-1,'10',float('nan'),float('inf')):
   self.transport.response['exact-provider-id']['brl']=value
   with self.assertRaisesRegex(m.VerificationError,'PRICE_NOT_AVAILABLE'):self.run_verify()
  self.assertFalse((self.root/b.REGISTRY).exists())
 def test_stale_or_future_price_refused(self):
  for offset in (-1900,60):
   self.transport.response['exact-provider-id']['last_updated_at']=int(NOW.timestamp())+offset
   with self.assertRaisesRegex(m.VerificationError,'STALE_OR_FUTURE'):self.run_verify()
 def test_repeated_success_does_not_requery_or_duplicate(self):
  self.run_verify();count=len(self.transport.calls);out=self.run_verify();self.assertEqual(out['status'],'CONFIRMED_BINDINGS_ALREADY_PRESENT');self.assertEqual(count,len(self.transport.calls));self.assertEqual(len(self.registry()),2)
 def test_existing_bindings_preserved_with_backup(self):
  prior={'instrument_id':IID,'provider':'CoinGecko','provider_id':'exact-provider-id','quote_currency':'BRL','identity_source_ref':'prior-reviewed','confirmed_by':'local','confirmed_at':(NOW-dt.timedelta(days=1)).isoformat(),'effective_from':NOW.date().isoformat()};(self.root/b.REGISTRY).write_text(b.canonical({'schema':b.SCHEMA,'bindings':[prior]}));before=(self.root/b.REGISTRY).read_bytes();out=self.run_verify();self.assertEqual(out['new_binding_count'],1);self.assertEqual(self.registry()[0],prior);self.assertEqual(next((self.root/'data/instruments').glob('*.backup_*')).read_bytes(),before)
 def test_existing_other_source_not_replaced(self):
  prior={'instrument_id':IID,'provider':'Other','provider_id':'other','quote_currency':'BRL','identity_source_ref':'prior','confirmed_by':'local','confirmed_at':(NOW-dt.timedelta(days=1)).isoformat(),'effective_from':NOW.date().isoformat()};(self.root/b.REGISTRY).write_text(b.canonical({'schema':b.SCHEMA,'bindings':[prior]}))
  with self.assertRaisesRegex(m.VerificationError,'CONFLICT'):self.run_verify()
  self.assertFalse(self.transport.calls)
 def test_queue_change_prevents_registration(self):
  calls=0
  def changing(root):
   nonlocal calls
   calls+=1;out=self.current(root)
   if calls>1:out['queue_digest']='changed'
   return out
  with self.assertRaisesRegex(m.VerificationError,'CONTEXT_CHANGED'):self.run_verify(queue_reader=changing)
  self.assertFalse((self.root/b.REGISTRY).exists())
 def test_source_http_failure_preserves_registry(self):
  with patch.object(self.transport,'get_json',side_effect=RuntimeError('HTTP unavailable')):
   with self.assertRaises(RuntimeError):self.run_verify()
  self.assertFalse((self.root/b.REGISTRY).exists())
 def test_no_history_model_snapshot_or_observation_write(self):
  p=self.root/'results/latest.json';p.parent.mkdir();p.write_bytes(b'untouched');out=self.run_verify();self.assertEqual(p.read_bytes(),b'untouched');self.assertFalse((self.root/'data/brain').exists());self.assertFalse(out['observations_written_by_command']);self.assertNotIn('"brl": 10',json.dumps(out))
 def test_duplicate_quotes_and_conflicting_identity_mapping_refused(self):
  self.doc['instruments'][0]['quote_currencies']=['BRL','BRL']
  with self.assertRaisesRegex(m.VerificationError,'QUOTE_LIST'):self.run_verify()
 def test_missing_timestamp_refused(self):
  self.transport.response['exact-provider-id'].pop('last_updated_at')
  with self.assertRaisesRegex(m.VerificationError,'TIMESTAMP_REQUIRED'):self.run_verify()
 def test_price_other_id_cannot_satisfy_confirmation(self):
  self.transport.response={'other-id':self.transport.response['exact-provider-id']}
  with self.assertRaisesRegex(m.VerificationError,'PRICE_NOT_AVAILABLE'):self.run_verify()
 def test_unsupported_provider_quote_refuses_entire_batch_before_price_get(self):
  original=self.transport.get_json
  def limited(path,params,timeout):
   if path.endswith('supported_vs_currencies'):
    self.transport.calls.append((path,params));return ['brl']
   return original(path,params,timeout)
  with patch.object(self.transport,'get_json',side_effect=limited):
   with self.assertRaisesRegex(m.VerificationError,'NOT_SUPPORTED'):self.run_verify()
  self.assertEqual(len(self.transport.calls),1);self.assertFalse((self.root/b.REGISTRY).exists())
 def test_full_command_entrypoint_with_mock_provider_and_private_report(self):
  import hashlib,io,os,shutil
  from contextlib import redirect_stdout
  source=Path(__file__).with_name('PORQUINHO_A24_VALIDAR_E_CADASTRAR_FONTES.command').read_text().split("<<'A24_VERIFIED_SOURCE'\n",1)[1].rsplit('\nA24_VERIFIED_SOURCE',1)[0]
  import ast
  tree=ast.parse(source);expected=next(ast.literal_eval(n.value) for block in tree.body if isinstance(block,ast.If) for n in block.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='EXPECTED' for t in n.targets))
  for rel in expected:
   p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path('/workspace/porquinho-a24/project')/rel,p)
  with tempfile.TemporaryDirectory() as tmp:
   home=Path(tmp);confirmation=home/'confirmed.json';confirmation.write_text(json.dumps(self.doc));digest=hashlib.sha256(confirmation.read_bytes()).hexdigest()
   with patch.object(sys,'argv',['command',str(self.root),str(confirmation),digest]),patch.object(Path,'home',return_value=home),patch('tools.review_funded_bindings_a24.current',side_effect=self.current),patch('universal_portfolio.research_quote_acquisition_a24.CoinGeckoTransport',return_value=self.transport),patch.object(self.transport,'close',create=True),redirect_stdout(io.StringIO()):exec(compile(source,'registration_command','exec'),{'__name__':'__main__'})
   reports=list((home/'Downloads').glob('*.json'));self.assertEqual(len(reports),1);report=json.loads(reports[0].read_text());self.assertEqual(report['new_binding_count'],2);self.assertEqual(report['network_requests'],2);self.assertNotIn('"brl": 10',reports[0].read_text())
if __name__=='__main__':unittest.main()
