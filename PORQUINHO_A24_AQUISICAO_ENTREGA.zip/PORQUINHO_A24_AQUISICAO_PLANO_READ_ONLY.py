import sys,os,json
from pathlib import Path
root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root))
def guard(event,args):
 if event=='open':
  mode,flags=args[1:3]
  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
 if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
sys.addaudithook(guard)
try:
 from universal_portfolio.universal_observation_bridge import build_read_only_bridge
 from universal_portfolio.research_quote_acquisition_a24 import plan
 demand=build_read_only_bridge(root).intelligence.get('funded_currency_research') or {}
 out=plan(root,demand)
 print(json.dumps({'validation':'A24_RESEARCH_ACQUISITION_PLAN_READ_ONLY','status':out['status'],
   'eligible_source_job_count':len(out['jobs']),'blocked_reason_counts':out['blocked_reason_counts'],
   'already_observed_request_count':out['already_observed_request_count'],'network_requests':0,
   'market_observations_written':False,'training_requested':False,'financial_mutation':False,
   'services_restarted':False,'automatic_execution_authorized':False,'canonical_publication_authorized':False},indent=2))
except Exception as exc:
 print(json.dumps({'validation':'A24_RESEARCH_ACQUISITION_PLAN_READ_ONLY','status':'PLAN_UNAVAILABLE','error':type(exc).__name__,'network_requests':0,'financial_mutation':False,'automatic_execution_authorized':False},indent=2))
