import ast,copy,datetime as dt,hashlib,json,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import research_quote_acquisition_a24 as q
from universal_portfolio import funded_currency_research_a24 as funding
from universal_portfolio import explicit_market_bindings_a24 as bindings

ROOT=Path(__file__).resolve().parents[1]
NOW=dt.datetime(2026,10,16,12,tzinfo=dt.timezone.utc)
IID='GLOBAL:MARKET:CLASS:INSTRUMENT'

class Transport:
 def __init__(self,now=NOW,quotes=None,supported=None):
  self.calls=[];self.now=now;self.quotes=quotes if quotes is not None else {'source-id':{'brl':Decimal('100.25'),'eur':Decimal('20.5'),'last_updated_at':int(now.timestamp())}};self.supported=supported if supported is not None else ['brl','eur','usd','jpy']
 def get_json(self,path,params,timeout):
  self.calls.append((path,params,timeout));return self.supported if path.endswith('supported_vs_currencies') else self.quotes
from decimal import Decimal
class Acquisition(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  (self.root/'data/instruments').mkdir(parents=True);(self.root/'data/universal_instrument_catalog.json').write_text(json.dumps({'instruments':[{'instrument_id':IID}]}))
  self.transport=Transport()
 def rows(self,**change):
  row={'instrument_id':IID,'provider':'CoinGecko','provider_id':'source-id','quote_currency':'BRL','identity_source_ref':'explicit-test-source','confirmed_by':'reviewer','confirmed_at':'2026-10-15T00:00:00+00:00','effective_from':'2026-10-16'};row.update(change);return row
 def save(self,rows):bindings.local(self.root,bindings.REGISTRY).write_text(bindings.canonical({'schema':bindings.SCHEMA,'bindings':rows}))
 def demand(self,currencies=('BRL',),duplicate_account=False):
  accounts=[{'account_id':'account-'+c,'institution_id':'bank','currency':c} for c in currencies]
  cash=[{'account_id':a['account_id'],'currency':a['currency'],'amount':'100'} for a in accounts]
  if duplicate_account:accounts.append({'account_id':'second','institution_id':'bank','currency':currencies[0]});cash.append({'account_id':'second','currency':currencies[0],'amount':'10'})
  return funding.project(cash=cash,registry={'accounts':accounts,'institutions':[{'institution_id':'bank','country':'PT'}]},candidates=[{'instrument_id':IID,'asset_class':'CRYPTO'}])
 def collect(self,d=None,**kw):
  d=d or self.demand();current={(c['account_id'],c['currency'],c['context_fingerprint']) for c in d['contexts']}
  args={'now':NOW,'transport':self.transport,'revalidate':lambda:current};args.update(kw)
  return q.collect(self.root,d,**args)
 def test_pending_127_demands_do_not_call_provider_or_create_data(self):
  d=self.demand();d['research_requests']*=127;out=self.collect(d)
  self.assertEqual(out['blocked_reason_counts'],{'EXPLICIT_PROVIDER_QUOTE_BINDING_REQUIRED':127});self.assertEqual(out['network_requests'],0);self.assertFalse(self.transport.calls);self.assertFalse((self.root/'data/brain').exists())
 def test_explicit_two_quotes_record_two_separate_contexts(self):
  self.save([self.rows(),self.rows(quote_currency='EUR')]);out=self.collect(self.demand(('BRL','EUR')))
  self.assertEqual(out['observations_created'],2);rows=q.read_records(self.root);self.assertEqual({r['quote_currency'] for r in rows},{'BRL','EUR'});self.assertEqual({r['instrument_id'] for r in rows},{IID})
  self.assertEqual({r['price'] for r in rows},{'100.25','20.5'});self.assertEqual(self.transport.calls[-1][1]['vs_currencies'],'brl,eur')
 def test_duplicate_accounts_share_market_observation(self):
  self.save([self.rows()]);out=self.collect(self.demand(duplicate_account=True));self.assertEqual(out['observations_created'],1)
 def test_repeat_day_is_idempotent_and_avoids_network(self):
  self.save([self.rows()]);self.collect();p=q.storage_path(self.root,NOW.date());before=p.read_bytes();calls=len(self.transport.calls)
  out=self.collect();self.assertEqual(out['network_requests'],0);self.assertEqual(len(self.transport.calls),calls);self.assertEqual(before,p.read_bytes())
 def test_next_day_appends_preserving_existing_bytes(self):
  self.save([self.rows()]);self.collect();p=q.storage_path(self.root,NOW.date());before=p.read_bytes();tomorrow=NOW+dt.timedelta(days=1)
  out=self.collect(now=tomorrow,transport=Transport(now=tomorrow));self.assertEqual(out['observations_created'],1);self.assertEqual(p.read_bytes(),before);self.assertEqual(len(q.read_records(self.root)),2);self.assertTrue(q.storage_path(self.root,tomorrow.date()).is_file())
 def test_requested_currency_never_substituted(self):
  self.save([self.rows()]);out=self.collect(transport=Transport(quotes={'source-id':{'eur':20,'last_updated_at':int(NOW.timestamp())}}))
  self.assertEqual(out['observations_created'],0);self.assertFalse(bindings.local(self.root,q.STORE).exists())
 def test_unsupported_currency_explicit_no_fallback(self):
  self.save([self.rows()]);out=self.collect(transport=Transport(supported=['eur']))
  self.assertEqual(out['status'],'PROVIDER_QUOTES_UNAVAILABLE');self.assertEqual(out['network_requests'],1);self.assertEqual(out['observations_created'],0)
 def test_provider_without_adapter_does_not_default_to_coingecko(self):
  self.save([self.rows(provider='OtherProvider')]);out=self.collect();self.assertEqual(out['blocked_reason_counts'],{'PROVIDER_ADAPTER_NOT_IMPLEMENTED':1});self.assertFalse(self.transport.calls)
 def test_future_binding_does_not_start_collection(self):
  self.save([self.rows(effective_from='2026-10-17')]);out=self.collect();self.assertEqual(out['blocked_reason_counts'],{'BINDING_NOT_EFFECTIVE':1});self.assertFalse(self.transport.calls)
 def test_ambiguous_sources_require_choice(self):
  self.save([self.rows(),self.rows(provider='AnotherProvider',provider_id='another')]);out=self.collect();self.assertEqual(out['blocked_reason_counts'],{'EXPLICIT_SOURCE_SELECTION_REQUIRED':1});self.assertFalse(self.transport.calls)
 def test_untrusted_source_candidates_in_request_do_not_grant_binding(self):
  d=self.demand();d['research_requests'][0]['source_candidates']=[self.rows()];out=self.collect(d);self.assertEqual(out['network_requests'],0)
 def test_funding_fingerprint_change_blocks_before_http(self):
  self.save([self.rows()]);out=self.collect(revalidate=lambda:set());self.assertEqual(out['reason'],'FUNDING_CONTEXT_CHANGED');self.assertEqual(out['network_requests'],0)
 def test_funding_change_during_http_blocks_recording(self):
  self.save([self.rows()]);d=self.demand();current={(c['account_id'],c['currency'],c['context_fingerprint']) for c in d['contexts']};answers=iter([current,set()])
  out=self.collect(d,revalidate=lambda:next(answers));self.assertEqual(out['observations_created'],0);self.assertEqual(out['reason'],'FUNDING_OR_BINDING_CHANGED_BEFORE_RECORDING');self.assertFalse(bindings.local(self.root,q.STORE).exists())
 def test_binding_change_during_http_blocks_recording(self):
  self.save([self.rows()]);d=self.demand();calls=0;current={(c['account_id'],c['currency'],c['context_fingerprint']) for c in d['contexts']}
  def revalidate():
   nonlocal calls
   calls+=1
   if calls==2:self.save([self.rows(identity_source_ref='changed')])
   return current
  out=self.collect(d,revalidate=revalidate);self.assertEqual(out['observations_created'],0);self.assertFalse(bindings.local(self.root,q.STORE).exists())
 def test_invalid_prices_are_not_recorded(self):
  self.save([self.rows()])
  for price in (True,0,-1,'100','NaN',float('inf')):
   with self.subTest(price=price):
    out=self.collect(transport=Transport(quotes={'source-id':{'brl':price,'last_updated_at':int(NOW.timestamp())}}));self.assertEqual(out['observations_created'],0)
 def test_stale_future_and_previous_day_are_not_recorded(self):
  self.save([self.rows()])
  for delta in (-1900,60,-86400):
   with self.subTest(delta=delta):
    out=self.collect(transport=Transport(quotes={'source-id':{'brl':100,'last_updated_at':int(NOW.timestamp())+delta}}));self.assertEqual(out['observations_created'],0)
 def test_http_error_does_not_export_response_or_credentials(self):
  self.save([self.rows()])
  with patch.object(self.transport,'get_json',side_effect=RuntimeError('SECRET-CREDENTIAL')):out=self.collect()
  self.assertEqual(out['reason'],'RuntimeError');self.assertNotIn('SECRET',json.dumps(out));self.assertFalse(bindings.local(self.root,q.STORE).exists())
 def test_store_is_not_legacy_market_csv_or_forecast_store(self):
  self.save([self.rows()]);legacy=self.root/'data/database/market_daily.csv';legacy.parent.mkdir();legacy.write_bytes(b'original-market-bytes')
  self.collect();self.assertEqual(legacy.read_bytes(),b'original-market-bytes');self.assertFalse((self.root/'data/brain/prospective').exists())
 def test_corrupt_observation_chain_blocks_future_collection(self):
  self.save([self.rows()]);self.collect();p=q.storage_path(self.root,NOW.date());p.write_text(p.read_text().replace('100.25','101.25'));before=p.read_bytes();calls=len(self.transport.calls)
  out=self.collect();self.assertEqual(out['status'],'ACQUISITION_FAILED_CLOSED');self.assertEqual(p.read_bytes(),before);self.assertEqual(len(self.transport.calls),calls)
 def test_flags_never_promote_or_authorize(self):
  self.save([self.rows()]);out=self.collect();r=q.read_records(self.root)[0]
  self.assertEqual(r['authority'],'RESEARCH_ONLY');self.assertEqual(r['economic_comparison_status'],'NOT_VALIDATED')
  for k in ('execution_authorized','automatic_execution_authorized','independent_archive_verified','fx_performed'):self.assertIs(r[k],False)
  self.assertFalse(out['canonical_publication_authorized']);self.assertFalse(out['training_requested'])
 def test_malicious_provider_id_not_used_as_request_list(self):
  self.save([self.rows(provider_id='source-id,other')]);out=self.collect();self.assertEqual(out['blocked_reason_counts'],{'PROVIDER_REQUEST_ID_INVALID':1});self.assertEqual(out['network_requests'],0)
 def test_endpoint_rejects_unapproved_host_before_credentials(self):
  (self.root/'config.json').write_text(json.dumps({'provider':{'base_url':'https://example.invalid/api/v3'}}))
  with self.assertRaisesRegex(q.AcquisitionError,'ENDPOINT_NOT_ALLOWED'):q.CoinGeckoTransport(self.root)
 def test_metadata_plan_does_not_write_or_call_provider(self):
  self.save([self.rows()]);before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};out=q.plan(self.root,self.demand(),now=NOW)
  self.assertEqual(len(out['jobs']),1);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()});self.assertFalse(self.transport.calls)
 def test_batch_bound_limits_recorded_jobs(self):
  self.save([self.rows(),self.rows(quote_currency='EUR')]);out=self.collect(self.demand(('BRL','EUR')),max_jobs=1);self.assertEqual(out['observations_created'],1);self.assertEqual(out['deferred_job_count'],1)
 def test_duplicate_observation_batch_is_rejected(self):
  self.save([self.rows()]);self.collect();r=q.read_records(self.root)[0]
  with self.assertRaisesRegex(q.AcquisitionError,'DUPLICATE_OBSERVATION_BATCH'):q.append_records(self.root,[r,r])
 def test_acquisition_plan_route_has_no_collection_side_effect(self):
  from flask import Flask,jsonify
  from universal_portfolio import universal_observation_bridge as bridge
  node=next(n for n in ast.parse((ROOT/'webapp/server.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='a24_research_acquisition_plan');app=Flask('acqplan');ns={'ROOT':self.root,'app':app,'jsonify':jsonify};exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_route','exec'),ns)
  with patch.object(bridge,'build_read_only_bridge',return_value=types.SimpleNamespace(intelligence={'funded_currency_research':self.demand()})),patch.object(q,'collect',side_effect=AssertionError('must not collect')):
   response=app.test_client().get('/api/research/acquisition-plan');self.assertEqual(response.status_code,200);self.assertEqual(response.json['eligible_source_job_count'],0);self.assertEqual(app.test_client().post('/api/research/acquisition-plan').status_code,405)
 def test_http_transport_keeps_tls_and_rejects_redirects(self):
  from unittest.mock import Mock
  transport=q.CoinGeckoTransport.__new__(q.CoinGeckoTransport);transport.base='https://api.coingecko.com/api/v3';transport.session=Mock()
  response=Mock();response.status_code=200;response.iter_content.return_value=[b'{"source-id":{"brl":100.25,"last_updated_at":1792152000}}'];response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False);transport.session.get.return_value=response
  payload=transport.get_json('/simple/price',{'ids':'source-id','vs_currencies':'brl'},6)
  self.assertEqual(payload['source-id']['brl'],Decimal('100.25'));kwargs=transport.session.get.call_args.kwargs
  self.assertFalse(kwargs['allow_redirects']);self.assertNotIn('verify',kwargs);self.assertEqual(kwargs['params']['vs_currencies'],'brl')
 def test_http_redirect_or_rate_limit_is_explicit(self):
  from unittest.mock import Mock
  for code in (302,403,429):
   transport=q.CoinGeckoTransport.__new__(q.CoinGeckoTransport);transport.base='https://api.coingecko.com/api/v3';transport.session=Mock()
   response=Mock();response.status_code=code;response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False);transport.session.get.return_value=response
   with self.subTest(code=code),self.assertRaisesRegex(q.AcquisitionError,'PROVIDER_HTTP_'+str(code)):transport.get_json('/simple/price',{},6)
 def test_mutated_context_is_not_accepted_with_stale_fingerprint(self):
  self.save([self.rows()]);d=self.demand();d['contexts'][0]['canonical_cash_observed']='999999';out=self.collect(d)
  self.assertEqual(out['blocked_reason_counts'],{'FUNDING_CONTEXT_FINGERPRINT_INVALID':1});self.assertEqual(out['network_requests'],0)
 def test_scheduler_refresh_calls_adapter_with_existing_demand(self):
  # Execute the exact newly wired refresh fragment, with the transport boundary mocked.
  code=(ROOT/'webapp/server.py').read_text();start=code.index('        from universal_portfolio.research_quote_acquisition_a24 import collect as _a24_collect_quotes');end=code.index('    except Exception as exc:',start)
  import textwrap
  fragment=textwrap.dedent(code[start:end]);d=self.demand();result={}
  ns={'ROOT':self.root,'_universal_result':types.SimpleNamespace(bridge=types.SimpleNamespace(intelligence={'funded_currency_research':d})),'universal_shadow':result}
  with patch.object(q,'collect',return_value={'status':'NO_ELIGIBLE_ACQUISITION_JOBS'}) as collect:exec(fragment,ns)
  collect.assert_called_once_with(self.root,d);self.assertEqual(result['funded_currency_acquisition']['status'],'NO_ELIGIBLE_ACQUISITION_JOBS')
 def test_provider_volume_and_cap_keep_requested_currency_units(self):
  self.save([self.rows()]);transport=Transport(quotes={'source-id':{'brl':100,'brl_market_cap':1234,'brl_24h_vol':56,'last_updated_at':int(NOW.timestamp())}})
  self.collect(transport=transport);r=q.read_records(self.root)[0]
  self.assertEqual(r['market_cap'],'1234');self.assertEqual(r['volume_24h'],'56');self.assertEqual(r['volume_semantics'],'PROVIDER_ROLLING_24H_NOT_CALENDAR_DAY_TOTAL');self.assertEqual(r['sampling'],'FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE')
 def test_optional_metrics_missing_remain_missing(self):
  self.save([self.rows()]);self.collect();r=q.read_records(self.root)[0];self.assertIsNone(r['market_cap']);self.assertIsNone(r['volume_24h'])
 def test_day_partitions_keep_history_out_of_current_day_lookup(self):
  self.save([self.rows()]);self.collect();tomorrow=NOW+dt.timedelta(days=1)
  self.collect(now=tomorrow,transport=Transport(now=tomorrow));self.assertEqual(len(q.read_records(self.root,day=tomorrow.date())),1);self.assertEqual(len(q.read_records(self.root)),2)
if __name__=='__main__':unittest.main()
