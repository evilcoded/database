from __future__ import annotations
import json, os, shutil, tempfile, threading, time, uuid, traceback, hmac
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

from flask import Flask, jsonify, render_template, request
from webapp.universal_position_router_api_v38275 import bp as universal_position_router_v38275_bp

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)

app = Flask(__name__, template_folder=str(ROOT/'templates'), static_folder=str(ROOT/'static'))
from webapp.pluggy_investment_read_api_r21386jb import bp as _pluggy_investment_read_bp_r21386jb
app.register_blueprint(_pluggy_investment_read_bp_r21386jb)
from webapp.manual_cash_api_r21256 import init as init_manual_cash_api_r21256
app.register_blueprint(init_manual_cash_api_r21256(ROOT, authority_root=ROOT))
from webapp.credential_api_g15 import init as init_credential_api_g15
app.register_blueprint(init_credential_api_g15(ROOT))
from webapp.connection_api_g15 import init as init_connection_api_g15
app.register_blueprint(init_connection_api_g15(ROOT))

# G15_R16130_PLUGGY_ITEM_DISCOVERY_API
# Explicit-user-action bridge only. Item identity may be persisted;
# discovered financial data is response-only.
from types import SimpleNamespace as _G15SimpleNamespace
from universal_portfolio.provider_item_registry import ProviderItemRegistry as _G15ProviderItemRegistry
from universal_portfolio.provider_connectivity import discover_pluggy_item_accounts as _g15_discover_pluggy_item_accounts

_G15_PROVIDER_ITEM_REGISTRY = _G15ProviderItemRegistry(ROOT/'data'/'provider_items.json')
_G15_PLUGGY_PROVIDER = _G15SimpleNamespace(provider_id='pluggy',adapter='OPEN_FINANCE_AGGREGATOR')

def _g15_safe_provider_error(exc):
    code=str(exc or '')
    allowed={'INVALID_PROVIDER_ITEM_IDENTITY','PROVIDER_NOT_SUPPORTED',
      'PROVIDER_CREDENTIAL_NOT_CONFIGURED','PROVIDER_CREDENTIAL_READ_FAILED',
      'PROVIDER_HTTP_401','PROVIDER_HTTP_403','PROVIDER_HTTP_429',
      'PROVIDER_TIMEOUT','PROVIDER_NETWORK_ERROR','PROVIDER_RESPONSE_TOO_LARGE',
      'PROVIDER_NON_JSON','PROVIDER_SCHEMA_INVALID','PROVIDER_REDIRECT_BLOCKED'}
    return code if code in allowed else 'PROVIDER_DISCOVERY_FAILED'

@app.route('/api/settings/providers/pluggy/items',methods=['GET','POST'])
def g15_pluggy_items():
    if request.method=='GET':
        rows=_G15_PROVIDER_ITEM_REGISTRY.list('pluggy')
        return jsonify(_clean_json({'ok':True,'schema':'porquinho.pluggy-item-discovery/1.0',
          'items':[{'provider_id':x.provider_id,'item_id':x.item_id,'state':x.state,'created_at':x.created_at} for x in rows],
          'financial_data_persisted':False,'institution_account_created':False,
          'ledger_mutated':False,'authority_changed':False}))
    body=request.get_json(silent=True)
    if not isinstance(body,dict) or set(body.keys())!={'item_id'}:
        return jsonify({'ok':False,'error':'ITEM_ID_ONLY_REQUIRED'}),400
    try:
        binding=_G15_PROVIDER_ITEM_REGISTRY.register('pluggy',body.get('item_id'))
        discovery=_g15_discover_pluggy_item_accounts(_G15_PLUGGY_PROVIDER,binding.item_id,root=ROOT)
        return jsonify(_clean_json({'ok':True,'schema':'porquinho.pluggy-item-discovery/1.0',
          'binding':{'provider_id':binding.provider_id,'item_id':binding.item_id,'state':binding.state,'created_at':binding.created_at},
          'discovery':discovery,'financial_data_persisted':False,
          'institution_account_created':False,'ledger_mutated':False,'authority_changed':False}))
    except ValueError:
        return jsonify({'ok':False,'error':'INVALID_PROVIDER_ITEM_IDENTITY'}),400
    except RuntimeError as exc:
        return jsonify({'ok':False,'error':_g15_safe_provider_error(exc)}),502


# G16_R1701_ACCOUNT_MAPPING_PREVIEW
# Explicit user action only; response-only sanitized identity preview.
@app.post('/api/settings/providers/pluggy/account-mapping-preview')
def g16_pluggy_account_mapping_preview():
    body=request.get_json(silent=True)
    if not isinstance(body,dict) or set(body.keys())!={'item_id'}:
        return jsonify({'ok':False,'error':'ITEM_ID_ONLY_REQUIRED'}),400
    item_id=str(body.get('item_id') or '').strip()
    try:
        known=any(x.item_id==item_id for x in _G15_PROVIDER_ITEM_REGISTRY.list('pluggy'))
        if not known:
            return jsonify({'ok':False,'error':'UNKNOWN_PROVIDER_ITEM'}),404
        discovery=_g15_discover_pluggy_item_accounts(_G15_PLUGGY_PROVIDER,item_id,root=ROOT)
        accounts=discovery.get('accounts',[]) if isinstance(discovery,dict) else []
        preview=[]
        for a in accounts:
            if not isinstance(a,dict): continue
            preview.append({'provider_account_id':a.get('id'),'name':a.get('name'),
              'account_type':a.get('type'),'account_subtype':a.get('subtype'),
              'currency':a.get('currencyCode'),'selected':False,'mapping_state':'UNMAPPED'})
        connector=((discovery.get('item') or {}).get('connector') or {}) if isinstance(discovery,dict) else {}
        return jsonify(_clean_json({'ok':True,'schema':'porquinho.account-mapping-preview/1.0',
          'provider_id':'pluggy','institution_preview':{'provider_connector_id':connector.get('id'),
          'name':connector.get('name'),'type':connector.get('type')},'accounts':preview,
          'account_count':len(preview),'selection_required':True,'mapping_persisted':False,
          'financial_data_persisted':False,'institution_account_created':False,
          'positions_created':False,'transactions_requested':False,'ledger_mutated':False,
          'authority_changed':False}))
    except RuntimeError as exc:
        safe=_g15_safe_provider_error(exc)
        print('[G16_MAP_DIAG] PROVIDER_FAILURE category='+str(safe), flush=True)
        return jsonify({'ok':False,'error':safe}),502
    except Exception as exc:
        print('[G16_MAP_DIAG] INTERNAL_FAILURE type='+type(exc).__name__, flush=True)
        return jsonify({'ok':False,'error':'MAPPING_PREVIEW_INTERNAL_ERROR'}),500

# G16_R1711_CONTROLLED_MAPPING_COMMIT
@app.post('/api/settings/providers/pluggy/account-mapping-commit')
def g16_pluggy_account_mapping_commit():
    from universal_portfolio.institution_accounts import InstitutionAccountRegistry, ManagementMode
    body=request.get_json(silent=True)
    if not isinstance(body,dict) or set(body.keys())!={'item_id','provider_account_ids'}:
        return jsonify({'ok':False,'error':'EXPLICIT_MAPPING_SELECTION_REQUIRED'}),400
    item_id=str(body.get('item_id') or '').strip(); selected=body.get('provider_account_ids')
    if not item_id or not isinstance(selected,list) or not selected:
        return jsonify({'ok':False,'error':'EXPLICIT_MAPPING_SELECTION_REQUIRED'}),400
    selected=list(dict.fromkeys(str(x).strip() for x in selected if str(x).strip()))
    if not any(x.item_id==item_id for x in _G15_PROVIDER_ITEM_REGISTRY.list('pluggy')):
        return jsonify({'ok':False,'error':'UNKNOWN_PROVIDER_ITEM'}),404
    try:
        discovery=_g15_discover_pluggy_item_accounts(_G15_PLUGGY_PROVIDER,item_id,root=ROOT)
        accounts=[a for a in discovery.get('accounts',[]) if isinstance(a,dict)]
        by_id={str(a.get('id')):a for a in accounts if a.get('id')}
        if any(x not in by_id for x in selected): return jsonify({'ok':False,'error':'ACCOUNT_SELECTION_NOT_IN_DISCOVERY'}),409
        connector=(discovery.get('item') or {}).get('connector') or {}; connector_id=str(connector.get('id') or '').strip()
        if not connector_id: return jsonify({'ok':False,'error':'CONNECTOR_IDENTITY_REQUIRED'}),409
        ia=InstitutionAccountRegistry(ROOT/'data'/'institution_accounts.json')
        inst=ia.add_institution(str(connector.get('name') or 'Pluggy Institution'),'XX','OTHER',source='PLUGGY')
        existing=ia.list_accounts(); mapped=[]; created=0
        for external_id in selected:
            a=by_id[external_id]; prior=next((x for x in existing if x.connector_id==connector_id and x.external_id==external_id),None)
            if prior: row=prior
            else:
                row=ia.add_account(inst.institution_id,a.get('name') or 'Conta conectada',a.get('type') or 'OTHER',a.get('currencyCode') or 'XXX',management_mode=ManagementMode.CONNECTED_READ.value,connector_id=connector_id,external_id=external_id,execution_enabled=False)
                existing.append(row); created+=1
            mapped.append({'account_id':row.account_id,'management_mode':row.management_mode,'created':prior is None})
        return jsonify(_clean_json({'ok':True,'schema':'porquinho.account-mapping-commit/1.0','mapped_accounts':mapped,'selected_count':len(selected),'created_count':created,'mapping_persisted':True,'management_mode':'CONNECTED_READ','transactions_requested':False,'balances_persisted':False,'positions_created':False,'ledger_mutated':False,'execution_enabled':False,'authority_changed':False}))
    except RuntimeError as exc:
        return jsonify({'ok':False,'error':_g15_safe_provider_error(exc)}),502
from universal_portfolio.manual_realize_pending_review import ManualRealizePendingReviewStore, ManualRealizePendingReviewRejected
from universal_portfolio.ledger import TransactionLedger
REALIZE_PENDING_STORE = ManualRealizePendingReviewStore()
from universal_portfolio.manual_sell_server_plan_store import ManualSellServerPlanStore, ManualSellServerPlanStoreError
SELL_SERVER_PLAN_STORE = ManualSellServerPlanStore(ROOT/'data'/'manual_sell_server_plans.json')

# Q10M10: persistent server-side composite execution dependencies.
# Foundation only: no execute route is registered by this patch.
from universal_portfolio.manual_sell_execution_authority_store import ManualSellExecutionAuthorityStore
from universal_portfolio.manual_fee_execution_authority_store import ManualFeeExecutionAuthorityStore
from universal_portfolio.manual_sell_fee_bundle_store import ManualSellFeeBundleStore
from universal_portfolio.manual_fee_recovery_artifact_store import ManualFeeRecoveryArtifactStore

SELL_EXECUTION_AUTHORITY_STORE = ManualSellExecutionAuthorityStore(ROOT/'data'/'manual_sell_execution_authorities.json')
FEE_EXECUTION_AUTHORITY_STORE = ManualFeeExecutionAuthorityStore(ROOT/'data'/'manual_fee_execution_authorities.json')
SELL_FEE_BUNDLE_STORE = ManualSellFeeBundleStore(ROOT/'data'/'manual_sell_fee_bundles.json')
FEE_RECOVERY_ARTIFACT_STORE = ManualFeeRecoveryArtifactStore(ROOT/'data'/'manual_fee_recovery_artifacts.json')

# Q10M13C: governed manual SELL+FEE execution dependencies.
from webapp.manual_sell_fee_execution_adapter_r21359b29q10m11 import execute_approved_session as _execute_manual_sell_fee_approved_session
from webapp.manual_sell_fee_execution_http_r21359b29q10m13a import init as _init_manual_sell_fee_execution_http

def _execute_manual_sell_fee_live(**kwargs):
    return _execute_manual_sell_fee_approved_session(
        pending_store=REALIZE_PENDING_STORE,
        sell_plan_store=SELL_SERVER_PLAN_STORE,
        sell_execution_store=SELL_EXECUTION_AUTHORITY_STORE,
        fee_execution_store=FEE_EXECUTION_AUTHORITY_STORE,
        bundle_store=SELL_FEE_BUNDLE_STORE,
        fee_recovery_artifact_store=FEE_RECOVERY_ARTIFACT_STORE,
        ledger=TransactionLedger(ROOT/'data'/'transaction_ledger.jsonl'),
        root=ROOT,
        **kwargs,
    )

# V382712_UNIVERSAL_PORTFOLIO_VALUATION_API
from webapp.universal_portfolio_valuation_api_v382712 import bp as universal_portfolio_valuation_v382712_bp
from webapp.universal_intelligence_api_v38284 import bp as universal_intelligence_v38284_bp
app.register_blueprint(universal_intelligence_v38284_bp)
app.register_blueprint(universal_portfolio_valuation_v382712_bp)

# V382710_FIXED_INCOME_VALUATION_API
from webapp.fixed_income_valuation_api_v382710 import bp as fixed_income_valuation_v382710_bp
app.register_blueprint(fixed_income_valuation_v382710_bp)
# V38270_UNIVERSAL_INSTRUMENT_CATALOG_API
from webapp.universal_instrument_catalog_api_v38270 import create_blueprint as _r21386ls23d_catalog_init
# R21.386LS23D2_CATALOG_REGISTRATION_MOVED_TO_SHARED_LOCAL_HUMAN
app.register_blueprint(universal_position_router_v38275_bp)
from webapp.financial_import_api import bp as financial_import_bp
app.register_blueprint(financial_import_bp)  # Porquinho V3.8.0.13
# V38264_BR_EQUITY_POSITION_API
from webapp.br_equity_position_api_v38264 import bp as br_equity_position_v38264_bp
app.register_blueprint(br_equity_position_v38264_bp)

# V38268_SYSTEM_KNOWLEDGE_API
from webapp.system_knowledge_api_v38268 import bp as system_knowledge_v38268_bp
app.register_blueprint(system_knowledge_v38268_bp)
app.config['MAX_CONTENT_LENGTH'] = 200 * 1024 * 1024

# One mutation worker is intentional: it serializes Brain/SQLite/API-heavy operations,
# while HTTP requests and the browser remain responsive. Read endpoints only read files.
EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix='porquinho-worker')
JOBS = {}
JOBS_LOCK = threading.RLock()
BRAIN_LOCAL = threading.local()
LAST_AUTO = 0.0
AUTO_LOCK = threading.Lock()



def _clean_json(v):
    import math
    if isinstance(v, dict): return {str(k): _clean_json(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [_clean_json(x) for x in v]
    if hasattr(v, 'isoformat') and not isinstance(v, (str,bytes)): return v.isoformat()
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)): return None
    return v

def _now():
    return datetime.now(timezone.utc).isoformat()


# Q10M13C: source registration; becomes reachable only after controlled restart.
MANUAL_SELL_FEE_EXECUTION_BP = _init_manual_sell_fee_execution_http(
    execute_approved_session=_execute_manual_sell_fee_live,
    now_fn=_now,
)
app.register_blueprint(MANUAL_SELL_FEE_EXECUTION_BP)


def _job_status(job_id, **changes):
    with JOBS_LOCK:
        j = JOBS.setdefault(job_id, {'id': job_id})
        j.update(changes)
        return dict(j)



# V38190R4_DIAGNOSTIC_RECOVERY
def _v38190r4_resolve_prior_refresh_diagnostic(success_kind, success_at):
    # Resolve only an older ACTIVE diagnostic after a later successful cycle
    # of the SAME job kind. Audit history is preserved; this is observability
    # reconciliation only and grants no production/financial authority.
    success_kind=str(success_kind or '').strip()
    if not success_kind:
        return {'status':'SUCCESS_KIND_UNAVAILABLE','production_effect':'OBSERVABILITY_ONLY'}
    path=ROOT/'results'/'diagnostics.json'
    try:
        data=_read_json(path,{})
        if not isinstance(data,dict):
            return {'status':'INVALID_DIAGNOSTICS_ENVELOPE','production_effect':'OBSERVABILITY_ONLY'}
        latest=data.get('latest')
        if not isinstance(latest,dict) or latest.get('status','ACTIVE')!='ACTIVE':
            return {'status':'NO_ACTIVE_DIAGNOSTIC','production_effect':'OBSERVABILITY_ONLY'}
        diag_kind=str(latest.get('job_kind') or latest.get('kind') or '').strip()
        if not diag_kind:
            return {'status':'ACTIVE_DIAGNOSTIC_KIND_UNAVAILABLE','production_effect':'OBSERVABILITY_ONLY'}
        if diag_kind != success_kind:
            return {'status':'ACTIVE_DIAGNOSTIC_DIFFERENT_KIND','diagnostic_kind':diag_kind,'success_kind':success_kind,'production_effect':'OBSERVABILITY_ONLY'}
        try:
            diag_ts=float(latest.get('timestamp'))
        except Exception:
            return {'status':'ACTIVE_DIAGNOSTIC_TIMESTAMP_UNAVAILABLE','production_effect':'OBSERVABILITY_ONLY'}
        try:
            success_ts=datetime.fromisoformat(str(success_at).replace('Z','+00:00')).timestamp()
        except Exception:
            return {'status':'SUCCESS_TIMESTAMP_UNAVAILABLE','production_effect':'OBSERVABILITY_ONLY'}
        if not (diag_ts < success_ts):
            return {'status':'ACTIVE_DIAGNOSTIC_NOT_OLDER','production_effect':'OBSERVABILITY_ONLY'}

        resolved=dict(latest)
        resolved['status']='RESOLVED'
        resolved['resolved_at']=success_at
        resolved['resolution_reason']='SUCCESSFUL_SUBSEQUENT_SAME_KIND_CYCLE'
        resolved['resolved_by_job_kind']=success_kind
        resolved['resolution_evidence']={'diagnostic_kind':diag_kind,'success_kind':success_kind,'success_at':success_at}
        resolved['production_effect']='OBSERVABILITY_ONLY'

        history=data.get('history')
        if not isinstance(history,list):
            history=[]
        diag_id=latest.get('id')
        if not any(isinstance(x,dict) and diag_id is not None and x.get('id')==diag_id for x in history):
            history.append(dict(latest))
        data['history']=history
        data['latest']=resolved
        data['updated_at']=success_ts

        tmp=path.with_suffix(path.suffix+'.tmp')
        tmp.write_text(json.dumps(_clean_json(data),ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(path)
        return {'status':'RESOLVED','diagnostic_id':diag_id,'production_effect':'OBSERVABILITY_ONLY'}
    except Exception as exc:
        # Diagnostic recovery must never make a successful refresh fail.
        return {'status':'RECOVERY_ERROR','error_type':type(exc).__name__,'production_effect':'OBSERVABILITY_ONLY'}


def submit(kind, fn):
    job_id = uuid.uuid4().hex[:12]
    _job_status(job_id, kind=kind, status='queued', created_at=_now(), message='Aguardando execução…')

    def runner():
        _job_status(job_id, status='running', started_at=_now(), message='Executando…')
        try:
            result = fn()
            _v38190r4_success_at=_now()
            _v38190r4_diag_recovery=_v38190r4_resolve_prior_refresh_diagnostic(kind,_v38190r4_success_at)
            _job_status(job_id, status='done', finished_at=_v38190r4_success_at, result=result, diagnostic_recovery=_v38190r4_diag_recovery, message='Concluído.')
        except Exception as exc:
            tb=traceback.format_exc()
            diagnostic={}
            try:
                from brain.diagnostics import ErrorAnalyzer
                diagnostic=ErrorAnalyzer(ROOT).analyze(kind,exc,tb)
            except Exception as diag_exc:
                diagnostic={'diagnostic_error':repr(diag_exc)}
            _job_status(job_id, status='error', finished_at=_now(), error=repr(exc), traceback=tb[-8000:], diagnostic=diagnostic, message=f'Erro: {exc}')

    EXECUTOR.submit(runner)
    return job_id


def brain():
    # Brain is created only inside the worker thread. No SQLite connection is shared with Flask.
    b = getattr(BRAIN_LOCAL, 'brain', None)
    if b is None:
        from brain.core.brain import PorquinhoBrain
        b = PorquinhoBrain(ROOT)
        BRAIN_LOCAL.brain = b
    return b


def _read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception:
        return default if default is not None else {}


def _read_csv(path):
    import pandas as pd
    p = Path(path)
    if not p.exists(): return []
    try:
        df = pd.read_csv(p)
        return _clean_json(df.to_dict('records'))
    except Exception:
        return []


def snapshot():
    p = ROOT/'results'/'latest.json'
    return _read_json(p, {'status':'aguardando primeira execução'})


def learning():
    lab = _read_json(ROOT/'results'/'prediction_lab.json', {})
    cycle = _read_json(ROOT/'results'/'learning_cycle.json', {})
    scan = _read_json(ROOT/'brain'/'reports'/'latest_scan.json', {})
    history = _read_json(ROOT/'brain'/'reports'/'history_import.json', {})
    # Lightweight counts only. Do not instantiate PorquinhoBrain during a 5s UI poll.
    st = {}
    try:
        import sqlite3
        db = ROOT/'data'/'memory.sqlite3'
        if db.exists():
            con = sqlite3.connect(db, timeout=5)
            for table, key in [('knowledge','knowledge'),('hypotheses','hypotheses'),('experiments','experiments')]:
                try: st[key] = int(con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0])
                except Exception: st[key] = 0
            con.close()
    except Exception: pass
    champion = lab.get('champion') or {}
    algos = lab.get('algorithms') or []
    valid = [a for a in algos if a.get('mae') is not None]
    confidence = _confidence(lab, cycle)
    diagnostics=_read_json(ROOT/'results'/'diagnostics.json',{})
    system_alerts=[]
    latest_diag=diagnostics.get('latest') or {}
    if latest_diag and latest_diag.get('status','ACTIVE')=='ACTIVE':
        system_alerts.append({'action':'ERRO','asset':'SISTEMA','message':latest_diag.get('diagnosis','Erro de execução detectado.')+' '+latest_diag.get('suggested_chat_command',''),'promising_pct':0,'risk':100,'timestamp':latest_diag.get('timestamp')})
    return {
        'confidence': confidence,
        'observations': lab.get('observations', cycle.get('cycles', 0)),
        'assets': lab.get('assets', 0),
        'model': champion.get('algorithm') or 'Baseline',
        'regime': snapshot().get('market', {}).get('regime'),
        'corr': champion.get('corr'),
        'hit_rate': champion.get('directional_hit_rate'),
        'mae': champion.get('mae'),
        'algorithms_tested': len(valid),
        'algorithms_total': 10,
        'experiments': st.get('experiments', 0),
        'knowledge': st.get('knowledge', 0),
        'hypotheses': st.get('hypotheses', 0),
        'research_runs': cycle.get('research_runs', 0),
        'last_research': cycle.get('last_research_at'),
        'lab': lab,
        'history_import': history,
        'scan': scan,
        'alerts': (_read_json(ROOT/'results'/'action_alerts.json',{}).get('alerts',[]) + system_alerts),
        'diagnostics': diagnostics,
        'patches': _read_json(ROOT/'results'/'patches.json',{'patches':[]}).get('patches',[]),
    }


def _confidence(lab, cycle):
    """Evidence-quality score, never a probability of future return.
    Uses multi-metric model quality + stability + sample depth + cross-model agreement.
    """
    champ=lab.get('champion') or {}
    hit=champ.get('directional_hit_rate'); corr=champ.get('corr'); n=float(lab.get('observations') or 0)
    tested=len([x for x in lab.get('algorithms',[]) if x.get('mae') is not None])
    folds=float(champ.get('folds') or 0); stability=float(champ.get('stability_score') or 0)
    model_score=float(champ.get('model_score') or 0)
    hit_component=max(0,min(100,50+(float(hit)-50)*4)) if hit is not None else 0
    corr_component=max(0,min(100,50+float(corr)*100)) if corr is not None else 0
    sample_component=min(100,(n/2500)*100)
    folds_component=min(100,folds*10)
    tested_component=min(100,tested*10)
    # Agreement: reward a champion that is not an isolated outlier among tested models.
    scores=[float(x.get('model_score')) for x in lab.get('algorithms',[]) if x.get('model_score') is not None]
    agreement=100.0 if len(scores)<2 else max(0,min(100,100-abs(model_score-float(np.median(scores)))*3))
    parts=[model_score,hit_component,corr_component,stability,sample_component,folds_component,tested_component,agreement]
    return round(sum(parts)/len(parts),1) if any(parts) else 0.0


def portfolio():
    o = snapshot()

    # R21.364B_PORTFOLIO_LIVE_FINANCIAL_COMPATIBILITY_OVERLAY
    # Financial truth: canonical runtime. Intelligence: last snapshot.
    try:
        from universal_portfolio.live_financial_projection import build as _build_live_projection
        _live_projection = _build_live_projection(ROOT, o)
    except Exception:
        _live_projection = None

    scores = o.get('scores', [])
    held = {str(s.get('asset','')).upper() for s in scores if float(s.get('current_value_eur') or 0) > 0}
    # If a stale/empty snapshot is present, keep the portfolio visible from portfolio.csv.
    if not scores:
        pf=_read_csv(ROOT/'data'/'portfolio.csv')
        scores=[]
        for r in pf:
            scores.append({'asset':str(r.get('asset','')).upper(),'account':r.get('account','N/A'),'current_value_eur':float(r.get('amount_eur') or 0),'invested_cost_eur':float(r.get('amount_eur') or 0),'pnl_eur':0,'pnl_pct':0,'current_weight_pct':0,'target_weight_pct':0,'target_action':'SEM_ALVO','action':'ACOMPANHE','promising_pct':0,'risk':0,'price_eur':float(r.get('entry_price_eur') or 0),'move_required_eur':0,'destination':'NONE','reason':'Aguardando snapshot de mercado.'})
    # Legacy *_eur compatibility is intentionally EUR-only.
    _eur = ((_live_projection or {}).get('currency_totals') or {}).get('EUR')
    _eur_market_value = _eur.get('market_value') if _eur is not None else None
    _eur_cost = _eur.get('invested_cost') if _eur is not None else None
    _eur_cash = _eur.get('cash') if _eur is not None else None
    if _eur is not None:
        _live_by_asset = {str(x.get('asset') or '').upper(): x for x in ((_live_projection or {}).get('positions') or []) if str(x.get('currency') or '').upper() == 'EUR'}
        for _s in scores:
            _p = _live_by_asset.get(str(_s.get('asset') or '').upper())
            if _p is None:
                continue
            # R21.373J2_RUNTIME_SCORE_IDENTITY_BRIDGE
            # Identity comes from canonical live position; intelligence remains snapshot-owned.
            _canonical_account_id = str(_p.get('account_id') or _p.get('account_reference') or '').strip()
            if _canonical_account_id.startswith('acct_'):
                _s['account_id'] = _canonical_account_id
            if _p.get('market_value') is not None:
                _s['current_value_eur'] = float(_p['market_value'])
            _s['invested_cost_eur'] = float(_p.get('cost_basis') or 0)
            _s['pnl_eur'] = float(_s.get('current_value_eur') or 0) - _s['invested_cost_eur']
            _s['pnl_pct'] = (100.0 * _s['pnl_eur'] / _s['invested_cost_eur']) if _s['invested_cost_eur'] else 0.0

    return {
        'capital_eur': o.get('capital_eur', 500),
        'value_eur': ((_eur_market_value + _eur_cash) if _eur_market_value is not None and _eur_cash is not None else o.get('total_wealth_eur', 0)),
        'invested_eur': (_eur_cost if _eur_cost is not None else o.get('portfolio_cost_eur', 0)),
        'cash_eur': (_eur_cash if _eur_cash is not None else o.get('cash_eur', 0)),
            # V38134R4_UI_CASH_BRIDGE
            'cash_reconciliation': o.get('cash_reconciliation'),
            'brain_experimental': o.get('brain_experimental'),
        # Q10M1: portfolio Result means unrealized P/L of currently held positions.
        # Wealth-vs-capital remains available separately as total_pnl_* in the snapshot.
        'pnl_eur': ((_eur_market_value - _eur_cost) if _eur_market_value is not None and _eur_cost is not None else o.get('pnl_eur', 0)),
        'pnl_pct': ((100.0 * (_eur_market_value - _eur_cost) / _eur_cost) if _eur_market_value is not None and _eur_cost else o.get('pnl_pct', 0)),
        'financial_projection': _live_projection,
        'scores': scores,
        # R21.373G_CANONICAL_PORTFOLIO_ACCOUNTS_ADAPTER
        'accounts': {
            aid: [s for s in scores if str(s.get('account_id') or s.get('account') or '') == aid and float(s.get('current_value_eur') or 0) > 0]
            for aid in sorted({str(s.get('account_id') or s.get('account') or '').strip() for s in scores if str(s.get('account_id') or s.get('account') or '').strip().startswith('acct_')})
        },
    }


def _bridge_authorized():
    configured = os.environ.get('PORQUINHO_BRIDGE_TOKEN', '')
    received = request.headers.get('X-Bridge-Token', '')
    return bool(configured and received and hmac.compare_digest(configured, received))


def bridge_portfolio():
    """Contrato externo estável; não expõe arquivos nem estruturas internas do Brain."""
    raw = _read_csv(ROOT/'data'/'portfolio.csv')
    live = {str(item.get('asset', '')).upper(): item for item in portfolio().get('scores', [])}
    positions = []
    for row in raw:
        symbol = str(row.get('asset', '')).upper().strip()
        if not symbol:
            continue
        account = str(row.get('account') or 'Porquinho').strip()
        quote = live.get(symbol, {})
        quantity = float(row.get('quantity') or 0)
        average_cost = float(row.get('entry_price_eur') or 0)
        current_price = float(quote.get('price_eur') or average_cost)
        invested = float(quote.get('invested_cost_eur') or row.get('amount_eur') or quantity * average_cost)
        market = float(quote.get('current_value_eur') or quantity * current_price)
        positions.append({
            'external_id': f'porquinho:{account.lower()}:{symbol.lower()}',
            'asset_name': symbol, 'symbol': symbol, 'asset_type': 'Criptoativo',
            'account': account, 'institution': account, 'currency': 'EUR',
            'quantity': quantity, 'average_cost': average_cost,
            'current_price': current_price, 'invested_value': invested,
            'market_value': market, 'profit': market - invested,
            'purchase_date': row.get('purchase_date'),
            'valuation_date': snapshot().get('timestamp'), 'source': 'PORQUINHO'
        })
    return {'contract': 'dff-porquinho/1.0', 'system': 'Porquinho',
            'version': '3.4.2-web', 'generated_at': _now(), 'positions': positions}


def intraday(hours=24):
    import csv
    from datetime import datetime, timezone, timedelta
    p = ROOT/'data'/'database'/'market_intraday_10m.csv'
    if not p.exists(): return []
    try:
        hours=max(1,min(48,int(hours)))
        now=datetime.now(timezone.utc)
        cutoff=now-timedelta(hours=hours)
        rows=[]
        from universal_portfolio.recovered_intraday_view import resolved_rows  # R21.17F_RECOVERED_INTRADAY_VIEW
        for row in resolved_rows(ROOT):
            raw=str(row.get('timestamp') or '').strip()
            if not raw: continue
            try:
                ts=datetime.fromisoformat(raw.replace('Z','+00:00'))
                if ts.tzinfo is None: ts=ts.replace(tzinfo=timezone.utc)
                ts=ts.astimezone(timezone.utc)
            except Exception: continue
            if not (cutoff <= ts <= now): continue
            item=dict(row); item['timestamp']=ts.isoformat()
            for k,v in list(item.items()):
                if v in ('',None): item[k]=None; continue
                if k not in ('timestamp','asset'):
                    try: item[k]=float(v)
                    except Exception: pass
            rows.append(item)
        rows.sort(key=lambda x:x['timestamp'])
        return _clean_json(rows)
    except Exception:
        return []

def daily():
    import pandas as pd
    p=ROOT/'data'/'database'/'portfolio_daily.csv'
    if not p.exists(): return []
    try:
        df=pd.read_csv(p)
        if df.empty:return []
        df['date']=pd.to_datetime(df['date'],errors='coerce')
        df=df.dropna(subset=['date']).sort_values(['date','asset'])
        return _clean_json(df.to_dict('records'))
    except Exception:
        return []


def history_meta():
    p=ROOT/'brain'/'reports'/'history_import.json'
    return _read_json(p, {})


def _v38130r3_auto_health(state, **extra):
    try:
        p=ROOT/'results'/'auto_cycle_health.json'
        payload={'at':_now(),'state':state,'cadence_seconds':600,'production_effect':'OBSERVABILITY_ONLY'}
        payload.update(extra)
        p.write_text(json.dumps(_clean_json(payload),ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        pass

# R21.190_MATURATION_HEALTH_SEMANTIC_WRITE
# Persist selected observability health artifacts only on semantic change.
# Volatile observation timestamps do not by themselves cause a rewrite.
# auto_cycle_health remains untouched because it is a cadence/heartbeat artifact.
def _r21190_write_health_on_semantic_change(path, payload, volatile_keys=('at',)):
    try:
        clean=_clean_json(payload)
        semantic={k:v for k,v in clean.items() if k not in volatile_keys}
        old=None
        if path.exists():
            try:
                old=_read_json(path, {})
            except Exception:
                old=None
        old_semantic={k:v for k,v in old.items() if k not in volatile_keys} if isinstance(old,dict) else None
        if old_semantic == semantic:
            return False
        tmp=path.with_suffix(path.suffix+'.tmp')
        tmp.write_text(json.dumps(clean,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(path)
        return True
    except Exception:
        return False


# R21.59_MATURATION_AUTOHOOK
_MATURATION_LOCK = threading.Lock()
_MATURATION_THREAD = None

# R21.93_PROSPECTIVE_BUY_READINESS_HEALTH — observational only
def _r2193_buy_readiness_health():
    try:
        from brain.prospective_buy_readiness_health import write as _write_buy_readiness_health
        return _write_buy_readiness_health(ROOT)
    except Exception as exc:
        return {'state':'FAIL_CLOSED','error_type':type(exc).__name__,
                'automatic_training':False,'automatic_promotion':False,
                'execution_authorized':False,'production_effect':'OBSERVABILITY_ONLY'}

def _r2159_maturation_health(state, **extra):
    try:
        p=ROOT/'results'/'maturation_intake_health.json'
        payload={'at':_now(),'state':state,'production_effect':'OBSERVABILITY_ONLY'}
        payload.update(extra)
        _r21190_write_health_on_semantic_change(p,payload)
    except Exception:
        pass

# R21.187_REAL_SHADOW_RUNTIME — observability only, write only on semantic change
def _r21187_real_shadow_health():
    try:
        from brain.canonical_derived_observation_loader import load as _load_obs
        from brain.derived_evidence_quality import assess as _quality
        from brain.claim_specific_robustness import assess as _temporal
        from brain.claim_regime_robustness import assess as _regime
        from brain.source_bound_analytical_stage import resolve as _resolve_stage
        from brain.prospective_buy_real_shadow_batch import run as _shadow_batch
        loaded=_load_obs(ROOT); obs=loaded.get('observations') or []
        qg=_quality(obs).get('groups') or []
        tg=_temporal(obs).get('groups') or []
        rg=_regime(obs).get('groups') or []
        def key(x):
            try:return (str(x.get('action') or ''),int(x.get('horizon_days')))
            except Exception:return None
        tm={key(x):x for x in tg if key(x)}
        rm={key(x):x for x in rg if key(x)}
        stages={}
        for q in qg:
            k=key(q)
            if k: stages[k]=_resolve_stage(q,tm.get(k),rm.get(k)).get('resolved_stage')
        observed=set()
        for x in obs:
            if x.get('source_authority')=='DERIVED_EVIDENCE_ONLY' and x.get('matured') is True:
                k=key(x)
                if k: observed.add(k)
        rows=[]
        for k in sorted(observed):
            if k[0]!='COMPRE': continue
            subset=[x for x in obs if key(x)==k]
            stage=stages.get(k)
            if stage not in ('LONGITUDINAL_EVIDENCE','LEARNED_RULE'):
                rows.append({'action':k[0],'horizon_days':k[1],'source_bound_stage':None,
                             'state':'FAIL_CLOSED','reason':'SOURCE_BOUND_STAGE_UNAVAILABLE',
                             'buy_shadow_count':0})
                continue
            z=_shadow_batch(ROOT,subset,current_stage=stage)
            rows.append({'action':k[0],'horizon_days':k[1],'source_bound_stage':stage,
                         'state':z.get('state'),'reason':z.get('reason'),
                         'buy_shadow_count':z.get('buy_shadow_count',0)})
        payload={'schema':'PORQUINHO_REAL_SHADOW_RUNTIME_HEALTH_V1',
                 'authority':'OBSERVABILITY_ONLY','state':'OBSERVED',
                 'observation_count':len(obs),'claim_count':len(rows),'claims':rows,
                 'future_information_used':False,'official_stage_modified':False,
                 'registry_write':False,'automatic_training':False,
                 'automatic_promotion':False,'execution_authorized':False,
                 'financial_state_modified':False,'production_effect':'OBSERVABILITY_ONLY'}
    except Exception as exc:
        payload={'schema':'PORQUINHO_REAL_SHADOW_RUNTIME_HEALTH_V1',
                 'authority':'OBSERVABILITY_ONLY','state':'FAIL_CLOSED',
                 'reason':type(exc).__name__,'official_stage_modified':False,
                 'registry_write':False,'automatic_training':False,
                 'automatic_promotion':False,'execution_authorized':False,
                 'financial_state_modified':False,'production_effect':'OBSERVABILITY_ONLY'}
    try:
        hp=ROOT/'results'/'prospective_buy_real_shadow_health.json'
        encoded=json.dumps(_clean_json(payload),ensure_ascii=False,indent=2,sort_keys=True)
        old=hp.read_text(encoding='utf-8') if hp.exists() else None
        if old!=encoded:
            tmp=hp.with_suffix(hp.suffix+'.tmp')
            tmp.write_text(encoded,encoding='utf-8');tmp.replace(hp)
            return {**payload,'health_write_performed':True}
        return {**payload,'health_write_performed':False}
    except Exception:
        return {**payload,'health_write_performed':False}

def _r2159_maturation_probe_async():
    global _MATURATION_THREAD
    with _MATURATION_LOCK:
        if _MATURATION_THREAD is not None and _MATURATION_THREAD.is_alive():
            return False
        def runner():
            try:
                from brain.maturation_intake_guard import run as maturation_guard_run
                r=maturation_guard_run(ROOT)
                # R21.108_PROSPECTIVE_BUY_OUTCOME_AUTO_PERSIST
                try:
                    from brain.prospective_buy_outcome_auto_persist import run as _r21108_outcome_persist
                    _r21108_outcomes=_read_json(ROOT/'data'/'brain_experimental_episodes'/'outcomes_latest.json', {})
                    _r21108_result=_r21108_outcome_persist(ROOT,_r21108_outcomes,_now(),persist_enabled=True)
                    _r21108_health={
                        'at':_now(),'state':_r21108_result.get('state'),
                        'forecast_record_count':_r21108_result.get('forecast_record_count'),
                        'counts':_r21108_result.get('counts'),
                        'sanitized_error_count':_r21108_result.get('sanitized_error_count'),
                        'historical_backfill':False,'automatic_training':False,
                        'automatic_promotion':False,'execution_authorized':False,
                        'production_effect':'OBSERVABILITY_ONLY'}
                except Exception as _r21108_exc:
                    _r21108_health={'at':_now(),'state':'FAIL_CLOSED',
                        'error_type':type(_r21108_exc).__name__,
                        'historical_backfill':False,'automatic_training':False,
                        'automatic_promotion':False,'execution_authorized':False,
                        'production_effect':'OBSERVABILITY_ONLY'}
                try:
                    _r21108_hp=ROOT/'results'/'prospective_buy_outcome_health.json'
                    _r21190_write_health_on_semantic_change(_r21108_hp,_r21108_health)
                except Exception:
                    pass
                # R21.142_PROSPECTIVE_BUY_BASELINE_V2_DRYRUN
                # Isolated V2 calibration baseline dry-run; no baseline persistence.
                try:
                    from brain.prospective_buy_calibration_baseline_freeze_runner_v2 import run as _r21142_baseline_v2
                    _r21142_result=_r21142_baseline_v2(ROOT,dry_run=True)
                    _r21142_health={
                        'at':_now(),'state':'OBSERVING',
                        'schema':_r21142_result.get('schema'),
                        'horizons':_r21142_result.get('horizons'),
                        'dry_run':True,'v2_persistence_enabled':False,
                        'automatic_training':False,'automatic_promotion':False,
                        'execution_authorized':False,'production_effect':'OBSERVABILITY_ONLY'}
                except Exception as _r21142_exc:
                    _r21142_health={'at':_now(),'state':'FAIL_CLOSED',
                        'error_type':type(_r21142_exc).__name__,
                        'dry_run':True,'v2_persistence_enabled':False,
                        'automatic_training':False,'automatic_promotion':False,
                        'execution_authorized':False,'production_effect':'OBSERVABILITY_ONLY'}
                try:
                    _r21142_hp=ROOT/'results'/'prospective_buy_baseline_health.json'
                    _r21190_write_health_on_semantic_change(_r21142_hp,_r21142_health)
                except Exception:
                    pass
                _r2193_buy_readiness_health()
                # R21.187_REAL_SHADOW_RUNTIME
                _r21187_real_shadow_health()
                _r2159_maturation_health(
                    'INTAKE_EXECUTED' if r.get('intake_executed') else 'WAITING',
                    watch_state=r.get('watch_state'),
                    due_target_count=r.get('due_target_count'),
                    skip_reason=r.get('skip_reason'),
                    execution_authorized=False)
            except Exception as exc:
                _r2159_maturation_health('ERROR',error_type=type(exc).__name__,execution_authorized=False)
        _MATURATION_THREAD=threading.Thread(target=runner,daemon=True,name='porquinho-maturation')
        _MATURATION_THREAD.start()
        return True


def auto_loop():
    # Starts after the web server is ready; never blocks startup.
    global LAST_AUTO
    while True:
        time.sleep(5)
        _r2159_maturation_probe_async()  # R21.59_MATURATION_AUTOHOOK_CALL
        try:
            with AUTO_LOCK:
                now=time.time()
                # V38136_WALL_CLOCK_CADENCE
                # Queue at most once per closed 10-minute wall-clock slot (:00/:10/.../:50).
                slot=int(now//600)
                if int(LAST_AUTO//600) >= slot: continue
                # V38190R3_SCHEDULER_RUNTIME_RECOVERY
                # A failed/queued/running job from an older slot must not permanently block cadence.
                with JOBS_LOCK:
                    active=[j for j in JOBS.values() if j.get('status') in ('queued','running')]
                active_current=[]
                for j in active:
                    try:
                        started=j.get('started_at') or j.get('created_at')
                        if started:
                            from datetime import datetime
                            jt=datetime.fromisoformat(str(started).replace('Z','+00:00')).timestamp()
                            if int(jt//600) >= slot: active_current.append(j)
                    except Exception:
                        active_current.append(j)
                if active_current:
                    _v38130r3_auto_health('WAITING_FOR_CURRENT_WORKER',active_jobs=len(active_current),wall_clock_slot=slot)
                    continue
                latest=ROOT/'results'/'latest.json'
                # A result already written in this wall-clock slot satisfies the cadence.
                if latest.exists() and int(latest.stat().st_mtime//600) >= slot:
                    _v38130r3_auto_health('WAITING_FOR_CADENCE',latest_age_seconds=round(now-latest.stat().st_mtime,2),wall_clock_slot=slot)
                    LAST_AUTO=now
                    continue
                LAST_AUTO=now
            jid=submit('auto_refresh', _refresh)
            _v38130r3_auto_health('REFRESH_QUEUED',job_id=jid,wall_clock_slot=slot)
        except Exception as exc:
            _v38130r3_auto_health('SCHEDULER_ERROR',error_type=type(exc).__name__)


# V3829R6_WEB_HISTORY_REFRESH_INTEGRATION
# Reuse the canonical historical fetcher in the web runtime.
# Cadence is conservative (6h), matching the fetcher's cache horizon.
# Failure is fail-open for the live 10-minute cycle: missing history remains missing,
# never synthetic. Historical refresh runs before porquinho.run so outcome evaluation
# can consume newly recorded daily observations in the same cycle.
def _v3829r6_refresh_history_if_due():
    report_path=ROOT/'brain'/'reports'/'history_fetch.json'
    try:
        if report_path.exists() and (time.time()-report_path.stat().st_mtime) < 21600:
            return {'status':'SKIPPED_FRESH','production_effect':'HISTORY_ONLY'}
    except Exception:
        pass
    try:
        from tools.fetch_history import main as fetch_history_main
        result=fetch_history_main()
        return {'status':'REFRESHED','production_effect':'HISTORY_ONLY','result':result}
    except Exception as exc:
        return {'status':'ERROR','production_effect':'NONE','error_type':type(exc).__name__,'error':str(exc)[:500]}


def _a6_safe_projection(value):
    """Public evidence only: no canonical authority or raw model/provenance data."""
    from collections.abc import Mapping
    import math
    actions = {"KEEP", "DEPLOY_CASH", "INCREASE", "REDUCE", "SELL",
               "REALLOCATE", "ABSTAIN", "NO_ALLOCATION"}
    if not isinstance(value, Mapping):
        value = {}
    proposal = value.get('experimental_brain_proposal')
    if (not isinstance(proposal, Mapping)
            or proposal.get('canonical_recommendation') is not False
            or proposal.get('asterisk_required') is not True
            or proposal.get('authority_status') != 'EXPERIMENTAL_NOT_CANONICAL'
            or proposal.get('action') not in actions
            or not all(isinstance(proposal.get(k), str) and proposal[k].strip()
                       for k in ('account_id', 'currency'))):
        proposal = None
    else:
        original = proposal
        allowed = ('action', 'action_label_pt', 'account_id', 'currency',
                   'alternative_id', 'instrument_id', 'comparison_id',
                   'horizon_unit', 'horizon_value',
                   'source_instrument_id', 'destination_instrument_id',
                   'asterisk_required', 'canonical_recommendation', 'authority_status',
                   'publication_ready', 'sizing_verified_for_observed_identity')
        proposal = {k: original.get(k) for k in allowed}
        sizing = original.get('governed_sizing_evidence')
        valid = (isinstance(sizing, Mapping)
                 and sizing.get('canonical_recommendation') is False
                 and sizing.get('execution_authorized') is False
                 and original.get('sizing_verified_for_observed_identity') is True
                 and sizing.get('status') in ('SIZING_READY', 'NO_ALLOCATION')
                 and type(sizing.get('suggested_amount')) in (int, float)
                 and math.isfinite(sizing['suggested_amount'])
                 and (sizing['suggested_amount'] == 0 if sizing['status'] == 'NO_ALLOCATION'
                      else sizing['suggested_amount'] > 0)
                 and sizing.get('action') == proposal['action']
                 and bool(proposal.get('comparison_id'))
                 and bool(proposal.get('alternative_id'))
                 and all(sizing.get(k) == proposal.get(k) for k in
                         ('account_id', 'currency', 'alternative_id', 'comparison_id',
                          'horizon_unit', 'horizon_value')))
        if valid:
            proposal['governed_sizing_evidence'] = {k: sizing.get(k) for k in
                ('status', 'action', 'suggested_amount', 'currency', 'account_id',
                 'alternative_id', 'comparison_id', 'horizon_unit', 'horizon_value',
                 'canonical_recommendation', 'execution_authorized')}
        else:
            proposal['sizing_verified_for_observed_identity'] = False
    abstention = value.get('economic_abstention')
    safe_abstention = None
    if proposal is None and isinstance(abstention, Mapping) and abstention.get('action') == 'ABSTAIN':
        import re
        reasons = abstention.get('reasons')
        reasons = reasons if isinstance(reasons, (list, tuple)) else ()
        reasons = tuple(x for x in reasons if isinstance(x, str)
                        and re.fullmatch(r'[A-Z][A-Z0-9_]{0,119}', x))[:16]
        safe_abstention = {'action': 'ABSTAIN', 'action_label_pt': 'ABSTER-SE',
                           'reasons': reasons, 'authority': 'NONE',
                           'execution_authorized': False}
    return {'schema': 'porquinho.a6-shadow-ui-transport/1.0',
            'status': 'EXPERIMENTAL_DECISION_AVAILABLE' if proposal else 'UNAVAILABLE',
            'experimental_brain_proposal': proposal,
            'economic_abstention': safe_abstention,
            'canonical_investment_recommendation': None,
            'canonical_decision_available': False,
            'canonical_promotion_status': 'BLOCKED_UNTIL_VERIFIED_PRODUCER',
            'execution_authorized': False}

# A7: process-local observation only; no disk writes or financial side effects.
_A7_LAST_SHADOW_PROJECTION = None

def _a7_status_projection():
    value = _A7_LAST_SHADOW_PROJECTION
    if not isinstance(value, dict) or value.get('schema') != 'porquinho.a6-shadow-ui-transport/1.0':
        return {'schema':'porquinho.a6-shadow-ui-transport/1.0', 'status':'UNAVAILABLE',
                'experimental_brain_proposal':None, 'canonical_investment_recommendation':None,
                'canonical_decision_available':False, 'execution_authorized':False}
    return _a6_safe_projection(value)

def _refresh(force=True):
    import importlib
    _v3829r6_refresh_history_if_due()
    porq=importlib.import_module('porquinho')
    porq.run(force_refresh=force)
    out=snapshot()

    # r21.386ly11d2 — Universal Brain shadow runtime wiring.
    # Reuses the existing refresh cadence only. Evidence/observation shadow:
    # no RecommendationHistory write, financial mutation, execution or legacy action promotion.
    global _A7_LAST_SHADOW_PROJECTION
    _A7_LAST_SHADOW_PROJECTION = None
    universal_shadow=None
    try:
        from datetime import datetime, timezone
        from universal_portfolio.universal_runtime_composition import compose_shadow_cycle
        _universal_started_at=datetime.now(timezone.utc).isoformat()
        _universal_observed_at=datetime.now(timezone.utc).isoformat()
        _universal_result=compose_shadow_cycle(
            ROOT,
            observed_at=_universal_observed_at,
            started_at=_universal_started_at,
            top_n=30,
        )
        _A7_LAST_SHADOW_PROJECTION = _a6_safe_projection(_universal_result.economic_decision_ui_projection)
        universal_shadow={
            'status':_universal_result.cycle.status,
            'cycle_id':_universal_result.cycle.context.cycle_id,
            'observed_at':_universal_result.cycle.context.observed_at,
            'candidate_count':len(_universal_result.bridge.candidates),
            'recommendation_snapshot_count':len(_universal_result.cycle.recommendation_snapshots),
            'history_write_performed':bool(_universal_result.cycle.history_write_performed),
            'financial_mutation':bool(_universal_result.cycle.financial_mutation),
            'execution_performed':bool(_universal_result.cycle.execution_performed),
            # A6: expose existing governed projection in refresh response only.
            # No persistence, no canonical promotion, no financial operations.
            'economic_decision_ui_projection': _a6_safe_projection(
                _universal_result.economic_decision_ui_projection),
        }
        # A24: read-only market HTTP only; observations use a separate research journal.
        from universal_portfolio.research_quote_acquisition_a24 import collect as _a24_collect_quotes
        universal_shadow['funded_currency_acquisition']=_a24_collect_quotes(
            ROOT,_universal_result.bridge.intelligence.get('funded_currency_research') or {})
    except Exception as exc:
        # Shadow failure is observable in this refresh result but cannot fail the legacy cycle.
        universal_shadow={'status':'SHADOW_ERROR','error_type':type(exc).__name__,'error':str(exc)}
    # P3_3_ECONOMIC_OBSERVATION_BEGIN
    # Read-only observation. Never derive utility from tickers, scores or signals.
    try:
        from universal_portfolio.brain_economic_runtime_boundary_p32 import observe_economic_decision
        _rows = getattr(_universal_result, 'economic_comparison_rows', None) if universal_shadow and universal_shadow.get('status') != 'SHADOW_ERROR' else None
        _observed = observe_economic_decision(_rows)
        universal_shadow['economic_observation'] = {
            'status': _observed.get('status', 'UNAVAILABLE'),
            'reason': _observed.get('reason'),
            'runtime_wiring': True,
            'execution_authorized': False,
        }
    except Exception as _exc:
        if universal_shadow is not None:
            universal_shadow['economic_observation'] = {
                'status': 'UNAVAILABLE',
                'reason': 'OBSERVATION_ERROR:' + type(_exc).__name__,
                'runtime_wiring': True, 'execution_authorized': False,
            }
    # P3_3_ECONOMIC_OBSERVATION_END
    try:
        from brain.evolution.learning_cycle import ingest_snapshot
        next_cycle=int(_read_json(ROOT/'results'/'learning_cycle.json',{}).get('cycles',0))+1
        do_research=(next_cycle % 3 == 0)
        state=ingest_snapshot(out, cycle_index=next_cycle, do_research=do_research)

        # r21.383g — autonomous Prediction Lab cadence.
        # One algorithm is evaluated every 6 learning cycles (~60 min at the
        # canonical 10-minute refresh cadence). This is learning only:
        # no automatic promotion, execution authority, orders, ledger or cash.
        if next_cycle % 6 == 0:
            try:
                from brain.evolution.prediction_lab import run_next as run_prediction_next
                state['prediction_lab']=run_prediction_next()
            except Exception as exc:
                state['prediction_lab_error']=str(exc)

            try:
                from brain.evolution.quantitative_evolution import run_next
                state['evolution']=run_next()
            except Exception as exc:
                state['evolution_error']=str(exc)
        # P35L_OBSERVABILITY_INTEGRATION_BEGIN
        # Research-only observation on the existing six-cycle cadence.
        # Never promote, execute, mutate financial state, or fail the legacy cycle.
        if next_cycle % 6 == 0:
            try:
                from brain.evolution.p35k_maturity_monitor import monitor as _p35l_monitor
                _p35l_result = _p35l_monitor(ROOT)
                if not isinstance(_p35l_result, dict):
                    raise TypeError('INVALID_MONITOR_RESULT')
                state['prospective_maturity'] = _p35l_result
            except Exception as _p35l_exc:
                state['prospective_maturity'] = {
                    'status': 'NOT_VALIDATED',
                    'monitor_status': 'FAIL_CLOSED',
                    'authority': 'RESEARCH_ONLY',
                    'economic_comparison_status': 'NOT_VALIDATED',
                    'comparator_promotion': False,
                    'execution_performed': False,
                    'issues': ['OBSERVABILITY_ERROR:' + type(_p35l_exc).__name__],
                }
        # P35L_OBSERVABILITY_INTEGRATION_END
    except Exception:
        state={}
    return {'status':'OK','snapshot':out,'learning_cycle':state,'universal_shadow':universal_shadow}


def _hydrate():
    import database
    database.main()
    return {'status':'OK','rows':len(_read_csv(ROOT/'data'/'database'/'market_daily.csv'))}


def _model(name):
    from brain.evolution.prediction_lab import run_algorithm
    return run_algorithm(name)


def _evolve():
    from brain.evolution.quantitative_evolution import run_next
    return run_next()


def _research():
    return brain().self_research()


def _chat(message):
    return brain().command(message, context={'last_algorithm': _read_json(ROOT/'results'/'prediction_lab.json',{}).get('algorithm')})


def _import_uploaded(filename, data, declared_type):
    temp=Path(tempfile.mkdtemp(prefix='porquinho_web_import_'))
    try:
        original=Path(filename).name
        mapping={'daily':'market_daily.csv','intraday':'market_intraday_10m.csv','portfolio':'portfolio_daily.csv','outcomes':'signal_outcomes.csv','legacy':'historico_compacto.csv'}
        dest=mapping.get(declared_type, original)
        (temp/dest).write_bytes(data)
        from tools.import_history import import_path
        result=import_path(temp)
        try:
            from porquinho import hydrate_portfolio_daily_from_market_history
            result['portfolio_daily_added']=hydrate_portfolio_daily_from_market_history()
        except Exception as exc:
            result.setdefault('errors',[]).append('Consolidação: '+str(exc))
        return {'status':'OK','type':declared_type,'result':result}
    finally:
        shutil.rmtree(temp,ignore_errors=True)



# V382421_ACCOUNT_ENTITY_UI_METADATA
@app.get("/api/account-entities")
def v382421_account_entities_get():
    import json
    from pathlib import Path
    q=Path(__file__).resolve().parents[1]/"data"/"account_entities.json"
    if not q.exists(): return {"ok":False,"error":"ACCOUNT_ENTITY_REGISTRY_NOT_FOUND"},404
    d=json.loads(q.read_text(encoding="utf-8"))
    if d.get("schema")!="porquinho.account-entity-registry/1.0": return {"ok":False,"error":"UNKNOWN_ACCOUNT_ENTITY_SCHEMA"},409
    return {"ok":True,"registry":d}

@app.post("/api/account-entities/<account_id>/metadata")
def v382421_account_entity_metadata_post(account_id):
    import json,datetime,os
    from pathlib import Path
    payload=request.get_json(silent=True) or {}
    allowed={"friendly_name","institution_name"}
    if any(k not in allowed for k in payload): return {"ok":False,"error":"UNSUPPORTED_METADATA_FIELD"},400
    q=Path(__file__).resolve().parents[1]/"data"/"account_entities.json"
    if not q.exists(): return {"ok":False,"error":"ACCOUNT_ENTITY_REGISTRY_NOT_FOUND"},404
    d=json.loads(q.read_text(encoding="utf-8"))
    if d.get("schema")!="porquinho.account-entity-registry/1.0": return {"ok":False,"error":"UNKNOWN_ACCOUNT_ENTITY_SCHEMA"},409
    target=next((e for e in d.get("entities",[]) if e.get("account_id")==account_id),None)
    if target is None: return {"ok":False,"error":"ACCOUNT_ENTITY_NOT_FOUND"},404
    def clean(v):
        if v is None: return None
        v=str(v).strip()
        return v[:120] if v else None
    for k in allowed:
        if k in payload: target[k]=clean(payload[k])
    target["metadata_provenance"]="EXPLICIT_USER_WRITE"
    target["metadata_updated_at"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
    target["financial_source_of_truth"]=False
    target["cash_source_of_truth"]=False
    target["position_source_of_truth"]=False
    tmp=q.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(d,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    os.replace(tmp,q)
    return {"ok":True,"entity":target,"production_effect":"NONE"}

@app.get('/')
def index():
    return render_template('index.html', version='3.4.2-web')

@app.get('/api/status')
def api_status():
    # A2_CANONICAL_AVAILABILITY_V1: reporting only; never promote shadow/legacy signals.
    canonical_availability = {
        'schema': 'porquinho.canonical-ui-availability/1.0',
        'status': 'UNAVAILABLE',
        'reason': 'CANONICAL_PRODUCER_NOT_WIRED',
        'canonical': None,
        'execution_authorized': False,
        'experimental_authority_unchanged': True,
        'a2_integration_state': 'ECONOMIC_EVIDENCE_ONLY_NOT_CANONICAL',
        'decision_actions_available': False,
        'market_provenance_required': True,
        'governed_sizing_required': True,
    }
    # A2_CANONICAL_STATUS_SOURCE_CONTRACT: reflect source wiring, never infer recommendations.
    # The existing universal runtime composition explicitly runs SHADOW mode with
    # zero canonical snapshots; observation is not a recommendation.
    from universal_portfolio.universal_runtime_composition import contract_payload as _a2_runtime_contract
    _a2_contract = _a2_runtime_contract()
    if (_a2_contract.get('runtime_wiring') is False
            and _a2_contract.get('canonical_recommendation_snapshots_expected') == 0):
        canonical_availability['reason'] = 'SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS'
        canonical_availability['producer_mode'] = 'SHADOW_OFFLINE_NO_HISTORY_WRITE'
    else:
        # A changed producer contract requires explicit reconciliation, not auto-promotion.
        canonical_availability['reason'] = 'CANONICAL_PRODUCER_CONTRACT_CHANGED_REVIEW_REQUIRED'
        canonical_availability['producer_mode'] = 'UNVERIFIED'
    return jsonify(_clean_json({'snapshot':snapshot(),'learning':learning(),'portfolio':portfolio(),'history':history_meta(),'jobs':list(JOBS.values())[-12:], 'canonical_decision_availability':canonical_availability, 'economic_decision_ui_projection':_a7_status_projection()}))

# V38131_EXECUTIVE_HEALTH_API

# V381310_LEARNING_BRAIN_COCKPIT
@app.get('/api/experience/learning')
def api_experience_learning():
    try:
        epdir=ROOT/'data'/'brain_experimental_episodes'
        summary=_read_json(epdir/'summary.json', {})
        contract=_read_json(epdir/'outcome_contract.json', {})
        outcomes=_read_json(epdir/'outcomes_latest.json', {})
        episodes=[]
        if epdir.exists():
            for fp in sorted(epdir.glob('*.json')):
                if fp.name in {'summary.json','outcome_contract.json','outcomes_latest.json'}: continue
                e=_read_json(fp,{})
                if e.get('schema')=='porquinho.brain-experimental-episode/1.0': episodes.append(e)
        episodes.sort(key=lambda e:(str(e.get('started_at','')),str(e.get('asset',''))),reverse=True)
        return {'schema':'porquinho.experience-learning/1.0','state':'OK','episode_count':len(episodes),
          'distinct_assets':len({str(e.get('asset','')) for e in episodes}),
          'experimental_episode_count':sum(1 for e in episodes if bool(e.get('experimental'))),
          'parity_episode_count':sum(1 for e in episodes if not bool(e.get('experimental'))),
          'episodes':episodes,'outcomes':outcomes,'contract':contract,'summary':summary,
          'confidence_semantics':'EVIDENCE_QUALITY_NOT_PROBABILITY',
          'experimental_star_semantics':'NOT_CONSOLIDATED_EVIDENCE',
          'execution':'MANUAL_ONLY','automatic_promotion':False,'production_effect':'NONE'}
    except Exception as exc:
        return {'schema':'porquinho.experience-learning/1.0','state':'ERROR','error':str(exc),
          'execution':'MANUAL_ONLY','automatic_promotion':False,'production_effect':'NONE'}

@app.get('/api/experience/health')
def api_experience_health():
    def read_health(name):
        try:
            return json.loads((ROOT/'results'/name).read_text(encoding='utf-8'))
        except Exception:
            return None
    return jsonify(_clean_json({
        'auto_cycle':read_health('auto_cycle_health.json'),
        'intraday_producer':read_health('intraday_producer_health.json'),
        'cadence_seconds':600,
        'execution_buy':'UNSUPPORTED',
        'execution_sell':'UNSUPPORTED',
        'production_mode':'HUMAN_CONTROLLED'
    }))

@app.get('/api/bridge/v1/health')
def api_bridge_health():
    if not os.environ.get('PORQUINHO_BRIDGE_TOKEN'):
        return jsonify({'error':'bridge disabled'}),503
    if not _bridge_authorized():
        return jsonify({'error':'unauthorized'}),401
    return jsonify({'contract':'dff-porquinho/1.0','system':'Porquinho',
                    'version':'3.4.2-web','status':'ok','generated_at':_now()})

# R21.367C2_PLANNING_BUDGET_API
from webapp.planning_budget_api_r21367c import init as init_planning_budget_api_r21367c
app.register_blueprint(init_planning_budget_api_r21367c(ROOT, snapshot))

# R21.369C_PLANNING_DIMENSIONS_API
try:
    from webapp.planning_dimensions_api_r21369c import init as _r21369c_init
    app.register_blueprint(_r21369c_init(ROOT, snapshot))
except Exception as _r21369c_exc:
    print("R21.369C planning dimensions API unavailable:", _r21369c_exc)

# R21.362_LIVE_FINANCIAL_PROJECTION_EXPERIENCE_ADAPTER
@app.get('/api/portfolio/live-projection')
def api_portfolio_live_projection_r21362():
    """Read-only Experience adapter over canonical financial runtime + last snapshot."""
    try:
        from universal_portfolio.live_financial_projection import build as build_live_financial_projection
        out = build_live_financial_projection(ROOT, snapshot())
        if out.get('cross_currency_aggregation') is not False:
            return jsonify({'ok':False,'error':'LIVE_PROJECTION_CROSS_CURRENCY_GUARD'}),500
        return jsonify(_clean_json({'ok':True,'projection':out}))
    except Exception as exc:
        return jsonify(_clean_json({'ok':False,'error':'LIVE_FINANCIAL_PROJECTION_UNAVAILABLE','detail':str(exc)})),500

@app.get('/api/bridge/v1/portfolio')
def api_bridge_portfolio():
    if not os.environ.get('PORQUINHO_BRIDGE_TOKEN'):
        return jsonify({'error':'bridge disabled'}),503
    if not _bridge_authorized():
        return jsonify({'error':'unauthorized'}),401
    return jsonify(_clean_json(bridge_portfolio()))

# V3678_FIXED_INCOME_UI_API
@app.get('/api/fixed-income/intelligence')
def api_fixed_income_intelligence():
    from market_data.service import MarketDataService
    from fixed_income.contract import build_contracts
    from fixed_income.decision import decide
    from fixed_income.learning import summarize
    raw=json.loads((ROOT/'static'/'data'/'portfolio_br_v365.json').read_text(encoding='utf-8'))
    contracts=build_contracts(raw.get('positions',[]))
    macro=MarketDataService(ROOT).macro_snapshot()
    decisions=[]
    for current in contracts:
        for candidate in contracts:
            if current['identity']['position_id']==candidate['identity']['position_id']:
                continue
            try:
                decisions.append(decide(current,candidate,macro,contracts,10000.0,365))
            except Exception as exc:
                decisions.append({'schema':'porquinho.fixed-income-decision/1.0','current_position_id':current['identity']['position_id'],'candidate_position_id':candidate['identity']['position_id'],'action':'MANTENHA','confidence':{'level':'INSUFFICIENT','meaning':'EVIDENCE_QUALITY'},'blockers':['DECISION_CALCULATION_UNAVAILABLE'],'warnings':[],'economic_advantage_brl':None,'economic_advantage_pct_points':None,'execution':'MANUAL_ONLY','error_type':type(exc).__name__})
    return jsonify(_clean_json({'schema':'porquinho.fixed-income-ui/1.0','generated_from':'LIVE_FIXED_INCOME_ENGINES','contracts':contracts,'decisions':decisions,'learning':summarize(ROOT/'data'/'fixed_income'/'learning_ledger.json'),'policy':{'execution':'MANUAL_ONLY','confidence_meaning':'EVIDENCE_QUALITY','comparison_amount_brl':10000.0,'comparison_horizon_days':365}}))


# V3710_EQUITY_UI_API
@app.get('/api/equities/intelligence')
def api_equities_intelligence():
    def _eq_read(name, default):
        return _read_json(ROOT/'data'/'equities'/name, default)
    market=_eq_read('market_snapshot_latest.json',{})
    fundamentals=_eq_read('fundamentals_latest.json',{})
    technical=_eq_read('technical_latest.json',{})
    risk=_eq_read('risk_regime_latest.json',{})
    opportunity=_eq_read('opportunity_latest.json',{})
    portfolio=_eq_read('portfolio_intelligence_latest.json',{})
    learning=_eq_read('learning_ledger.json',{})
    decisions=_eq_read('decision_latest.json',{})
    return jsonify(_clean_json({
        'schema':'porquinho.equity-ui/1.0',
        'generated_from':'LIVE_EQUITY_INTELLIGENCE_SNAPSHOTS',
        'market':market,
        'fundamentals':fundamentals,
        'technical':technical,
        'risk_regime':risk,
        'opportunity':opportunity,
        'portfolio':portfolio,
        'learning':learning,
        'decisions':decisions,
        'policy':{
            'execution':'MANUAL_ONLY',
            'confidence_meaning':'EVIDENCE_QUALITY',
            'frontend_recalculates_decisions':False
        }
    }))

@app.get('/api/market-data/macro')
def api_market_data_macro():
    from market_data.service import MarketDataService
    return jsonify(_clean_json(MarketDataService(ROOT).macro_snapshot()))

@app.get('/api/market-data/radar')
def api_market_data_radar():
    from market_data.service import MarketDataService
    return jsonify(_clean_json(MarketDataService(ROOT).radar_snapshot()))

@app.get('/api/intraday')
def api_intraday():
    h=max(1,min(48,int(request.args.get('hours',24))))
    return jsonify(_clean_json({'hours':h,'rows':intraday(h)}))

@app.get('/api/daily')
def api_daily():
    return jsonify(_clean_json({'rows':daily()}))

@app.get('/api/job/<job_id>')
def api_job(job_id):
    with JOBS_LOCK: j=JOBS.get(job_id)
    if not j:return jsonify({'error':'job not found'}),404
    return jsonify(_clean_json(j))

@app.get('/api/portfolio/position/<asset>')
def api_portfolio_position_v38941(asset):
    try:
        from webapp.portfolio_edit_v38941 import get_position
        return jsonify(_clean_json({"status":"OK","position":get_position(ROOT,asset)}))
    except Exception as exc:return jsonify({"status":"ERROR","error":str(exc)}),400

@app.post('/api/portfolio/position')
def api_portfolio_position_update_v38941():
    try:
        from webapp.portfolio_edit_v38941 import apply
        return jsonify(_clean_json(apply(ROOT,request.get_json(silent=True) or {},pending_store=REALIZE_PENDING_STORE)))
    except Exception as exc:return jsonify({"status":"ERROR","error":str(exc)}),400

@app.get('/api/portfolio/position/review/<session_id>')
def api_portfolio_realize_review_v38941(session_id):
    try: return jsonify(_clean_json(REALIZE_PENDING_STORE.get(session_id)))
    except ManualRealizePendingReviewRejected as exc: return jsonify({"status":"ERROR","error":str(exc)}),404

@app.post('/api/portfolio/position/review/<session_id>/approve')
def api_portfolio_realize_approve_v38941(session_id):
    try:
        body=request.get_json(silent=True) or {}
        if body.get("approval") is not True: return jsonify({"status":"ERROR","error":"EXPLICIT_APPROVAL_REQUIRED"}),400
        ledger=TransactionLedger(ROOT/'data'/'transaction_ledger.jsonl')
        result=REALIZE_PENDING_STORE.approve(session_id=session_id,sell_candidate_id=str(body.get("sell_candidate_id") or ""),fee_candidate_id=body.get("fee_candidate_id"),approval=True,approved_by="WEB_HUMAN_EXPLICIT",approved_at=_now(),ledger=ledger)
        plans=REALIZE_PENDING_STORE.build_plans(session_id=session_id,root=ROOT,ledger=ledger)
        persisted_at=_now()
        SELL_SERVER_PLAN_STORE.persist_ready(session_id=result.session_id,plan=plans["sell_plan"],created_at=persisted_at)
        # Q10M12B: persist approved execution context before any future execute call.
        ctx=REALIZE_PENDING_STORE.get_financial_context(result.session_id)
        fee_review=ctx.get("fee_review")
        SELL_FEE_BUNDLE_STORE.persist_ready_or_get_existing(
            bundle_id=result.session_id,
            sell_plan_sha256=plans["sell_plan"].plan_sha256,
            fee_required=fee_review is not None,
            created_at=persisted_at,
        )
        if fee_review is not None:
            FEE_RECOVERY_ARTIFACT_STORE.persist_or_get_existing(
                bundle_id=result.session_id,
                sell_plan_sha256=plans["sell_plan"].plan_sha256,
                fee_review=fee_review,
                created_at=persisted_at,
            )
        return jsonify(_clean_json({"status":"COMMIT_PLAN_READY","session_id":result.session_id,"explicit_approval_received":True,"sell_approval_sha256":result.sell_approval.approval_sha256,"fee_approval_sha256":None if result.fee_approval is None else result.fee_approval.approval_sha256,"sell_plan_sha256":plans["sell_plan"].plan_sha256,"fee_plan_sha256":None if plans["fee_plan"] is None else plans["fee_plan"].plan_sha256,"position_domain":result.position_domain,"position_id":result.position_id,"commit_ready":False,"commit_plan_created":True,"ledger_append":False,"alerts_acknowledged":0,"canonical_real_ledger_authorized":False}))
    except ManualRealizePendingReviewRejected as exc: return jsonify({"status":"ERROR","error":str(exc)}),409
    except Exception as exc: return jsonify({"status":"ERROR","error":str(exc)}),400

@app.post('/api/refresh')
def api_refresh():
    return jsonify(_clean_json({'job_id':submit('refresh',_refresh)}))

@app.post('/api/hydrate')
def api_hydrate():
    return jsonify(_clean_json({'job_id':submit('history_hydrate',_hydrate)}))

@app.post('/api/model')
def api_model():
    data=request.get_json(silent=True) or {}
    name=data.get('algorithm')
    if not name:return jsonify({'error':'Selecione um algoritmo'}),400
    return jsonify(_clean_json({'job_id':submit('model',lambda:_model(name))}))

@app.post('/api/evolve')
def api_evolve():
    return jsonify(_clean_json({'job_id':submit('evolve',_evolve)}))

@app.post('/api/research')
def api_research():
    return jsonify(_clean_json({'job_id':submit('research',_research)}))

@app.post('/api/chat')
def api_chat():
    data=request.get_json(silent=True) or {}
    msg=str(data.get('message','')).strip()
    if not msg:return jsonify({'error':'Mensagem vazia'}),400
    return jsonify(_clean_json({'job_id':submit('chat',lambda:_chat(msg))}))


@app.get('/api/patches')
def api_patches():
    from brain.patches import PatchRegistry
    return jsonify(_clean_json({'patches':PatchRegistry(ROOT).list()}))

@app.post('/api/patch/<patch_id>/implement')
def api_patch_implement(patch_id):
    def work():
        from brain.patches import PatchRegistry
        from brain.evolution.validator import Validator
        return PatchRegistry(ROOT).implement(patch_id,Validator(ROOT))
    return jsonify(_clean_json({'job_id':submit('patch_implement',work)}))


@app.post('/api/browser-diagnostic')
def api_browser_diagnostic():
    data=request.get_json(silent=True) or {}
    allowed={k:data.get(k) for k in ('stage','timestamp','user_agent','chart_available','canvas_present','canvas_width','canvas_height','intraday_rows','intraday_chart_created','error_message','error_stack')}
    allowed['received_at']=time.time()
    p=ROOT/'results'/'browser_runtime.json'; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(_clean_json(allowed),ensure_ascii=False,indent=2),encoding='utf-8')
    return jsonify({'ok':True})

@app.post('/api/import')
def api_import():
    declared=request.form.get('type','legacy')
    f=request.files.get('file')
    if not f:return jsonify({'error':'Selecione um arquivo'}),400
    raw=f.read()
    return jsonify({'job_id':submit('import',lambda:_import_uploaded(f.filename,raw,declared))})

# G17_R185_LIVE_EPHEMERAL_BALANCE_API
@app.post("/api/settings/providers/pluggy/ephemeral-balance")
def g17_pluggy_ephemeral_balance():
    from flask import request, jsonify
    from universal_portfolio.provider_connectivity import read_authorized_pluggy_mapped_balance
    try:
        body=request.get_json(silent=True)
        if not isinstance(body,dict) or set(body.keys()) != {"item_id","account_id"}:
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        item_id=body.get("item_id"); account_id=body.get("account_id")
        if not isinstance(item_id,str) or not item_id.strip() or not isinstance(account_id,str) or not account_id.strip():
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        provider=_G15_PLUGGY_PROVIDER
        result=read_authorized_pluggy_mapped_balance(provider,item_id.strip(),account_id.strip(),root=ROOT,timeout=10)
        return jsonify({"ok":True,"result":result}),200
    except RuntimeError as exc:
        code=str(exc)
        safe=code if code.startswith("PROVIDER_HTTP_") or code.isupper() and len(code)<80 else "EPHEMERAL_BALANCE_READ_FAILED"
        return jsonify({"ok":False,"error":safe}),409
    except Exception:
        return jsonify({"ok":False,"error":"EPHEMERAL_BALANCE_READ_FAILED"}),500

# G18_R193_OBSERVATIONAL_BALANCE_SNAPSHOT_API
@app.post("/api/settings/providers/pluggy/balance-observation")
def g18_pluggy_balance_observation():
    from flask import request, jsonify
    from universal_portfolio.account_balance_observations import persist_authorized_ephemeral_balance_observation, BalanceObservationError
    try:
        body=request.get_json(silent=True)
        if not isinstance(body,dict) or set(body.keys()) != {"item_id","account_id"}: return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        item_id=body.get("item_id"); account_id=body.get("account_id")
        if not isinstance(item_id,str) or not item_id.strip() or not isinstance(account_id,str) or not account_id.strip(): return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        result=persist_authorized_ephemeral_balance_observation(provider=_G15_PLUGGY_PROVIDER,item_id=item_id.strip(),account_id=account_id.strip(),root=ROOT,observation_path=ROOT/"data"/"account_balance_observations.json",timeout=10)
        return jsonify({"ok":True,"result":result}),200
    except (BalanceObservationError,RuntimeError) as exc:
        code=str(exc); safe=code if (code.startswith("PROVIDER_HTTP_") or (code.isupper() and len(code)<96)) else "BALANCE_OBSERVATION_FAILED"
        return jsonify({"ok":False,"error":safe}),409
    except Exception:
        return jsonify({"ok":False,"error":"BALANCE_OBSERVATION_FAILED"}),500

# G181_R197_OBSERVATION_HISTORY_READ_API
@app.get("/api/settings/account-balance-observations")
def g181_account_balance_observation_history():
    from flask import request, jsonify
    from universal_portfolio.account_balance_observations import read_authorized_account_balance_observations, BalanceObservationError
    try:
        allowed={"account_id","limit"}
        if not set(request.args.keys()).issubset(allowed) or "account_id" not in request.args: return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        account_id=request.args.get("account_id","").strip()
        raw_limit=request.args.get("limit","50")
        if not account_id: return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        try: limit=int(raw_limit)
        except Exception: return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        result=read_authorized_account_balance_observations(account_id=account_id,root=ROOT,observation_path=ROOT/"data"/"account_balance_observations.json",limit=limit)
        return jsonify({"ok":True,"result":result}),200
    except BalanceObservationError as exc:
        code=str(exc); safe=code if code.isupper() and len(code)<96 else "OBSERVATION_HISTORY_FAILED"
        return jsonify({"ok":False,"error":safe}),409
    except Exception:
        return jsonify({"ok":False,"error":"OBSERVATION_HISTORY_FAILED"}),500

# G19_R20102_SANITIZED_LIVE_FAILURE_DIAGNOSTICS
def _g19_safe_failure_stage(code):
    c = str(code or "").upper()
    if any(x in c for x in ("CONNECTED_READ","EXECUTION","CANONICAL","MAPPED","DISCOVERY","ITEM_")): return "CANONICAL_GATE"
    if any(x in c for x in ("CREDENTIAL","AUTH","API_KEY","CLIENT_ID","CLIENT_SECRET")): return "AUTH"
    if any(x in c for x in ("TIMEOUT","HTTP","REQUEST_FAILED","REDIRECT","CONTENT_TYPE","RESPONSE_TOO_LARGE")): return "HTTP"
    if any(x in c for x in ("ACCOUNT_MISMATCH","TRANSACTION_ACCOUNT")): return "ACCOUNT_IDENTITY"
    if any(x in c for x in ("CURSOR","PAGE_LIMIT","PAGINATION","NEXT_")): return "PAGINATION"
    if "G19_STRUCT_GATE" in c: return "STRUCT_GATE"
    if "G19_STRUCT_AUTH" in c: return "STRUCT_AUTH"
    if "G19_STRUCT_TRANSPORT" in c: return "STRUCT_TRANSPORT"
    if "G19_STRUCT_POSTCONDITION" in c: return "STRUCT_POSTCONDITION"
    if "POSTCONDITION" in c: return "POSTCONDITION"
    if any(x in c for x in ("SCHEMA","JSON","TRANSACTION_","INVALID_")): return "SCHEMA"
    return "UNKNOWN"

# G19_R2091_CONTROLLED_LIVE_TRANSACTION_ENDPOINT
@app.post("/api/settings/providers/pluggy/ephemeral-transactions")
def g19_pluggy_ephemeral_transactions():
    from flask import request, jsonify
    from universal_portfolio.provider_connectivity import PluggyTransactionReadRequest, read_authorized_pluggy_transactions
    try:
        body=request.get_json(silent=True)
        if not isinstance(body,dict) or set(body.keys()) != {"item_id","account_id","start_at","end_at"}:
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        vals={k:body.get(k) for k in ("item_id","account_id","start_at","end_at")}
        if not all(isinstance(v,str) and v.strip() for v in vals.values()):
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        req=PluggyTransactionReadRequest(vals["account_id"].strip(),vals["item_id"].strip(),vals["start_at"].strip(),vals["end_at"].strip(),3)
        result=read_authorized_pluggy_transactions(provider=_G15_PLUGGY_PROVIDER,request=req,root=ROOT,timeout=10)
        false_keys=("transactions_persisted","ledger_mutated","portfolio_mutated","positions_mutated","patrimony_mutated","brain_mutated","execution_enabled","authority_changed")
        if result.get("observation_state")!="EPHEMERAL_PROVIDER_TRANSACTIONS" or any(result.get(k) is not False for k in false_keys):
            raise RuntimeError("TRANSACTION_POSTCONDITION_FAILED")
        from universal_portfolio.transaction_observations import transaction_selection_ref, transaction_observation_id, TransactionObservationRegistry
        existing={r.get("observation_id") for r in TransactionObservationRegistry(ROOT/"data"/"transaction_observations.json").observations(vals["account_id"].strip()) if isinstance(r,dict)}
        safe=[]
        for row in result.get("transactions",[]):
            if not isinstance(row,dict): raise RuntimeError("TRANSACTION_POSTCONDITION_FAILED")
            public={k:row.get(k) for k in ("amount","date","description","type","status")}
            public["selection_ref"]=transaction_selection_ref(account_id=vals["account_id"].strip(),provider_transaction_id=row.get("transaction_id"))
            oid=transaction_observation_id(account_id=vals["account_id"].strip(),provider_transaction_id=row.get("transaction_id"))
            if oid in existing: public["observation_id"]=oid
            safe.append(public)
        return jsonify({"ok":True,"result":{"observation_state":"EPHEMERAL_PROVIDER_TRANSACTIONS","transaction_count":len(safe),"transactions":safe,
            "transactions_persisted":False,"ledger_mutated":False,"portfolio_mutated":False,"positions_mutated":False,
            "patrimony_mutated":False,"brain_mutated":False,"execution_enabled":False,"authority_changed":False}}),200
    except RuntimeError as exc:
        structural=getattr(exc, "_g19_structural_stage", None)
        structural_allowed={"STRUCT_GATE","STRUCT_AUTH","STRUCT_TRANSPORT","STRUCT_HTTP","STRUCT_PAGE_VALIDATION","STRUCT_PAGE_SCHEMA","STRUCT_PAGE_IDENTITY","STRUCT_PAGE_PAGINATION","STRUCT_PAGE_VALUE","STRUCT_PAGE_ENVELOPE","STRUCT_PAGE_CURSOR","STRUCT_ROW_SHAPE","STRUCT_ROW_FIELDS","STRUCT_ROW_VALUE","STRUCT_POSTCONDITION"}
        stage=structural if structural in structural_allowed else _g19_safe_failure_stage(str(exc))
        print(f"[G19_SAFE_DIAG] stage={stage}", flush=True)
        return jsonify({"ok":False,"error":"EPHEMERAL_TRANSACTION_READ_FAILED","stage":stage}),409
    except Exception:
        print("[G19_SAFE_DIAG] stage=UNKNOWN", flush=True)
        return jsonify({"ok":False,"error":"EPHEMERAL_TRANSACTION_READ_FAILED","stage":"UNKNOWN"}),500



# G110_R216_TRANSACTION_OBSERVATION_RECONCILIATION_ENDPOINT
@app.post("/api/settings/providers/pluggy/transaction-observation-reconciliation")
def g110_pluggy_transaction_observation_reconciliation():
    from flask import request, jsonify
    from universal_portfolio.provider_connectivity import PluggyTransactionReadRequest, read_authorized_pluggy_transactions
    from universal_portfolio.transaction_observations import TransactionObservationRegistry
    from universal_portfolio.transaction_observation_reconciliation import reconcile_authorized_observation, TransactionObservationReconciliationError
    from universal_portfolio.transaction_observation_validations import TransactionObservationValidationRegistry, TransactionObservationValidationRegistryError
    try:
        body=request.get_json(silent=True)
        allowed={"item_id","account_id","start_at","end_at","observation_id"}
        if not isinstance(body,dict) or set(body.keys()) != allowed:
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        vals={k:body.get(k) for k in allowed}
        if not all(isinstance(v,str) and v.strip() for v in vals.values()):
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        vals={k:v.strip() for k,v in vals.items()}
        req=PluggyTransactionReadRequest(vals["account_id"],vals["item_id"],vals["start_at"],vals["end_at"],3)
        observations=TransactionObservationRegistry(ROOT/"data"/"transaction_observations.json").observations(vals["account_id"])
        provider_result=read_authorized_pluggy_transactions(provider=_G15_PLUGGY_PROVIDER,request=req,root=ROOT,timeout=10)
        false_keys=("transactions_persisted","ledger_mutated","portfolio_mutated","positions_mutated","patrimony_mutated","brain_mutated","execution_enabled","authority_changed")
        if not isinstance(provider_result,dict) or provider_result.get("observation_state")!="EPHEMERAL_PROVIDER_TRANSACTIONS" or any(provider_result.get(k) is not False for k in false_keys):
            raise TransactionObservationReconciliationError("provider_reread:postcondition")
        rows=provider_result.get("transactions")
        if not isinstance(rows,list):
            raise TransactionObservationReconciliationError("provider_reread:postcondition")
        current=[]
        required={"transaction_id","amount","date","description","type","status"}
        for row in rows:
            if not isinstance(row,dict) or set(row)!=required:
                raise TransactionObservationReconciliationError("provider_reread:postcondition")
            current.append({"amount":row["amount"],"transaction_at":row["date"],"description":row["description"],"type":row["type"],"status":row["status"]})
        validation_registry=TransactionObservationValidationRegistry(ROOT/"data"/"transaction_observation_validations.json")
        result=reconcile_authorized_observation(
            observation_id=vals["observation_id"],account_id=vals["account_id"],
            observations=observations,current_transactions=current,
            persist_validation=validation_registry.append)
        public={k:result.get(k) for k in ("observation_id","account_id","validation_status","validated_at","changed_fields","missing_scope","authority","ledger_semantics","execution","canonicalized","imported","ledger_mutated","portfolio_mutated","positions_mutated","patrimony_mutated","brain_mutated","authority_changed")}
        public.update({"ok":True,"schema":"porquinho.transaction-observation-reconciliation/1.0","provider_reread":True,"browser_financial_data_accepted":False})
        return jsonify(_clean_json(public))
    except (TransactionObservationReconciliationError,TransactionObservationValidationRegistryError,ValueError):
        return jsonify({"ok":False,"error":"TRANSACTION_OBSERVATION_RECONCILIATION_FAILED"}),400
    except RuntimeError:
        return jsonify({"ok":False,"error":"TRANSACTION_OBSERVATION_RECONCILIATION_FAILED"}),502


# G110_R213_TRANSACTION_OBSERVATION_ENDPOINT
@app.post("/api/settings/providers/pluggy/transaction-observation")
def g110_pluggy_transaction_observation():
    from flask import request, jsonify
    from universal_portfolio.provider_connectivity import PluggyTransactionReadRequest
    from universal_portfolio.transaction_observations import observe_authorized_pluggy_transaction, TransactionObservationError
    try:
        body=request.get_json(silent=True)
        allowed={"item_id","account_id","start_at","end_at","selection_ref"}
        if not isinstance(body,dict) or set(body.keys()) != allowed:
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        vals={k:body.get(k) for k in allowed}
        if not all(isinstance(v,str) and v.strip() for v in vals.values()):
            return jsonify({"ok":False,"error":"INVALID_REQUEST"}),400
        req=PluggyTransactionReadRequest(vals["account_id"].strip(),vals["item_id"].strip(),vals["start_at"].strip(),vals["end_at"].strip(),3)
        result=observe_authorized_pluggy_transaction(provider=_G15_PLUGGY_PROVIDER,request=req,selection_ref=vals["selection_ref"].strip(),root=ROOT,observation_path=ROOT/"data"/"transaction_observations.json",timeout=10)
        required_false=("browser_financial_data_accepted","transactions_imported","ledger_mutated","portfolio_mutated","positions_mutated","patrimony_mutated","brain_mutated","execution_enabled","authority_changed")
        if result.get("observation_persisted") is not True or result.get("authority")!="OBSERVATIONAL_ONLY" or result.get("ledger_semantics")!="NONE" or any(result.get(k) is not False for k in required_false):
            raise TransactionObservationError("TRANSACTION_OBSERVATION_POSTCONDITION_FAILED")
        safe_observation=result.get("observation")
        if not isinstance(safe_observation,dict) or any(k in safe_observation for k in ("provider_transaction_id","external_id","connector_id","api_key")):
            raise TransactionObservationError("TRANSACTION_OBSERVATION_POSTCONDITION_FAILED")
        return jsonify({"ok":True,"result":{"observation_persisted":True,"observation":safe_observation,"authority":"OBSERVATIONAL_ONLY","ledger_semantics":"NONE","provider_reread":True,"browser_financial_data_accepted":False,"transactions_imported":False,"ledger_mutated":False,"portfolio_mutated":False,"positions_mutated":False,"patrimony_mutated":False,"brain_mutated":False,"execution_enabled":False,"authority_changed":False}}),200
    except (TransactionObservationError,RuntimeError) as exc:
        code=str(exc); safe=code if code.isupper() and len(code)<96 else "TRANSACTION_OBSERVATION_FAILED"
        return jsonify({"ok":False,"error":safe}),409
    except Exception:
        return jsonify({"ok":False,"error":"TRANSACTION_OBSERVATION_FAILED"}),500

# R21.378D_INVESTMENT_PLAN_PREVIEW_API
from webapp.investment_plan_api_r21378d import create_blueprint as _r21378d_create_blueprint
app.register_blueprint(_r21378d_create_blueprint(ROOT, snapshot))


# r21.379d — canonical planning dimensions read-only projection
from webapp.investment_planning_dimensions_api_r21379d import register as register_investment_planning_dimensions_r21379d
register_investment_planning_dimensions_r21379d(app, ROOT)

from webapp.investment_plan_weekly_target_api_r21384d import create_blueprint as _r21384d_create_blueprint
app.register_blueprint(_r21384d_create_blueprint(ROOT))

# R21_386FK2_MANUAL_BUY_LIVE_HTTP_WIRING
from webapp.local_human_mutation_security_http_r21386eo import LocalHumanHttpSecurity as _r21386eo_LocalHumanHttpSecurity, init as _r21386eo_init
from webapp.manual_buy_create_order_http_r21386ep import init as _r21386ep_init
from universal_portfolio.manual_buy_live_domain_adapter import create_confirmed_order as _r21386fi_create_confirmed_order

_r21386_manual_buy_security = _r21386eo_LocalHumanHttpSecurity()
app.register_blueprint(_r21386ls23d_catalog_init(authorize_mutation=_r21386_manual_buy_security.authorize_request))
# R21_386LS16C5C_MANUAL_EXTERNAL_TRADE_HTTP
from webapp.manual_external_trade_api_r21386ls16a import create_blueprint as _r21386ls16c5c_init
from universal_portfolio.manual_buy_live_authority_reader import read as _r21386ls16c5c_read_live
from universal_portfolio.canonical_opportunity_manual_trade import build_trade_draft as _r21386ls16c5c_trade_draft
from universal_portfolio.manual_external_trade_review import build_review as _r21386ls16c5c_review, confirm_already_executed as _r21386ls16c5c_confirm
from universal_portfolio.manual_external_trade_production_authority import build_sequence as _r21386ls16c5c_sequence, issue_authority as _r21386ls16c5c_authority
from universal_portfolio.ledger import TransactionLedger as _r21386ls16c5c_Ledger
from universal_portfolio.manual_external_trade_durable_store import ManualExternalTradeDurableStore as _r21386ls16f_DurableStore
from universal_portfolio.manual_external_trade_production_authority import initial_journal as _r21386ls16f_initial_journal
from universal_portfolio.manual_external_trade_durable_execution_recovery import execute_recovery_foundation as _r21386ls18a_execute_recovery
from universal_portfolio.manual_external_trade_canonical_commit_integration import execute_foundation as _r21386ls18a_execute_foundation
def _r21386ls26b_account_mapping(account):
    # Composition-boundary adapter only: preserve LS1 strict Mapping contract.
    # Do not alias, infer, or hardcode account identity.
    fields=('account_id','institution_id','name','account_type','currency','management_mode',
            'connector_id','external_id','execution_enabled','owner_profile','created_at')
    out={k:getattr(account,k,None) for k in fields}
    if not str(out.get('account_id') or '').strip():
        raise RuntimeError('LIVE_ACCOUNT_ID_REQUIRED')
    if not str(out.get('currency') or '').strip():
        raise RuntimeError('LIVE_ACCOUNT_CURRENCY_REQUIRED')
    return out

def _r21386ls16c5c_build_draft(browser_trade):
    live=_r21386ls16c5c_read_live(project_root=ROOT); trade=dict(browser_trade); trade['provenance']={'source':'MANUAL_EXTERNAL_TRADE'}
    if 'funding_detail' in trade and 'funding_details' not in trade: trade['funding_details']=trade.pop('funding_detail')
    accounts=tuple(_r21386ls26b_account_mapping(x) for x in live.accounts)
    return _r21386ls16c5c_trade_draft(catalog=live.catalog,accounts=accounts,trade=trade,opportunity=None)
def _r21386ls16c5c_ledger_head(): return _r21386ls16c5c_Ledger(ROOT/'data'/'transaction_ledger.jsonl').verify()['head_hash']
_r21386ls16f_store = _r21386ls16f_DurableStore(ROOT/'data'/'manual_external_trade_execution_authorities.json')
def _r21386ls18a_execute_authorized(sequence_id):
    ledger=_r21386ls16c5c_Ledger(ROOT/'data'/'transaction_ledger.jsonl')
    return _r21386ls18a_execute_recovery(root=ROOT,store=_r21386ls16f_store,sequence_id=sequence_id,ledger=ledger,live_authority_reader=_r21386ls16c5c_read_live,execute_foundation=_r21386ls18a_execute_foundation,now_iso=lambda: datetime.now(timezone.utc).isoformat())
app.register_blueprint(_r21386ls16c5c_init(build_draft=_r21386ls16c5c_build_draft,build_review=_r21386ls16c5c_review,build_confirmation=_r21386ls16c5c_confirm,build_sequence=_r21386ls16c5c_sequence,issue_authority=_r21386ls16c5c_authority,initial_journal=_r21386ls16f_initial_journal,persist_authorized=_r21386ls16f_store.persist_ready,durable_record_loader=_r21386ls16f_store.load,execute_authorized=_r21386ls18a_execute_authorized,ledger_head_reader=_r21386ls16c5c_ledger_head,authorize_mutation=_r21386_manual_buy_security.authorize_request,now_iso=lambda: datetime.now(timezone.utc).isoformat()))
# R21_386LS16C5C_MANUAL_EXTERNAL_TRADE_HTTP_END
app.register_blueprint(_r21386eo_init(security=_r21386_manual_buy_security))
app.register_blueprint(_r21386ep_init(
    security=_r21386_manual_buy_security,
    create_confirmed_order=_r21386fi_create_confirmed_order,
    project_root=ROOT,
))

# R21_386HB_F8_PRODUCT_COCKPIT
from webapp.f8_product_cockpit_r21386hb import init as _r21386hb_init
app.register_blueprint(_r21386hb_init(project_root=ROOT))

# R21_386IO_OPPORTUNITY_ECONOMIC_READINESS_UI
from webapp.opportunity_economic_readiness_api_r21386io import create_blueprint as _r21386io_create_blueprint
app.register_blueprint(_r21386io_create_blueprint(ROOT))

# R21_386IR_F85_SIZING_READINESS_UI
from webapp.opportunity_sizing_readiness_api_r21386ir import create_blueprint as _r21386ir_create_blueprint
app.register_blueprint(_r21386ir_create_blueprint(ROOT))

# R21.386LF_UNIFIED_HISTORY_READ_API
# Read-only projections. These routes do not mutate histories or inherit authority.
@app.get('/api/system/history/summary')
def r21386lf_history_summary():
    from universal_portfolio.unified_history_query import UnifiedHistoryQuery
    return jsonify(UnifiedHistoryQuery(ROOT).summary())

@app.get('/api/system/history/operational')
def r21386lf_history_operational():
    from universal_portfolio.unified_history_query import UnifiedHistoryQuery
    q=UnifiedHistoryQuery(ROOT)
    return jsonify({"contract":"porquinho.system-operational-history-view/1.0",
                    "read_only":True,"incidents":q.operational(),"diagnostics":q.diagnostics()})

@app.get('/api/system/history/patches')
def r21386lf_history_patches():
    from universal_portfolio.unified_history_query import UnifiedHistoryQuery
    q=UnifiedHistoryQuery(ROOT)
    p=q.patches()
    return jsonify({"contract":"porquinho.system-patch-history-view/1.0",
                    "read_only":True,"repairs":p["repairs"],"registry":p["registry"]})

@app.get('/api/portfolio/history/recommendations')
def r21386lf_history_recommendations():
    from universal_portfolio.unified_history_query import UnifiedHistoryQuery
    return jsonify({"contract":"porquinho.recommendation-history-view/1.0",
                    "read_only":True,"records":UnifiedHistoryQuery(ROOT).recommendations()})

@app.get('/api/portfolio/history/transactions')
def r21386lf_history_transactions():
    from universal_portfolio.unified_history_query import UnifiedHistoryQuery
    return jsonify({"contract":"porquinho.transaction-history-view/1.0",
                    "read_only":True,"records":UnifiedHistoryQuery(ROOT).transactions(),
                    "provenance_status":"NO_PROVEN_CANONICAL_EVENT_BACKFILL"})
# /R21.386LF_UNIFIED_HISTORY_READ_API

# A24_ACQUISITION_PLAN_READ_ONLY
@app.get('/api/research/acquisition-plan')
def a24_research_acquisition_plan():
    from universal_portfolio.universal_observation_bridge import build_read_only_bridge
    from universal_portfolio.research_quote_acquisition_a24 import plan
    demand=build_read_only_bridge(ROOT).intelligence.get('funded_currency_research') or {}
    try:
        result=plan(ROOT,demand)
        result['eligible_source_job_count']=len(result.pop('jobs'))
        return jsonify(result)
    except Exception as exc:
        return jsonify({'status':'PLAN_UNAVAILABLE','reason':type(exc).__name__,'network_requests':0,'automatic_execution_authorized':False}),409

# A24_FUNDING_RESEARCH_READ_ONLY
@app.get('/api/research/funding-contexts')
def a24_funding_research_contexts():
    from universal_portfolio.universal_observation_bridge import build_read_only_bridge
    result=build_read_only_bridge(ROOT).intelligence.get('funded_currency_research') or {}
    return jsonify(result), (409 if result.get('status')=='UNAVAILABLE' else 200)

if __name__=='__main__':
    import logging
    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    threading.Thread(target=auto_loop,daemon=True,name='porquinho-auto-loop').start()
    app.run(host='127.0.0.1',port=8765,debug=False,threaded=True)
