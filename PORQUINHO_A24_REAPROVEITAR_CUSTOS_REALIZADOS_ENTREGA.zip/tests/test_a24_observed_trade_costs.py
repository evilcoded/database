"""Executed-cost reuse from existing contracts; synthetic trades and no live writes."""
import copy,datetime as dt,json,tempfile,unittest
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from universal_portfolio import observed_trade_costs_a24 as observed
from universal_portfolio.ledger import TransactionLedger
from universal_portfolio.manual_external_trade_production_authority import build_sequence
from universal_portfolio.manual_external_trade_durable_store import SCHEMA as STORE_SCHEMA
NOW=dt.datetime(2026,10,16,12,tzinfo=dt.timezone.utc)
class Observed(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();(self.root/'data').mkdir();self.ledger=TransactionLedger(self.root/'data/transaction_ledger.jsonl')
  self.trade={'event_type':'BUY','asset_id':'EXPLICIT:GLOBAL:INSTRUMENT','account_id':'ACCOUNT_PRIVATE','currency':'JPY','quantity':'2','unit_price':'50','gross_amount':'100','executed_at':'2026-10-16T01:00:00Z','external_id':'TRADE1','source_ref':'SOURCE','provenance':{'source':'SYNTHETIC'},'identity_fingerprint_v2':'trade-fp'}
  self.fee={'event_type':'FEE','account_id':'ACCOUNT_PRIVATE','currency':'JPY','gross_amount':'1','executed_at':'2026-10-16T01:00:00Z','external_id':'FEE1','identity_fingerprint_v2':'fee-fp','provenance':{'parent_external_id':'TRADE1'}}
 def seed(self):self.ledger.append(self.trade);self.ledger.append(self.fee)
 def read(self):return observed.read(self.root,now=NOW)
 def rows(self):return self.read()['observations']
 def durable(self,status='COMPLETED'):
  review=SimpleNamespace(review_id='review1',economic_payload={'transaction_type':'BUY','funding_source':'REGISTERED_ACCOUNT_CASH','account_id':self.trade['account_id'],'instrument_id':self.trade['asset_id'],'transaction_currency':self.trade['currency'],'executed_at':self.trade['executed_at'],'quantity':'2','unit_price':'50','gross_amount':'100','fee_amount':'1','fee_currency':'JPY'})
  seq=build_sequence(review=review,confirmation=SimpleNamespace(already_executed_externally=True,review_id='review1',review_sha256='reviewhash'))
  self.trade['identity_fingerprint_v2']=seq.steps[0].identity_fingerprint_v2;self.fee['identity_fingerprint_v2']=seq.steps[1].identity_fingerprint_v2;self.fee['provenance']={}
  record={'sequence_id':seq.sequence_id,'sequence_sha256':seq.sequence_sha256,'authority_sha256':'authorityhash','status':status,'sequence':asdict(seq),'authority':{},'journal':{},'created_at':'2026-10-16T01:00:00Z','updated_at':'2026-10-16T01:00:00Z','terminal_detail':None}
  p=self.root/'data/manual_external_trade_execution_authorities.json';p.write_text(json.dumps({'schema':STORE_SCHEMA,'records':{seq.sequence_id:record}}));return p
 def test_exact_realized_amount_and_ratio(self):
  self.seed();r=self.rows()[0];self.assertEqual(r['observed_fee_amount'],'1');self.assertEqual(r['observed_fee_to_gross_fraction'],'0.01');self.assertEqual(r['currency'],'JPY');self.assertEqual(r['gross_amount'],'100')
 def test_assetless_fee_by_sequence(self):
  self.durable();self.seed();r=self.rows()[0];self.assertEqual(r['fee_assetless_count'],1);self.assertIn('EXPLICIT_SEQUENCE_STEP_IDENTITY',r['link_methods'])
 def test_mixed_link_methods_count_fee_once(self):
  self.durable();self.fee['provenance']={'parent_external_id':'TRADE1'};self.seed();r=self.rows()[0];self.assertEqual(len(r['fee_event_ids']),1);self.assertEqual(len(r['link_methods']),2)
 def test_different_account_refused(self):self.fee['account_id']='OTHER';self.seed();self.assertEqual(self.rows(),[])
 def test_different_currency_refused(self):self.fee['currency']='USD';self.seed();self.assertEqual(self.rows(),[])
 def test_fee_identity_conflict_refused(self):self.fee['asset_id']='OTHER:IDENTITY';self.seed();self.assertEqual(self.rows(),[])
 def test_missing_fee_not_zero(self):self.ledger.append(self.trade);self.assertEqual(self.rows(),[]);self.assertIn('EXPLICIT_LINKED_FEE_REQUIRED_NO_ZERO_ASSUMPTION',self.read()['blocking_reason_counts'])
 def test_explicit_fee_zero_preserved(self):self.fee['gross_amount']='0';self.seed();self.assertEqual(self.rows()[0]['observed_fee_amount'],'0')
 def test_bad_fee_not_silently_ignored(self):self.fee['gross_amount']='NaN';self.seed();self.assertEqual(self.rows(),[])
 def test_matching_time_amount_symbol_not_link(self):self.fee['provenance']={};self.fee['asset_id']=self.trade['asset_id'];self.seed();self.assertEqual(self.rows(),[])
 def test_duplicate_parent_trade_not_chosen(self):self.seed();self.ledger.append({**self.trade,'executed_at':'2026-10-16T02:00:00Z','identity_fingerprint_v2':'other-fp'});self.assertEqual(self.rows(),[])
 def test_sequence_fee_mismatch_refused(self):self.durable();self.fee['gross_amount']='2';self.seed();self.assertEqual(self.rows(),[])
 def test_sequence_trade_mismatch_refused(self):self.durable();self.trade['gross_amount']='101';self.trade['unit_price']='50.5';self.seed();self.assertEqual(self.rows(),[])
 def test_sequence_pending_not_executed_evidence(self):self.durable('IN_PROGRESS');self.seed();self.assertEqual(self.rows(),[])
 def test_future_trade_not_observed(self):self.trade['executed_at']='2027-01-01T00:00:00Z';self.seed();self.assertEqual(self.rows(),[])
 def test_future_fee_not_observed(self):self.fee['executed_at']='2027-01-01T00:00:00Z';self.seed();self.assertEqual(self.rows(),[])
 def test_nonfinite_and_inconsistent_trade_gross_refused(self):self.trade['gross_amount']='999';self.seed();self.assertEqual(self.rows(),[])
 def test_missing_aware_time_refused(self):self.trade['executed_at']='2026-10-16';self.seed();self.assertEqual(self.rows(),[])
 def test_explicit_commit_plan_link(self):self.trade['commit_plan_id']='plan';self.fee['commit_plan_id']='plan';self.fee['provenance']={};self.seed();self.assertIn('EXPLICIT_COMMIT_PLAN_ID',self.rows()[0]['link_methods'])
 def test_explicit_manual_transaction_link(self):self.trade['manual_external_transaction_id']='tx';self.fee['manual_external_transaction_id']='tx';self.fee['provenance']={};self.seed();self.assertIn('EXPLICIT_MANUAL_EXTERNAL_TRANSACTION_ID',self.rows()[0]['link_methods'])
 def test_same_fee_cannot_cost_two_trades(self):
  self.trade['commit_plan_id']='other';self.seed();self.ledger.append({**self.trade,'external_id':'TRADE2','identity_fingerprint_v2':'fp2','commit_plan_id':'plan2'});self.ledger.append({**self.fee,'external_id':'FEE2','identity_fingerprint_v2':'fpfee2','provenance':{'parent_external_id':'TRADE2'}})
  self.assertEqual(len(self.rows()),2)
  # Explicit conflict: the first fee also claims the second trade's unique plan.
  events=self.ledger.events();events[1]['commit_plan_id']='plan2';rows,issues,n=observed.analyze(events,{},now=NOW);self.assertEqual(rows,[]);self.assertIn('FEE_ALREADY_LINKED_TO_ANOTHER_TRADE',issues)
 def test_reversed_trade_not_reused(self):self.seed();e=self.ledger.events()[0];self.ledger.append({'event_type':'SELL','reversal_of_event_id':e['event_id'],'external_id':'reverse-trade'});self.assertEqual(self.rows(),[])
 def test_reversed_fee_not_reused(self):self.seed();e=self.ledger.events()[1];self.ledger.append({'event_type':'DEPOSIT','reversal_of_event_id':e['event_id'],'external_id':'reverse-fee'});self.assertEqual(self.rows(),[])
 def test_no_forecast_policy_or_authority_created(self):
  self.seed();r=self.rows()[0];self.assertIsNone(r['future_cost_estimate']);self.assertFalse(r['spread_slippage_tax_coverage_proven'])
  for k,v in observed.flags().items():self.assertEqual(r[k],v)
 def test_summary_redacts_amounts_quantities_accounts(self):
  self.seed();s=observed.summary(self.root,now=NOW);self.assertEqual(s['observed_trade_cost_count'],1);self.assertNotIn('ACCOUNT_PRIVATE',json.dumps(s));self.assertNotIn('observed_fee_amount',json.dumps(s));self.assertNotIn('gross_amount',json.dumps(s))
 def test_read_does_not_rewrite_or_create_any_data(self):
  self.durable();self.seed();before={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in self.root.rglob('*') if p.is_file()};self.read();observed.summary(self.root,now=NOW);self.assertEqual(before,{p:(p.read_bytes(),p.stat().st_mtime_ns) for p in self.root.rglob('*') if p.is_file()})
 def test_missing_ledger_no_store_created(self):self.assertEqual(self.read()['status'],'EXISTING_LEDGER_NOT_PRESENT');self.assertFalse(self.ledger.path.exists())
 def test_corrupt_ledger_unavailable_not_zero(self):self.seed();self.ledger.path.write_text('{}\n');s=observed.build(self.root,now=NOW);self.assertEqual(s['status'],'OBSERVED_COST_INSPECTION_UNAVAILABLE');self.assertIsNone(s['summary']['observed_trade_cost_count'])
 def test_corrupt_durable_store_unavailable(self):self.seed();(self.root/'data/manual_external_trade_execution_authorities.json').write_text('{}');self.assertEqual(observed.build(self.root,now=NOW)['status'],'OBSERVED_COST_INSPECTION_UNAVAILABLE')
 def test_symlink_ledger_refused(self):
  self.seed();p=self.ledger.path;target=self.root/'preserved';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target)
  with self.assertRaises(ValueError):self.read()
 def test_source_append_during_read_refused(self):
  self.seed();original=TransactionLedger.events
  def changed(obj):
   result=original(obj);obj.path.write_bytes(obj.path.read_bytes()+b'\n');return result
  with patch.object(TransactionLedger,'events',changed):
   with self.assertRaises(ValueError):self.read()
 def test_bridge_receives_typed_realized_values(self):
  self.durable();self.seed();from universal_portfolio.universal_observation_bridge import build_read_only_bridge
  result=build_read_only_bridge(self.root);r=result.intelligence['observed_manual_trade_costs'];self.assertEqual(r['summary']['observed_trade_cost_count'],1);self.assertEqual(r['observations'][0]['observed_fee_amount'],'1')
 def test_economic_source_diagnostic_receives_summary(self):
  self.seed();from universal_portfolio.economic_evidence_source_status_a2 import evidence_source_status
  r=evidence_source_status(self.root);self.assertEqual(r['observed_manual_trade_costs']['observed_trade_cost_count'],1);self.assertFalse(r['comparison_authorized'])
 def test_realized_evidence_cannot_be_promoted_by_governed_assembler(self):
  self.seed();from universal_portfolio.economic_component_set_producer_a24 import produce
  self.assertEqual(produce(self.rows()[0])['sets'],[])
