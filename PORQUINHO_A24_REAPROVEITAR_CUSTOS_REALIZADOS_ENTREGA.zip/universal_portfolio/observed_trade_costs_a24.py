"""Read existing executed trade/fee evidence. Never a future pricing model.
No data copying, journal creation, recovery, authority promotion or financial writes.
"""
import datetime as dt,json,hashlib
from collections import Counter,defaultdict
from dataclasses import dataclass,asdict
from decimal import Decimal,localcontext
from pathlib import Path
from .explicit_market_bindings_a24 import local
from .ledger import TransactionLedger
from .ledger_financial_translation import canonical_transaction_type,LedgerTranslationError
from .manual_external_trade_durable_store import _decode_durable_record,SCHEMA as STORE_SCHEMA
SCHEMA='porquinho.observed-trade-costs-a24/1.0'
class ObservationError(ValueError):pass

def text(v):return isinstance(v,str) and bool(v) and v==v.strip()
def number(v,positive=False):
 if isinstance(v,bool) or v is None or len(str(v))>80:raise ObservationError('OBSERVED_AMOUNT_REQUIRED')
 try:d=Decimal(str(v))
 except Exception:raise ObservationError('OBSERVED_AMOUNT_REQUIRED')
 if not d.is_finite() or d<0 or (positive and d==0) or abs(d.as_tuple().exponent)>24:raise ObservationError('FINITE_NONNEGATIVE_OBSERVED_AMOUNT_REQUIRED')
 return d

def kind(e):
 try:return canonical_transaction_type(e)
 except LedgerTranslationError:return None

def identity(e):
 a=e.get('asset_id');b=e.get('instrument_id')
 if a and b and a!=b:raise ObservationError('CONFLICTING_EXPLICIT_IDENTITIES')
 return a or b

def instant(v):
 try:t=dt.datetime.fromisoformat(v.replace('Z','+00:00'))
 except Exception:raise ObservationError('AWARE_EXECUTION_TIMESTAMP_REQUIRED')
 if t.tzinfo is None or t.utcoffset() is None:raise ObservationError('AWARE_EXECUTION_TIMESTAMP_REQUIRED')
 return t.astimezone(dt.timezone.utc)

def flags():return {'authority':'NONE','financial_mutation':False,'history_write_performed':False,'future_costs_validated':False,'comparison_authorized':False,'canonical_publication_authorized':False,'execution_authorized':False}

@dataclass(frozen=True)
class ObservedTradeCost:
 instrument_id:str
 account_id:str
 currency:str
 side:str
 executed_at:str
 trade_event_id:str
 trade_event_hash:str
 gross_amount:str
 quantity:str
 unit_price:str
 observed_fee_amount:str
 observed_fee_to_gross_fraction:str
 fee_event_ids:tuple
 fee_event_hashes:tuple
 fee_assetless_count:int
 link_methods:tuple
 completed_sequence_ids:tuple
 source_ref_present:bool
 def payload(self):
  return {**asdict(self),'schema':SCHEMA,'status':'EXECUTED_TRADE_AND_FEE_OBSERVED',
   'economic_role':'REALIZED_TRADE_COST_NOT_PRETRADE_TARIFF','decimal_ratio_precision':50,
   'fee_component_coverage':'ONLY_EXPLICITLY_LINKED_LEDGER_FEE_EVENTS',
   'spread_slippage_tax_coverage_proven':False,'execution_venue_inferred':False,
   'future_cost_estimate':None,**flags()}

def analyze(events,records,*,now):
 """Pure linkage; evidence for all executed trades, not symbol-selected examples."""
 def reversal_ref(e):return e.get('reversal_of_event_id') or (e.get('provenance') or {}).get('reversal_of_event_id')
 reversed_ids={reversal_ref(e) for e in events if text(reversal_ref(e))}
 trades=[e for e in events if kind(e) in ('BUY','SELL') and not reversal_ref(e)];fees=[e for e in events if kind(e)=='FEE' and not reversal_ref(e)]
 if len(trades)>2000 or len(records)>2000:raise ObservationError('OBSERVED_COST_CONTEXT_LIMIT')
 by_fp=defaultdict(list);by_external=defaultdict(list)
 for event in events:
  if text(event.get('identity_fingerprint_v2')):by_fp[event['identity_fingerprint_v2']].append(event)
  if text(event.get('external_id')):by_external[event['external_id']].append(event)
 claims={};issues=Counter();candidates=[];contexts=[]
 for trade in trades:
  try:
   if trade.get('event_id') in reversed_ids:raise ObservationError('REVERSED_TRADE_REQUIRES_CANONICAL_RECONCILIATION')
   tid=identity(trade);account=trade.get('account_id');cur=trade.get('currency');at=instant(trade.get('executed_at'))
   if not all(text(v) for v in (tid,account,cur)) or not cur.isascii() or not cur.isalpha() or not cur.isupper():raise ObservationError('EXPLICIT_TRADE_SCOPE_REQUIRED')
   if at>now:raise ObservationError('FUTURE_TRADE_NOT_OBSERVED')
   q,p,g=(number(trade.get(k),True) for k in ('quantity','unit_price','gross_amount'))
   with localcontext() as ctx:
    ctx.prec=200
    if (q*p).quantize(Decimal(1).scaleb(g.as_tuple().exponent))!=g:raise ObservationError('TRADE_SETTLED_GROSS_MISMATCH')
   linked={};methods=set();sequences=set();bad=[]
   def add(fee,method,step=None):
    if kind(fee)!='FEE':bad.append('EXPLICIT_LINK_NOT_A_FEE');return
    if fee.get('account_id')!=account or fee.get('currency')!=cur:bad.append('LINKED_FEE_SCOPE_MISMATCH');return
    fee_iid=identity(fee)
    if fee_iid is not None and fee_iid!=tid:bad.append('LINKED_FEE_IDENTITY_MISMATCH');return
    if fee.get('event_id') in reversed_ids:bad.append('REVERSED_FEE_REQUIRES_CANONICAL_RECONCILIATION');return
    if instant(fee.get('executed_at'))>now:bad.append('FUTURE_FEE_NOT_OBSERVED');return
    number(fee.get('gross_amount'))
    if step is not None:
     if step.get('account_id')!=account or step.get('currency')!=cur or number(step.get('gross_amount'))!=number(fee.get('gross_amount')):bad.append('SEQUENCE_FEE_ECONOMICS_MISMATCH');return
     step_iid=identity(step)
     if step_iid is not None and step_iid!=tid:bad.append('SEQUENCE_FEE_IDENTITY_MISMATCH');return
    linked[fee['event_id']]=fee;methods.add(method)
   ext=trade.get('external_id')
   if text(ext):
    matches=[f for f in fees if (f.get('provenance') or {}).get('parent_external_id')==ext]
    if matches and len(by_external[ext])!=1:bad.append('PARENT_EXTERNAL_TRADE_NOT_UNIQUE')
    elif matches:
     for fee in matches:add(fee,'EXPLICIT_PARENT_EXTERNAL_ID')
   for key in ('manual_external_transaction_id','commit_plan_id'):
    value=trade.get(key)
    if not text(value):continue
    matches=[f for f in fees if f.get(key)==value]
    if matches and sum(t.get(key)==value for t in trades)!=1:bad.append('EXPLICIT_TRANSACTION_LINK_NOT_UNIQUE')
    else:
     for fee in matches:add(fee,'EXPLICIT_'+key.upper())
   fp=trade.get('identity_fingerprint_v2')
   if text(fp):
    if len(by_fp[fp])!=1:bad.append('TRADE_STEP_IDENTITY_NOT_UNIQUE')
    else:
     for sid,record in records.items():
      steps=record['sequence'].get('steps') or []
      match=[s for s in steps if s.get('identity_fingerprint_v2')==fp and s.get('kind')==kind(trade)]
      if not match:continue
      if len(match)!=1:bad.append('SEQUENCE_TRADE_STEP_NOT_UNIQUE');continue
      if record.get('status')!='COMPLETED':bad.append('LINKED_MANUAL_SEQUENCE_NOT_COMPLETED');continue
      payload=match[0].get('payload') or {}
      if identity(payload)!=tid or payload.get('account_id')!=account or payload.get('currency')!=cur or number(payload.get('quantity'),True)!=q or number(payload.get('gross_amount'),True)!=g:bad.append('SEQUENCE_TRADE_ECONOMICS_MISMATCH');continue
      sequences.add(sid)
      for step in steps:
       if step.get('kind')!='FEE':continue
       fee_fp=step.get('identity_fingerprint_v2');found=by_fp.get(fee_fp,[])
       if not text(fee_fp) or len(found)!=1:bad.append('SEQUENCE_FEE_MISSING_OR_NOT_UNIQUE');continue
       add(found[0],'EXPLICIT_SEQUENCE_STEP_IDENTITY',step.get('payload') or {})
   if bad:
    issues.update(set(bad));continue
   if not linked:issues['EXPLICIT_LINKED_FEE_REQUIRED_NO_ZERO_ASSUMPTION']+=1;continue
   with localcontext() as ctx:
    ctx.prec=200;fee_total=sum((number(f['gross_amount']) for f in linked.values()),Decimal('0'))
    ctx.prec=50;ratio=fee_total/g
   prov=trade.get('provenance') or {}
   observation=ObservedTradeCost(tid,account,cur,kind(trade),at.isoformat(),trade['event_id'],trade['event_hash'],str(g),str(q),str(p),str(fee_total),str(ratio),tuple(sorted(linked)),tuple(linked[k]['event_hash'] for k in sorted(linked)),sum(identity(f) is None for f in linked.values()),tuple(sorted(methods)),tuple(sorted(sequences)),text(trade.get('source_ref')) or text(prov.get('source_ref')))
   candidates.append(observation)
   for fee_id in linked:claims.setdefault(fee_id,set()).add(trade['event_id'])
  except ObservationError as exc:issues[str(exc)]+=1
  except Exception:issues['UNSUPPORTED_EXISTING_TRADE_SHAPE']+=1
 reused={fid for fid,owners in claims.items() if len(owners)>1};accepted=[]
 for row in candidates:
  if set(row.fee_event_ids)&reused:issues['FEE_ALREADY_LINKED_TO_ANOTHER_TRADE']+=1
  else:accepted.append(row)
 return accepted,dict(issues),len(trades)

def read(root,*,now=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 if now.tzinfo is None:raise ObservationError('AWARE_OBSERVATION_TIME_REQUIRED')
 now=now.astimezone(dt.timezone.utc);root=Path(root).resolve(strict=True)
 ledger_path=local(root,'data/transaction_ledger.jsonl');store_path=local(root,'data/manual_external_trade_execution_authorities.json')
 def version(p):
  s=p.stat() if p.exists() else None
  if s and s.st_size>64*1024*1024:raise ObservationError('EXISTING_SOURCE_SIZE_LIMIT')
  return (s.st_size,s.st_mtime_ns,s.st_ino) if s else None
 before={p:version(p) for p in (ledger_path,store_path)}
 if before[ledger_path] is None:return {'schema':SCHEMA,'status':'EXISTING_LEDGER_NOT_PRESENT','observations':[],'trade_event_count':0,'blocking_reason_counts':{},**flags()}
 events=TransactionLedger(ledger_path).events()
 if len(events)>20000:raise ObservationError('EXISTING_EVENT_READ_LIMIT')
 records={}
 if store_path.exists():
  doc=json.loads(store_path.read_bytes())
  if doc.get('schema')!=STORE_SCHEMA or not isinstance(doc.get('records'),dict):raise ObservationError('MANUAL_EXECUTION_STORE_SCHEMA_REQUIRED')
  records=doc['records']
  for sid,record in records.items():
   _decode_durable_record(record)
   if record.get('sequence_id')!=sid:raise ObservationError('MANUAL_SEQUENCE_KEY_MISMATCH')
 accepted,issues,n=analyze(events,records,now=now)
 if before!={p:version(p) for p in before}:raise ObservationError('EXISTING_SOURCES_CHANGED_DURING_READ')
 return {'schema':SCHEMA,'status':'EXISTING_TRADE_COSTS_OBSERVED','observations':[r.payload() for r in accepted],'trade_event_count':n,'blocking_reason_counts':issues,'source_files_stable_during_read':True,'ledger_local_chain_verified':True,**flags()}

def _empty_summary():
 return {'schema':SCHEMA,'status':'OBSERVED_COST_INSPECTION_UNAVAILABLE','trade_event_count':None,'observed_trade_cost_count':None,'linked_fee_event_count':None,'assetless_fee_event_count':None,'contexts':[],'blocking_reason_counts':{},'financial_amounts_exported':False,**flags()}

def summary(root,*,now=None,data=None):
 out=_empty_summary()
 try:
  value=read(root,now=now) if data is None else data
  rows=value['observations'];contexts={}
  for row in rows:
   key=(row['instrument_id'],row['account_id'],row['currency'],row['side'])
   context=contexts.setdefault(key,{'instrument_id':key[0],'account_context_ref':hashlib.sha256(json.dumps([key[1],key[2]]).encode()).hexdigest(),'currency':key[2],'side':key[3],'observed_trade_count':0,'linked_fee_count':0,'assetless_fee_count':0})
   context['observed_trade_count']+=1;context['linked_fee_count']+=len(row['fee_event_ids']);context['assetless_fee_count']+=row['fee_assetless_count']
  return {**out,'status':value['status'],'trade_event_count':value['trade_event_count'],'observed_trade_cost_count':len(rows),'linked_fee_event_count':len({f for r in rows for f in r['fee_event_ids']}),'assetless_fee_event_count':sum(r['fee_assetless_count'] for r in rows),'contexts':sorted(contexts.values(),key=lambda r:(r['instrument_id'],r['account_context_ref'],r['currency'],r['side'])),'blocking_reason_counts':value['blocking_reason_counts']}
 except Exception as exc:return {**out,'error_type':type(exc).__name__}

def build(root,*,now=None):
 try:
  data=read(root,now=now)
  return {**data,'summary':summary(root,data=data)}
 except Exception as exc:
  diagnostic=_empty_summary();diagnostic['error_type']=type(exc).__name__
  return {'schema':SCHEMA,'status':'OBSERVED_COST_INSPECTION_UNAVAILABLE','observations':[],'error_type':type(exc).__name__,'summary':diagnostic,**flags()}
