"""Read-only evidence availability from existing prediction laboratory artifact.
Never treats research forecasts as comparator validation.
"""
from __future__ import annotations
import json
from pathlib import Path
from collections.abc import Mapping

def evidence_source_status(root):
    path=Path(root)/"results"/"prediction_lab.json"
    from .research_economic_series_a24 import summary
    research_series=summary(root)
    from .observed_trade_costs_a24 import summary as observed_summary
    realized_costs=observed_summary(root)
    result={"observed_manual_trade_costs":realized_costs,"research_market_series":research_series,"source":"results/prediction_lab.json", "status":"UNAVAILABLE",
            "reason":"LAB_RESULT_MISSING", "prediction_count":0,
            "matured_training_labels":"UNKNOWN", "comparison_authorized":False,
            "research_only":True}
    if not path.is_file():return result
    try:
        if path.stat().st_size>12_000_000:
            return dict(result,reason="LAB_RESULT_TOO_LARGE")
        lab=json.loads(path.read_text(encoding="utf-8"))
    except (OSError,ValueError,UnicodeError):
        return dict(result,reason="LAB_RESULT_UNREADABLE")
    if not isinstance(lab,Mapping):return dict(result,reason="LAB_RESULT_INVALID")
    predictions=lab.get("predictions")
    if not isinstance(predictions,list):predictions=[]
    result["prediction_count"]=len(predictions)
    result["lab_status"]=str(lab.get("status") or "UNKNOWN")
    result["target"]=str(lab.get("target") or "UNKNOWN")
    result["trained_at"]=str(lab.get("trained_at") or "UNKNOWN")
    result["observations"]=lab.get("observations") if isinstance(lab.get("observations"),int) else None
    result["status"]="RESEARCH_AVAILABLE" if predictions else "UNAVAILABLE"
    result["reason"]="RESEARCH_FORECASTS_NOT_COMPARATOR_VALIDATED" if predictions else "NO_RESEARCH_PREDICTIONS"
    # This lab cannot attest to matured *prospective* decisions from this artifact.
    return result
