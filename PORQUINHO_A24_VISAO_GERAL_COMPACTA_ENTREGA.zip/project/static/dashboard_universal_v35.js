/* V35: presentation only. No decision/learning/financial mutation. */
'use strict';
const v35State={active:'dashboard',plots:new Map(),pending:[],assetRows:[]};
const v35PopupStore=new Map(),v35Movables=new Map();
const v35PriorShow=showExperienceView,v35PriorMount=a24UiMount,v35PriorOpen=openModal,v35PriorClose=closeModal;
function v35HomeMovables(){for(const {node,home} of v35Movables.values())if(node.parentElement!==home)home.appendChild(node)}
openModal=function(title,html){v35HomeMovables();return v35PriorOpen(title,html)};
closeModal=function(){v35HomeMovables();return v35PriorClose()};
function v35Modal(title,html){openModal(title,`<div class="v35-popup">${html}</div>`);v35Popupify(document.getElementById('modalBody'),'dialog');document.getElementById('modal')?.setAttribute('role','dialog');document.getElementById('modal')?.setAttribute('aria-modal','true')}
function v35Popupify(root,prefix){
 if(!root)return;
 for(const details of [...root.querySelectorAll('details')].reverse()){
  const summary=details.querySelector(':scope > summary');const title=summary?.textContent||'Detalhes';const key=prefix+':'+(details.dataset.a24Disclosure||title);summary?.remove();
  v35PopupStore.set(key,{title,html:details.innerHTML});const button=document.createElement('button');button.type='button';button.className='v35-detail-button';button.dataset.v35Popup=key;button.textContent=title;details.replaceWith(button);
 }
}
function v35Facts(d){return a24UiFacts(d)}
function v35Currency(d){
 if(a24CockpitState.currency)return a24CockpitState.currency;
 const rows=[...(v35Facts(d)?.currency_totals||[])].sort((a,b)=>b.position_count-a.position_count||String(a.currency).localeCompare(String(b.currency)));
 const q=rows[0]?.currency||a24PlotSeries(d)[0]?.quote_currency||'';if(q)a24CockpitState.currency=q;return q;
}
function v35Metric(label,value,sub=''){return `<article class="v35-metric"><small>${esc(label)}</small><strong>${esc(value)}</strong><span>${esc(sub)}</span></article>`}
function v35Metrics(d){
 const f=v35Facts(d),q=v35Currency(d),ps=(f?.positions||[]).filter(a24UiScope),cs=(f?.cash||[]).filter(a24UiScope);
 const sum=(rows,key)=>rows.every(r=>r.context_status==='EXACT_REGISTERED_CONTEXT'&&a24PlotNumber(r[key])!==null)?rows.reduce((n,r)=>n+Number(r[key]),0):null;
 if(!f)return '<p class="a24-empty">Resumo financeiro indisponível nesta leitura.</p>';
 const cash=sum(cs,'amount'),value=sum(ps,'reference_market_value'),pnl=sum(ps,'reference_pnl');
 const wealth=value!==null&&cash!==null?value+cash:null;
 return `<div class="v35-metrics">${v35Metric('Patrimônio de referência',a24UiMoney(wealth,q),'Somente quando todas as posições têm cotação exata')}${v35Metric('Resultado de referência',a24UiMoney(pnl,q),'Variação sobre o custo; não é lucro realizado')}${v35Metric('Cash registrado',a24UiMoney(cash,q),q||'Moeda não informada')}${v35Metric('Posições acompanhadas',String(ps.length),'Contextos da moeda e conta selecionadas')}</div>`;
}
function v35PositionPopup(index){
 const p=v35Facts(a24MonitorData)?.positions?.[index];if(!p)return;
 const labels={instrument_id:'Identidade financeira',account_id:'Conta',currency:'Moeda',quantity:'Quantidade',cost_basis:'Custo registrado',reference_market_value:'Valor de referência',reference_pnl:'Resultado de referência',reference_pnl_pct:'Resultado de referência (%)',reference_quote_at:'Data da cotação',context_status:'Contexto',valuation_status:'Estado da avaliação'};
 v35Modal(p.display_label||p.instrument_id||'Posição',`<dl>${Object.entries(labels).map(([key,label])=>`<div><dt>${label}</dt><dd>${esc(p[key]??'Indisponível')}</dd></div>`).join('')}</dl><p>${esc(a24UiAccount(p.account_id,p.currency))}</p><p>${a24UiPositionReading(p)}</p><p class="a24-caption">Valores indisponíveis não são zero. A identidade financeira e a moeda foram preservadas.</p><button onclick="closeModal();showExperienceView('transactions')">Abrir transações</button>`);
}
function v35Positions(d){
 const f=v35Facts(d);if(!f)return '<p class="a24-empty">Posições indisponíveis nesta leitura.</p>';
 const rows=f.positions.map((p,i)=>({p,i})).filter(({p})=>a24UiScope(p)&&a24UiSearch(p));
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Posições atuais</h2><button onclick="showExperienceView('transactions')">Transações</button></div><table class="v35-table"><thead><tr><th>Ativo / conta</th><th>Valor de referência</th><th>Resultado</th><th class="v35-wide-only">Leitura</th></tr></thead><tbody>${rows.map(({p,i})=>`<tr tabindex="0" role="button" data-v35-position="${i}" aria-label="Ver detalhes de ${esc(p.display_label||p.instrument_id)}"><td><b>${esc(p.display_label||p.instrument_id)}</b><small>${esc(a24UiAccount(p.account_id,p.currency,d))} · ${esc(p.currency)}</small></td><td>${esc(a24UiMoney(p.reference_market_value,p.currency))}</td><td>${esc(a24UiMoney(p.reference_pnl,p.currency))}</td><td class="v35-wide-only">${a24UiPositionReading(p)}</td></tr>`).join('')||'<tr><td colspan="4">Nenhuma posição nestes filtros.</td></tr>'}</tbody></table><p class="a24-caption">Clique numa posição para quantidade, custo, fonte e detalhes completos.</p></section>`;
}
function v35PendingRows(){
 const scores=(typeof lastStatus==='object'&&lastStatus?.portfolio?.scores)||[];
 const actions=new Set(['COMPRE','BUY','VENDA','SELL','REALIZE','REDUCE','INCREASE','DEPLOY_CASH','REALLOCATE']);
 return scores.filter(r=>actions.has(String(r.action||'').toUpperCase())&&a24UiSearch({...r,display_label:r.asset||r.display_label})&&(!r.currency||!a24CockpitState.currency||r.currency===a24CockpitState.currency)&&(!r.account_id||!a24CockpitState.account||r.account_id===a24CockpitState.account));
}
function v35ActionPopup(i){
 const r=v35State.pending[i];if(!r)return;const reading=a24OperationalReading(r);
 v35Modal('Leitura atual · '+(r.asset||r.instrument_id||'Ativo'),`${a24OperationalBadge(r)}<dl>${['instrument_id','account_id','currency','promising_pct','opportunity','entry','risk','asymmetry','action','execution_state','execution_fraction_pct'].map(k=>`<div><dt>${esc(k)}</dt><dd>${esc(r[k]??'Não informado')}</dd></div>`).join('')}</dl><p>${esc(reading?.context||'Contexto não confirmado')}</p><p>Sinal analítico existente do Brain. Não representa uma ordem já criada ou autorização automática.</p>`);
}
function v35Pending(d){
 v35State.pending=v35PendingRows();
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Ativos com ações pendentes</h2><span>${v35State.pending.length} sinais</span></div><div class="v35-action-list">${v35State.pending.map((r,i)=>`<button data-v35-action="${i}" class="v35-action-row"><span><b>${esc(r.asset||r.instrument_id||'Ativo')}</b><small>${esc(r.currency||'Referência · moeda não confirmada')}</small></span><span>${a24OperationalBadge(r)}</span><span><small>Avaliação atual</small><b>${r.promising_pct==null?'Indisponível':esc(Number(r.promising_pct).toLocaleString('pt-PT',{maximumFractionDigits:1}))}</b></span></button>`).join('')||'<p class="a24-empty">Nenhum sinal de ação elegível no snapshot e nos filtros atuais.</p>'}</div><p class="a24-caption">Sinais atuais do Brain, sujeitos à confirmação manual; não são ordens já criadas. Referências sem moeda explícita permanecem identificadas.</p></section>`;
}
function v35Daily(d){
 const q=v35Currency(d),series=a24PlotSeries(d).filter(s=>s.quote_currency===q);
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Acompanhamento diário · ${esc(q)}</h2><div class="v35-plot-controls"><select aria-label="Período diário" data-a24-plot-period>${[30,90,365].map(n=>`<option value="${n}" ${Number(a24CockpitState.plotPeriod)===n?'selected':''}>${n} dias</option>`).join('')}</select><select aria-label="Medida diária" data-a24-plot-mode><option value="index" ${a24CockpitState.plotMode==='index'?'selected':''}>Base 100</option><option value="price" ${a24CockpitState.plotMode==='price'?'selected':''}>Cotação</option><option value="drawdown" ${a24CockpitState.plotMode==='drawdown'?'selected':''}>Queda do pico</option></select></div></div>${series.length?a24PlotLine(series,d,q):'<p class="a24-empty">Histórico diário indisponível nesta moeda.</p>'}<div class="a24-plot-legend">${series.map((s,i)=>`<button data-a24-plot-series="${esc(s.series_id)}" aria-pressed="${!a24PlotHidden.has(s.series_id)}" style="--series:${a24PlotPalette[i%a24PlotPalette.length]}">${esc(s.display_label||s.instrument_id)}</button>`).join('')}</div><button data-v35-daily-sources>Fontes e dados do gráfico</button><p class="a24-caption">Cotações da fonte. Base 100 não é rentabilidade da carteira.</p></section>`;
}
function v35IntradaySeries(d){
 const q=v35Currency(d),rows=d?.cockpit_intraday?.series||[];return rows.filter(s=>s.quote_currency===q&&a24UiSearch(s)&&(!a24CockpitState.account||(s.scope==='EXPLICIT_ROW_CONTEXT'&&(v35Facts(d)?.research_contexts||[]).some(c=>c.account_id===a24CockpitState.account&&c.instrument_id===s.instrument_id&&c.quote_currency===q))));
}
function v35IntradayLine(series,d){
 const now=Date.parse(d?.cockpit_intraday?.observed_at),hours=Number(v35State.hours||24),start=now-hours*3600000;const groups=series.map(s=>({s,pp:s.points.filter(p=>Date.parse(p.date)>=start)})).filter(x=>x.pp.length);if(!groups.length)return '<p class="a24-empty">Sem registros intraday neste período e moeda. Nenhuma curva foi simulada.</p>';
 const all=groups.flatMap(x=>x.pp),times=all.map(p=>Date.parse(p.date)),t0=Math.min(...times),t1=Math.max(...times);const vals=groups.flatMap(({pp})=>pp.map(p=>Number(p.price)/Number(pp[0].price)*100));let lo=Math.min(...vals)-.1,hi=Math.max(...vals)+.1;const x=t=>52+(t-t0)/(t1-t0||1)*560,y=v=>194-(v-lo)/(hi-lo)*165;
 return `<svg class="v35-intraday-svg" viewBox="0 0 640 230" role="img" aria-label="Intraday de cotações em base 100"><line x1="52" y1="194" x2="612" y2="194" class="a24-plot-grid"/>${[lo,(lo+hi)/2,hi].map(v=>`<text x="46" y="${y(v)+3}" text-anchor="end">${v.toFixed(1)}</text>`).join('')}${groups.map(({s,pp},i)=>{const points=pp.map(p=>({t:Date.parse(p.date),v:Number(p.price)/Number(pp[0].price)*100,p}));return `<path d="${points.map((p,j)=>(j?'L':'M')+x(p.t).toFixed(1)+' '+y(p.v).toFixed(1)).join(' ')}" fill="none" stroke="${a24PlotPalette[i%8]}" stroke-width="2.5"/>${points.map(p=>`<circle cx="${x(p.t)}" cy="${y(p.v)}" r="${pp.length===1?4:1.7}" fill="${a24PlotPalette[i%8]}"><title>${esc(s.display_label)} · ${esc(p.p.date)} · ${esc(a24PlotPrice(p.p.price,s.quote_currency))}</title></circle>`).join('')}`}).join('')}${[t0,(t0+t1)/2,t1].map(t=>`<text x="${x(t)}" y="220" text-anchor="middle">${esc(new Date(t).toLocaleTimeString('pt-PT',{hour:'2-digit',minute:'2-digit'}))}</text>`).join('')}</svg>`;
}
function v35Intraday(d){
 const ss=v35IntradaySeries(d),gaps=ss.map(s=>s.observed_cadence_seconds).filter(n=>Number.isFinite(n)&&n>0);const cadence=gaps.length?Math.max(...gaps)/60:null;
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Acompanhamento intraday · ${esc(v35Currency(d))}</h2><select aria-label="Período intraday" data-v35-hours>${[6,24,48].map(h=>`<option value="${h}" ${Number(v35State.hours||24)===h?'selected':''}>${h} horas</option>`).join('')}</select></div>${v35IntradayLine(ss,d)}<div class="v35-legend">${ss.map((s,i)=>`<span style="color:${a24PlotPalette[i%8]}">● ${esc(s.display_label)}</span>`).join('')}</div><p class="a24-caption">${cadence!==null?'Cadência mediana observada nas séries: até '+esc(cadence.toLocaleString('pt-PT',{maximumFractionDigits:1}))+' min. ':''}Horários disponíveis, sem interpolação nova. ${ss.some(s=>s.scope!=='EXPLICIT_ROW_CONTEXT')?'Referência legada compatível com o produtor atual em EUR; não é cotação de uma posição canônica nem atestado histórico. O produtor legado reamostra dados em 10 minutos.':''}</p><button data-v35-intraday-sources>Fontes e dados intraday</button></section>`;
}
function v35Swaps(d){
 const a=d?.reallocation_analysis;if(a?.status!=='REALLOCATION_COMPARISONS_INSPECTED'||!Array.isArray(a.rows))return '<p class="a24-empty">Comparação de realocação indisponível.</p>';
 const rows=a.rows.filter(r=>a24UiScope(r)&&a24UiSearch(r)),candidates=rows.filter(r=>r.status==='GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING');
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Realocação entre ativos</h2><button data-v35-all-swaps>Todas as comparações · ${rows.length}</button></div><div class="v35-swap-grid">${candidates.map(r=>`<article class="v35-swap"><h3>${esc(r.source_display_label||r.source_instrument_id)} → ${esc(r.destination_display_label||r.destination_instrument_id)}</h3><small>${esc(a24UiAccount(r.account_id,r.currency,d))} · ${esc(r.currency)}</small><p><b>Sem recomendação final de movimentação.</b></p><p>Valor a mover: <b>ainda não definido pelo Brain.</b></p><p class="a24-caption">Há vantagem bruta nas comparações disponíveis. Custos e dimensionamento continuam pendentes. Capital comparado não é valor recomendado.</p><button data-v35-swap="${esc(r.alternative_id)}">Avaliação e pendências</button></article>`).join('')||'<p class="a24-empty">Nenhum candidato bruto nestes filtros.</p>'}</div></section>`;
}
function v35Assets(d){
 const rows=(v35Facts(d)?.catalog||[]).filter(a24UiSearch);v35State.assetRows=rows;
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Ativos · catálogo universal</h2><button onclick="v38272OpenInstrumentOnboarding()">Cadastrar instrumento</button></div><div class="v35-asset-grid">${rows.map((r,i)=>`<button data-v35-asset="${i}" class="v35-asset"><span class="v35-asset-mark">${esc((r.symbol||r.name||'?').slice(0,3))}</span><span><b>${esc(r.symbol||r.name||'Instrumento')}</b><small>${esc(r.name||'')} · ${esc(r.asset_class||'Classe não informada')}</small><small>${esc(r.market||'Mercado não informado')} · ${esc(r.currency||r.quote_currency||'Moeda não declarada')}</small></span><span>↗</span></button>`).join('')||'<p class="a24-empty">Nenhum instrumento no catálogo e na pesquisa atual.</p>'}</div><p class="a24-caption">Catálogo identifica instrumentos; não comprova posição ou saldo. Clique para contexto, fontes e acompanhamento.</p></section>`;
}
function v35AssetPopup(i){const r=v35State.assetRows[i];if(!r)return;const d=a24MonitorData;const positions=(v35Facts(d)?.positions||[]).filter(p=>p.instrument_id===r.instrument_id),contexts=(d.global_research_lab?.contexts||[]).filter(c=>c.instrument_id===r.instrument_id);v35Modal(r.name||r.symbol||'Ativo',`<dl>${Object.entries(r).map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><h3>Posições com identidade exata · ${positions.length}</h3>${positions.map(p=>`<p>${esc(a24UiAccount(p.account_id,p.currency,d))} · ${esc(p.currency)} · ${esc(p.quantity??'Quantidade indisponível')}</p>`).join('')}<h3>Contextos de acompanhamento · ${contexts.length}</h3>${contexts.map(c=>`<p>${esc(c.quote_currency)} · ${esc(c.provider)} / ${esc(c.provider_id)} · ${esc(c.observation_count)} observações</p>`).join('')||'<p>Acompanhamento por fonte/moeda ainda não disponível.</p>'}`)}
function v35Market(d){return `<div class="v35-two">${v35Daily(d)}${v35Intraday(d)}</div>${a24PlotHeatmap(d)}${a24UiResearch(d)}`}
function v35Cockpit(d){const a=d.reallocation_analysis||{},f=v35Facts(d);return `<div class="v35-metrics">${v35Metric('Contextos pesquisados',String(d.global_research_lab?.context_count??'Indisponível'))}${v35Metric('Pares comparados',String(a.compared_pair_count??'Indisponível'))}${v35Metric('Candidatos brutos',String(a.gross_candidate_count??'Indisponível'),'Não são ordens')}${v35Metric('Posições canônicas',String(f?.positions.length??'Indisponível'))}</div>${a24PlotGauges(d)}<section class="v35-portlet"><h2>Estado e evidências do Brain</h2><p>${esc(a24MonitorHealthText(d.monitor))}</p><p>${esc(a24ProspectivePolicyMessage(d))}</p><button data-v35-diagnostics>Diagnósticos e aprendizado</button></section>`}
function v36Spark(points){
 const pp=(points||[]).slice(-30).map(p=>Number(p.price)).filter(v=>Number.isFinite(v)&&v>0);if(pp.length<2)return '<span class="v36-muted">Sem série</span>';
 const lo=Math.min(...pp),hi=Math.max(...pp),path=pp.map((v,i)=>(i?'L':'M')+(i/(pp.length-1)*74).toFixed(1)+' '+(25-(v-lo)/(hi-lo||1)*22).toFixed(1)).join(' ');
 return `<svg class="v36-spark" viewBox="0 0 76 28" role="img" aria-label="Últimas cotações diárias; sem interpolação nova"><path d="${path}" fill="none" stroke="${pp.at(-1)>=pp[0]?'#00e4a8':'#ff657e'}" stroke-width="2"/></svg>`;
}
function v36AccountPanel(d){
 const rows=(v35Facts(d)?.cash||[]).filter(a24UiScope);return `<section class="v35-portlet v36-banks"><div class="v35-heading"><h2>Contas e bancos</h2><button onclick="showExperienceView('accounts')">Gerenciar ↗</button></div><table class="v35-table"><thead><tr><th>Conta</th><th>Moeda</th><th>Cash registrado</th></tr></thead><tbody>${rows.slice(0,6).map(c=>`<tr><td>${esc(a24UiAccount(c.account_id,c.currency,d))}</td><td>${esc(c.currency)}</td><td>${esc(a24UiMoney(c.context_status==='EXACT_REGISTERED_CONTEXT'?c.amount:null,c.currency))}</td></tr>`).join('')||'<tr><td colspan="3">Cash indisponível nestes filtros.</td></tr>'}</tbody></table><p class="a24-caption">Cash registrado por conta; não representa patrimônio ou saldo livre para uma ordem. Todas as contas permanecem na tela Contas e Bancos.</p></section>`;
}
function v36SystemPanel(d){
 const m=d?.monitor||{},capture=d?.research_capture||{},charts=d?.cockpit_charts||{};
 const rows=[['Monitor',a24MonitorHealthText(m)],['Snapshot',a24MonitorTime(m.snapshot)],['Históricos diários',charts.status==='CHART_SOURCES_INSPECTED'?String(charts.series?.length||0)+' séries':'Indisponível'],['Intraday',d?.cockpit_intraday?.status==='INTRADAY_INSPECTED'?String(d.cockpit_intraday.series?.length||0)+' séries':'Indisponível'],['Capturas hoje',capture.verified_records_today??'Indisponível']];
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Estado do sistema</h2><button onclick="showExperienceView('cockpit')">Ver Brain ↗</button></div><dl class="v36-state">${rows.map(([k,v])=>`<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl><p class="a24-caption">Monitor ativo não comprova certificação dos modelos ou autorização de execução automática. As datas de maturação não são calculadas a partir do aniversário do sistema.</p></section>`;
}
function v36OpportunitySummary(d){
 const rows=(d?.reallocation_analysis?.rows||[]).filter(r=>a24UiScope(r)&&a24UiSearch(r)),cs=rows.filter(r=>r.status==='GROSS_REALLOCATION_CANDIDATE_COSTS_AND_SIZING_PENDING');
 return `<section class="v35-portlet"><div class="v35-heading"><h2>Oportunidades de realocação</h2><button onclick="showExperienceView('opportunities')">Ver todas ↗</button></div>${cs.slice(0,3).map(r=>`<div class="v36-opportunity"><b>${esc(r.source_display_label||r.source_instrument_id)} → ${esc(r.destination_display_label||r.destination_instrument_id)}</b><small>${esc(r.currency)} · ${esc(a24UiAccount(r.account_id,r.currency,d))}</small><span>Em análise · valor a mover não definido</span><button data-v35-swap="${esc(r.alternative_id)}">Detalhes</button></div>`).join('')||'<p class="a24-empty">Nenhum candidato bruto nos filtros atuais.</p>'}<p class="a24-caption">Vantagem bruta não é recomendação final. Custos e dimensionamento continuam pendentes; o capital de comparação não é valor recomendado.</p></section>`;
}
function v35Dashboard(d){return `<div class="v36-dashboard">${v35Metrics(d)}<div class="v36-charts">${v35Daily(d)}${v35Intraday(d)}</div><div class="v36-widget-grid">${v35Pending(d)}${v35CompactMarket(d)}${v36AccountPanel(d)}${v35Allocation(d)}${v36SystemPanel(d)}${v36OpportunitySummary(d)}</div><div class="v36-bottom">${a24PlotGauges(d)}${a24PlotHeatmap(d)}</div></div>`}

function v35CompactMarket(d){const ss=a24PlotSeries(d).slice(0,6);return `<section class="v35-portlet"><div class="v35-heading"><h2>Principais ativos · ${esc(v35Currency(d))}</h2><button onclick="showExperienceView('market')">Mercado ↗</button></div><table class="v35-table v36-market"><thead><tr><th>Ativo</th><th>Cotação / fonte</th><th>Diário</th></tr></thead><tbody>${ss.map(s=>{const p=s.points.at(-1);return `<tr><td><b>${esc(s.display_label||s.instrument_id)}</b></td><td>${esc(a24PlotPrice(p?.price,s.quote_currency))}<small>${esc(s.provider)} · ${esc(p?.date||'Data indisponível')}</small></td><td>${v36Spark(s.points)}</td></tr>`}).join('')||'<tr><td colspan="3">Fontes indisponíveis nesta moeda.</td></tr>'}</tbody></table></section>`}

function v35Allocation(d){const q=v35Currency(d),ps=(v35Facts(d)?.positions||[]).filter(a24UiScope),rows=ps.filter(p=>a24PlotNumber(p.cost_basis)!==null&&p.context_status==='EXACT_REGISTERED_CONTEXT').map(p=>({label:p.display_label||p.instrument_id,value:Number(p.cost_basis)}));return `<section class="v35-portlet">${a24PlotDonut(rows,q,rows.length+' de '+ps.length+' posições com custo conhecido')}</section>`}
function v35Render(kind,d){if(d?.schema!=='porquinho.monitor-consolidation-a24/1.0')return '<p class="a24-empty">Aguardando leitura do sistema.</p>';v35Currency(d);const body=kind==='dashboard'?v35Dashboard(d):kind==='portfolio'?v35Metrics(d)+v35Positions(d)+a24PlotFinancial(d):kind==='market'?v35Market(d):kind==='opportunities'?v35Swaps(d):kind==='assets'?v35Assets(d):v35Cockpit(d);return a24UiHealth(d)+a24UiFilters(d)+body}
function v36CompactNotes(host,kind){
 if(kind!=='dashboard')return;
 host.querySelectorAll('.a24-caption').forEach((p,i)=>{const title='Sobre estes dados',key='v36-note:'+i;v35PopupStore.set(key,{title,html:'<p>'+esc(p.textContent)+'</p>'});const button=document.createElement('button');button.type='button';button.className='v36-note';button.dataset.v35Popup=key;button.textContent='ⓘ Sobre estes dados';p.replaceWith(button)});
}
function v35Mount(){
 for(const kind of ['dashboard','cockpit','market','portfolio','opportunities','assets']){const host=document.getElementById('v35-'+kind)||document.getElementById('a24-'+kind);if(!host||!host.closest('.experience-view')?.classList.contains('active-view'))continue;const input=host.querySelector('[data-a24-filter="query"]');if(input===document.activeElement)continue;host.innerHTML=v35Render(kind,a24MonitorData);v35Popupify(host,kind);v36CompactNotes(host,kind)}
}
a24UiMount=v35Mount;a24MountMonitor=v35Mount;
showExperienceView=function(name,button){
 const route=name==='overview'?'dashboard':name;
 if(route==='ai'){if(typeof openChat==='function')openChat();return}
 if(route==='financial-import'){v35OpenMovable('import');return}
 if(['dashboard','assets'].includes(route)&&document.getElementById('view-v35-'+route)){
  document.querySelectorAll('.experience-view').forEach(n=>n.classList.remove('active-view'));document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));document.getElementById('view-v35-'+route).classList.add('active-view');document.querySelector('[data-target="'+route+'"]')?.classList.add('active');v35State.active=route;v35Mount();void a24FetchMonitor();try{sessionStorage.setItem('porquinho.experience.view.v1',route)}catch(_){}document.querySelector('.workspace main')?.scrollTo({top:0,behavior:'instant'});return;
 }
 const result=v35PriorShow(route,button);v35State.active=route;if(route==='cockpit'){document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));document.querySelector('[data-target="cockpit"]')?.classList.add('active')}
 v35Mount();return result;
};
function v35OpenMovable(key){const saved=v35Movables.get(key);if(!saved)return;openModal(key==='import'?'Importação financeira':'Controles e registros anteriores','<div id="v35-movable-slot"></div>');document.getElementById('v35-movable-slot').appendChild(saved.node)}
function v35Init(){
 const main=document.querySelector('main');if(!main)return;document.body.classList.add('v36-layout');
 const nav=document.querySelector('.side-nav');const dashboard=nav?.querySelector('[data-target="dashboard"]');if(dashboard)dashboard.querySelector('span').textContent='Visão geral';
 if(nav&&!nav.querySelector('[data-target="cockpit"]')){const b=document.createElement('button');b.className='nav-item';b.dataset.target='cockpit';b.innerHTML='<i>◈</i><span>Cockpit do Brain</span>';b.onclick=()=>showExperienceView('cockpit',b);dashboard?.after(b)}
 for(const key of ['ai','financial-import'])nav?.querySelector('[data-target="'+key+'"]')?.remove();
 for(const [kind,title,desc] of [['dashboard','Visão geral','Seus investimentos, sinais e acompanhamento em um só lugar.'],['assets','Ativos','Catálogo universal e detalhes de acompanhamento.']]){const view=document.createElement('section');view.id='view-v35-'+kind;view.className='experience-view';view.innerHTML=`<div class="v361-page-head v35-page-head"><div><span class="v361-eyebrow">PORQUINHO · UNIVERSO GLOBAL</span><h1>${title}</h1><p>${desc}</p></div><button onclick="a24FetchMonitor(true)">Verificar acompanhamento</button></div><div class="a24-space v35-space" id="v35-${kind}"></div>`;main.appendChild(view)}
 for(const kind of ['cockpit','market','portfolio','opportunities'])document.getElementById('a24-'+kind)?.classList.add('v35-space');
 const cockpit=document.querySelector('#view-cockpit .v361-page-head p');if(cockpit)cockpit.textContent='Saúde do acompanhamento, cobertura e evidências do Brain.';
 for(const kind of ['market','portfolio']){const view=document.getElementById('view-'+kind);view?.querySelectorAll(':scope > details').forEach((n,i)=>{const home=document.createElement('div');home.hidden=true;view.appendChild(home);const content=document.createElement('div');content.dataset.v35Movable=kind+i;n.querySelector(':scope > summary')?.remove();while(n.firstChild)content.appendChild(n.firstChild);home.appendChild(content);v35Movables.set(kind+i,{node:content,home});const b=document.createElement('button');b.textContent=kind==='market'?'Acervo e controles de referência':'Controles de posição anteriores';b.dataset.v35Movable=kind+i;n.replaceWith(b)})}
 const imports=document.getElementById('view-financial-import');if(imports){imports.classList.remove('active-view');imports.hidden=true;const holder=document.createElement('div');holder.dataset.v35Movable='import';while(imports.firstChild)holder.appendChild(imports.firstChild);imports.appendChild(holder);v35Movables.set('import',{node:holder,home:imports})}
 nav?.querySelectorAll('button').forEach(b=>{b.setAttribute('aria-label',b.querySelector('span')?.textContent||b.textContent)});
 document.addEventListener('click',event=>{const t=event.target?.closest('button,[data-v35-position]');if(!t)return;
  if(t.dataset.v35Popup){const p=v35PopupStore.get(t.dataset.v35Popup);if(p)v35Modal(p.title,p.html)}
  else if(t.dataset.v35Position!==undefined)v35PositionPopup(Number(t.dataset.v35Position));
  else if(t.dataset.v35Action!==undefined)v35ActionPopup(Number(t.dataset.v35Action));
  else if(t.dataset.v35Asset!==undefined)v35AssetPopup(Number(t.dataset.v35Asset));
  else if(t.dataset.v35Movable)v35OpenMovable(t.dataset.v35Movable);
  else if(t.hasAttribute('data-v35-daily-sources'))v35Modal('Fontes e dados · diário',a24PlotHistory(a24MonitorData));
  else if(t.hasAttribute('data-v35-intraday-sources'))v35Modal('Fontes e dados · intraday',`<p>Base 100 por série. Produtor legado compatível com EUR; cadência de 10 minutos, sem atestado histórico por linha ou ligação financeira.</p>${v35IntradaySeries(a24MonitorData).map(s=>`<h3>${esc(s.display_label)} · ${esc(s.quote_currency)}</h3><p>${esc(s.scope)}</p><div class="a24-chart-data"><table class="v35-table">${s.points.map(p=>`<tr><td>${esc(p.date)}</td><td>${esc(a24PlotPrice(p.price,s.quote_currency))}</td></tr>`).join('')}</table></div>`).join('')}`);
  else if(t.hasAttribute('data-v35-diagnostics'))v35Modal('Evidências e aprendizado',a24UiDiagnostics(a24MonitorData));
  else if(t.hasAttribute('data-v35-all-swaps'))v35Modal('Comparações de realocação',a24ReallocationPanel(a24MonitorData));
  else if(t.dataset.v35Swap){const r=a24MonitorData.reallocation_analysis.rows.find(x=>x.alternative_id===t.dataset.v35Swap);if(r)v35Modal('Avaliação de realocação',a24ReallocationDetailed({...a24MonitorData,reallocation_analysis:{...a24MonitorData.reallocation_analysis,rows:[r],pair_count:1,compared_pair_count:r.models.length?1:0,gross_candidate_count:1}}))}
 });
 document.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&e.target?.hasAttribute('data-v35-position')){e.preventDefault();v35PositionPopup(Number(e.target.dataset.v35Position))}if(e.key==='Escape')closeModal()});
 document.addEventListener('change',e=>{if(e.target?.hasAttribute('data-v35-hours')){v35State.hours=Number(e.target.value);v35Mount()}});
 showExperienceView('dashboard');
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',v35Init);else v35Init();
