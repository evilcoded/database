import unittest,tempfile,stat
from pathlib import Path
from unittest.mock import patch
from tools import iphone_local_access_a24 as mobile
class Mobile(unittest.TestCase):
 def test_guide_preserves_loopback_origin(self):
  h=mobile.render({'mac_lan_ip':'192.168.1.2','mac_user':'test','porquinho_http_200':True,'ssh_listener_reachable':True});self.assertIn('http://127.0.0.1:8765/',h);self.assertIn('127.0.0.1:8765',h);self.assertIn('ainda não verificada',h);self.assertNotIn('0.0.0.0',h)
 def test_guide_escapes_local_metadata(self):
  h=mobile.render({'mac_user':'<script>bad</script>','mac_lan_ip':'<img>'});self.assertNotIn('<script>',h);self.assertIn('&lt;script&gt;',h)
 def test_public_ip_not_advertised_as_private_wifi(self):
  with patch.object(mobile.subprocess,'check_output',return_value=b'8.8.8.8'):self.assertIsNone(mobile.lan_ip())
 def test_rfc1918_address_reused_without_network_mutation(self):
  with patch.object(mobile.subprocess,'check_output',return_value=b'192.168.10.2'):self.assertEqual(mobile.lan_ip(),'192.168.10.2')
 def test_local_guide_exclusive_and_private(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp).resolve();a=mobile.write_guide(folder,{});before=a.read_bytes();b=mobile.write_guide(folder,{});self.assertNotEqual(a,b);self.assertEqual(a.read_bytes(),before);self.assertEqual(stat.S_IMODE(a.stat().st_mode),0o600)
 def test_symlink_output_refused(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp).resolve();(folder/'link').symlink_to(folder,target_is_directory=True)
   with self.assertRaises(ValueError):mobile.write_guide(folder/'link',{})
if __name__=='__main__':unittest.main()
