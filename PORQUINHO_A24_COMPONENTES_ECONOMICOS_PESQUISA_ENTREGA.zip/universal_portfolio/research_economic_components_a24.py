"""Account-scoped research components; deliberately not the governed input contract."""
import datetime as dt
import fcntl
import math
import os
from pathlib import Path
from brain.evolution import global_research_lab_a24 as lab
from . import global_history_source_a24 as history
from . import research_quote_acquisition_a24 as quotes
from .explicit_market_bindings_a24 import local,digest,load
SCHEMA='porquinho.research-economic-components-a24/1.0'
STORE='data/brain/research_economic_components_a24'
METHOD='RETURN_AND_REALIZED_DOWNSIDE_COMPONENTS_V1'
COMPONENTS=('forward_return','risk_measure','counterfactual_return','transaction_cost','relative_utility')
class ComponentError(ValueError):pass

def flags():
 return {'authority':'NONE','research_only':True,'comparison_authorized':False,
  'model_validation_proven':False,'canonical_publication_authorized':False,
  'execution_authorized':False,'financial_mutation':False,'legacy_learning_modified':False}

def validated_experiment(root,body,now):
 source_hash=digest(body);path=local(root,lab.STORE+'/experiments/'+body['series_id']+'/'+source_hash+'.json')
 if not path.exists():return None
 result=history.read_sealed(path);stamp=quotes.utc(dt.datetime.fromisoformat(result['computed_at']))
 if stamp>now or result!={**lab.experiment(body,now=stamp),'computed_at':stamp.isoformat()}:raise ComponentError('RESEARCH_EXPERIMENT_PROJECTION_MISMATCH')
 return result

def packet(body,experiment,context,*,now):
 stamp=quotes.utc(dt.datetime.fromisoformat(experiment['computed_at']))
 if stamp>now or experiment!={**lab.experiment(body,now=stamp),'computed_at':stamp.isoformat()}:raise ComponentError('RESEARCH_EXPERIMENT_PROJECTION_MISMATCH')
 if experiment.get('source_body_sha256')!=digest(body) or experiment.get('series_id')!=body['series_id']:raise ComponentError('EXPERIMENT_SOURCE_MISMATCH')
 if context['currency']!=body['binding']['quote_currency']:raise ComponentError('ACCOUNT_QUOTE_CURRENCY_MISMATCH')
 if experiment.get('forecast') is None:raise ComponentError('CURRENT_RESEARCH_FORECAST_REQUIRED')
 for k,v in lab.flags().items():
  if experiment.get(k)!=v:raise ComponentError('RESEARCH_AUTHORITY_CONTRACT_REQUIRED')
 if (now.date()-dt.date.fromisoformat(body['observations'][-1]['observation_date'])).days>3:raise ComponentError('STALE_RESEARCH_SOURCE')
 prices=[float(row['price']) for row in body['observations']];last=len(prices)-1
 # Match the model's matured training population and strict label embargo.
 origins=[i for i in range(lab.LOOKBACK,last-lab.HORIZON)]
 returns=[prices[i+lab.HORIZON]/prices[i]-1 for i in origins]
 if len(returns)<lab.MIN_TRAIN:raise ComponentError('MATURED_RESEARCH_LABELS_REQUIRED')
 mean=sum(returns)/len(returns);downside=math.sqrt(sum(min(v,0)**2 for v in returns)/len(returns))
 if not all(math.isfinite(v) for v in (mean,downside,experiment['forecast']['value'])):raise ComponentError('FINITE_COMPONENT_REQUIRED')
 if not math.isclose(mean,experiment['forecast']['baseline_value'],rel_tol=1e-12,abs_tol=1e-12):raise ComponentError('TRAINING_POPULATION_MISMATCH')
 scope={'instrument_id':body['binding']['instrument_id'],'account_id':context['account_id'],
  'currency':context['currency'],'horizon_unit':'OBSERVATIONS','horizon_value':lab.HORIZON}
 provenance={'source_body_sha256':digest(body),'experiment_sha256':digest(experiment),
  'source_fetched_at':body['fetched_at'],'experiment_computed_at':experiment['computed_at'],
  'source_available_point_in_time_in_past':False,'sampling':body['sampling'],
  'provider':body['binding']['provider'],'provider_id':body['binding']['provider_id'],
  'identity_source_ref':body['binding']['identity_source_ref']}
 def value(n,unit,status,method):
  return {**scope,'value':n,'unit':unit,'status':status,'validation_status':'NOT_VALIDATED_FOR_COMPARATOR',
   'authority':'NONE','method':method,'provenance':dict(provenance)}
 components={
  'forward_return':value(experiment['forecast']['value'],'RETURN_FRACTION','EXPERIMENTAL_MODEL_OUTPUT',lab.METHOD),
  'risk_measure':value(downside,'DOWNSIDE_RMS_RETURN_FRACTION','HISTORICAL_DESCRIPTION_NOT_FORWARD_RISK','REALIZED_DOWNSIDE_RMS_30_OBSERVATIONS_V1'),
  'counterfactual_return':value(mean,'RETURN_FRACTION','REFERENCE_ONLY_NOT_ACTION_COUNTERFACTUAL','EXPANDING_MATURED_TRAINING_LABEL_MEAN'),
  'transaction_cost':{**scope,'value':None,'unit':'REFERENCE_CAPITAL_FRACTION','status':'ACCOUNT_VENUE_COST_EVIDENCE_REQUIRED','validation_status':'NOT_VALIDATED_FOR_COMPARATOR','authority':'NONE'},
  'relative_utility':{**scope,'value':None,'unit':'POLICY_UTILITY','status':'EXPLICIT_UTILITY_POLICY_REQUIRED','validation_status':'NOT_VALIDATED_FOR_COMPARATOR','authority':'NONE'}}
 return {'schema':SCHEMA,'method':METHOD,**scope,'context_fingerprint':context['context_fingerprint'],
  'series_id':body['series_id'],'source_body_sha256':digest(body),'experiment_sha256':digest(experiment),
  'status':'PARTIAL_RESEARCH_COMPONENTS_NOT_COMPARATOR_READY','components':components,
  'research_label_count':len(returns),'last_training_label_end':body['observations'][origins[-1]+lab.HORIZON]['observation_date'],
  'risk_comparability_basis':'SAME_30_OBSERVATION_LABEL_POPULATION_NOT_CURRENCY_CONVERSION',
  'capital_or_order_size_assumed':False,'action_selected':False,'source_destination_pair_created':False,
  'blocking_reasons':['FORWARD_RETURN_MODEL_NOT_VALIDATED','HISTORICAL_RISK_NOT_FORWARD_VALIDATED',
   'ACTION_SPECIFIC_COUNTERFACTUAL_REQUIRED','ACCOUNT_VENUE_COST_EVIDENCE_REQUIRED','EXPLICIT_UTILITY_POLICY_REQUIRED',
   'REFERENCE_CAPITAL_AND_ALTERNATIVES_REQUIRED'],**flags()}

def target(root,payload):
 return local(root,STORE+'/packets/'+digest({'series_id':payload['series_id'],'account_id':payload['account_id'],'currency':payload['currency']})+'/'+digest(payload)+'.json')

def prepare(root,demand,now):
 planned,eligible,latest=lab.sources(root,demand,now)
 contexts={(c['account_id'],c['currency'],c['context_fingerprint']):c for c in demand['contexts'] if c.get('research_enabled') is True}
 rows=[]
 for key,job in sorted(eligible.items()):
  for funding in sorted(job['funding_contexts']):
   context=contexts.get(tuple(funding))
   if context is None:raise ComponentError('CURRENT_FUNDED_CONTEXT_REQUIRED')
   scope={'instrument_id':job['binding']['instrument_id'],'quote_currency':job['binding']['quote_currency'],
    'provider':job['binding']['provider'],'provider_id':job['binding']['provider_id'],'series_id':key}
   row={**scope,'account_id':context['account_id'],'context_fingerprint':context['context_fingerprint'],
    'status':'AWAITING_GLOBAL_HISTORY','packet':None,'source':None}
   if key in latest:
    path,body=latest[key];row['source']=(path,body);experiment=validated_experiment(root,body,now)
    row['status']='AWAITING_GLOBAL_RESEARCH_PROCESSING'
    if experiment:
     if (now.date()-dt.date.fromisoformat(body['observations'][-1]['observation_date'])).days>3:row['status']='STALE_RESEARCH_SOURCE'
     elif experiment.get('forecast') is None:row['status']='INSUFFICIENT_RESEARCH_HISTORY'
     else:row.update(status='AWAITING_COMPONENT_PRODUCTION',packet=packet(body,experiment,context,now=now))
   rows.append(row)
 return planned,rows

def run(root,demand,*,now=None,revalidate=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc));handle=None
 out={'schema':SCHEMA,'status':'RESEARCH_COMPONENTS_NOT_RUN','packets_created':0,'network_requests':0,**flags()}
 try:
  planned,rows=prepare(root,demand,now)
  ready=[row for row in rows if row['packet'] is not None]
  if not ready:return {**out,'status':'AWAITING_ELIGIBLE_RESEARCH_EXPERIMENTS'}
  directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True)
  fd=os.open(local(root,STORE+'/producer.lock'),os.O_CREAT|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600);handle=os.fdopen(fd,'w')
  try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return {**out,'status':'RESEARCH_COMPONENT_PRODUCER_BUSY'}
  for row in ready:
   payload=row['packet'];path=target(root,payload)
   if path.exists():
    if history.read_sealed(path)!=payload:raise ComponentError('EXISTING_COMPONENT_PACKET_PRESERVED')
    continue
   current=(revalidate or (lambda:quotes.current_contexts(root)))()
   if digest(load(root))!=planned['binding_digest'] or (row['account_id'],row['quote_currency'],row['context_fingerprint']) not in current:raise ComponentError('COMPONENT_ELIGIBILITY_CHANGED')
   source,body=row['source']
   if history.read_sealed(source)!=body:raise ComponentError('COMPONENT_SOURCE_CHANGED')
   experiment=validated_experiment(root,body,now)
   if experiment is None or digest(experiment)!=payload['experiment_sha256']:raise ComponentError('COMPONENT_EXPERIMENT_CHANGED')
   history.store_once(path,payload)
   return {**out,'status':'PARTIAL_RESEARCH_COMPONENT_PACKET_RECORDED','packets_created':1}
  return {**out,'status':'RESEARCH_COMPONENT_PACKETS_CURRENT'}
 except Exception as exc:return {**out,'status':'RESEARCH_COMPONENT_PRODUCTION_UNAVAILABLE','error_type':type(exc).__name__}
 finally:
  if handle is not None:handle.close()

def summary(root,demand,*,now=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc))
 out={'schema':SCHEMA,'status':'RESEARCH_COMPONENTS_INSPECTED','account_context_count':0,'packet_count':0,
  'available_component_count':0,'missing_component_count':0,'blocking_reason_counts':{},'contexts':[],
  'history_write_performed':False,'network_requests':0,**flags()}
 try:
  planned,rows=prepare(root,demand,now);counts={};public=[];n=0
  for row in rows:
   item={k:row[k] for k in ('instrument_id','quote_currency','provider','provider_id','status')}
   item.update(available_components=[],missing_components=list(COMPONENTS))
   payload=row['packet']
   if payload is not None:
    path=target(root,payload)
    if path.exists():
     if history.read_sealed(path)!=payload:raise ComponentError('COMPONENT_PACKET_PROJECTION_MISMATCH')
     n+=1;item.update(status=payload['status'],available_components=['forward_return','risk_measure','counterfactual_return'],missing_components=['transaction_cost','relative_utility'])
     for reason in payload['blocking_reasons']:counts[reason]=counts.get(reason,0)+1
   public.append(item)
  return {**out,'account_context_count':len(rows),'packet_count':n,'available_component_count':3*n,
   'missing_component_count':5*len(rows)-3*n,'blocking_reason_counts':counts,'contexts':public}
 except Exception as exc:return {**out,'status':'RESEARCH_COMPONENT_INSPECTION_UNAVAILABLE','account_context_count':None,'packet_count':None,'available_component_count':None,'missing_component_count':None,'error_type':type(exc).__name__}
