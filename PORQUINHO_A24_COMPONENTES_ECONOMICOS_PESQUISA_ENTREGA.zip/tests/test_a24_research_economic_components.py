"""Account-scoped drafts and incomplete-input safety, using synthetic sources."""
import copy,datetime as dt,unittest,fcntl,json,ast,types
from pathlib import Path
from unittest.mock import patch
import test_a24_global_research_lab as fixture
from universal_portfolio import research_economic_components_a24 as c,global_history_source_a24 as h
from universal_portfolio import economic_component_set_producer_a24 as governed
from brain.evolution import global_research_lab_a24 as lab
NOW=fixture.NOW
class Components(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Lab();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root;self.demand=self.f.demand
 def source(self):return self.f.source()
 def seed(self):self.source();self.f.runlab()
 def current(self):return {(x['account_id'],x['currency'],x['context_fingerprint']) for x in self.demand['contexts']}
 def runproducer(self):return c.run(self.root,self.demand,now=NOW,revalidate=self.current)
 def summary(self):return c.summary(self.root,self.demand,now=NOW)
 def read(self):return h.read_sealed(next((self.root/c.STORE/'packets').rglob('*.json')))
 def test_no_history_no_packets(self):self.assertEqual(self.runproducer()['packets_created'],0);self.assertEqual(self.summary()['contexts'][0]['status'],'AWAITING_GLOBAL_HISTORY')
 def test_history_without_experiment_waits(self):
  self.source();self.assertEqual(self.summary()['contexts'][0]['status'],'AWAITING_GLOBAL_RESEARCH_PROCESSING');self.assertEqual(self.runproducer()['packets_created'],0)
 def test_one_partial_packet_created(self):
  self.seed();self.assertEqual(self.runproducer()['packets_created'],1);s=self.summary();self.assertEqual(s['packet_count'],1);self.assertEqual(s['available_component_count'],3);self.assertEqual(s['missing_component_count'],2)
 def test_exact_account_currency_identity(self):
  self.seed();self.runproducer();p=self.read();scope=p['components']['forward_return'];self.assertEqual(scope['account_id'],self.demand['contexts'][0]['account_id']);self.assertEqual(scope['currency'],'BRL');self.assertEqual(scope['instrument_id'],p['instrument_id'])
 def test_unknown_cost_not_zero(self):
  self.seed();self.runproducer();self.assertIsNone(self.read()['components']['transaction_cost']['value'])
 def test_utility_not_invented(self):
  self.seed();self.runproducer();self.assertIsNone(self.read()['components']['relative_utility']['value'])
 def test_no_validation_or_authority_created(self):
  self.seed();self.runproducer();p=self.read()
  for component in p['components'].values():self.assertEqual(component['validation_status'],'NOT_VALIDATED_FOR_COMPARATOR');self.assertEqual(component['authority'],'NONE')
  self.assertFalse(p['comparison_authorized']);self.assertFalse(p['canonical_publication_authorized']);self.assertFalse(p['action_selected']);self.assertFalse(p['source_destination_pair_created'])
 def test_governed_assembler_refuses_research_packet(self):
  self.seed();self.runproducer();result=governed.produce(self.read());self.assertEqual(result['sets'],[]);self.assertIn('COMPONENT_SOURCE_SCHEMA_REQUIRED',result['diagnostic']['blocking_reason_counts'])
 def test_repeat_preserves_versions(self):
  self.seed();self.runproducer();before={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in (self.root/c.STORE/'packets').rglob('*.json')};self.assertEqual(self.runproducer()['packets_created'],0);self.assertEqual(before,{p:(p.read_bytes(),p.stat().st_mtime_ns) for p in before})
 def test_summary_no_writes_no_account_values(self):
  self.seed();self.runproducer();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};s=self.summary();self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()});self.assertNotIn('account_id',json.dumps(s));self.assertNotIn('value',json.dumps(s))
 def test_risk_nonnegative_and_historical(self):
  self.seed();self.runproducer();risk=self.read()['components']['risk_measure'];self.assertGreaterEqual(risk['value'],0);self.assertEqual(risk['status'],'HISTORICAL_DESCRIPTION_NOT_FORWARD_RISK')
 def test_reference_not_action_counterfactual(self):
  self.seed();self.runproducer();self.assertEqual(self.read()['components']['counterfactual_return']['status'],'REFERENCE_ONLY_NOT_ACTION_COUNTERFACTUAL')
 def test_all_positive_training_returns_have_zero_realized_downside(self):
  self.seed();self.runproducer();self.assertEqual(self.read()['components']['risk_measure']['value'],0)
 def test_negative_return_forecast_not_clamped(self):
  job=self.f.f.job();response=self.f.f.response(364)
  for index,p in enumerate(response['prices']):p[1]=str(1000-index)
  body=h.bundle(job['binding'],response,now=NOW,binding_digest='fixture');h.store_once(h.path_for(self.root,job,NOW),body);self.f.runlab();self.runproducer();p=self.read();self.assertLess(p['components']['forward_return']['value'],0);self.assertGreater(p['components']['risk_measure']['value'],0)
 def test_training_population_matches_existing_lab(self):
  self.seed();self.runproducer();p=self.read();body=self.f.body();experiment=c.validated_experiment(self.root,body,NOW);self.assertEqual(p['research_label_count'],experiment['forecast']['model']['training_label_count']);self.assertEqual(p['last_training_label_end'],experiment['forecast']['model']['last_training_label_end'])
 def test_wrong_account_currency_refused(self):
  self.seed();body=self.f.body();e=c.validated_experiment(self.root,body,NOW);ctx={**self.demand['contexts'][0],'currency':'EUR'}
  with self.assertRaises(ValueError):c.packet(body,e,ctx,now=NOW)
 def test_tampered_resealed_experiment_refused(self):
  self.seed();path=next((self.root/lab.STORE/'experiments').rglob('*.json'));b=h.read_sealed(path);b['forecast']['value']=999;path.unlink();h.store_once(path,b);self.assertEqual(self.runproducer()['status'],'RESEARCH_COMPONENT_PRODUCTION_UNAVAILABLE')
 def test_direct_forged_experiment_refused(self):
  self.seed();b=self.f.body();e=c.validated_experiment(self.root,b,NOW);e['forecast']['value']=999
  with self.assertRaises(ValueError):c.packet(b,e,self.demand['contexts'][0],now=NOW)
 def test_removed_binding_not_reused(self):
  self.seed();self.f.f.f.save([]);self.assertEqual(self.summary()['account_context_count'],0);self.assertEqual(self.runproducer()['packets_created'],0)
 def test_funding_change_before_write_refused(self):
  self.seed();self.assertEqual(c.run(self.root,self.demand,now=NOW,revalidate=lambda:set())['packets_created'],0)
 def test_producer_lock_refused(self):
  self.seed();directory=self.root/c.STORE;directory.mkdir(parents=True)
  with (directory/'producer.lock').open('w') as stream:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);self.assertEqual(self.runproducer()['status'],'RESEARCH_COMPONENT_PRODUCER_BUSY')
 def test_corrupt_packet_not_reported_available(self):
  self.seed();self.runproducer();p=next((self.root/c.STORE/'packets').rglob('*.json'));p.write_text('{}');self.assertEqual(self.summary()['status'],'RESEARCH_COMPONENT_INSPECTION_UNAVAILABLE')
 def test_stale_source_not_consumed(self):
  self.seed();self.runproducer();s=c.summary(self.root,self.demand,now=NOW+dt.timedelta(days=5));self.assertEqual(s['packet_count'],0);self.assertEqual(s['contexts'][0]['status'],'STALE_RESEARCH_SOURCE')
 def test_sources_legacy_and_models_unchanged(self):
  self.seed();p=self.root/'results/legacy_snapshot';p.parent.mkdir(parents=True);p.write_bytes(b'PRESERVE');before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};self.runproducer()
  for p,data in before.items():self.assertEqual(p.read_bytes(),data)
 def test_no_http(self):
  self.seed()
  with patch.object(h.Transport,'get_json',side_effect=AssertionError('NO_HTTP')):self.assertEqual(self.runproducer()['network_requests'],0)
 def test_duplicate_accounts_remain_separate(self):
  self.seed();self.demand=self.f.f.f.demand(duplicate_account=True);self.assertEqual(self.summary()['account_context_count'],2);self.assertEqual(self.runproducer()['packets_created'],1);self.assertEqual(self.runproducer()['packets_created'],1);self.assertEqual(self.summary()['packet_count'],2);self.assertEqual(len({h.read_sealed(p)['account_id'] for p in (self.root/c.STORE/'packets').rglob('*.json')}),2)
 def test_actual_cycle_hook_preserves_demand(self):
  tree=ast.parse((Path(__file__).resolve().parents[1]/'webapp/server.py').read_text());refresh=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_refresh');imp=next(n for n in ast.walk(refresh) if isinstance(n,ast.ImportFrom) and n.module=='universal_portfolio.research_economic_components_a24');assignment=next(n for n in ast.walk(refresh) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_a24_run_research_components');ns={'ROOT':self.root,'universal_shadow':{},'_universal_result':types.SimpleNamespace(bridge=types.SimpleNamespace(intelligence={'funded_currency_research':self.demand}))}
  with patch.object(c,'run',return_value={'status':'TEST'}) as hook:exec(compile(ast.Module(body=[imp,assignment],type_ignores=[]),'actual_component_hook','exec'),ns)
  hook.assert_called_once_with(self.root,self.demand)
