import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('inventory', Path(__file__).with_name('inventory.py'))
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class InventoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name).resolve()
        self.root = self.base / 'project'
        (self.root / 'webapp').mkdir(parents=True)
        (self.root / 'webapp/server.py').write_text('# fixture')
        (self.root / 'data').mkdir()

    def put(self, path, value):
        p = self.root / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(value))
        return p

    def test_missing_is_scoped_not_platform_absence(self):
        r = m.inventory(self.root)
        self.assertEqual(r['status'], 'INVENTORY_COMPLETE_WITHIN_SURVEYED_SCOPE')
        self.assertTrue(r['absence_is_not_proof_no_policy_exists_elsewhere'])
        self.assertTrue(all(x['status'] == 'MISSING' for x in r['sources']))

    def test_real_fields_without_financial_values_or_ids(self):
        p = self.put('data/investment_plans.json', {'plans': [{'planning_budget_id': 'PRIVATE_ID', 'strategy': 'PRIVATE_STRATEGY', 'allowed_asset_classes': ['PRIVATE_CLASS'], 'account_id': 'PRIVATE_ACCOUNT', 'planning_budget_amount': '98765.43'}]})
        before = p.read_bytes()
        r = m.inventory(self.root)
        s = json.dumps(r)
        for value in ('PRIVATE_', '98765.43'):
            self.assertNotIn(value, s)
        x = next(x for x in r['sources'] if x['source'] == 'data/investment_plans.json')
        self.assertEqual(x['structural_candidate_counts']['investment_plan_shaped_objects'], 1)
        self.assertEqual(p.read_bytes(), before)

    def test_execution_budget_not_dimension_policy(self):
        r = m.describe({'max_per_transaction': 50, 'max_per_day': 80, 'weekly_budget': 200})
        self.assertEqual(r['structural_candidate_counts'], {'execution_budget_policy_shaped_objects': 1})
        self.assertFalse(r['candidate_validity_assessed'])

    def test_declared_validation_not_certification(self):
        r = m.describe({'threshold': .2, 'metric_semantics': 'anything', 'scale': 'a', 'unit': 'b', 'horizon': 'c', 'validated': True})
        self.assertEqual(r['structural_candidate_counts']['risk_policy_shaped_objects'], 1)
        self.assertFalse(r['candidate_validity_assessed'])
        self.assertNotIn('.2', json.dumps(r))

    def test_secrets_subtrees_and_filenames_excluded(self):
        self.put('data/risk_token_settings.json', {'risk_policy': {'threshold': 777}})
        self.put('data/settings.json', {'api_key': {'risk_policy': {'threshold': 777}}, 'policy_id': 'private'})
        r = m.inventory(self.root)
        row = next(x for x in r['sources'] if x['source'] == 'data/settings.json')
        self.assertNotIn('threshold', row['recognized_field_occurrence_counts'])
        self.assertEqual(len(r['sources']), len(m.KNOWN))

    def test_additional_filename_not_exported(self):
        self.put('data/Jonas_private_risk_settings.json', {'risk_policy': {}})
        r = m.inventory(self.root)
        self.assertNotIn('Jonas', json.dumps(r))
        self.assertTrue(any(x['source'] == 'ADDITIONAL_CONFIGURATION_CANDIDATE' for x in r['sources']))

    def test_symlink_refused(self):
        target = self.base / 'private.json'
        target.write_text('{"risk_policy": {}}')
        (self.root / 'data/settings.json').symlink_to(target)
        row = next(x for x in m.inventory(self.root)['sources'] if x['source'] == 'data/settings.json')
        self.assertEqual(row['reason'], 'SYMLINK_REFUSED')

    def test_no_recursive_history_scan(self):
        self.put('data/brain/history/settings.json', {'risk_policy': {}})
        self.put('data/transaction_ledger.json', {'risk_policy': {}})
        self.assertTrue(all(x['status'] == 'MISSING' for x in m.inventory(self.root)['sources']))

    def test_invalid_json_and_duplicate_keys_are_not_validated(self):
        p = self.root / 'data/settings.json'
        for raw in ('{"threshold": NaN}', '{"threshold":1,"threshold":2}', '{'):
            p.write_text(raw)
            r = m.inventory(self.root)
            self.assertEqual(r['status'], 'INVENTORY_INCOMPLETE')

    def test_source_size_and_node_limits(self):
        self.put('data/settings.json', {'risk_policy': {}})
        with patch.object(m, 'MAX_BYTES', 4):
            r = m.inventory(self.root)
            self.assertEqual(r['status'], 'INVENTORY_INCOMPLETE')
        with patch.object(m, 'MAX_NODES', 2):
            with self.assertRaises(m.InventoryError):
                m.describe([1, 2, 3])

    def test_change_after_read_detected(self):
        p = self.put('data/settings.json', {'risk_policy': {}})
        original = m.describe
        def changed(value):
            p.write_text('{}')
            return original(value)
        with patch.object(m, 'describe', changed):
            self.assertFalse(m.inventory(self.root)['source_files_stable_during_survey'])

    def test_output_only_outside_project_preserves_sources(self):
        sentinel = self.put('data/settings.json', {'threshold': 5})
        before = sentinel.read_bytes()
        with self.assertRaises(m.InventoryError):
            m.save(self.root, self.root / 'data')
        a, r = m.save(self.root, self.base)
        b, _ = m.save(self.root, self.base)
        self.assertNotEqual(a, b)
        self.assertEqual(a.stat().st_mode & 0o777, 0o600)
        self.assertEqual(json.loads(a.read_text()), r)
        self.assertEqual(sentinel.read_bytes(), before)
        self.assertFalse(r['project_mutation'])
        self.assertFalse(r['canonical_publication_authorized'])


if __name__ == '__main__':
    unittest.main()
