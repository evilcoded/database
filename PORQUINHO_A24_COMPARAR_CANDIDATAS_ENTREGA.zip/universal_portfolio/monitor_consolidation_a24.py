"""Read-only operational visibility. Never emits or promotes investment decisions."""
import datetime as dt,json
from dataclasses import asdict
from decimal import Decimal,InvalidOperation
from pathlib import Path
from .explicit_market_bindings_a24 import local,load,text
SCHEMA='porquinho.monitor-consolidation-a24/1.0'

def instant(value):
 try:
  result=dt.datetime.fromisoformat(value.replace('Z','+00:00'))
  return result.astimezone(dt.timezone.utc) if result.tzinfo and result.utcoffset() is not None else None
 except (ValueError,TypeError,AttributeError):return None

def stamp(value,now):
 t=instant(value)
 return {'at':t.isoformat() if t else None,'age_seconds':max(0,int((now-t).total_seconds())) if t and t<=now else None,'time_status':'FUTURE' if t and t>now else 'PRESENT' if t else 'UNKNOWN'}

def position_records(values):
 from .opening_seeded_derivation import SeededPosition
 if not isinstance(values,(list,tuple)):raise ValueError('POSITIONS_COLLECTION_REQUIRED')
 rows=[]
 verified_accounts={'CANONICAL_POSITION_IDENTITY_BINDING','EXPLICIT_CANONICAL_BINDING_DERIVED_VIEW','EXPLICIT_TRANSACTION_ACCOUNT'}
 for position in values:
  if isinstance(position,SeededPosition):row=asdict(position)
  elif isinstance(position,dict):row=dict(position)
  else:raise ValueError('UNSUPPORTED_POSITION_RECORD')
  ref=row.get('account_reference')
  if isinstance(ref,str) and row.get('account_status') in verified_accounts:
   row['account_reference']={'value':ref,'status':row['account_status']}
  rows.append(row)
 return rows

def projected_account_records(positions,registry):
 """Accept projected account IDs only when exactly verified in today's registry."""
 accounts=registry.get('accounts',[])
 if not isinstance(accounts,list):raise ValueError('ACCOUNT_REGISTRY_ROWS_REQUIRED')
 out=[]
 for original in positions:
  row=dict(original)
  if row.get('account_status')=='CANONICAL_ACCOUNT_ID_AS_PROJECTED':
   ref=row.get('account_reference')
   if isinstance(ref,str) and text(ref):
    matches=[a for a in accounts if isinstance(a,dict) and a.get('account_id')==ref]
    if len(matches)==1 and matches[0].get('currency')==row.get('currency'):
     row['account_reference']={'value':ref,'status':'PROJECTED_ACCOUNT_VERIFIED_IN_CURRENT_REGISTRY'}
  out.append(row)
 return out

def identity_link_index(links):
 from .reviewed_research_identity_links_a24 import index
 return index(links)

def context(row):
 iid=row.get('canonical_instrument_id') or row.get('instrument_id');aid=row.get('account_id');reference=row.get('account_reference')
 nested=reference.get('value') if isinstance(reference,dict) else None
 if aid and nested and aid!=nested:return None
 if not aid:aid=nested
 q=row.get('currency')
 if not all(text(x) for x in (iid,aid,q)) or not q.isascii() or not q.isalpha() or not q.isupper():return None
 if row.get('canonical_instrument_id') and row.get('instrument_id') and row['canonical_instrument_id']!=row['instrument_id']:return None
 return iid,aid,q

def project(positions,bindings,observations,*,canonical_reason,identity_links=()):
 links=identity_link_index(identity_links)
 def nonzero(pos):
  quantity=pos.get('quantity')
  if quantity is None:return True
  try:return Decimal(str(quantity))!=0
  except (InvalidOperation,ValueError):return True
 positions=[pos for pos in positions if nonzero(pos)]
 counts={};keys={};research_keys={}
 for pos in positions:
  key=context(pos)
  if key:
   keys[key]=keys.get(key,0)+1
   target=links.get(key[0],{}).get('research_instrument_id',key[0]);rkey=(target,key[1],key[2])
   research_keys[rkey]=research_keys.get(rkey,0)+1
 rows=[]
 for pos in positions:
  quantity=pos.get('quantity')
  if quantity is not None:
   try:
    if Decimal(str(quantity)).is_finite() and Decimal(str(quantity))==0:continue
   except (InvalidOperation,ValueError):pass
  key=context(pos);row={'instrument_id':key[0] if key else None,'account_id':key[1] if key else None,'currency':key[2] if key else None,
   'canonical_status':'UNAVAILABLE','canonical_reason':canonical_reason,'execution_authorized':False,'recommendation':None}
  if not key:row.update(identity_status='INCOMPLETE_OR_CONFLICTING',research_status='IDENTITY_CONTEXT_REQUIRED')
  elif keys[key]!=1:row.update(identity_status='DUPLICATE_CONTEXT',research_status='AMBIGUOUS_POSITION_CONTEXT')
  else:
   row['identity_status']='EXACT_POSITION_CONTEXT'
   link=links.get(key[0]);research_iid=link['research_instrument_id'] if link else key[0]
   row['research_instrument_id']=research_iid
   row['research_identity_status']='EXPLICIT_REVIEWED_COMPATIBILITY' if link else 'EXACT_IDENTITY'
   if link:row['research_identity_evidence_ref']=link['evidence_ref']
   if research_keys[(research_iid,key[1],key[2])]!=1:
    row['research_status']='AMBIGUOUS_POSITION_CONTEXT'
    counts[row['research_status']]=counts.get(row['research_status'],0)+1;rows.append(row);continue
   if link and any((b['instrument_id'],b['quote_currency'])==(key[0],key[2]) for b in bindings):
    row['research_status']='SOURCE_SELECTION_REQUIRED'
    counts[row['research_status']]=counts.get(row['research_status'],0)+1;rows.append(row);continue
   sources=[b for b in bindings if (b['instrument_id'],b['quote_currency'])==(research_iid,key[2])]
   if not sources:row['research_status']='EXPLICIT_SOURCE_BINDING_REQUIRED'
   elif len(sources)!=1:row['research_status']='SOURCE_SELECTION_REQUIRED'
   else:
    b=sources[0];quotes=[q for q in observations if (q['instrument_id'],q['provider'].lower(),q['provider_id'],q['quote_currency'])==(research_iid,b['provider'].lower(),b['provider_id'],key[2])]
    row['research_status']='CAPTURE_OBSERVED_TODAY' if quotes else 'AWAITING_NORMAL_CAPTURE_TODAY'
    if quotes:row['captured_at']=max(q['fetched_at'] for q in quotes)
  counts[row['research_status']]=counts.get(row['research_status'],0)+1;rows.append(row)
 return rows,counts

def research_display_contexts(contexts,catalog):
 """Label exact identities for display only; never derive identity or currency."""
 labels={};conflicts=set()
 entries=catalog.get('instruments',[]) if isinstance(catalog,dict) else []
 if not isinstance(entries,(list,tuple)):entries=[]
 for row in entries:
  if not isinstance(row,dict):continue
  iid=row.get('instrument_id');label=row.get('symbol') or row.get('name')
  if not text(iid) or not text(label) or len(label)>120:continue
  if iid in labels and labels[iid]!=label:conflicts.add(iid)
  labels[iid]=label
 return [{**row,'display_label':labels[row['instrument_id']] if row.get('instrument_id') in labels and row['instrument_id'] not in conflicts else row.get('instrument_id'),
  'display_label_evidence':'EXACT_CATALOG_METADATA' if row.get('instrument_id') in labels and row['instrument_id'] not in conflicts else 'IDENTIFIER_ONLY'} for row in contexts]

def inspect(root,*,now=None,runtime_reader=None):
 now=now or dt.datetime.now(dt.timezone.utc)
 if now.tzinfo is None or now.utcoffset() is None:raise ValueError('AWARE_TIME_REQUIRED')
 now=now.astimezone(dt.timezone.utc);root=Path(root).resolve(strict=True);issues=[]
 def document(rel):
  try:
   p=local(root,rel)
   if not p.exists():return {}
   stat=p.stat()
   if stat.st_size>64*1024*1024:raise ValueError('SIZE_LIMIT')
   value=json.loads(p.read_bytes())
   if p.stat().st_mtime_ns!=stat.st_mtime_ns or p.stat().st_size!=stat.st_size:raise ValueError('CHANGED_DURING_READ')
   if not isinstance(value,dict):raise ValueError('MAPPING_REQUIRED')
   return value
  except Exception as exc:issues.append({'source':rel,'error_type':type(exc).__name__});return {}
 health=document('results/auto_cycle_health.json');snapshot=document('results/latest.json');lab=document('results/prediction_lab.json')
 from .universal_runtime_composition import contract_payload
 contract=contract_payload();reason='SHADOW_RUNTIME_NO_CANONICAL_SNAPSHOTS' if contract.get('canonical_recommendation_snapshots_expected')==0 and contract.get('runtime_wiring') is False else 'CANONICAL_CONTRACT_REQUIRES_REVIEW'
 registry_ok=journal_ok=positions_ok=False;bindings=[];observations=[];positions=[]
 try:bindings=load(root)['bindings'];registry_ok=True
 except Exception as exc:issues.append({'source':'explicit_bindings','error_type':type(exc).__name__})
 try:
  from .research_quote_acquisition_a24 import read_records
  observations=read_records(root,day=now.date());journal_ok=True
 except Exception as exc:issues.append({'source':'daily_research_journal','error_type':type(exc).__name__})
 try:
  if runtime_reader is None:
   from .canonical_runtime_read_model import build
   runtime_reader=build
  runtime=runtime_reader(root)
  if runtime.get('authority')!='NONE' or runtime.get('ledger_write') is not False:raise ValueError('READ_MODEL_CONTRACT_REQUIRED')
  positions=position_records(runtime['positions'])
  if any(p.get('account_status')=='CANONICAL_ACCOUNT_ID_AS_PROJECTED' for p in positions):
   positions=projected_account_records(positions,document('data/institution_accounts.json'))
  positions_ok=True
 except Exception as exc:positions=[];issues.append({'source':'runtime_positions','error_type':type(exc).__name__})
 from .reviewed_research_identity_links_a24 import load as research_links
 try:links=research_links(root)
 except Exception as exc:
  links=[];registry_ok=False;issues.append({'source':'reviewed_research_identity_links','error_type':type(exc).__name__})
 rows,counts=project(positions,bindings,observations,canonical_reason=reason,identity_links=links)
 if not registry_ok or not journal_ok:
  for row in rows:row['research_status']='SOURCE_INSPECTION_UNAVAILABLE'
  counts={'SOURCE_INSPECTION_UNAVAILABLE':len(rows)} if rows else {}
 heartbeat=stamp(health.get('at'),now);snapshot_time=stamp(snapshot.get('timestamp',snapshot.get('generated_at')),now);model_time=stamp(lab.get('trained_at'),now)
 raw_contract=lab.get('input_contract');global_reader=bool(isinstance(raw_contract,dict) and raw_contract.get('schema')=='porquinho.global-market-reader-a24/1.0' and raw_contract.get('historical_row_attestation') is False and raw_contract.get('canonical_publication_authorized') is False)
 from .research_economic_series_a24 import summary as economic_series_summary
 research_economic_series=economic_series_summary(root,now=now)
 if research_economic_series['status']=='RESEARCH_SERIES_INSPECTION_UNAVAILABLE':issues.append({'source':'research_economic_series','error_type':research_economic_series.get('error_type','UnknownError')})
 from .global_history_source_a24 import summary as history_source_summary
 global_history=history_source_summary(root)
 if global_history['status']=='GLOBAL_HISTORY_INSPECTION_UNAVAILABLE':issues.append({'source':'global_history_source','error_type':global_history.get('error_type','UnknownError')})
 from brain.evolution.global_research_lab_a24 import summary as global_lab_summary
 try:
  from .universal_observation_bridge import build_read_only_bridge
  bridge=build_read_only_bridge(root)
  demand=bridge.intelligence.get('funded_currency_research') or {}
  from .learned_policy_economic_basis_a24 import summarize as summarize_economic_basis
  economic_basis=summarize_economic_basis(bridge.intelligence.get('learned_policy_economic_basis') or {'schema':'porquinho.learned-policy-economic-basis-a24/1.0','status':'LEARNED_ECONOMIC_BASIS_UNAVAILABLE','reason':'NotTransported'})
  from .learned_policy_account_context_a24 import summarize as summarize_learned_scope
  learned_scope=summarize_learned_scope(bridge.intelligence.get('learned_policy_account_context') or {'schema':'porquinho.learned-policy-account-context-a24/1.0','status':'LEARNED_POLICY_ACCOUNT_SCOPE_UNAVAILABLE','reason':'NotTransported'})
  learned_policy=bridge.intelligence.get('learned_allocation_policy') or {'schema':'porquinho.learned-allocation-policy-a24/1.0','status':'LEARNED_POLICY_RESEARCH_UNAVAILABLE','error_type':'NotTransported'}
  from .economic_action_policy_a24 import summarize as summarize_action_policy
  action_policy=summarize_action_policy(bridge.intelligence.get('economic_action_policy') or {'schema':'porquinho.economic-action-policy-a24/1.0','status':'ACTION_POLICY_INPUT_UNAVAILABLE','reason':'POLICY_INPUT_NOT_TRANSPORTED'})
  from .economic_action_evidence_a24 import summarize as summarize_action_evidence
  action_evidence=summarize_action_evidence(bridge.intelligence.get('economic_action_evidence') or {'schema':'porquinho.economic-action-evidence-a24/1.0','status':'ACTION_EVIDENCE_UNAVAILABLE','reason':'ACTION_EVIDENCE_NOT_TRANSPORTED'})
  from .economic_action_plan_a24 import summarize as summarize_action_plan
  action_plan=summarize_action_plan(bridge.intelligence.get('economic_action_plan') or {'schema':'porquinho.economic-action-plan-a24/1.0','status':'ACTION_CONTEXT_PROJECTION_UNAVAILABLE','reason':'ACTION_PLAN_NOT_TRANSPORTED'})
  from brain.evolution.global_existing_lab_a24 import summary as reused_lab_summary
  reused_lab=reused_lab_summary(root,demand,now=now)
  from brain.evolution.global_model_evaluation_a24 import inspect as assess_models
  model_evaluation=assess_models(root,demand,now=now)
  model_evaluation['contexts']=research_display_contexts(model_evaluation.get('contexts',[]),document('data/universal_instrument_catalog.json'))
  global_lab=global_lab_summary(root,demand,now=now)
  if isinstance(global_lab.get('contexts'),list):global_lab['contexts']=research_display_contexts(global_lab['contexts'],document('data/universal_instrument_catalog.json'))
  from .research_economic_components_a24 import summary as component_summary
  research_components=component_summary(root,demand,now=now)
  from .account_cost_evidence_a24 import summary as cost_summary
  account_cost=cost_summary(root,demand,now=now)
 except Exception as exc:
  economic_basis={'schema':'porquinho.learned-policy-economic-basis-a24/1.0','status':'LEARNED_ECONOMIC_BASIS_UNAVAILABLE','reason':type(exc).__name__}
  learned_scope={'schema':'porquinho.learned-policy-account-context-a24/1.0','status':'LEARNED_POLICY_ACCOUNT_SCOPE_UNAVAILABLE','reason':type(exc).__name__}
  learned_policy={'schema':'porquinho.learned-allocation-policy-a24/1.0','status':'LEARNED_POLICY_RESEARCH_UNAVAILABLE','error_type':type(exc).__name__}
  action_policy={'schema':'porquinho.economic-action-policy-a24/1.0','status':'ACTION_POLICY_INPUT_UNAVAILABLE','reason':type(exc).__name__}
  action_evidence={'schema':'porquinho.economic-action-evidence-a24/1.0','status':'ACTION_EVIDENCE_UNAVAILABLE','reason':type(exc).__name__}
  action_plan={'schema':'porquinho.economic-action-plan-a24/1.0','status':'ACTION_CONTEXT_PROJECTION_UNAVAILABLE','reason':type(exc).__name__}
  reused_lab={'schema':'porquinho.global-existing-lab-a24/1.0','status':'EXISTING_GLOBAL_LAB_INSPECTION_UNAVAILABLE','experiments':[],'error_type':type(exc).__name__}
  model_evaluation={'schema':'porquinho.global-model-evaluation-a24/1.0','status':'GLOBAL_MODEL_ASSESSMENT_UNAVAILABLE','contexts':[],'error_type':type(exc).__name__}
  account_cost={'schema':'porquinho.account-cost-evidence-a24/1.0','status':'ACCOUNT_COST_INSPECTION_UNAVAILABLE','error_type':type(exc).__name__}
  research_components={'schema':'porquinho.research-economic-components-a24/1.0','status':'RESEARCH_COMPONENT_INSPECTION_UNAVAILABLE','error_type':type(exc).__name__}
  global_lab={'schema':'porquinho.global-research-lab-a24/1.0','status':'GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE','error_type':type(exc).__name__}
 if economic_basis.get('status')=='LEARNED_ECONOMIC_BASIS_UNAVAILABLE':issues.append({'source':'learned_policy_economic_basis','error_type':economic_basis.get('reason','UnknownError')})
 if learned_scope.get('status')=='LEARNED_POLICY_ACCOUNT_SCOPE_UNAVAILABLE':issues.append({'source':'learned_policy_account_context','error_type':learned_scope.get('reason','UnknownError')})
 if learned_policy.get('status')=='LEARNED_POLICY_RESEARCH_UNAVAILABLE':issues.append({'source':'learned_allocation_policy','error_type':learned_policy.get('error_type','UnknownError')})
 if action_policy.get('status')!='ACTION_POLICY_GATES_ASSESSED_SHADOW_ONLY':issues.append({'source':'economic_action_policy','error_type':action_policy.get('reason','UnknownError')})
 if action_evidence.get('status')!='ACTION_EVIDENCE_ATTACHED_NOT_COMPARATOR_READY':issues.append({'source':'economic_action_evidence','error_type':action_evidence.get('reason','UnknownError')})
 if action_plan.get('status')!='ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY':issues.append({'source':'economic_action_plan','error_type':action_plan.get('reason','UnknownError')})
 from .observed_trade_costs_a24 import summary as observed_cost_summary
 observed_costs=observed_cost_summary(root,now=now)
 return {'learned_policy_economic_basis':economic_basis,'learned_policy_account_context':learned_scope,'learned_allocation_policy':learned_policy,'economic_action_policy':action_policy,'economic_action_evidence':action_evidence,'economic_action_plan':action_plan,'global_existing_lab':reused_lab,'global_model_evaluation':model_evaluation,'observed_manual_trade_costs':observed_costs,'account_cost_evidence':account_cost,'research_economic_components':research_components,'global_research_lab':global_lab,'global_history_source':global_history,'research_economic_series':research_economic_series,'schema':SCHEMA,'diagnostic_revision':'LEARNED_POLICY_ECONOMIC_BASIS_1','status':'PARTIAL_READ_ONLY_OBSERVATION' if issues else 'READ_ONLY_OBSERVATION','observed_at':now.isoformat(),
  'monitor':{'heartbeat':heartbeat,'heartbeat_recent':heartbeat['age_seconds'] is not None and heartbeat['age_seconds']<=1800,'state':health.get('state') if health.get('state') in ('WAITING_FOR_CURRENT_WORKER','WAITING_FOR_CADENCE','REFRESH_QUEUED','SCHEDULER_ERROR') else 'UNKNOWN','snapshot':snapshot_time},
  'brain':{'lab_result':model_time,'global_reader_contract_present':global_reader,'model_certified':False},
  'research_capture':{'day_utc':now.date().isoformat(),'binding_count':len(bindings) if registry_ok else None,'verified_records_today':len(observations) if journal_ok else None,'status':'PRESENT' if observations and journal_ok else 'NO_RECORDS_TODAY' if journal_ok else 'INSPECTION_UNAVAILABLE','sampling':'FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE'},
  'canonical':{'status':'UNAVAILABLE','reason':reason,'recommendation':None,'execution_authorized':False},'position_inspection_available':positions_ok,'position_record_count':len(positions) if positions_ok else None,'excluded_zero_position_count':len(positions)-len(rows) if positions_ok else None,'positions':rows,'position_research_counts':counts,'issues':issues,
  'financial_mutation':False,'history_write_performed':False,'execution_authorized':False,'canonical_publication_authorized':False}
