import copy
import json
import unittest
import test_a24_learned_policy_account_context as context
from universal_portfolio import learned_policy_economic_basis_a24 as p
from universal_portfolio.explicit_market_bindings_a24 import digest


class EconomicBasis(unittest.TestCase):
    def setUp(self):
        self.fixture = context.AccountPolicyContext(); self.fixture.setUp()

    def inputs(self, experiments=None):
        experiments = copy.deepcopy(experiments or [context.l.experiment()])
        for exp in experiments:
            for group in (exp['folds'], exp['forecasts']):
                for row in group:
                    row['quote_currency'] = 'BRL'
                    row['instrument_id'] = (context.a.I, context.a.J)[int(row['provider_id'][-1])]
        refs = {'fixture/' + e['algorithm'] + '.json': e for e in experiments}
        body = {'version': {'cohort': 'fixture', 'input_experiments': {path: digest(e) for path, e in refs.items()}},
                'computed_at': context.l.NOW.isoformat(), 'research': context.l.p.learn(experiments, now=context.l.NOW)}
        scope = context.p.project(self.fixture.action, self.fixture.funding, [body])
        return scope, [body], refs

    def project(self, experiments=None): return p.project(*self.inputs(experiments))

    def test_common_currency_capital_date_horizon(self):
        r = self.project(); row = r['rows'][0]
        self.assertEqual((row['currency'], row['reference_capital'], row['horizon_unit'], row['horizon_value']), ('BRL', '50', 'OBSERVATIONS', 30))
        self.assertEqual(row['forecast_origin'], '2026-10-16')

    def test_existing_common_unit_builder_used_without_invented_costs(self):
        row = self.project()['rows'][0]
        self.assertEqual(row['common_research_unit']['schema'], p.utility.SCHEMA)
        self.assertEqual(row['common_research_unit']['expected_return_pct'], '2')
        self.assertEqual(row['common_research_unit']['expected_gross_change'], '1')
        self.assertIsNone(row['common_research_unit']['expected_net_change'])
        self.assertIsNone(row['expected_net_change'])
        self.assertEqual(row['total_cost_status'], 'UNKNOWN')

    def test_observed_training_risk_not_forward_risk(self):
        row = self.project()['rows'][0]
        self.assertIsNotNone(row['training_observed_risk']['downside_rms_pp'])
        self.assertFalse(row['observed_risk_is_forward_risk'])
        self.assertIsNone(row['common_research_unit']['risk_measure'])

    def test_same_current_distribution_is_not_independent_votes(self):
        a = context.l.experiment(); b = context.l.experiment('SVR')
        r = self.project([a, b]); s = p.summarize(r)
        self.assertEqual(s['scenario_count'], 2)
        self.assertEqual(s['current_distribution_group_count'], 1)
        self.assertEqual(s['observed_behavior_group_count'], 1)
        self.assertFalse(s['observed_behavior_groups_are_independent_evidence'])
        self.assertEqual(s['discarded_candidate_count'], 0)

    def test_distribution_group_does_not_claim_identical_forecasts(self):
        a = context.l.experiment(); b = context.l.experiment('SVR')
        for row in b['forecasts']: row['value_pct'] *= 2
        r = self.project([a, b]); s = p.summarize(r)
        self.assertEqual(s['current_distribution_group_count'], 1)
        self.assertNotEqual(r['rows'][0]['common_research_unit']['expected_return_pct'], r['rows'][1]['common_research_unit']['expected_return_pct'])

    def test_different_evaluated_distributions_not_merged_by_current_weights(self):
        a = context.l.experiment(); b = context.l.experiment('SVR')
        for e in (a, b):
            for row in e['folds']: row['actual_pct'] = 0
        for row in b['folds']: row['prediction_pct'] = 1 if row['provider_id'] == 'source-0' else 2
        s = p.summarize(self.project([a, b]))
        self.assertGreater(s['observed_behavior_group_count'], s['current_distribution_group_count'])

    def test_cash_only_execution_na_does_not_make_total_cost_zero(self):
        a = context.l.experiment()
        for row in a['forecasts']: row['value_pct'] = -1
        row = self.project([a])['rows'][0]
        self.assertEqual(row['execution_transaction_cost_status'], 'NOT_APPLICABLE_NO_TRADE_LEGS')
        self.assertEqual(row['total_cost_status'], 'UNKNOWN')
        self.assertIsNone(row['expected_net_change'])
        self.assertIn('CASH_YIELD_MODEL_REQUIRED', row['comparability_gaps'])

    def test_zero_cash_component_does_not_require_cash_yield(self):
        row = self.project()['rows'][0]
        self.assertEqual(row['current_cash_fraction'], '0')
        self.assertNotIn('CASH_YIELD_MODEL_REQUIRED', row['comparability_gaps'])

    def test_reference_capital_separates_groups(self):
        scope, bodies, refs = self.inputs(); other = copy.deepcopy(scope['scenarios'][0]); other['budget_reference_capital'] = '25'
        scope['scenarios'].append(other)
        s = p.summarize(p.project(scope, bodies, refs))
        self.assertEqual(s['common_basis_group_count'], 2)

    def test_accounts_do_not_share_comparison_basis(self):
        scope, bodies, refs = self.inputs(); other = copy.deepcopy(scope['scenarios'][0]); other['account_id'] = 'other'
        scope['scenarios'].append(other)
        self.assertEqual(p.summarize(p.project(scope, bodies, refs))['common_basis_group_count'], 2)

    def test_plan_and_budget_do_not_share_comparison_basis(self):
        scope, bodies, refs = self.inputs(); other = copy.deepcopy(scope['scenarios'][0]); other['plan_id'] = 'other-plan'; other['budget_id'] = 'other-budget'
        scope['scenarios'].append(other)
        self.assertEqual(p.summarize(p.project(scope, bodies, refs))['common_basis_group_count'], 2)

    def test_wrong_currency_refused(self):
        scope, bodies, refs = self.inputs(); scope['scenarios'][0]['currency'] = 'EUR'
        with self.assertRaisesRegex(ValueError, 'COMMON_UNIT_MISMATCH'): p.project(scope, bodies, refs)

    def test_days_not_observations(self):
        scope, bodies, refs = self.inputs(); scope['scenarios'][0]['horizon_unit'] = 'DAYS'
        with self.assertRaisesRegex(ValueError, 'COMMON_UNIT_MISMATCH'): p.project(scope, bodies, refs)

    def test_exact_experiment_references_required(self):
        scope, bodies, refs = self.inputs(); refs['fixture/Ridge.json']['forecasts'][0]['value_pct'] += 1
        with self.assertRaisesRegex(ValueError, 'EXACT_POLICY_SOURCE'): p.project(scope, bodies, refs)

    def test_research_result_cannot_be_forged(self):
        scope, bodies, refs = self.inputs(); bodies[0]['research']['candidates'][0]['held_out']['mean_gross_return_pp'] += 1
        with self.assertRaisesRegex(ValueError, 'RECONSTRUCTION_MISMATCH'): p.project(scope, bodies, refs)

    def test_scoped_weights_cannot_be_renormalized(self):
        scope, bodies, refs = self.inputs(); scope['scenarios'][0]['legs'][0]['fraction_denominator'] = 2
        with self.assertRaisesRegex(ValueError, 'DISTRIBUTION_CHANGED'): p.project(scope, bodies, refs)

    def test_missing_source_or_candidate_no_fallback(self):
        scope, bodies, refs = self.inputs(); scope['scenarios'][0]['candidate_id'] = 'old'
        with self.assertRaisesRegex(ValueError, 'REFERENCE_NOT_RESOLVED'): p.project(scope, bodies, refs)

    def test_input_authority_leak_refused(self):
        scope, bodies, refs = self.inputs(); scope['comparison_authorized'] = True
        with self.assertRaisesRegex(ValueError, 'NONAUTHORIZING'): p.project(scope, bodies, refs)

    def test_blockers_not_removed_and_no_winner_rank_or_order(self):
        r = self.project(); row = r['rows'][0]
        self.assertIn('VALIDATED_SIZING_REQUIRED', row['comparability_gaps'])
        self.assertIn('CURRENT_PRETRADE_VENUE_AND_NOTIONAL_REQUIRED', row['comparability_gaps'])
        self.assertFalse(row['execution_venue_selected']); self.assertFalse(row['order_notional_created'])
        self.assertIsNone(row['utility_score']); self.assertFalse(r['ranking_created'])
        self.assertFalse(r['comparison_authorized']); self.assertFalse(r['canonical_publication_authorized'])

    def test_summary_has_no_accounts_values_or_forecasts(self):
        raw = json.dumps(p.summarize(self.project()))
        for key in ('account_id', 'reference_capital', 'expected_return_pct', 'expected_gross_change', 'candidate_id', 'instrument_id'):
            self.assertNotIn('"' + key + '"', raw)

    def test_pure_calculation_preserves_inputs(self):
        inputs = self.inputs(); before = copy.deepcopy(inputs)
        p.project(*inputs)
        self.assertEqual(before, inputs)
