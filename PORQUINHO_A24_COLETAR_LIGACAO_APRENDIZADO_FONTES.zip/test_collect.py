import importlib.util
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('collector', Path(__file__).with_name('collect.py'))
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


class Collect(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name).resolve(); self.root = self.base / 'project'
        (self.root / 'webapp').mkdir(parents=True)
        (self.root / 'webapp/server.py').write_text('raise RuntimeError("MUST_NOT_EXECUTE")\n')

    def put(self, rel, raw):
        p = self.root / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(raw)
        return p

    def test_collects_only_code_never_executes_it(self):
        self.put('brain/memory/store.py', 'class MemoryStore: pass\n')
        self.put('data/memory.sqlite', 'PRIVATE MEMORY CONTENT')
        self.put('results/model_params.json', '{"private_weights":123}')
        self.put('brain/config.json', '{"secret":"PRIVATE CONFIG"}')
        path, report = m.collect(self.root, self.base)
        with zipfile.ZipFile(path) as z:
            self.assertIn('project/brain/memory/store.py', z.namelist())
            self.assertFalse(any(n.startswith('project/data/') or n.startswith('project/results/') or n.endswith('config.json') for n in z.namelist()))
            self.assertNotIn('PRIVATE MEMORY CONTENT', ''.join(z.read(n).decode() for n in z.namelist()))
        self.assertFalse(report['application_modules_imported'])
        self.assertFalse(report['learning_functionality_proven'])

    def test_preserves_all_sources_and_state_across_repeat(self):
        self.put('data/history.json', '{"old":"unchanged"}')
        before = {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        a, _ = m.collect(self.root, self.base); b, _ = m.collect(self.root, self.base)
        self.assertNotEqual(a, b)
        self.assertEqual(before, {str(p.relative_to(self.root)): p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
        self.assertEqual(a.stat().st_mode & 0o777, 0o600)

    def test_missing_memory_is_reported_not_inferred_as_broken_runtime(self):
        _, report = m.collect(self.root, self.base)
        self.assertEqual(report['sources']['brain/memory/store.py']['status'], 'MISSING_IN_SELECTED_PROJECT')
        self.assertFalse(report['learning_functionality_proven'])

    def test_symlink_source_refused(self):
        external = self.base / 'private.py'; external.write_text('private = 1\n')
        target = self.root / 'brain/memory/store.py'; target.parent.mkdir(parents=True); target.symlink_to(external)
        path, r = m.collect(self.root, self.base)
        self.assertEqual(r['sources']['brain/memory/store.py']['status'], 'NOT_EXPORTED')
        with zipfile.ZipFile(path) as z: self.assertNotIn('project/brain/memory/store.py', z.namelist())

    def test_size_and_invalid_syntax_fail_closed(self):
        self.put('brain/memory/store.py', 'not valid python !!!!')
        _, r = m.collect(self.root, self.base)
        self.assertEqual(r['sources']['brain/memory/store.py']['reason'], 'SyntaxError')
        with patch.object(m, 'MAX_FILE', 2):
            _, r = m.collect(self.root, self.base)
            self.assertEqual(r['sources']['webapp/server.py']['status'], 'NOT_EXPORTED')

    def test_literal_credentials_skip_source_file(self):
        for raw in ('API_KEY = "PRIVATE_SECRET"', 'credentials = {"access_token": "PRIVATE_SECRET"}'):
            self.put('brain/research/engine.py', raw)
            path, r = m.collect(self.root, self.base)
            self.assertEqual(r['sources']['brain/research/engine.py']['status'], 'NOT_EXPORTED')
            with zipfile.ZipFile(path) as z: self.assertNotIn('project/brain/research/engine.py', z.namelist())

    def test_static_call_counts_not_runtime_claim(self):
        self.put('brain/evolution/learning_cycle.py', 'def f():\n mem = MemoryStore()\n mem.event("snapshot", {})\n')
        _, r = m.collect(self.root, self.base)
        self.assertEqual(r['sources']['brain/evolution/learning_cycle.py']['recognized_static_call_counts'], {'MemoryStore': 1, 'event': 1})
        self.assertFalse(r['execution_authorized'])

    def test_output_inside_project_refused(self):
        with self.assertRaises(m.CollectError): m.collect(self.root, self.root)
        self.assertFalse(list(self.root.glob('*.zip')))


if __name__ == '__main__': unittest.main()
