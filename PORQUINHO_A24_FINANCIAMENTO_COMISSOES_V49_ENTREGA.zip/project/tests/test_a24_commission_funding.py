import json,tempfile
from pathlib import Path
from universal_portfolio import research_tariff_context_a24 as tariffs
import copy,unittest
from decimal import Decimal as D
from universal_portfolio.commission_funding_a24 import assess,financed_buy,commission
from universal_portfolio.account_cost_evidence_a24 import CostError

def variant(rate='2.5', **kw):
 return {'label':'Documented category','conditional_category':False,'bands':[{'from':'0','until':None,'rate_pct':rate,**kw}]}
def row(cap='100',sell=None,buy=None):
 legs=[]
 for side,iid,v in [('SELL','origin',sell or variant()),('BUY','destination',buy or variant())]:
  legs.append({'side':side,'account_id':'account','instrument_id':iid,'currency':'ABC','reference_variants':[v],'policy_id':'public','source_document_sha256':'a'*64,'unresolved_components':['spread','taxes']})
 return {'account_id':'account','reference_capital':cap,'currency':'ABC','source_instrument_id':'origin','destination_instrument_id':'destination','documented_tariff_provisions':{'legs':legs},'models':[{'algorithm':'model','cohort_digest':'b'*64,'source_return_pct':'-3','destination_return_pct':'5'}]}
class Funding(unittest.TestCase):
 def scenarios(self,r=None,precision=2,**kw):return assess(r or row(),precision,**kw)['scenarios']
 def test_percentage_funding(self):
  x=self.scenarios(row(sell=variant('2'),buy=variant('3')))[0]
  self.assertEqual(D(x['destination_reference_amount']),D('95.14'));self.assertEqual(D(x['cash_remainder']),D('.0058'))
 def test_explicit_round_up(self):
  v=variant(rounding_quantum='.01',rounding_mode='CEILING',rounding_stage='AFTER_CLAMP');x=self.scenarios(row(sell=v,buy=v))[0]
  self.assertEqual(D(x['sell_commission']),D('2.50'));self.assertEqual(D(x['buy_commission']),D('2.38'));self.assertEqual(D(x['destination_reference_amount']),D('95.12'))
 def test_partial_preserves_unsold(self):
  xs=self.scenarios(row('200'),notionals=['100']);x=next(x for x in xs if D(x['source_sale_reference_amount'])==100)
  self.assertEqual(D(x['remaining_source_reference_capital']),100)
 def test_budget_identity(self):
  for x in self.scenarios(row('123.4567')):
   self.assertEqual(sum(D(x[k]) for k in ['destination_reference_amount','buy_commission','sell_commission','cash_remainder']),D(x['source_sale_reference_amount']))
   self.assertGreaterEqual(D(x['cash_remainder']),0)
 def test_fractional_cap_preserved(self):self.assertEqual(D(self.scenarios(row('100.009'))[0]['remaining_source_reference_capital']),D('.009'))
 def test_no_precision_guess(self):self.assertEqual(assess(row(),None)['status'],'EXPLICIT_CURRENCY_PRECISION_REQUIRED')
 def test_boolean_precision_refused(self):self.assertFalse(self.scenarios(precision=True))
 def test_integer_precision(self):self.assertEqual(D(self.scenarios(precision=0)[0]['destination_reference_amount'])%1,0)
 def test_three_decimal_precision(self):self.assertEqual(D(self.scenarios(precision=3)[0]['currency_quantum']),D('.001'))
 def test_large_value_precision(self):self.assertTrue(self.scenarios(row('1000000000000000000000000000000'),18))
 def test_nonmonotonic_boundary(self):
  v=variant();v['bands']=[{'from':'0','until':'100','rate_pct':'0','fixed_amount':'100'},{'from':'100','until':None,'rate_pct':'0'}]
  self.assertEqual(financed_buy(D('150'),v,D('.01')),(D('150'),D('0')))
 def test_minimum_fee(self):self.assertEqual(financed_buy(D('10'),variant('1',minimum_amount='2'),D('.01')),(D('8'),D('2')))
 def test_explicit_gap_not_filled(self):
  v=variant('0');v['bands']=[{'from':'0','until':'200','rate_pct':'0'},{'from':'200','from_exclusive':True,'until':None,'rate_pct':'0'}]
  self.assertIsNone(commission(v,D('200')));self.assertEqual(financed_buy(D('200'),v,D('.01'))[0],D('199.99'))
 def test_sale_cost_exhausts_budget(self):self.assertFalse(self.scenarios(row(sell=variant('100'))))
 def test_no_affordable_purchase(self):self.assertFalse(self.scenarios(row(buy=variant('0',fixed_amount='1000'))))
 def test_mismatching_account(self):
  r=row();r['documented_tariff_provisions']['legs'][0]['account_id']='other';self.assertFalse(self.scenarios(r))
 def test_mismatching_currency(self):
  r=row();r['documented_tariff_provisions']['legs'][1]['currency']='OTHER';self.assertFalse(self.scenarios(r))
 def test_mismatching_identity(self):
  r=row();r['documented_tariff_provisions']['legs'][0]['instrument_id']='different';self.assertFalse(self.scenarios(r))
 def test_categories_not_selected(self):
  r=row();v=variant('3.5');v['conditional_category']=True;r['documented_tariff_provisions']['legs'][0]['reference_variants'].append(v)
  xs=self.scenarios(r);self.assertEqual(len(xs),2);self.assertTrue(any(x['conditional_category'] for x in xs));self.assertTrue(all(x['selected'] is False for x in xs))
 def test_model_delta_accounts_for_cash(self):
  x=self.scenarios()[0];expected=D(x['destination_reference_amount'])*D('1.05')+D(x['cash_remainder'])-D(x['source_sale_reference_amount'])*D('.97')
  self.assertEqual(D(x['models'][0]['commission_adjusted_uplift_amount']),expected)
 def test_model_advantage_can_be_erased(self):
  r=row(sell=variant('10'),buy=variant('10'));self.assertFalse(self.scenarios(r)[0]['positive_for_all_available_estimators'])
 def test_inputs_unchanged_and_costs_unknown(self):
  r=row();old=copy.deepcopy(r);x=self.scenarios(r)[0];self.assertEqual(r,old);self.assertIsNone(x['total_cost']);self.assertFalse(x['execution_authorized']);self.assertEqual(x['unresolved_components'],['spread','taxes'])
 def test_invalid_notional_refused(self):
  for value in ['101','1.001']:
   with self.assertRaises(CostError):self.scenarios(notionals=[value])
 def test_overlapping_bands_refused(self):
  v=variant();v['bands'].append({'from':'1','until':None,'rate_pct':'1'})
  with self.assertRaises(CostError):financed_buy(D('10'),v,D('.01'))
 def test_nonfinite_model_refused(self):
  r=row();r['models'][0]['destination_return_pct']='NaN'
  with self.assertRaises(CostError):self.scenarios(r)


class Integration(unittest.TestCase):
 def setup_root(self,root,precision=2):
  import test_a24_research_tariff_context as f
  helper=f.TariffContext();helper.setUp();result=helper.build_fixture(root)
  doc={'schema':'porquinho.currency-registry/1.0','currencies':[{'currency_code':'EUR','active':True,'precision':precision}]}
  (Path(root)/'data/currency_registry.json').write_text(json.dumps(doc))
  return helper,result
 def test_real_projection_and_files_preserved(self):
  with tempfile.TemporaryDirectory() as root:
   helper,result=self.setup_root(root);before={p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()};out=tariffs.build(root,result,now=helper.now)
   self.assertGreater(out['commission_funded_hypothesis_count'],0);self.assertTrue(all(p.read_bytes()==v for p,v in before.items()));self.assertNotIn('commission_funding',result['rows'][0])
 def test_precision_not_invented_for_missing_registry(self):
  with tempfile.TemporaryDirectory() as root:
   helper,result=self.setup_root(root);(Path(root)/'data/currency_registry.json').unlink();out=tariffs.build(root,result,now=helper.now)
   self.assertEqual(out['commission_funded_hypothesis_count'],0);self.assertEqual(out['commission_funding_status_counts'],{'EXPLICIT_CURRENCY_PRECISION_REQUIRED':1})
 def test_currency_change_during_read_keeps_prior_readings(self):
  from unittest.mock import patch
  with tempfile.TemporaryDirectory() as root:
   helper,result=self.setup_root(root);real=tariffs.read;n=0
   def read(r,rel):
    nonlocal n
    obj,raw=real(r,rel)
    if rel=='data/currency_registry.json':
     n+=1
     if n>1:raw+=b' '
    return obj,raw
   with patch.object(tariffs,'read',side_effect=read):out=tariffs.build(root,result,now=helper.now)
   self.assertEqual(out['rows'],result['rows']);self.assertEqual(out['documented_tariff_catalog_status'],'TARIFF_PROVISIONS_UNAVAILABLE')
 def test_private_money_not_exported_in_audit(self):
  from tools.reallocation_source_audit_v43 import project
  p=row();p['commission_funding']={'status':'COMMISSION_ONLY_SELF_FUNDED_HYPOTHESES','scenarios':[{'cash_remainder':'PRIVATE_MONEY'}]};p['models'][0]['private']='PRIVATE_MODEL'
  out=project({'reallocation_analysis':{'rows':[p]}},{})
  self.assertNotIn('PRIVATE',json.dumps(out));self.assertEqual(out['pairs'][0]['commission_funded_hypothesis_count'],1)

if __name__=='__main__':unittest.main()
