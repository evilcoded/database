"""Documented commission references, isolated from complete executable cost quotes.
No bank, currency, asset, rate, or tariff branch is embedded in the engine.
"""
import copy
import json
from collections import Counter
from decimal import Decimal
from pathlib import Path
from .account_cost_evidence_a24 import COMPONENTS, CostError, accounts, number, timestamp
from .explicit_market_bindings_a24 import local, digest
from .official_tariff_provision_a24 import provision, SCHEMA as TARIFF_SCHEMA
CATALOG='config/research_tariff_sources_a24.json'
SCHEMA='porquinho.research-tariff-catalog-a24/1.0'

def leg(policies, account, iid, currency, asset_class, identities, principal, side, *, now):
    principal=number(principal,True)
    base={'status':'DOCUMENTED_TARIFF_SOURCE_REQUIRED','side':side,'reference_amount':str(principal),
          'instrument_id':iid,'account_id':account.get('account_id'),'currency':currency,'estimates':[],'total_cost':None,
          'execution_quote':False,'selected':False,'independent_attestation':False}
    if not identities or len(identities)!=1:
        return {**base,'status':'EXACT_PROVIDER_IDENTITY_REQUIRED'}
    if account.get('currency')!=currency:return {**base,'status':'ACCOUNT_CURRENCY_MISMATCH'}
    matched=[];expired=False
    for policy in policies:
        scope=policy['scope'];source=policy['source']
        if (scope['institution_name'].strip().casefold(),scope['registry_country'],scope['pricing_plan'].strip().casefold(),scope['currency'],scope['asset_class']) != (account.get('_institution_name','').strip().casefold(),account.get('_institution_country'),(account.get('pricing_plan') or '').strip().casefold(),currency,asset_class):continue
        if timestamp(source['observed_at'])>now or not timestamp(source['observed_at'])<timestamp(source['review_until']):raise CostError('TARIFF_SOURCE_REVIEW_WINDOW_INVALID')
        if now>=timestamp(source['review_until']):expired=True;continue
        matched.append(policy)
    if not matched:return {**base,'status':'TARIFF_SOURCE_RECHECK_REQUIRED' if expired else base['status']}
    if len(matched)!=1:return {**base,'status':'AMBIGUOUS_TARIFF_POLICY_REVIEW_REQUIRED'}
    policy=matched[0];source=policy['source'];provider,provider_id=next(iter(identities));estimates=[];reference_variants=[]
    for variant in policy['variants']:
        if variant['provider']!=provider or provider_id not in variant['provider_ids']:continue
        reference_variants.append({k:copy.deepcopy(variant[k]) for k in ('label','conditional_category','bands')})
        bands=[b for b in variant['bands'] if (principal>number(b['from']) if b.get('from_exclusive') else principal>=number(b['from'])) and (b.get('until') is None or principal<number(b['until']))]
        if len(bands)>1:raise CostError('AMBIGUOUS_TARIFF_BAND')
        if not bands:continue
        band=bands[0]
        query={k:account[k] for k in ('account_id','institution_id','pricing_plan')}
        query.update(institution_country=account['_institution_country'],instrument_id=iid,currency=currency,execution_venue_id='DOCUMENTED_REFERENCE_NOT_VERIFIED_EXECUTION_VENUE',side=side,reference_amount=str(principal),product=policy['scope']['asset_class'],channel='DOCUMENTED_REFERENCE')
        components={k:{'status':'UNKNOWN','currency':currency} for k in COMPONENTS}
        rule={'status':'KNOWN','currency':currency,'evidence_ref':source['url'],'formula':'FIXED_PLUS_PERCENT_THEN_CLAMP','fixed_amount':'0','rate_pct':band['rate_pct'],'minimum_amount':band.get('minimum_amount'),'maximum_amount':band.get('maximum_amount')}
        for key in ('rounding_quantum','rounding_mode','rounding_stage'):
            if key in band:rule[key]=band[key]
        components['brokerage']=rule
        contract={**query,'schema':TARIFF_SCHEMA,'applicability_confirmed':True,
                  'effective_from':source['observed_at'],'effective_until':source['review_until'],
                  'source':{**source,'kind':'OFFICIAL_BANK_TARIFF','official_source_verified':True},'components':components}
        # Applicability here is explicitly the conditional documentary scenario above,
        # never verified applicability of the source to a broker order or legal entity.
        calculated=provision(contract,query,now=now)
        estimates.append({'label':variant['label'],'commission_reference_amount':calculated['known_cost_subtotal'],
                          'conditional_category':variant['conditional_category'],'rate_pct':band['rate_pct'],
                          'minimum_amount':band.get('minimum_amount'),'rounding_rule':calculated['components']['brokerage'].get('rounding_rule')})
    return {**base,'status':'DOCUMENTED_COMMISSION_REFERENCE_PARTIAL' if estimates else 'ASSET_OR_TARIFF_BRACKET_REVIEW_REQUIRED',
            'policy_id':policy['policy_id'],'source_url':source['url'],'source_document_sha256':source['document_sha256'],
            'source_observed_at':source['observed_at'],'source_review_until':source['review_until'],
            'source_jurisdiction':policy['scope']['source_jurisdiction'],'pricing_plan':account['pricing_plan'],
            'applicability':'DECLARED_INSTITUTION_PLAN_MATCH_DOCUMENTARY_SCENARIO_ONLY',
            'unresolved_components':sorted(set(policy['unresolved_components']) | (set(COMPONENTS)-{'brokerage'})),'notice':policy['notice'],'estimates':estimates,'reference_variants':reference_variants}

def attach(result, policies, registered, classes, *, now, precisions=None):
    for row in result.get('rows',[]):
        cap=row.get('reference_capital');account=registered.get(row['account_id'])
        if cap is None or account is None or number(cap)<=0:
            row['documented_tariff_provisions']={'status':'POSITION_REFERENCE_AND_ACCOUNT_REQUIRED','legs':[],'total_cost':None};continue
        legs=[]
        for side,iid,research,prefix in [('SELL',row['source_instrument_id'],row['source_research_instrument_id'],'source'),('BUY',row['destination_instrument_id'],row['destination_research_instrument_id'],'destination')]:
            identities={(m[prefix+'_provider'],m[prefix+'_provider_id']) for m in row['models']}
            legs.append(leg(policies,account,iid,row['currency'],classes.get(research),identities,number(cap),side,now=now))
        row['documented_tariff_provisions']={'status':'DOCUMENTARY_REFERENCES_NOT_FUNDED_TRADE','legs':legs,
            'basis':'SAME_REFERENCE_NOTIONAL_PER_LEG_NOT_SELF_FINANCED_ORDER',
            'total_cost':None,'selected_amount':None,'cost_evidence_promoted':False,'execution_authorized':False}
        from .commission_funding_a24 import assess
        try:
            row['commission_funding']=assess(row,(precisions or {}).get(row['currency']),notionals=[c['source_sale_reference_amount'] for c in row.get('reviewed_two_leg_cost_scenarios',[])])
        except Exception as exc:
            row['commission_funding']={'status':'COMMISSION_FUNDING_UNAVAILABLE','scenarios':[],'error_type':type(exc).__name__,'selected_amount':None,'total_cost':None,'execution_authorized':False}
    result['documented_tariff_leg_status_counts']=dict(Counter(leg['status'] for r in result.get('rows',[]) for leg in r.get('documented_tariff_provisions',{}).get('legs',[])))
    result['commission_funding_status_counts']=dict(Counter(r.get('commission_funding',{}).get('status','POSITION_REFERENCE_AND_ACCOUNT_REQUIRED') for r in result.get('rows',[])))
    result['commission_funded_hypothesis_count']=sum(len(r.get('commission_funding',{}).get('scenarios',[])) for r in result.get('rows',[]))
    return result

def read(root, rel):
    p=local(root,rel)
    if not p.exists():return None,None
    if p.stat().st_size>4*1024*1024:raise CostError('TARIFF_CONTEXT_READ_LIMIT')
    raw=p.read_bytes();return json.loads(raw),raw

def build(root, result, *, now):
    """A failed tariff source cannot hide current research readings or cost quotes."""
    try:
        document,raw=read(root,CATALOG)
        if document is None:return {**result,'documented_tariff_catalog_status':'CATALOG_NOT_CONFIGURED'}
        if document.get('schema')!=SCHEMA or not isinstance(document.get('policies'),list) or len(document['policies'])>256:raise CostError('TARIFF_CATALOG_SCHEMA_REQUIRED')
        if len({p['policy_id'] for p in document['policies']})!=len(document['policies']):raise CostError('UNIQUE_TARIFF_POLICY_REQUIRED')
        registered,version=accounts(root);classes={};sources={}
        for rel in ('data/universal_instrument_catalog.json','data/instruments/manual_instruments.json'):
            body,content=read(root,rel);sources[rel]=content
            for r in (body or {}).get('instruments',[]):
                if not isinstance(r,dict) or not isinstance(r.get('instrument_id'),str) or not isinstance(r.get('asset_class'),str):continue
                if r['instrument_id'] in classes and classes[r['instrument_id']]!=r['asset_class']:raise CostError('CONFLICTING_ASSET_CLASS')
                classes[r['instrument_id']]=r['asset_class']
        currency_document,currency_raw=read(root,'data/currency_registry.json');sources['data/currency_registry.json']=currency_raw
        precisions={}
        if currency_document and currency_document.get('schema')=='porquinho.currency-registry/1.0':
            entries=currency_document.get('currencies',[])
            counts=Counter(c.get('currency_code') for c in entries if isinstance(c,dict))
            precisions={c['currency_code']:c['precision'] for c in entries if isinstance(c,dict) and counts[c.get('currency_code')]==1 and c.get('active') is True and type(c.get('precision')) is int and 0<=c['precision']<=18}
        projected=attach(copy.deepcopy(result),document['policies'],registered,classes,now=now,precisions=precisions)
        if read(root,CATALOG)[1]!=raw or accounts(root)[1]!=version or any(read(root,r)[1]!=v for r,v in sources.items()):raise CostError('TARIFF_CONTEXT_CHANGED_DURING_READ')
        projected['documented_tariff_catalog_status']='DOCUMENTED_SOURCES_PROJECTED_NOT_COST_QUOTES';projected['documented_tariff_catalog_digest']=digest(document)
        return projected
    except Exception as exc:
        return {**result,'documented_tariff_catalog_status':'TARIFF_PROVISIONS_UNAVAILABLE','documented_tariff_error_type':type(exc).__name__}
