"""Self-funding *commission-only hypotheses*, never executable net sizing.
Searches each documented band independently; no bank/currency/rate branches.
"""
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
from .account_cost_evidence_a24 import number, CostError
from .official_tariff_provision_a24 import component_amount

def return_number(value):
    result=Decimal(str(value))
    if not result.is_finite() or abs(result)>Decimal('1e30'):raise CostError('FINITE_RETURN_REQUIRED')
    return result

def rule(band):
    result={'formula':'FIXED_PLUS_PERCENT_THEN_CLAMP','fixed_amount':band.get('fixed_amount','0'),
            'rate_pct':band['rate_pct'],'minimum_amount':band.get('minimum_amount'),'maximum_amount':band.get('maximum_amount')}
    for key in ('rounding_quantum','rounding_mode','rounding_stage'):
        if key in band:result[key]=band[key]
    return result

def bands(variant):
    rows=variant['bands']
    if not isinstance(rows,list) or not 1<=len(rows)<=64:raise CostError('BOUNDED_DOCUMENTED_BANDS_REQUIRED')
    ordered=sorted(rows,key=lambda b:number(b['from']));previous=None
    for b in ordered:
        low=number(b['from']);high=number(b['until']) if b.get('until') is not None else None
        if high is not None and high<=low:raise CostError('VALID_TARIFF_INTERVAL_REQUIRED')
        if previous is not None and (previous.get('until') is None or number(previous['until'])>low):raise CostError('OVERLAPPING_TARIFF_BANDS_REFUSED')
        component_amount(rule(b),Decimal('1')) # Validate even bands outside the budget.
        previous=b
    return ordered

def commission(variant, principal):
    selected=[b for b in bands(variant) if (principal>number(b['from']) if b.get('from_exclusive') else principal>=number(b['from'])) and (b.get('until') is None or principal<number(b['until']))]
    return component_amount(rule(selected[0]),principal) if len(selected)==1 else None

def financed_buy(budget, variant, quantum):
    with localcontext() as ctx:
        ctx.prec=200
        return _financed_buy(number(budget,True),variant,number(quantum,True))

def _financed_buy(budget, variant, quantum):
    """Largest supported quantum amount. Fee may jump at band boundaries.
    Every band is searched independently, so no global monotonicity is assumed.
    """
    best=None
    for band in bands(variant):
        low=int((number(band['from'])/quantum).to_integral_value(rounding=ROUND_CEILING))
        if band.get('from_exclusive') and Decimal(low)*quantum==number(band['from']):low+=1
        low=max(1,low);high=int((budget/quantum).to_integral_value(rounding=ROUND_FLOOR))
        if band.get('until') is not None:high=min(high,int((number(band['until'])/quantum).to_integral_value(rounding=ROUND_CEILING))-1)
        answer=None
        while low<=high:
            mid=(low+high)//2;principal=Decimal(mid)*quantum;fee=component_amount(rule(band),principal)
            if principal+fee<=budget:answer=(principal,fee);low=mid+1
            else:high=mid-1
        if answer and (best is None or answer[0]>best[0]):best=answer
    return best

def assess(row, precision, *, notionals=()):
    with localcontext() as ctx:
        ctx.prec=200
        return _assess(row,precision,notionals=notionals)

def _assess(row, precision, *, notionals=()):
    base={'status':'EXPLICIT_CURRENCY_PRECISION_REQUIRED','scenarios':[], 'selected_amount':None,
          'total_cost':None,'execution_authorized':False,'cost_evidence_promoted':False}
    if type(precision) is not int or not 0<=precision<=18:return base
    cap=number(row['reference_capital'],True);quantum=Decimal(1).scaleb(-precision)
    legs=row.get('documented_tariff_provisions',{}).get('legs',[])
    sell=[l for l in legs if l.get('side')=='SELL'];buy=[l for l in legs if l.get('side')=='BUY']
    if len(sell)!=1 or len(buy)!=1:return {**base,'status':'BOTH_DOCUMENTED_TARIFF_LEGS_REQUIRED'}
    sell,buy=sell[0],buy[0]
    if not row.get('account_id') or any(l.get('account_id')!=row['account_id'] for l in (sell,buy)):return {**base,'status':'EXACT_ACCOUNT_REQUIRED'}
    if any(l.get('currency')!=row['currency'] for l in (sell,buy)):return {**base,'status':'SAME_CURRENCY_REQUIRED'}
    if sell.get('instrument_id')!=row['source_instrument_id'] or buy.get('instrument_id')!=row['destination_instrument_id']:return {**base,'status':'EXACT_FINANCIAL_IDENTITIES_REQUIRED'}
    sv,bv=sell.get('reference_variants',[]),buy.get('reference_variants',[])
    if not sv or not bv:return {**base,'status':'BOTH_DOCUMENTED_TARIFF_LEGS_REQUIRED'}
    if len(sv)>16 or len(bv)>16 or len(sv)*len(bv)>128:raise CostError('COMMISSION_SCENARIO_LIMIT')
    source={cap//quantum*quantum}
    for value in notionals:
        amount=number(value,True)
        if amount>cap or amount%quantum:raise CostError('SUPPORTED_SOURCE_NOTIONAL_WITHIN_POSITION_REQUIRED')
        source.add(amount)
    if len(source)>16:raise CostError('SOURCE_SCENARIO_LIMIT')
    result=[]
    with localcontext() as ctx:
        ctx.prec=200
        for sold in sorted(source):
            if sold<=0:continue
            for s in sv:
                sc=commission(s,sold)
                if sc is None or sc>=sold:continue
                budget=sold-sc
                for b in bv:
                    financed=financed_buy(budget,b,quantum)
                    if not financed:continue
                    principal,bc=financed;cash=budget-principal-bc
                    if cash<0 or principal+bc+sc+cash!=sold:raise CostError('COMMISSION_FUNDING_IDENTITY_FAILED')
                    if len(result)>=128:raise CostError('COMMISSION_SCENARIO_LIMIT')
                    models=[]
                    for model in row.get('models',[]):
                        # Kept source cancels on both sides. Residual cash at nominal value;
                        # no forward cash yield, interest, or missing cost is certified.
                        delta=principal*(1+return_number(model['destination_return_pct'])/100)+cash-sold*(1+return_number(model['source_return_pct'])/100)
                        models.append({'algorithm':model['algorithm'],'cohort_digest':model['cohort_digest'],'commission_adjusted_uplift_amount':str(delta)})
                    result.append({'source_sale_reference_amount':str(sold),'sell_commission':str(sc),
                        'destination_reference_amount':str(principal),'buy_commission':str(bc),
                        'cash_remainder':str(cash),'remaining_source_reference_capital':str(cap-sold),
                        'documented_commission_subtotal':str(sc+bc),'currency_quantum':str(quantum),
                        'quantum_semantics':'CONFIGURED_CURRENCY_REFERENCE_PRECISION_NOT_BROKER_LOT',
                        'sell_category':s['label'],'buy_category':b['label'],
                        'conditional_category':s['conditional_category'] or b['conditional_category'],
                        'sell_policy_id':sell['policy_id'],'buy_policy_id':buy['policy_id'],
                        'sell_source_sha256':sell['source_document_sha256'],'buy_source_sha256':buy['source_document_sha256'],
                        'unresolved_components':sorted(set(sell['unresolved_components'])|set(buy['unresolved_components'])),
                        'models':models,'positive_for_all_available_estimators':bool(models) and all(Decimal(m['commission_adjusted_uplift_amount'])>0 for m in models),
                        'self_funded_under_documented_commissions_only':True,'other_cash_requested_under_this_hypothesis':'0',
                        'cash_remainder_valued_at_nominal':True,'total_cost':None,'selected':False,
                        'execution_authorized':False,'lot_constraints_verified':False})
    return {**base,'status':'COMMISSION_ONLY_SELF_FUNDED_HYPOTHESES' if result else 'NO_SUPPORTED_COMMISSION_FUNDED_HYPOTHESIS',
            'scenarios':result,'source_reference_capital':str(cap),'currency_quantum':str(quantum)}
