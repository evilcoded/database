"""Stored snapshots may contain large research payloads; no invented P/L."""
import datetime as dt
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import cockpit_intraday_a24 as intraday
from universal_portfolio import experience_panels_a24 as panels

NOW=dt.datetime(2026,10,21,12,11,tzinfo=dt.timezone.utc)
class LargeSnapshotPL(unittest.TestCase):
 def make(self,root,minutes=10,size=2*1024*1024+100):
  folder=root/'snapshots';folder.mkdir()
  paths=[]
  for index,(stamp,pnl) in enumerate([(NOW-dt.timedelta(minutes=minutes+1),'10'),(NOW-dt.timedelta(minutes=1),'13')]):
   body=dict(timestamp=stamp.isoformat(),currency='ABC',total_wealth='120',cash='20',portfolio_value='100',total_pnl=pnl,research_payload='x'*size)
   p=folder/f'snapshot_20261021_12000{index}.json';p.write_text(json.dumps(body));paths.append(p)
  return paths
 def test_large_recent_snapshots_produce_real_ten_minute_difference(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);ps=self.make(root);before=[p.read_bytes() for p in ps]
   result=intraday.snapshot_pnl(root,NOW);self.assertEqual(result['series'][0]['change_10m'],'3');self.assertEqual(result['series'][0]['quote_currency'],'ABC')
   self.assertEqual(before,[p.read_bytes() for p in ps]);self.assertFalse(result['history_write_performed'])
 def test_large_daily_wealth_snapshot_is_read_without_reconstruction(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root)
   result=panels.history(root,NOW);self.assertEqual(result['series'][0]['points'][0]['value'],'120');self.assertFalse(result['backfill_performed'])
 def test_large_but_nonmatching_interval_is_not_ten_minutes(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,minutes=30)
   self.assertIsNone(intraday.snapshot_pnl(root,NOW)['series'][0]['change_10m'])
 def test_stale_large_snapshots_do_not_create_live_difference(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root)
   self.assertIsNone(intraday.snapshot_pnl(root,NOW+dt.timedelta(hours=1))['series'][0]['change_10m'])
 def test_per_file_limit_remains_bounded_and_observable(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,size=panels.SNAPSHOT_MAX_BYTES+1)
   result=intraday.snapshot_pnl(root,NOW);self.assertEqual(result['series'],[]);self.assertEqual(result['skipped_reason_counts']['PER_FILE_READ_LIMIT'],2)
   self.assertEqual(panels.history(root,NOW)['series'],[])
 def test_total_budget_stops_reader_without_fabricating_values(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);self.make(root,size=200)
   with patch.object(panels,'SNAPSHOT_TOTAL_BYTES',1):
    result=intraday.snapshot_pnl(root,NOW);self.assertEqual(result['series'],[]);self.assertEqual(result['skipped_reason_counts']['TOTAL_READ_LIMIT'],1)
    self.assertEqual(panels.history(root,NOW)['series'],[])
