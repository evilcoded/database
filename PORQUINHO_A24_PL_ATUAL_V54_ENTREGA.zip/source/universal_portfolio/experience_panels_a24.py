"""Existing UI sources only: snapshots, objectives, horizons and verified transactions.
Does not reconstruct past holdings from today's quantities or mutate any source.
"""
import datetime as dt,json,hashlib,math
from decimal import Decimal
from .explicit_market_bindings_a24 import local
SCHEMA='porquinho.experience-panels-a24/1.0'
SNAPSHOT_MAX_BYTES=8*1024*1024
SNAPSHOT_TOTAL_BYTES=64*1024*1024
def stamp(v):
 try:
  t=dt.datetime.fromisoformat(v.replace('Z','+00:00'))
  return t.astimezone(dt.timezone.utc) if t.tzinfo else None
 except (ValueError,TypeError,AttributeError):return None
def number(v):
 try:
  if isinstance(v,bool) or v in (None,''):return None
  d=Decimal(str(v));return d if d.is_finite() and math.isfinite(float(d)) else None
 except Exception:return None
def read(root,rel,default,limit=8*1024*1024):
 p=local(root,rel)
 if not p.exists():return default
 if p.stat().st_size>limit:raise ValueError('READ_LIMIT')
 raw=p.read_bytes();data=json.loads(raw)
 if raw!=p.read_bytes():raise ValueError('SOURCE_CHANGED')
 return data

def snapshot_point(raw,*,now):
 t=stamp(raw.get('timestamp'));scope=None
 if not t or t>now:return None
 q=raw.get('currency');v=number(raw.get('total_wealth'));cash=number(raw.get('cash'));invested=number(raw.get('portfolio_value'))
 if isinstance(q,str) and q and q.isalpha() and q.isupper() and all(x is not None for x in (v,cash,invested)):
  scope='EXPLICIT_SNAPSHOT_CURRENCY'
 elif raw.get('cash_reconciliation',{}).get('schema')=='porquinho.real-cash-reconciliation/2.0' and raw['cash_reconciliation'].get('currency')=='EUR' and raw['cash_reconciliation'].get('cross_currency_aggregation') is False:
  q='EUR';v=number(raw.get('total_wealth_eur'));cash=number(raw.get('cash_eur'));invested=number(raw.get('portfolio_value_eur'));scope='LEGACY_PRODUCER_EUR_REFERENCE_NOT_HISTORICALLY_ATTESTED'
 if scope is None or any(x is None or x<0 for x in (v,cash,invested)) or abs(v-cash-invested)>Decimal('.02'):return None
 return {'date':t.isoformat(),'value':str(v),'cash':str(cash),'invested':str(invested),'currency':q,'scope':scope,'account_id':raw.get('account_id') if scope=='EXPLICIT_SNAPSHOT_CURRENCY' else None}

def history(root,now):
 folder=local(root,'snapshots');selected={}
 if folder.exists():
  for p in sorted(folder.glob('snapshot_*.json')):
   day=p.name[9:17]
   if len(day)==8 and day.isdigit():selected[day]=p
 # Last stored snapshot per named UTC day. Never read hydrated portfolio_daily.csv.
 points=[];skipped=0;used=0
 for p in list(sorted(selected.values(),reverse=True))[:366]:
  try:
   if p.is_symlink() or p.stat().st_size>SNAPSHOT_MAX_BYTES:skipped+=1;continue
   used+=p.stat().st_size
   if used>SNAPSHOT_TOTAL_BYTES:skipped+=1;continue
   with p.open('rb') as handle:raw=handle.read(SNAPSHOT_MAX_BYTES+1)
   if len(raw)>SNAPSHOT_MAX_BYTES:skipped+=1;continue
   row=snapshot_point(json.loads(raw),now=now)
   if raw!=p.read_bytes():raise ValueError('SNAPSHOT_CHANGED')
   if row:row['source_sha256']=hashlib.sha256(raw).hexdigest();points.append(row)
   else:skipped+=1
  except Exception:skipped+=1
 groups={}
 for p in points:groups.setdefault((p['currency'],p['scope'],p['account_id']),[]).append(p)
 return {'status':'STORED_SNAPSHOTS_READ','series':[{'currency':q,'scope':scope,'account_id':account,'points':sorted(rows,key=lambda r:r['date'])} for (q,scope,account),rows in groups.items()],
  'skipped_snapshots':skipped,'sampling':'LAST_NAMED_SNAPSHOT_PER_DAY_MAX_366','backfill_performed':False,'cash_flow_adjusted_return':False}

def maturity(raw,now):
 upcoming=[];overdue=[];seen=set();matured=0
 for e in raw.get('episodes',[]):
  for h in e.get('horizons',[]):
   t=stamp(h.get('due_at'));key=(e.get('episode_id') or (e.get('asset'),e.get('started_at')),h.get('horizon_days'),h.get('due_at'))
   if key in seen:continue
   seen.add(key)
   if h.get('status')=='MATURED':matured+=1
   if h.get('status')!='PENDING' or not t:continue
   row={'episode_id':e.get('episode_id'),'asset':e.get('asset'),'horizon_days':h.get('horizon_days'),'due_at':t.isoformat()}
   (upcoming if t>now else overdue).append(row)
 upcoming.sort(key=lambda r:r['due_at']);overdue.sort(key=lambda r:r['due_at'])
 return {'status':'STORED_HORIZONS_READ','next_due_at':upcoming[0]['due_at'] if upcoming else None,'pending_future_count':len(upcoming),'due_pending_count':len(overdue),'matured_count':matured,'upcoming':upcoming[:30],'due_pending':overdue[:30],'model_approval_implied':False}

def objectives(root):
 from .investment_plan_weekly_target_runtime import prepare
 targets=read(root,'data/investment_plan_weekly_targets.json',{'targets':[]});plans=read(root,'data/investment_plans.json',{'plans':[]})
 read(root,'data/planning_budgets.json',{'budgets':[]})
 rows=[];active=[]
 for p in plans.get('plans',[]):
  if p.get('status')=='ACTIVE' and p.get('authority')=='NONE' and p.get('execution_mode')=='MANUAL':
   try:
    x=prepare(root=root,plan_id=p.get('plan_id'),objective_return_pct=0)['target'];active.append({k:x[k] for k in ('investment_plan_id','account_id','currency','reference_capital')})
   except Exception:continue
 for t in targets.get('targets',[]):
  try:
   x=prepare(root=root,plan_id=t['investment_plan_id'],objective_return_pct=t['objective_return_pct'])['target']
   if any(t.get(k)!=x.get(k) for k in ('investment_plan_id','account_id','currency','reference_capital','objective_amount')):continue
   if t.get('schema')!='porquinho.investment-plan-weekly-target/1.0' or t.get('authority')!='NONE' or t.get('automatic_execution_authorized') is not False:continue
   rows.append({**{k:x[k] for k in ('investment_plan_id','account_id','currency','reference_capital','objective_return_pct','objective_amount')},'status':'REGISTERED_PLANNING_DRAFT','achieved_amount':None,'period_start':None,'period_end':None})
  except Exception:continue
 return {'status':'REGISTERED_OBJECTIVES_READ','targets':rows,'active_plans':active,'progress_status':'NO_VERIFIED_WEEKLY_PERFORMANCE_WINDOW','execution_quota':False}

def transactions(root):
 from .unified_history_query import UnifiedHistoryQuery
 from .ledger import TransactionLedger
 p=local(root,'data/transaction_ledger.jsonl')
 if not p.exists():return {'status':'LEDGER_NOT_PRESENT','records':[],'execution_inferred':False}
 if p.stat().st_size>32*1024*1024:raise ValueError('LEDGER_READ_LIMIT')
 if TransactionLedger(p).verify().get('status')!='OK':raise ValueError('LEDGER_VERIFICATION_FAILED')
 rows=UnifiedHistoryQuery(root).transactions();out=[]
 for row in rows:
  t=stamp(row.get('executed_at'))
  if t:out.append({k:row.get(k) for k in ('event_id','executed_at','instrument_id','account_id','currency','transaction_type','quantity','unit_price','gross_amount')})
 return {'status':'VERIFIED_LEDGER_PROJECTION','records':sorted(out,key=lambda r:r['executed_at'],reverse=True)[:100],'execution_inferred':False}

def build(root,*,now):
 result={'schema':SCHEMA,'execution_authorized':False,'history_write_performed':False,'financial_mutation':False,'issues':[]}
 for key,fn in [('wealth_history',lambda:history(root,now)),('weekly_goal',lambda:objectives(root)),('maturation',lambda:maturity(read(root,'data/brain_experimental_episodes/outcomes_latest.json',{}),now)),('transactions',lambda:transactions(root))]:
  try:result[key]=fn()
  except Exception as exc:result[key]={'status':'UNAVAILABLE','error_type':type(exc).__name__};result['issues'].append(key)
 return result
