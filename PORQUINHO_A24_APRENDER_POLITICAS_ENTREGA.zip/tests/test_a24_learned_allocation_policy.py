import copy
import datetime as dt
import fcntl
import unittest
from unittest.mock import patch
import test_a24_global_existing_lab as existing
from brain.evolution import learned_allocation_policy_a24 as p
from universal_portfolio.explicit_market_bindings_a24 import digest

NOW = dt.datetime(2026, 10, 17, tzinfo=dt.timezone.utc)


def experiment(algorithm='Ridge', spacing=45):
    rows = []
    first = dt.date(2024, 1, 1)
    for i in range(10):
        origin = first + dt.timedelta(days=i * spacing)
        for j in range(2):
            rows.append({'instrument_id': 'GLOBAL:TEST:TEST:' + str(j), 'provider': 'fixture',
                'provider_id': 'source-' + str(j), 'quote_currency': 'TST',
                'origin': origin.isoformat(), 'target': (origin + dt.timedelta(days=30)).isoformat(),
                'last_training_label_end': (origin - dt.timedelta(days=1)).isoformat(),
                'prediction_pct': 2 - j, 'actual_pct': 2 if j == 0 else -1})
    forecasts = [{**{k: rows[j][k] for k in p.KEY}, 'origin': '2026-10-16',
        'last_training_label_end': '2026-10-15', 'value_pct': 2 - j} for j in range(2)]
    return {'algorithm': algorithm, 'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30,
            'folds': rows, 'forecasts': forecasts, **existing.lab.flags()}


class PolicyLearning(unittest.TestCase):
    def learn(self, e=None): return p.learn([e or experiment()], now=NOW)

    def test_candidates_learned_from_existing_predictions(self):
        r = self.learn(); self.assertEqual(r['status'], 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY')
        self.assertEqual(r['searched_candidate_count'], 2)
        self.assertEqual(r['candidates'][0]['maximum_selected_sources'], 1)
        self.assertGreater(r['candidates'][0]['training']['mean_gross_return_pp'], r['baseline']['training']['mean_gross_return_pp'])

    def test_holdout_outcomes_do_not_choose_candidate(self):
        before = self.learn(); e = experiment()
        for row in e['folds']:
            if row['origin'] >= before['held_out_boundary']: row['actual_pct'] = -50 if row['provider_id'] == 'source-0' else 90
        after = self.learn(e)
        self.assertEqual([(c['algorithm'], c['maximum_selected_sources'], c['training']) for c in before['candidates']], [(c['algorithm'], c['maximum_selected_sources'], c['training']) for c in after['candidates']])
        self.assertNotEqual(before['candidates'][0]['held_out'], after['candidates'][0]['held_out'])

    def test_changed_training_outcomes_change_learned_concentration(self):
        e = experiment(); before = self.learn(e)
        for row in e['folds']:
            if row['origin'] < before['held_out_boundary']:
                row['actual_pct'] = -10 if row['provider_id'] == 'source-0' else 10
        after = self.learn(e)
        self.assertEqual(before['candidates'][0]['maximum_selected_sources'], 1)
        self.assertEqual(after['candidates'][0]['maximum_selected_sources'], 2)
        self.assertEqual(after['candidates'][0]['single_source_weight_cap'], .5)

    def test_two_models_compared_on_training_without_promoting_champion(self):
        a = experiment(); b = experiment('SVR')
        for row in b['folds']: row['prediction_pct'] = 1 if row['provider_id'] == 'source-0' else 2
        r = p.learn([a, b], now=NOW)
        self.assertEqual(r['algorithm_count'], 2)
        self.assertEqual(r['searched_candidate_count'], 4)
        self.assertTrue(all(c['algorithm'] == 'Ridge' for c in r['candidates']))
        self.assertFalse(r['policy_validation_proven'])

    def test_training_labels_mature_before_holdout(self):
        r = self.learn()
        self.assertTrue(all(end < r['held_out_boundary'] for _, end in r['training_intervals']))

    def test_intervals_disjoint_on_both_sides(self):
        r = self.learn()
        for key in ('training_intervals', 'held_out_intervals'):
            intervals = r[key]
            self.assertTrue(all(intervals[i][1] < intervals[i+1][0] for i in range(len(intervals)-1)))

    def test_too_few_disjoint_periods_not_approved(self):
        r = self.learn(experiment(spacing=10))
        self.assertEqual(r['status'], 'INSUFFICIENT_DISJOINT_POLICY_PERIODS')
        self.assertFalse(r['policy_validation_proven'])

    def test_no_positive_forecast_retains_nominal_cash(self):
        e = experiment()
        for row in e['forecasts']: row['value_pct'] = -1
        r = self.learn(e)
        self.assertEqual(r['candidates'][0]['current_research_weights'], [])
        self.assertEqual(r['candidates'][0]['current_nominal_cash_fraction'], 1)

    def test_partial_positive_selection_does_not_renormalize(self):
        rows = [{'instrument_id': str(j), 'provider': 'test', 'provider_id': str(j), 'quote_currency': 'TST', 'prediction_pct': 1 if j == 0 else -1} for j in range(2)]
        self.assertEqual(sum(p.allocation(rows, 2).values()), .5)

    def test_algorithms_require_identical_actual_population(self):
        a = experiment(); b = experiment('SVR'); b['folds'][0]['actual_pct'] += 1
        with self.assertRaisesRegex(ValueError, 'MATCHED_POLICY'): p.learn([a, b], now=NOW)

    def test_missing_period_not_silently_filled(self):
        e = experiment(); e['folds'].pop()
        with self.assertRaisesRegex(ValueError, 'COMPLETE_COMMON'): self.learn(e)

    def test_cross_currency_not_aggregated(self):
        e = experiment(); e['folds'][0]['quote_currency'] = 'EUR'
        with self.assertRaisesRegex(ValueError, 'CROSS_CURRENCY'): self.learn(e)

    def test_duplicate_sample_refused(self):
        e = experiment(); e['folds'].append(e['folds'][0])
        with self.assertRaisesRegex(ValueError, 'DUPLICATE_POLICY_SAMPLE'): self.learn(e)

    def test_different_sources_same_instrument_not_double_counted(self):
        e = experiment()
        for r in e['folds']: r['instrument_id'] = 'same'
        with self.assertRaisesRegex(ValueError, 'MULTIPLE_SOURCES'): self.learn(e)

    def test_bad_forecast_population_refused(self):
        e = experiment(); e['forecasts'].pop()
        with self.assertRaisesRegex(ValueError, 'CURRENT_FORECAST'): self.learn(e)

    def test_model_training_future_labels_refused(self):
        e = experiment(); e['folds'][0]['last_training_label_end'] = e['folds'][0]['origin']
        with self.assertRaisesRegex(ValueError, 'MATURED_PURGED'): self.learn(e)

    def test_same_day_realized_label_not_assumed_available(self):
        e = experiment(); e['folds'][-1]['target'] = NOW.date().isoformat()
        with self.assertRaisesRegex(ValueError, 'MATURED_PURGED'): self.learn(e)

    def test_days_not_observations(self):
        e = experiment(); e['horizon_unit'] = 'DAYS'
        with self.assertRaisesRegex(ValueError, '30_OBSERVATION'): self.learn(e)

    def test_nonfinite_and_boolean_refused(self):
        for value in (True, float('nan')):
            e = experiment(); e['folds'][0]['prediction_pct'] = value
            with self.assertRaises(ValueError): self.learn(e)

    def test_explicit_authority_leak_refused(self):
        e = experiment(); e['execution_authorized'] = True
        with self.assertRaisesRegex(ValueError, 'RESEARCH_ONLY'): self.learn(e)

    def test_no_policy_or_execution_certification(self):
        r = self.learn()
        for k, v in p.flags().items(): self.assertEqual(r[k], v)
        self.assertFalse(r['costs_and_rebalancing_turnover_modelled'])
        self.assertFalse(r['sqlite_memory_used_for_training'])
        self.assertNotIn('suggested_amount', r)

    def test_empty_history_reports_insufficient(self):
        e = experiment(); e['folds'] = []
        self.assertEqual(self.learn(e)['status'], 'INSUFFICIENT_POLICY_RESEARCH_PERIODS')


class Persistence(unittest.TestCase):
    def setUp(self):
        self.f = existing.Reuse(); self.f.setUp(); self.addCleanup(self.f.doCleanups)
        self.root = self.f.root; self.demand = self.f.demand
        self.f.runlab()

    def run_policy(self, **kw):
        return p.run(self.root, self.demand, now=existing.NOW, revalidate=self.f.current, **kw)

    def test_versions_created_without_touching_existing_learning(self):
        sentinel = self.root / 'data/memory.sqlite3'; sentinel.write_bytes(b'OLD_MEMORY')
        before = {x: x.read_bytes() for x in self.root.rglob('*') if x.is_file()}
        r = self.run_policy(); self.assertEqual(r['versions_created'], 1)
        for path, raw in before.items(): self.assertEqual(path.read_bytes(), raw)
        self.assertEqual(self.run_policy()['versions_created'], 0)

    def test_summary_readonly_no_fit_no_network(self):
        self.run_policy(); before = {x: x.read_bytes() for x in self.root.rglob('*') if x.is_file()}
        with patch.object(existing.lab, 'model_for', side_effect=AssertionError('NO_MODEL_FIT')), patch.object(existing.h.Transport, 'get_json', side_effect=AssertionError('NO_NETWORK')):
            result = p.summary(self.root, self.demand, now=existing.NOW)
        self.assertEqual(result['status'], 'LEARNED_POLICY_RESEARCH_INSPECTED')
        self.assertEqual(before, {x: x.read_bytes() for x in self.root.rglob('*') if x.is_file()})

    def test_funding_changed_refuses_persistence(self):
        r = p.run(self.root, self.demand, now=existing.NOW, revalidate=lambda: set())
        self.assertEqual(r['versions_created'], 0)
        self.assertFalse(list((self.root / p.STORE).glob('versions/*.json')))

    def test_tampered_policy_result_refused(self):
        self.run_policy(); path = next((self.root / p.STORE).glob('versions/*.json'))
        body = existing.h.read_sealed(path); body['research']['policy_validation_proven'] = True
        job = p.work(self.root, self.demand, existing.NOW)[1][0]
        with self.assertRaises(ValueError): p.check_stored(body, job, existing.NOW)

    def test_removed_binding_removes_current_policy_context(self):
        self.run_policy(); self.f.f.f.f.save([])
        self.assertEqual(p.summary(self.root, self.demand, now=existing.NOW)['contexts'], [])

    def test_busy_producer_no_second_writer(self):
        directory = self.root / p.STORE; directory.mkdir(parents=True)
        with (directory / 'producer.lock').open('w') as stream:
            fcntl.flock(stream, fcntl.LOCK_EX)
            self.assertEqual(self.run_policy()['status'], 'LEARNED_POLICY_PRODUCER_BUSY')
