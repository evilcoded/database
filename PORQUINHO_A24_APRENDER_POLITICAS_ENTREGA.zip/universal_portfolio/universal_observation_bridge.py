from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable, Mapping
import json, math

from universal_portfolio.universal_domain_discovery import (
    adapt_crypto_market_rows, load_local_b3_candidates, build_observation, domain_statuses
)
from universal_portfolio.universal_specialized_intelligence import project_universal_intelligence

SCHEMA="porquinho.universal-observation-bridge/1.0"
VERSION="r21.386ly11c"
INVARIANTS=MappingProxyType({
 "read_only_artifact_consumption":True,
 "runtime_wiring":False,
 "history_write":False,
 "financial_mutation":False,
 "execution_authority":False,
 "legacy_action_promotion":False,
 "legacy_target_weight_promotion":False,
 "legacy_move_required_promotion":False,
 "catalog_is_not_discovery_authority":True,
 "pending_is_not_ineligible":True,
 "missing_is_not_zero":True,
 "silent_fx":False,
 "real_instrument_structural_hardcodes":False,
 "adapter_first_no_reset":True,
})

class UniversalObservationBridgeError(ValueError): pass

def _json(path:Path)->dict[str,Any]:
    if not path.exists(): return {}
    raw=json.loads(path.read_text(encoding="utf-8"))
    return raw if isinstance(raw,dict) else {}

def _finite(v:Any)->float|None:
    try:
        x=float(v)
        return x if math.isfinite(x) else None
    except Exception:return None

def _catalog(root:Path)->dict[str,dict[str,Any]]:
    d=_json(root/"data/universal_instrument_catalog.json")
    out={}
    for x in d.get("instruments") or []:
        if not isinstance(x,Mapping): continue
        iid=str(x.get("instrument_id") or "").strip()
        if iid: out[iid]=dict(x)
    return out

def _held_ids(root:Path)->set[str]:
    # Read-only, identity-only discovery from existing canonical artifacts.
    ids=set()
    for rel in ("data/universal_positions.json","data/portfolio_registry.json"):
        d=_json(root/rel)
        def walk(v):
            if isinstance(v,dict):
                iid=str(v.get("instrument_id") or "").strip()
                if iid: ids.add(iid)
                for z in v.values(): walk(z)
            elif isinstance(v,list):
                for z in v: walk(z)
        walk(d)
    # Fixed-income valuation observations carry canonical position identity.
    d=_json(root/"data/fixed_income_positions/valuation_observations.json")
    for x in d.get("observations") or []:
        if isinstance(x,Mapping):
            iid=str(x.get("instrument_id") or "").strip()
            if iid: ids.add(iid)
    return ids

def _crypto_rows(root:Path, held:set[str], catalog:Mapping[str,Mapping[str,Any]])->list[dict[str,Any]]:
    latest=_json(root/"results/latest.json")
    rows=[]
    # This bridge consumes observational market facts only. Legacy action,
    # target weights, movement and execution fields are deliberately ignored.
    for index,x in enumerate(latest.get("scores") or [],1):
        if not isinstance(x,Mapping): continue
        sym=str(x.get("asset") or "").strip().upper()
        if not sym: continue
        rows.append({
          "symbol":sym,
          "id":x.get("provider_id"),
          "market_cap_rank":index,
          "current_price":_finite(x.get("price_eur")),
          "market_cap":_finite(x.get("market_cap_eur")),
          "total_volume":_finite(x.get("volume24h_eur")),
          "price_change_percentage_24h":_finite(x.get("change_24h")),
          "price_change_percentage_7d_in_currency":_finite(x.get("change_7d")),
          "price_change_percentage_30d_in_currency":_finite(x.get("change_30d")),
        })
    candidates=adapt_crypto_market_rows(
        rows, held_instrument_ids=held, jurisdiction="GLOBAL", market="CRYPTO",
        currency="EUR", source="RESULTS_LATEST_MARKET_FACTS_ONLY")
    # Catalog may enrich exact matching canonical identity metadata but never
    # creates candidates. No symbol guessing is used to change identity.
    return candidates

def _candidate_domain_key(candidate:Mapping[str,Any], expected_asset_class:str)->str|None:
    # Association only; never constructs/replaces universal identity.
    iid=str(candidate.get('instrument_id') or '').strip()
    actual=str(candidate.get('asset_class') or '').strip().upper()
    expected=str(expected_asset_class or '').strip().upper()
    if not iid or actual!=expected: return None
    parts=iid.split(':')
    if len(parts)!=4 or parts[2].strip().upper()!=expected: return None
    terminal=parts[3].strip().upper()
    return terminal or None

def _unique_domain_artifact_index(rows:Iterable[Mapping[str,Any]],keys:tuple[str,...]):
    grouped={}
    for row in rows:
        if not isinstance(row,Mapping): continue
        vals=[]
        for key in keys:
            v=row.get(key)
            if isinstance(v,str) and v.strip(): vals.append(v.strip().upper())
        vals=list(dict.fromkeys(vals))
        if len(vals)==1: grouped.setdefault(vals[0],[]).append(row)
    ambiguous={k for k,v in grouped.items() if len(v)!=1}
    return {k:v[0] for k,v in grouped.items() if len(v)==1},ambiguous

def _equity_specialized(root:Path, candidates:Iterable[Mapping[str,Any]])->dict[str,dict[str,Any]]:
    dec=_json(root/'data/equities/decision_latest.json')
    index,ambiguous=_unique_domain_artifact_index(dec.get('decisions') or [],('symbol','asset','ticker'))
    out={}
    for c in candidates:
        if not isinstance(c,Mapping): continue
        if str(c.get('asset_class') or '').upper()!='EQUITY': continue
        iid=str(c.get('instrument_id') or '').strip(); sym=_candidate_domain_key(c,'EQUITY')
        if not iid or not sym or sym in ambiguous or sym not in index: continue
        row=index[sym]
        out[iid]={'intelligence_state':'PARTIAL_EVIDENCE','domain_source':'data/equities/decision_latest.json','domain_status':'CURRENT_SPECIALIZED_ARTIFACT_NONCANONICAL_ACTION','domain_score':_finite(row.get('opportunity_score')),'evidence':{'evidence_quality':row.get('evidence_quality'),'confidence':row.get('confidence'),'legacy_domain_action_observed':bool(row.get('action'))},'provenance':{'schema':dec.get('schema'),'generated_at':dec.get('generated_at'),'binding':'EXISTING_CANONICAL_ID_TERMINAL_TO_UNIQUE_DOMAIN_ARTIFACT','legacy_action_not_promoted':True}}
    return out

def _crypto_specialized(root:Path, candidates:Iterable[Mapping[str,Any]])->dict[str,dict[str,Any]]:
    latest=_json(root/'results/latest.json')
    index,ambiguous=_unique_domain_artifact_index(latest.get('scores') or [],('asset','symbol','ticker'))
    out={}
    for c in candidates:
        if not isinstance(c,Mapping): continue
        if str(c.get('asset_class') or '').upper()!='CRYPTO': continue
        iid=str(c.get('instrument_id') or '').strip(); sym=_candidate_domain_key(c,'CRYPTO')
        if not iid or not sym or sym in ambiguous or sym not in index: continue
        row=index[sym]
        evidence={k:row.get(k) for k in ('change_24h','change_7d','change_30d','market_cap_eur','volume24h_eur','evidence_quality','evidence_count','historical_validation') if k in row}
        out[iid]={'intelligence_state':'PARTIAL_EVIDENCE','domain_source':'results/latest.json::scores','domain_status':'LEGACY_DOMAIN_INTELLIGENCE_ADAPTED_NONCANONICAL_ACTION','domain_score':None,'evidence':evidence,'provenance':{'timestamp':latest.get('timestamp'),'binding':'EXISTING_CANONICAL_ID_TERMINAL_TO_UNIQUE_DOMAIN_ARTIFACT','legacy_action_not_promoted':True,'legacy_target_weight_not_promoted':True,'legacy_move_required_not_promoted':True}}
    return out

def _fixed_income_specialized(root:Path)->dict[str,dict[str,Any]]:
    d=_json(root/"data/fixed_income_positions/valuation_observations.json")
    out={}
    for x in d.get("observations") or []:
        if not isinstance(x,Mapping): continue
        iid=str(x.get("instrument_id") or "").strip()
        if not iid: continue
        out[iid]={
          "intelligence_state":"PARTIAL_EVIDENCE",
          "domain_source":"data/fixed_income_positions/valuation_observations.json",
          "domain_status":"PENDING_PRODUCTION_DECISION_AUTHORITY",
          "domain_score":None,
          "evidence":{"gross_balance":x.get("gross_balance"),"net_balance":x.get("net_balance"),
                      "current_ir_rate":x.get("current_ir_rate"),"next_ir_rate":x.get("next_ir_rate"),
                      "observed_at":x.get("observed_at"),"evidence":x.get("evidence")},
          "provenance":x.get("provenance"),
        }
    return out

@dataclass(frozen=True)
class UniversalObservationBridgeResult:
    candidates:tuple[dict[str,Any],...]
    observation:dict[str,Any]
    intelligence:dict[str,Any]
    domain_statuses:tuple[dict[str,Any],...]
    source_refs:tuple[str,...]
    def payload(self):
        return {"schema":SCHEMA,"version":VERSION,"candidates":list(self.candidates),
                "observation":self.observation,"intelligence":self.intelligence,
                "domain_statuses":list(self.domain_statuses),"source_refs":list(self.source_refs),
                "invariants":dict(INVARIANTS)}

def build_read_only_bridge(root:str|Path,*,top_n:int=30)->UniversalObservationBridgeResult:
    r=Path(root)
    if top_n<1: raise UniversalObservationBridgeError("TOP_N_INVALID")
    held=_held_ids(r); catalog=_catalog(r)
    crypto=_crypto_rows(r,held,catalog)
    b3=load_local_b3_candidates(r,held_instrument_ids=held)
    candidates=[*crypto,*b3]

    # Held canonical instruments absent from current discovery remain observable,
    # but only when exact canonical metadata exists. Catalog is metadata authority,
    # not discovery authority.
    existing={str(x.get("instrument_id")) for x in candidates}
    for iid in sorted(held-existing):
        meta=catalog.get(iid)
        if not meta: continue
        candidates.append({
          "instrument_id":iid,"symbol":meta.get("symbol"),"asset_class":meta.get("asset_class"),
          "market":meta.get("market"),"jurisdiction":meta.get("jurisdiction"),
          "currency":meta.get("currency") or "UNAVAILABLE","held":True,
          "provider_rank":None,"discovery_source":"HELD_CANONICAL_POSITION_METADATA",
          "identity_provenance":"EXACT_CANONICAL_CATALOG_METADATA_FOR_HELD_POSITION",
          "ranking_semantics":"HELD_OUTSIDE_DISCOVERY_REMAINS_OBSERVED",
        })

    observation=build_observation(candidates,top_n=top_n)
    selected=observation.get("selected") or observation.get("candidates") or candidates
    specialized={}
    specialized.update(_crypto_specialized(r,selected))
    specialized.update(_equity_specialized(r,selected))
    specialized.update(_fixed_income_specialized(r))
    intelligence=project_universal_intelligence(selected,specialized)

    # A24: carry explicit governed envelopes from existing observation artifacts.
    # Ordinary market facts and research forecasts never become validated inputs.
    from .governed_economic_input_transport_a24 import collect_inputs
    intelligence.update(collect_inputs(r, observed_ids={x["instrument_id"] for x in selected}))

    # A24: funding contexts are observation demand, never recommendation authority.
    from .funded_currency_research_a24 import build as funding_research
    intelligence['funded_currency_research']=funding_research(r,candidates=selected)
    from .economic_action_plan_a24 import build as build_action_plan
    intelligence['economic_action_plan']=build_action_plan(r,funding=intelligence['funded_currency_research'],candidates=selected)

    # Existing executed costs are realized evidence, never a pretrade tariff.
    from .observed_trade_costs_a24 import build as observed_trade_costs
    intelligence['observed_manual_trade_costs']=observed_trade_costs(r)
    from .economic_action_evidence_a24 import build as attach_action_evidence
    intelligence['economic_action_evidence']=attach_action_evidence(r,intelligence['economic_action_plan'],intelligence['observed_manual_trade_costs'])
    from .economic_action_policy_a24 import build as assess_action_policies
    intelligence['economic_action_policy']=assess_action_policies(r,intelligence['economic_action_plan'])

    from brain.evolution.learned_allocation_policy_a24 import summary as learned_policy_summary
    intelligence['learned_allocation_policy']=learned_policy_summary(r,intelligence['funded_currency_research'])

    statuses=[x.payload() for x in domain_statuses(candidates)]
    refs=tuple(x for x in (
      "results/latest.json::market_facts_only" if (r/"results/latest.json").exists() else None,
      "normalized_b3_market_adapter" if b3 else None,
      "data/equities/decision_latest.json::evidence_only" if (r/"data/equities/decision_latest.json").exists() else None,
      "data/fixed_income_positions/valuation_observations.json::facts_only" if (r/"data/fixed_income_positions/valuation_observations.json").exists() else None,
      "data/universal_instrument_catalog.json::metadata_only" if (r/"data/universal_instrument_catalog.json").exists() else None,
    ) if x)
    return UniversalObservationBridgeResult(tuple(candidates),observation,intelligence,tuple(statuses),refs)

def contract_payload():
    return {"schema":SCHEMA,"version":VERSION,"role":"OFFLINE_READ_ONLY_UNIVERSAL_OBSERVATION_BRIDGE",
            "top_n_default":30,"invariants":dict(INVARIANTS),"runtime_wiring":False,
            "history_write":False,"financial_mutation":False,"execution_authority":False}
