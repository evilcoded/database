"""Autonomous allocation-policy hypotheses from existing global experiments.
Learn on earlier labels, evaluate later disjoint periods; never financial authority.
"""
import datetime as dt
import fcntl
import math
import os
from pathlib import Path
from . import global_existing_lab_a24 as lab
from universal_portfolio import global_history_source_a24 as history
from universal_portfolio import research_quote_acquisition_a24 as quotes
from universal_portfolio.explicit_market_bindings_a24 import digest, local, load

SCHEMA = 'porquinho.learned-allocation-policy-a24/1.0'
STORE = 'data/brain/learned_allocation_policy_a24'
METHOD = 'POSITIVE_FORECAST_TOP_K_EQUAL_WEIGHT_PURGED_PARETO_V1'
KEY = ('instrument_id', 'provider', 'provider_id', 'quote_currency')
BLOCKERS = ('RETROSPECTIVE_SOURCE_AVAILABILITY_NOT_ATTESTED',
            'PROSPECTIVE_POLICY_VALIDATION_REQUIRED', 'PRETRADE_COSTS_REQUIRED',
            'LIQUIDITY_AND_BROKER_ELIGIBILITY_REQUIRED',
            'ACTION_SPECIFIC_COMPARISON_AND_SIZING_REQUIRED',
            'INDEPENDENT_CANONICAL_PRODUCER_REQUIRED')


class PolicyError(ValueError):
    pass


def flags():
    return {'authority': 'RESEARCH_ONLY', 'model_validation_proven': False,
            'policy_validation_proven': False, 'comparison_authorized': False,
            'canonical_publication_authorized': False, 'execution_authorized': False,
            'financial_mutation': False, 'legacy_learning_modified': False,
            'sqlite_memory_used_for_training': False, 'manual_thresholds_required': False}


def number(value):
    if isinstance(value, bool) or not math.isfinite(float(value)):
        raise PolicyError('FINITE_NONBOOLEAN_VALUE_REQUIRED')
    return float(value)


def day(value):
    return dt.date.fromisoformat(value)


def identity(row):
    result = tuple(row.get(k) for k in KEY)
    if not all(isinstance(v, str) and v.strip() == v and v for v in result):
        raise PolicyError('EXPLICIT_SOURCE_CURRENCY_IDENTITY_REQUIRED')
    return result


def metrics(values):
    if not values:
        raise PolicyError('NONEMPTY_POLICY_SAMPLE_REQUIRED')
    return {'period_count': len(values), 'mean_gross_return_pp': sum(values) / len(values),
            'downside_rms_pp': math.sqrt(sum(min(v, 0) ** 2 for v in values) / len(values)),
            'worst_gross_period_pp': min(values)}


def allocation(rows, k):
    # Research hypothesis: a sleeve is 1/k; unfilled positive-forecast sleeves
    # stay in nominal cash. No model is assumed to estimate execution costs.
    ordered = sorted(rows, key=lambda r: (-number(r['prediction_pct']), identity(r)))
    return {identity(r): 1.0 / k for r in ordered[:k] if number(r['prediction_pct']) > 0}


def score(groups, k):
    values = []
    for rows in groups:
        weights = allocation(rows, k)
        values.append(sum(weights.get(identity(r), 0) * number(r['actual_pct']) for r in rows))
    return metrics(values)


def disjoint(groups):
    result = []
    last = None
    for rows in groups:
        if last is None or day(rows[0]['origin']) > last:
            result.append(rows)
            last = max(day(r['target']) for r in rows)
    return result


def learn(experiments, *, now):
    if not experiments or len(experiments) > 10:
        raise PolicyError('BOUNDED_EXISTING_EXPERIMENTS_REQUIRED')
    algorithms = set()
    population = None
    currency = None
    grouped = {}
    forecasts = {}
    for exp in experiments:
        if exp.get('horizon_unit') != 'OBSERVATIONS' or exp.get('horizon_value') != 30:
            raise PolicyError('EXPLICIT_30_OBSERVATION_TARGET_REQUIRED')
        if exp.get('authority') != 'RESEARCH_ONLY' or any(exp.get(k) is not False for k in ('execution_authorized','comparison_authorized','model_validation_proven','canonical_publication_authorized')):
            raise PolicyError('RESEARCH_ONLY_EXPERIMENT_REQUIRED')
        algorithm = exp['algorithm']
        if algorithm in algorithms:
            raise PolicyError('DUPLICATE_ALGORITHM')
        algorithms.add(algorithm)
        rows = exp.get('folds', [])
        if not rows:
            return {'schema': SCHEMA, 'status': 'INSUFFICIENT_POLICY_RESEARCH_PERIODS', 'algorithm_count': len(experiments), 'candidates': [], 'blocking_reasons': list(BLOCKERS), **flags()}
        if len(rows) > 1000:
            raise PolicyError('POLICY_SAMPLE_LIMIT')
        seen = {}
        groups = {}
        for row in rows:
            key = identity(row)
            if currency is None:
                currency = key[-1]
            if key[-1] != currency:
                raise PolicyError('CROSS_CURRENCY_POLICY_LEARNING_REFUSED')
            origin, target = day(row['origin']), day(row['target'])
            if not day(row['last_training_label_end']) < origin < target < now.date():
                raise PolicyError('MATURED_PURGED_MODEL_LABELS_REQUIRED')
            sample = (*key, row['origin'], row['target'])
            if sample in seen:
                raise PolicyError('DUPLICATE_POLICY_SAMPLE')
            number(row['prediction_pct'])
            actual = number(row['actual_pct'])
            if actual < -100:
                raise PolicyError('LONG_ONLY_RETURN_BELOW_MINUS_100')
            seen[sample] = actual
            groups.setdefault(row['origin'], []).append(row)
        if population is not None and seen != population:
            raise PolicyError('MATCHED_POLICY_LEARNING_POPULATION_REQUIRED')
        population = seen
        ordered = [groups[o] for o in sorted(groups)]
        universe = None
        for group in ordered:
            keys = {identity(r) for r in group}
            if len({k[0] for k in keys}) != len(keys):
                raise PolicyError('MULTIPLE_SOURCES_FOR_SAME_POLICY_INSTRUMENT')
            if universe is not None and universe != keys:
                raise PolicyError('COMPLETE_COMMON_CROSS_SECTION_REQUIRED')
            if len({r['target'] for r in group}) != 1:
                raise PolicyError('COMMON_REALIZED_INTERVAL_REQUIRED')
            universe = keys
        grouped[algorithm] = ordered
        current = exp.get('forecasts', [])
        if len(current) > 100:
            raise PolicyError('FORECAST_POPULATION_LIMIT')
        keys = [identity(r) for r in current]
        if len(keys) != len(set(keys)) or set(keys) != universe or len({r['origin'] for r in current}) != 1:
            raise PolicyError('COMPLETE_COMMON_CURRENT_FORECAST_REQUIRED')
        for row in current:
            number(row['value_pct'])
            if not day(row['last_training_label_end']) < day(row['origin']) <= now.date():
                raise PolicyError('CURRENT_FORECAST_TIME_INVALID')
        forecasts[algorithm] = current
    common = grouped[sorted(algorithms)[0]]
    if len(common) < 4:
        return {'schema': SCHEMA, 'status': 'INSUFFICIENT_POLICY_RESEARCH_PERIODS',
                'algorithm_count': len(algorithms), 'candidates': [], 'blocking_reasons': list(BLOCKERS), **flags()}
    # A fixed chronological protocol, not an optimized split. Purge every
    # training target that reaches the first held-out origin. Score disjoint
    # intervals on both sides. No holdout outcome is used in candidate selection.
    boundary = common[len(common) // 2][0]['origin']
    train = {a: disjoint([g for g in groups if max(r['target'] for r in g) < boundary]) for a, groups in grouped.items()}
    test = {a: disjoint([g for g in groups if g[0]['origin'] >= boundary]) for a, groups in grouped.items()}
    if min(len(train[a]) for a in algorithms) < 2 or min(len(test[a]) for a in algorithms) < 2:
        return {'schema': SCHEMA, 'status': 'INSUFFICIENT_DISJOINT_POLICY_PERIODS',
                'algorithm_count': len(algorithms), 'candidates': [], 'blocking_reasons': list(BLOCKERS), **flags()}
    count = len(common[0])
    candidates = []
    for algorithm in sorted(algorithms):
        for k in range(1, count + 1):
            candidates.append({'algorithm': algorithm, 'maximum_selected_sources': k,
                               'single_source_weight_cap': 1.0 / k,
                               'training': score(train[algorithm], k)})
    def dominates(x, y):
        a, b = x['training'], y['training']
        return (a['mean_gross_return_pp'] >= b['mean_gross_return_pp'] and a['downside_rms_pp'] <= b['downside_rms_pp']
                and (a['mean_gross_return_pp'] > b['mean_gross_return_pp'] or a['downside_rms_pp'] < b['downside_rms_pp']))
    frontier = [c for c in candidates if not any(dominates(other, c) for other in candidates)]
    for row in frontier:
        algorithm, k = row['algorithm'], row['maximum_selected_sources']
        row['held_out'] = score(test[algorithm], k)
        current = [{**r, 'prediction_pct': r['value_pct']} for r in forecasts[algorithm]]
        weights = allocation(current, k)
        row['current_research_weights'] = [{**dict(zip(KEY, key)), 'weight': value} for key, value in sorted(weights.items())]
        row['current_nominal_cash_fraction'] = max(0, 1 - sum(weights.values()))
        row['current_forecast_origin'] = current[0]['origin']
        row['candidate_id'] = digest({'method': METHOD, 'algorithm': algorithm, 'k': k, 'population': sorted(population.items())})
    baseline = lambda groups: metrics([sum(number(r['actual_pct']) for r in g) / len(g) for g in groups])
    return {'schema': SCHEMA, 'status': 'ALLOCATION_POLICY_CANDIDATES_LEARNED_RESEARCH_ONLY',
            'method': METHOD, 'quote_currency': currency, 'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30,
            'algorithm_count': len(algorithms), 'searched_candidate_count': len(candidates),
            'policy_family': 'LONG_ONLY_TOP_K_EQUAL_WEIGHT_POSITIVE_GROSS_FORECAST',
            'selection': 'TRAINING_PARETO_MEAN_GROSS_RETURN_MAX_DOWNSIDE_RMS_MIN_NO_SINGLE_WINNER',
            'held_out_boundary': boundary, 'training_intervals': [[g[0]['origin'], g[0]['target']] for g in train[sorted(algorithms)[0]]],
            'held_out_intervals': [[g[0]['origin'], g[0]['target']] for g in test[sorted(algorithms)[0]]],
            'baseline': {'definition': 'EQUAL_WEIGHT_ALL_COMMON_SOURCES_GROSS_NO_COSTS',
                         'training': baseline(train[sorted(algorithms)[0]]), 'held_out': baseline(test[sorted(algorithms)[0]])},
            'cash_semantics': 'NOMINAL_ZERO_PRICE_RETURN_NO_INTEREST_OR_FEES_MODELLED',
            'positions_are_source_contexts_not_account_orders': True,
            'broker_account_plan_eligibility_not_applied': True,
            'costs_and_rebalancing_turnover_modelled': False,
            'candidates': frontier, 'blocking_reasons': list(BLOCKERS), **flags()}


def work(root, demand, now):
    plan, jobs = lab.jobs(root, demand, now)
    cohorts = {}; frames = {}
    for job in jobs:
        if not job['path'].exists():
            continue
        cohort = job['metadata']['cohort_digest']
        if cohort not in frames:
            frames[cohort] = lab.input_frame([body for _, body in job['pairs']])
        result = lab.validate(history.read_sealed(job['path']), job, now, frame=frames[cohort])
        if result['status'] != 'EXISTING_LAB_REUSED_GLOBAL_RESEARCH_ONLY':
            continue
        cohorts.setdefault(cohort, []).append((job, result))
    result = []
    for cohort, pairs in sorted(cohorts.items()):
        version = {'cohort': cohort, 'method': METHOD,
                   'producer_code_digest': digest(Path(__file__).read_text()),
                   'input_experiments': {str(j['path'].relative_to(root)): digest(r) for j, r in pairs}}
        result.append({'version': version, 'pairs': pairs,
                       'path': local(root, STORE + '/versions/' + digest(version) + '.json')})
    return plan, result


def check_stored(body, job, now):
    if body.get('version') != job['version'] or quotes.utc(dt.datetime.fromisoformat(body['computed_at'])) > now:
        raise PolicyError('POLICY_VERSION_OR_TIME_MISMATCH')
    expected = learn([r for _, r in job['pairs']], now=quotes.utc(dt.datetime.fromisoformat(body['computed_at'])))
    if body.get('research') != expected:
        raise PolicyError('POLICY_RESEARCH_RECONSTRUCTION_MISMATCH')
    return body


def run(root, demand, *, now=None, revalidate=None):
    now = quotes.utc(now or dt.datetime.now(dt.timezone.utc)); root = Path(root).resolve(strict=True)
    out = {'schema': SCHEMA, 'versions_created': 0, 'network_requests': 0, **flags()}
    handle = None
    try:
        plan, jobs = work(root, demand, now)
        if not jobs:
            return {**out, 'status': 'AWAITING_EXISTING_GLOBAL_EXPERIMENTS'}
        directory = local(root, STORE); directory.mkdir(parents=True, exist_ok=True)
        fd = os.open(local(root, STORE + '/producer.lock'), os.O_CREAT | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
        handle = os.fdopen(fd, 'w')
        try: fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError: return {**out, 'status': 'LEARNED_POLICY_PRODUCER_BUSY'}
        for job in jobs:
            if job['path'].exists():
                check_stored(history.read_sealed(job['path']), job, now); continue
            body = {'version': job['version'], 'computed_at': now.isoformat(),
                    'research': learn([r for _, r in job['pairs']], now=now)}
            check_stored(body, job, now)
            current = (revalidate or (lambda: quotes.current_contexts(root)))()
            if digest(load(root)) != plan['binding_digest'] or any(tuple(c) not in current for j, _ in job['pairs'] for info in j['eligible'].values() for c in info['funding_contexts']):
                raise PolicyError('FUNDED_SOURCE_CONTEXT_CHANGED')
            if any(history.read_sealed(j['path']) != r or any(history.read_sealed(p) != b for p, b in j['pairs']) for j, r in job['pairs']):
                raise PolicyError('EXPERIMENT_OR_MARKET_SOURCE_CHANGED')
            history.store_once(job['path'], body)
            return {**out, 'status': body['research']['status'], 'versions_created': 1}
        return {**out, 'status': 'CURRENT_POLICY_RESEARCH_ALREADY_RECORDED'}
    except Exception as exc:
        return {**out, 'status': 'LEARNED_POLICY_RESEARCH_UNAVAILABLE', 'error_type': type(exc).__name__}
    finally:
        if handle is not None: handle.close()


def summary(root, demand, *, now=None):
    now = quotes.utc(now or dt.datetime.now(dt.timezone.utc)); root = Path(root).resolve(strict=True)
    out = {'schema': SCHEMA, 'contexts': [], **flags()}
    try:
        _, jobs = work(root, demand, now)
        for job in jobs:
            row = {'quote_currency': job['pairs'][0][1]['quote_currency'], 'status': 'AWAITING_POLICY_LEARNING'}
            if job['path'].exists():
                result = check_stored(history.read_sealed(job['path']), job, now)['research']
                row.update(status=result['status'], algorithm_count=result['algorithm_count'],
                           searched_candidate_count=result.get('searched_candidate_count', 0),
                           retained_candidate_count=len(result['candidates']),
                           training_period_count=len(result.get('training_intervals', [])),
                           held_out_period_count=len(result.get('held_out_intervals', [])),
                           blocking_reasons=result['blocking_reasons'])
            out['contexts'].append(row)
        return {**out, 'status': 'LEARNED_POLICY_RESEARCH_INSPECTED',
                'candidate_count': sum(r.get('retained_candidate_count', 0) for r in out['contexts'])}
    except Exception as exc:
        return {**out, 'status': 'LEARNED_POLICY_RESEARCH_UNAVAILABLE', 'error_type': type(exc).__name__}
