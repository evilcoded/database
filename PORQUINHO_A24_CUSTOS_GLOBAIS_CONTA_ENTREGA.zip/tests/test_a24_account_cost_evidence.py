"""Explicit cost scope, temporal validity and nonmutation with synthetic data."""
import copy,datetime as dt,json,tempfile,unittest,fcntl
from pathlib import Path
from unittest.mock import patch
import test_a24_research_quote_acquisition as fixture
from universal_portfolio import account_cost_evidence_a24 as cost
from universal_portfolio import economic_component_set_producer_a24 as governed
from universal_portfolio.ledger import TransactionLedger
from tools import review_account_costs_a24 as cli
NOW=fixture.NOW
class Cost(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Acquisition();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root.resolve();self.f.save([self.f.rows()]);self.demand=self.f.demand();self.registry=self.root/'data/institution_accounts.json';self.registry.write_text(json.dumps({'schema':'porquinho.institution-account-registry/1.0','accounts':[{'account_id':'account-BRL','institution_id':'bank','currency':'BRL'}],'institutions':[{'institution_id':'bank','country':'PT'}]}))
 def row(self,**kw):
  row={'schema':cost.SCHEMA,'evidence_id':'explicit-reviewed-quote-1','account_id':'account-BRL','institution_id':'bank','institution_country':'PT','instrument_id':fixture.IID,'currency':'BRL','execution_venue_id':'EXECUTION:VENUE:EXPLICIT','side':'BUY','reference_amount':'100','confirmed':True,'component_coverage_reviewed':True,'reviewed_by':'reviewer','reviewed_at':NOW.isoformat(),'effective_from':(NOW-dt.timedelta(hours=1)).isoformat(),'effective_until':(NOW+dt.timedelta(hours=1)).isoformat(),
   'components':{n:{'status':'KNOWN','amount':'0.10','currency':'BRL','unit':'CURRENCY_AMOUNT','source_kind':'OFFICIAL_PRETRADE_QUOTE','source_ref':'synthetic-official-quote','applicability_ref':'explicit-quote-scope','as_of':(NOW-dt.timedelta(minutes=1)).isoformat()} for n in cost.COMPONENTS},**cost.flags()};row.update(kw);return row
 def apply(self,rows=None):return cost.apply_reviewed(self.root,{'schema':cost.SCHEMA,'reviews':rows or [self.row()]},now=NOW)
 def query(self,**kw):q={k:self.row()[k] for k in cost.SCOPE};q.update(kw);return q
 def estimate(self,**kw):return cost.estimate(self.root,self.query(**kw),now=NOW)
 def test_complete_quote_exact_decimal_total(self):
  self.apply();q=self.estimate();self.assertEqual(q['total_cost'],'0.60');self.assertEqual(q['reference_capital_fraction'],'0.006');self.assertFalse(q['model_validation_proven']);self.assertFalse(q['actual_fill_cost'])
 def test_unknown_cost_never_zero(self):
  row=self.row();row['components']['taxes'].update(status='UNKNOWN',amount=None);self.apply([row]);q=self.estimate();self.assertIsNone(q['total_cost']);self.assertEqual(q['missing_components'],['taxes'])
 def test_absence_requires_explicit_evidence(self):self.assertEqual(self.estimate()['status'],'EXPLICIT_CURRENT_COST_EVIDENCE_REQUIRED')
 def test_explicit_zero_is_accepted_without_inventing_it(self):
  row=self.row()
  for c in row['components'].values():c['amount']='0'
  self.apply([row]);self.assertEqual(self.estimate()['total_cost'],'0')
 def test_not_applicable_requires_proof_and_null_amount(self):
  row=self.row();row['components']['taxes'].update(status='NOT_APPLICABLE',amount=None);self.apply([row]);self.assertEqual(self.estimate()['total_cost'],'0.50')
 def test_not_applicable_without_applicability_ref_refused(self):
  row=self.row();row['components']['taxes'].update(status='NOT_APPLICABLE',amount=None,applicability_ref=None)
  with self.assertRaises(ValueError):self.apply([row])
 def test_wrong_currency_no_fallback(self):
  self.apply()
  with self.assertRaises(ValueError):self.estimate(currency='EUR')
 def test_different_registered_account_rejected_no_reuse(self):
  self.apply();r=json.loads(self.registry.read_text());r['accounts'].append({'account_id':'other','institution_id':'bank','currency':'BRL'});self.registry.write_text(json.dumps(r));self.assertIsNone(self.estimate(account_id='other')['total_cost'])
 def test_different_instrument_rejected_despite_same_symbol(self):self.apply();self.assertIsNone(self.estimate(instrument_id='OTHER:GLOBAL:ID')['total_cost'])
 def test_quote_provider_not_execution_venue(self):self.apply();self.assertIsNone(self.estimate(execution_venue_id='CoinGecko')['total_cost'])
 def test_side_not_inferred(self):self.apply();self.assertIsNone(self.estimate(side='SELL')['total_cost'])
 def test_reference_notional_exact_no_scaling(self):self.apply();self.assertIsNone(self.estimate(reference_amount='200')['total_cost'])
 def test_numerically_equal_notional_accepted(self):self.apply();self.assertEqual(self.estimate(reference_amount='100.00')['total_cost'],'0.60')
 def test_expired_quote_unavailable(self):
  self.apply();q=cost.estimate(self.root,self.query(),now=NOW+dt.timedelta(hours=2));self.assertEqual(q['status'],'COST_EVIDENCE_OUTSIDE_VALIDITY');self.assertIsNone(q['total_cost'])
 def test_not_yet_effective_quote_unavailable(self):
  row=self.row(evidence_id='future',effective_from=(NOW+dt.timedelta(minutes=1)).isoformat());self.apply([row]);self.assertEqual(self.estimate(evidence_id='future')['status'],'COST_EVIDENCE_OUTSIDE_VALIDITY')
 def test_overlap_not_arbitrarily_selected(self):self.apply();self.apply([self.row(evidence_id='other-review')]);self.assertEqual(self.estimate()['status'],'AMBIGUOUS_COST_EVIDENCE_EXPLICIT_SELECTION_REQUIRED');self.assertEqual(self.estimate(evidence_id='other-review')['total_cost'],'0.60')
 def test_unconfirmed_review_not_applied(self):
  with self.assertRaises(ValueError):self.apply([self.row(confirmed=False)])
  self.assertFalse((self.root/cost.STORE).exists())
 def test_existing_evidence_cannot_be_overwritten(self):
  self.apply();before={p:p.read_bytes() for p in (self.root/cost.STORE/'reviews').glob('*.json')};row=self.row();row['components']['taxes']['amount']='1'
  with self.assertRaises(ValueError):self.apply([row])
  self.assertEqual(before,{p:p.read_bytes() for p in before})
 def test_repeat_idempotent(self):self.apply();self.assertEqual(self.apply()['new_evidence_count'],0)
 def test_whole_batch_validated_before_any_write(self):
  with self.assertRaises(ValueError):self.apply([self.row(),self.row(evidence_id='bad',currency='EUR')])
  self.assertFalse((self.root/cost.STORE).exists())
 def test_decimal_nan_boolean_negative_refused(self):
  for amount in ('NaN','Infinity','-1',True,1.2):
   row=self.row();row['components']['brokerage']['amount']=amount
   with self.assertRaises(ValueError):self.apply([row])
 def test_source_timestamp_not_future(self):
  row=self.row();row['components']['brokerage']['as_of']=(NOW+dt.timedelta(minutes=1)).isoformat()
  with self.assertRaises(ValueError):self.apply([row])
 def test_component_currency_and_unit_exact(self):
  for kw in ({'currency':'EUR'},{'unit':'PERCENT'}):
   row=self.row();row['components']['brokerage'].update(kw)
   with self.assertRaises(ValueError):self.apply([row])
 def test_component_missing_or_unknown_extra_refused(self):
  for kind in ('missing','extra'):
   row=self.row()
   if kind=='missing':row['components'].pop('spread')
   else:row['components']['extra']={}
   with self.assertRaises(ValueError):self.apply([row])
 def test_changed_bank_binding_refused_at_estimate(self):
  self.apply();r=json.loads(self.registry.read_text());r['institutions'].append({'institution_id':'new','country':'XX'});r['accounts'][0]['institution_id']='new';self.registry.write_text(json.dumps(r))
  with self.assertRaises(ValueError):self.estimate()
 def test_no_model_or_governed_authority(self):
  self.apply();q=self.estimate();self.assertEqual(governed.produce(q)['sets'],[])
  with self.assertRaises(ValueError):self.apply([self.row(model_validation_proven=True)])
 def test_ledger_actual_fee_count_not_tariff(self):
  ledger=TransactionLedger(self.root/'data/transaction_ledger.jsonl');ledger.append({'event_type':'FEE','account_id':'account-BRL','currency':'BRL','gross_amount':'1','executed_at':NOW.isoformat(),'external_id':'synthetic'});before=ledger.path.read_bytes();s=cost.ledger_survey(self.root);self.assertEqual(s['fee_event_count'],1);self.assertFalse(s['tariff_inferred']);self.assertEqual(ledger.path.read_bytes(),before);self.assertIsNone(self.estimate()['total_cost'])
 def test_ledger_corruption_explicit(self):
  (self.root/'data/transaction_ledger.jsonl').write_text('{}\n');self.assertEqual(cost.summary(self.root,self.demand,now=NOW)['status'],'ACCOUNT_COST_INSPECTION_UNAVAILABLE')
 def test_missing_ledger_not_created(self):
  self.assertEqual(cost.ledger_survey(self.root)['status'],'LEDGER_MISSING');self.assertFalse((self.root/'data/transaction_ledger.jsonl').exists())
 def test_read_only_summary_contains_no_private_amounts_or_accounts(self):
  self.apply();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};s=cost.summary(self.root,self.demand,now=NOW);self.assertEqual(s['complete_active_review_count'],1);self.assertNotIn('account-BRL',json.dumps(s));self.assertNotIn('0.60',json.dumps(s));self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_template_blank_no_venue_or_amount_assumption(self):
  t=cost.review_template(self.root,self.demand,now=NOW);self.assertEqual(len(t['reviews']),2)
  for r in t['reviews']:self.assertFalse(r['confirmed']);self.assertIsNone(r['execution_venue_id']);self.assertIsNone(r['reference_amount']);self.assertIsNone(r['reviewed_at'])
  self.assertFalse((self.root/cost.STORE).exists())
 def test_template_currency_universal(self):
  r=json.loads(self.registry.read_text());r['accounts']=[{'account_id':'account-JPY','institution_id':'bank','currency':'JPY'}];self.registry.write_text(json.dumps(r));self.f.save([self.f.rows(quote_currency='JPY')]);d=self.f.demand(('JPY',));self.assertEqual(cost.review_template(self.root,d,now=NOW)['reviews'][0]['currency'],'JPY')
 def test_exclusive_export_outside_project_preserves_data(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp).resolve()/'review.json';before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};self.assertEqual(cli.export(self.root,path,demand=self.demand,now=NOW)['review_case_count'],2)
   with self.assertRaises(ValueError):cli.export(self.root,path,demand=self.demand,now=NOW)
   self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_export_inside_project_refused(self):
  with self.assertRaises(ValueError):cli.export(self.root,self.root/'review.json',demand=self.demand,now=NOW)
 def test_corrupt_or_symlink_review_refused(self):
  self.apply();p=next((self.root/cost.STORE/'reviews').glob('*.json'));p.write_text('{}')
  with self.assertRaises(ValueError):cost.load(self.root,now=NOW)
 def test_writer_lock_refused(self):
  directory=self.root/cost.STORE;directory.mkdir(parents=True)
  with (directory/'review.lock').open('w') as stream:
   fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
   with self.assertRaises(ValueError):self.apply()
 def test_invalid_demand_not_zero_ready(self):self.assertEqual(cost.summary(self.root,{},now=NOW)['status'],'ACCOUNT_COST_INSPECTION_UNAVAILABLE')
 def test_known_fee_requires_quote_or_contract_not_applicability_only(self):
  row=self.row();row['components']['brokerage']['source_kind']='APPLICABILITY_EVIDENCE'
  with self.assertRaises(ValueError):self.apply([row])
 def test_component_coverage_requires_explicit_review(self):
  with self.assertRaises(ValueError):self.apply([self.row(component_coverage_reviewed=False)])
 def test_institution_locality_change_invalidates_existing_quote(self):
  self.apply();obj=json.loads(self.registry.read_text());obj['institutions'][0]['country']='OTHER';self.registry.write_text(json.dumps(obj))
  with self.assertRaises(ValueError):self.estimate()
 def test_numeric_false_not_accepted_as_authority_flag(self):
  with self.assertRaises(ValueError):self.apply([self.row(comparison_authorized=0)])
 def test_review_bundle_symlink_refused(self):
  self.apply();p=next((self.root/cost.STORE/'reviews').glob('*.json'));raw=p.read_bytes();target=self.root/'preserved-evidence';target.write_bytes(raw);p.unlink();p.symlink_to(target)
  with self.assertRaises(ValueError):cost.load(self.root,now=NOW)
  self.assertEqual(target.read_bytes(),raw)
 def test_review_output_symlink_preserves_target(self):
  with tempfile.TemporaryDirectory() as tmp:
   folder=Path(tmp).resolve();target=folder/'preserved';target.write_bytes(b'PRESERVE');path=folder/'review.json';path.symlink_to(target)
   with self.assertRaises(ValueError):cli.export(self.root,path,demand=self.demand,now=NOW)
   self.assertEqual(target.read_bytes(),b'PRESERVE')
