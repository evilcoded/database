"""Explicit current pretrade cost evidence, separate from financial/learning stores.
A reviewed quote is an input declaration, never independent validation or a fee append.
"""
import datetime as dt
import fcntl
import json
import os
from decimal import Decimal,localcontext
from pathlib import Path
from . import global_history_source_a24 as storage
from .explicit_market_bindings_a24 import local,digest
from .research_quote_acquisition_a24 import utc
SCHEMA='porquinho.account-cost-evidence-a24/1.0'
STORE='data/brain/account_cost_evidence_a24'
COMPONENTS=('brokerage','exchange_fees','spread','slippage','taxes','other_costs')
SCOPE=('account_id','institution_id','institution_country','instrument_id','currency','execution_venue_id','side','reference_amount')
class CostError(ValueError):pass

def flags():return {'authority':'NONE','model_validation_proven':False,'comparison_authorized':False,'canonical_publication_authorized':False,'execution_authorized':False,'financial_mutation':False,'ledger_write':False}
def text(value):return isinstance(value,str) and 0<len(value)<=500 and value==value.strip()
def number(value,positive=False):
 if isinstance(value,bool) or not isinstance(value,(str,int,Decimal)) or len(str(value))>80:raise CostError('EXPLICIT_DECIMAL_AMOUNT_REQUIRED')
 try:d=Decimal(str(value))
 except Exception:raise CostError('EXPLICIT_DECIMAL_AMOUNT_REQUIRED')
 if not d.is_finite() or d<0 or (positive and d==0) or abs(d.as_tuple().exponent)>24:raise CostError('NONNEGATIVE_FINITE_AMOUNT_REQUIRED')
 return d

def timestamp(value):
 if not text(value):raise CostError('AWARE_TIMESTAMP_REQUIRED')
 try:return utc(dt.datetime.fromisoformat(value))
 except Exception:raise CostError('AWARE_TIMESTAMP_REQUIRED')

def accounts(root):
 # Same canonical registry filename and unique historical fallback as the planner,
 # with bounded stable reads and no changes to existing registry semantics.
 p=local(root,'data/institution_accounts.json')
 if not p.exists():
  found=list(local(root,'data').glob('*institution*account*.json'))
  if len(found)!=1:raise CostError('ACCOUNT_REGISTRY_UNRESOLVED')
  p=local(root,str(found[0].relative_to(Path(root).resolve())))
 before=p.stat()
 if before.st_size>4*1024*1024:raise CostError('ACCOUNT_REGISTRY_SIZE_LIMIT')
 obj=json.loads(p.read_bytes());after=p.stat()
 if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise CostError('ACCOUNT_REGISTRY_CHANGED')
 if obj.get('schema')!='porquinho.institution-account-registry/1.0':raise CostError('ACCOUNT_REGISTRY_SCHEMA_REQUIRED')
 rows=obj.get('accounts');banks=obj.get('institutions')
 if not isinstance(rows,list) or not isinstance(banks,list):raise CostError('ACCOUNT_REGISTRY_INVALID')
 out={};institutions={}
 for bank in banks:
  key=bank.get('institution_id')
  if not text(key) or key in institutions:raise CostError('UNIQUE_INSTITUTION_REQUIRED')
  institutions[key]=bank
 for row in rows:
  key=row.get('account_id')
  if not text(key) or key in out or row.get('institution_id') not in institutions:raise CostError('UNIQUE_REGISTERED_ACCOUNT_REQUIRED')
  country=institutions[row['institution_id']].get('country')
  if not text(country):raise CostError('EXPLICIT_INSTITUTION_LOCALITY_REQUIRED')
  out[key]={**row,'_institution_country':country}
 return out,digest(obj)

def validate(row,*,now):
 if not isinstance(row,dict) or row.get('schema')!=SCHEMA or row.get('confirmed') is not True:raise CostError('EXPLICIT_REVIEW_CONFIRMATION_REQUIRED')
 if row.get('component_coverage_reviewed') is not True:raise CostError('EXPLICIT_COMPONENT_COVERAGE_REVIEW_REQUIRED')
 if any((row.get(k) is not v) if isinstance(v,bool) else (row.get(k)!=v) for k,v in flags().items()):raise CostError('NONAUTHORIZING_COST_CONTRACT_REQUIRED')
 if not all(text(row.get(k)) for k in (*SCOPE,'evidence_id','reviewed_by','reviewed_at','effective_from','effective_until')):raise CostError('EXPLICIT_COST_SCOPE_REQUIRED')
 if row['side'] not in ('BUY','SELL'):raise CostError('EXPLICIT_BUY_OR_SELL_SIDE_REQUIRED')
 cur=row['currency']
 if not cur.isascii() or not cur.isalpha() or not cur.isupper() or len(cur)>16:raise CostError('EXPLICIT_UPPERCASE_CURRENCY_REQUIRED')
 number(row['reference_amount'],True)
 start=timestamp(row['effective_from']);end=timestamp(row['effective_until']);review=timestamp(row['reviewed_at'])
 if start>=end or review>now:raise CostError('COST_REVIEW_TIME_INVALID')
 raw=row.get('components')
 if not isinstance(raw,dict) or set(raw)!=set(COMPONENTS):raise CostError('ALL_COST_COMPONENT_STATUSES_REQUIRED')
 for name,c in raw.items():
  if not isinstance(c,dict) or c.get('currency')!=cur or c.get('unit')!='CURRENCY_AMOUNT':raise CostError('COST_COMPONENT_CURRENCY_UNIT_MISMATCH')
  status=c.get('status')
  if status not in ('KNOWN','NOT_APPLICABLE','UNKNOWN'):raise CostError('COST_COMPONENT_STATUS_REQUIRED')
  if status=='KNOWN':
   number(c.get('amount'))
   if c.get('source_kind') not in ('OFFICIAL_PRETRADE_QUOTE','ACCOUNT_PRICING_CONTRACT'):raise CostError('KNOWN_AMOUNT_REQUIRES_QUOTE_OR_CONTRACT')
  elif c.get('amount') is not None:raise CostError('UNKNOWN_OR_INAPPLICABLE_AMOUNT_FORBIDDEN')
  if status!='UNKNOWN':
   if c.get('source_kind') not in ('OFFICIAL_PRETRADE_QUOTE','ACCOUNT_PRICING_CONTRACT','APPLICABILITY_EVIDENCE') or not text(c.get('source_ref')) or not text(c.get('applicability_ref')):raise CostError('COMPONENT_SOURCE_AND_APPLICABILITY_REQUIRED')
   if timestamp(c.get('as_of'))>review:raise CostError('COMPONENT_SOURCE_AFTER_REVIEW')
 return row

def current_scope(row,registered):
 account=registered.get(row['account_id'])
 if account is None or account.get('currency')!=row['currency'] or account.get('institution_id')!=row['institution_id'] or account.get('_institution_country')!=row['institution_country']:raise CostError('CURRENT_ACCOUNT_INSTITUTION_CURRENCY_MISMATCH')

def load(root,*,now):
 directory=local(root,STORE+'/reviews');paths=sorted(directory.glob('*.json')) if directory.exists() else []
 if len(paths)>1024 or sum(p.stat().st_size for p in paths)>16*1024*1024:raise CostError('COST_EVIDENCE_READ_LIMIT')
 before={p:(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in paths};out={}
 for p in paths:
  p=local(root,str(p.relative_to(Path(root).resolve())));body=storage.read_sealed(p)
  if body.get('schema')!=SCHEMA or p.stem!=digest(body) or not isinstance(body.get('reviews'),list) or not 1<=len(body['reviews'])<=1000:raise CostError('COST_REVIEW_BUNDLE_INVALID')
  for row in body['reviews']:
   validate(row,now=now);key=row['evidence_id']
   if key in out and out[key]!=row:raise CostError('CONFLICTING_EVIDENCE_ID')
   out[key]=row
 if paths!=(sorted(directory.glob('*.json')) if directory.exists() else []) or before!={p:(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in before}:raise CostError('COST_EVIDENCE_CHANGED_DURING_READ')
 return out

def apply_reviewed(root,document,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc))
 if not isinstance(document,dict) or document.get('schema')!=SCHEMA or not isinstance(document.get('reviews'),list):raise CostError('COST_REVIEW_DOCUMENT_REQUIRED')
 selected=[r for r in document['reviews'] if isinstance(r,dict) and r.get('confirmed') is True]
 if not 1<=len(selected)<=1000:raise CostError('EXPLICIT_CONFIRMED_REVIEWS_REQUIRED')
 registry,registry_hash=accounts(root)
 for row in selected:validate(row,now=now);current_scope(row,registry)
 if len({r['evidence_id'] for r in selected})!=len(selected):raise CostError('UNIQUE_EVIDENCE_IDS_REQUIRED')
 directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True)
 fd=os.open(local(root,STORE+'/review.lock'),os.O_CREAT|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600)
 with os.fdopen(fd,'w') as stream:
  try:fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:raise CostError('COST_REVIEW_WRITER_BUSY')
  previous=load(root,now=now)
  for row in selected:
   if row['evidence_id'] in previous and previous[row['evidence_id']]!=row:raise CostError('EXISTING_EVIDENCE_PRESERVED_USE_NEW_ID')
  fresh=[r for r in selected if r['evidence_id'] not in previous]
  if accounts(root)[1]!=registry_hash:raise CostError('ACCOUNT_REGISTRY_CHANGED_BEFORE_REVIEW_WRITE')
  if fresh:
   body={'schema':SCHEMA,'reviews':sorted(fresh,key=lambda r:r['evidence_id'])};storage.store_once(local(root,STORE+'/reviews/'+digest(body)+'.json'),body)
 return {'schema':SCHEMA,'status':'REVIEWED_COST_DECLARATIONS_RECORDED','new_evidence_count':len(fresh),'total_evidence_count':len(previous)+len(fresh),'independent_attestation':False,**flags()}

def estimate(root,query,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc))
 if not isinstance(query,dict) or not all(text(query.get(k)) for k in SCOPE):raise CostError('EXPLICIT_ORDER_COST_SCOPE_REQUIRED')
 ref=number(query['reference_amount'],True);registry,_=accounts(root);current_scope(query,registry)
 if query['side'] not in ('BUY','SELL'):raise CostError('EXPLICIT_BUY_OR_SELL_SIDE_REQUIRED')
 rows=list(load(root,now=now).values())
 scope=[r for r in rows if all(r[k]==query[k] for k in SCOPE if k!='reference_amount') and number(r['reference_amount'],True)==ref]
 if 'evidence_id' in query:
  if not text(query['evidence_id']):raise CostError('EXPLICIT_EVIDENCE_SELECTION_REQUIRED')
  scope=[r for r in scope if r['evidence_id']==query['evidence_id']]
 active=[r for r in scope if timestamp(r['effective_from'])<=now<timestamp(r['effective_until'])]
 base={'schema':SCHEMA,'status':'EXPLICIT_CURRENT_COST_EVIDENCE_REQUIRED','total_cost':None,'reference_capital_fraction':None,'independent_attestation':False,**flags()}
 if not active:return {**base,'status':'COST_EVIDENCE_OUTSIDE_VALIDITY' if scope else base['status']}
 if len(active)!=1:return {**base,'status':'AMBIGUOUS_COST_EVIDENCE_EXPLICIT_SELECTION_REQUIRED'}
 row=active[0];unknown=[n for n in COMPONENTS if row['components'][n]['status']=='UNKNOWN']
 if unknown:return {**base,'status':'PARTIAL_COST_EVIDENCE','evidence_id':row['evidence_id'],'missing_components':unknown}
 with localcontext() as ctx:
  ctx.prec=200
  total=sum((number(row['components'][n]['amount']) for n in COMPONENTS if row['components'][n]['status']=='KNOWN'),Decimal('0'))
  ctx.prec=50;ratio=total/ref
 return {**base,'status':'REVIEWED_PRETRADE_COST_ESTIMATE_NOT_VALIDATED','evidence_id':row['evidence_id'],
  'total_cost':str(total),'reference_capital_fraction':str(ratio),'ratio_decimal_precision':50,'actual_fill_cost':False}

def ledger_survey(root):
 from .ledger import TransactionLedger
 from .ledger_financial_translation import canonical_transaction_type,LedgerTranslationError
 p=local(root,'data/transaction_ledger.jsonl')
 if not p.exists():return {'status':'LEDGER_MISSING','fee_event_count':0,'tariff_inferred':False}
 before=p.stat()
 if before.st_size>64*1024*1024:raise CostError('LEDGER_SURVEY_SIZE_LIMIT')
 rows=TransactionLedger(p).events();after=p.stat()
 if (before.st_size,before.st_mtime_ns,before.st_ino)!=(after.st_size,after.st_mtime_ns,after.st_ino):raise CostError('LEDGER_CHANGED_DURING_SURVEY')
 count=0
 for row in rows:
  try:count+=canonical_transaction_type(row)=='FEE'
  except LedgerTranslationError:continue
 return {'status':'LOCAL_CHAIN_VERIFIED_FEE_EVENT_COUNTS_ONLY','fee_event_count':count,'tariff_inferred':False,'net_fee_total_computed':False}

def summary(root,demand,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc))
 out={'schema':SCHEMA,'status':'ACCOUNT_COST_EVIDENCE_INSPECTED','reviewed_evidence_count':0,'funded_account_context_count':0,'active_review_count':0,'complete_active_review_count':0,'independent_attestation':False,'history_write_performed':False,'network_requests':0,**flags()}
 try:
  if not isinstance(demand,dict) or demand.get('schema')!='porquinho.funded-currency-research-a24/1.0' or demand.get('status')!='OBSERVATION_DEMAND_PROJECTED':raise CostError('CURRENT_FUNDED_DEMAND_REQUIRED')
  rows=load(root,now=now);contexts={(c['account_id'],c['currency'],c['institution_id']) for c in demand.get('contexts',[]) if c.get('research_enabled') is True}
  registry,_=accounts(root)
  active=[]
  for row in rows.values():
   try:current_scope(row,registry)
   except CostError:continue
   if (row['account_id'],row['currency'],row['institution_id']) in contexts and timestamp(row['effective_from'])<=now<timestamp(row['effective_until']):active.append(row)
  return {**out,'reviewed_evidence_count':len(rows),'funded_account_context_count':len(contexts),'active_review_count':len(active),
   'complete_active_review_count':sum(all(r['components'][n]['status']!='UNKNOWN' for n in COMPONENTS) for r in active),'ledger_survey':ledger_survey(root)}
 except Exception as exc:return {**out,'status':'ACCOUNT_COST_INSPECTION_UNAVAILABLE','reviewed_evidence_count':None,'active_review_count':None,'complete_active_review_count':None,'error_type':type(exc).__name__}

def review_template(root,demand,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc))
 from .research_quote_acquisition_a24 import plan
 registry,_=accounts(root);planned=plan(root,demand,now=now,include_observed=True);rows=[]
 contexts={(c['account_id'],c['currency'],c['context_fingerprint']):c for c in demand['contexts'] if c.get('research_enabled') is True}
 for job in planned['jobs']:
  for funding in job['funding_contexts']:
   context=contexts[tuple(funding)];account=registry[context['account_id']]
   if account['currency']!=context['currency'] or account['institution_id']!=context['institution_id']:raise CostError('CURRENT_ACCOUNT_CONTEXT_MISMATCH')
   for side in ('BUY','SELL'):
    scope={'account_id':context['account_id'],'institution_id':context['institution_id'],'institution_country':account['_institution_country'],'instrument_id':job['binding']['instrument_id'],'currency':context['currency'],'side':side}
    rows.append({'schema':SCHEMA,'case_id':digest(scope),**scope,'execution_venue_id':None,'reference_amount':None,'evidence_id':None,'confirmed':False,'component_coverage_reviewed':False,'reviewed_by':None,'reviewed_at':None,'effective_from':None,'effective_until':None,
     'components':{n:{'status':'UNKNOWN','amount':None,'currency':context['currency'],'unit':'CURRENCY_AMOUNT','source_kind':None,'source_ref':None,'applicability_ref':None,'as_of':None} for n in COMPONENTS},**flags()})
 return {'schema':SCHEMA,'status':'UNFILLED_COST_REVIEW_TEMPLATE','reviews':sorted(rows,key=lambda r:r['case_id']),
  'notes':['LOCAL_REVIEW_ONLY_NOT_APPLIED','REFERENCE_AMOUNT_IS_AN_EXPLICIT_OPERATION_NOT_CASH_OR_BUDGET','EXECUTION_VENUE_IS_NOT_THE_MARKET_DATA_PROVIDER','UNKNOWN_COST_IS_NOT_ZERO'],**flags()}
