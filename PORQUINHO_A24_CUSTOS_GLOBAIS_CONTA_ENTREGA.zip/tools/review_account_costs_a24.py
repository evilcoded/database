"""Local review only: no HTTP, execution, fee append or automatic apply."""
import argparse,datetime as dt,json,os,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from universal_portfolio import account_cost_evidence_a24 as cost

def export(root,output,*,demand=None,now=None):
 root=Path(root).resolve();raw=Path(output).expanduser()
 if raw.is_symlink():raise cost.CostError('REVIEW_OUTPUT_SYMLINK_REFUSED')
 folder=raw.parent.resolve(strict=True);destination=folder/raw.name
 if destination.is_relative_to(root):raise cost.CostError('REVIEW_MUST_BE_OUTSIDE_PROJECT')
 if destination.exists():raise cost.CostError('EXISTING_REVIEW_PRESERVED')
 if demand is None:
  from universal_portfolio.universal_observation_bridge import build_read_only_bridge
  demand=build_read_only_bridge(root).intelligence.get('funded_currency_research') or {}
 body=cost.review_template(root,demand,now=now)
 data=(json.dumps(body,ensure_ascii=False,indent=2)+'\n').encode();fd,name=tempfile.mkstemp(prefix='.cost-review-',dir=folder)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
  os.link(name,destination)
 finally:
  if os.path.exists(name):os.unlink(name)
 return {'status':'UNFILLED_LOCAL_COST_REVIEW_CREATED','review_case_count':len(body['reviews']),'path':str(destination),'evidence_applied':False,'financial_mutation':False}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--root',default=str(ROOT));sub=parser.add_subparsers(dest='command',required=True)
 sub.add_parser('export').add_argument('--output',required=True);sub.add_parser('apply-reviewed').add_argument('--file',required=True);sub.add_parser('estimate').add_argument('--file',required=True)
 args=parser.parse_args()
 if args.command=='export':result=export(args.root,args.output)
 else:
  p=Path(args.file).expanduser()
  if p.is_symlink() or p.stat().st_size>2*1024*1024:raise cost.CostError('REVIEW_INPUT_REFUSED')
  document=json.loads(p.read_bytes());result=cost.apply_reviewed(args.root,document) if args.command=='apply-reviewed' else cost.estimate(args.root,document)
 print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':
 try:main()
 except Exception as exc:
  print(json.dumps({'status':'COST_REVIEW_NOT_COMPLETED','reason':str(exc) if isinstance(exc,cost.CostError) else type(exc).__name__,'financial_mutation':False},ensure_ascii=False));raise SystemExit(1)
