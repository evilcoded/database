"""Synthetic provider data, no network or actual account values."""
import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
from decimal import Decimal
from universal_portfolio import global_history_source_a24 as h,research_quote_acquisition_a24 as q
import test_a24_research_quote_acquisition as fixture
NOW=fixture.NOW
class History(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Acquisition();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root.resolve();self.f.save([self.f.rows()]);self.demand=self.f.demand();self.calls=[]
 def response(self,n=90):
  dates=[int((NOW-dt.timedelta(days=i)).replace(hour=0,minute=0,second=0,microsecond=0).timestamp()*1000) for i in range(n,0,-1)]
  return {'prices':[[stamp,Decimal('100.125')+i] for i,stamp in enumerate(dates)],'market_caps':[[stamp,1000+i] for i,stamp in enumerate(dates)],'total_volumes':[[stamp,100+i] for i,stamp in enumerate(dates)]}
 def get(self,path,params,timeout):self.calls.append((path,params,timeout));return self.response()
 def current(self):return {(c['account_id'],c['currency'],c['context_fingerprint']) for c in self.demand['contexts']}
 def collect(self,**kw):return h.collect(self.root,self.demand,now=NOW,transport=type('T',(),{'get_json':lambda obj,*a,**k:self.get(*a,**k)})(),revalidate=lambda:self.current(),**kw)
 def job(self):return h.plan(self.root,self.demand,now=NOW)['jobs'][0]
 def test_no_binding_no_network_or_store(self):
  self.f.save([]);self.assertEqual(self.collect()['network_requests'],0);self.assertFalse((self.root/h.STORE).exists())
 def test_daily_quotes_do_not_prevent_separate_history(self):
  self.f.collect();self.assertEqual(len(q.plan(self.root,self.demand,now=NOW)['jobs']),0);self.assertEqual(len(h.plan(self.root,self.demand,now=NOW)['jobs']),1)
 def test_collect_exact_source_quote_and_immutable_bundle(self):
  sentinel=self.root/'data/existing';sentinel.write_bytes(b'PRESERVE');out=self.collect();self.assertEqual(out['network_requests'],1);self.assertEqual(out['observations_created'],90);self.assertEqual(self.calls[0][1],{'vs_currency':'brl','days':365,'interval':'daily'});self.assertEqual(sentinel.read_bytes(),b'PRESERVE');self.assertFalse(out['training_requested'])
 def test_repeat_does_not_fetch_or_rewrite(self):
  self.collect();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};out=self.collect();self.assertEqual(out['network_requests'],0);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_multiple_accounts_deduplicate_one_source_request(self):
  self.demand=self.f.demand(duplicate_account=True);self.assertEqual(len(h.plan(self.root,self.demand,now=NOW)['jobs']),1)
 def test_one_source_request_per_cycle(self):
  self.f.save([self.f.rows(),self.f.rows(quote_currency='EUR')]);self.demand=self.f.demand(('BRL','EUR'));out=self.collect();self.assertEqual(out['network_requests'],1);self.assertEqual(len(h.plan(self.root,self.demand,now=NOW)['jobs']),1)
 def test_credential_or_provider_failure_backoff_no_secrets(self):
  def fail(*a,**k):raise q.AcquisitionError('PROVIDER_HTTP_429')
  self.get=fail;out=self.collect();self.assertEqual(out['provider_http_status'],429);self.assertEqual(self.collect()['network_requests'],0);self.assertEqual(len(h.plan(self.root,self.demand,now=NOW+dt.timedelta(hours=6))['jobs']),1)
 def test_funding_change_before_request_refused(self):
  self.current=lambda:set();self.assertEqual(self.collect()['network_requests'],0)
 def test_funding_change_after_request_no_bundle(self):
  old=self.get
  def changed(*a,**k):r=old(*a,**k);self.current=lambda:set();return r
  self.get=changed;out=self.collect();self.assertEqual(out['bundles_created'],0);self.assertEqual(out['network_requests'],1)
 def test_binding_change_during_request_no_bundle(self):
  old=self.get
  def changed(*a,**k):r=old(*a,**k);self.f.save([]);return r
  self.get=changed;self.assertEqual(self.collect()['bundles_created'],0)
 def test_exact_decimal_prices_preserved(self):self.assertEqual(h.points(self.response(1),NOW)[0]['price'],'100.125')
 def test_partial_current_day_excluded(self):
  r=self.response(2);r['prices'].append([int(NOW.timestamp()*1000),200]);self.assertEqual(len(h.points(r,NOW)),2)
 def test_duplicate_past_day_refused(self):
  r=self.response(2);r['prices'].append([r['prices'][0][0]+1000,200])
  with self.assertRaisesRegex(ValueError,'DUPLICATE_HISTORY_DAY'):h.points(r,NOW)
 def test_future_day_refused(self):
  r=self.response(2);r['prices'].append([int((NOW+dt.timedelta(days=1)).timestamp()*1000),200])
  with self.assertRaises(ValueError):h.points(r,NOW)
 def test_nonpositive_nonfinite_and_boolean_prices_refused(self):
  for value in (0,-1,'NaN','Infinity',True):
   r=self.response(1);r['prices'][0][1]=value
   with self.assertRaises(ValueError):h.points(r,NOW)
 def test_missing_optional_source_values_not_zero(self):self.assertIsNone(h.points({'prices':self.response(1)['prices']},NOW)[0]['market_cap'])
 def test_no_close_or_past_prediction_attestation(self):
  b=h.bundle(self.f.rows(),self.response(),now=NOW,binding_digest='digest');self.assertEqual(b['sampling'],h.SAMPLING);self.assertFalse(b['historical_row_attestation']);self.assertFalse(b['past_forecast_availability_attested']);self.assertEqual(b['fetched_at'],NOW.isoformat())
 def test_bundle_version_does_not_replace_previous_day(self):
  job=self.job();self.collect();old=h.path_for(self.root,job,NOW);before=old.read_bytes();out=h.collect(self.root,self.demand,now=NOW+dt.timedelta(days=1),transport=type('T',(),{'get_json':lambda obj,*a,**k:self.response()})(),revalidate=self.current);self.assertEqual(out['bundles_created'],1);self.assertEqual(old.read_bytes(),before)
 def test_tampered_bundle_refused(self):
  job=self.job();self.collect();p=h.path_for(self.root,job,NOW);raw=p.read_text();p.write_text(raw.replace('100.125','101.125'))
  with self.assertRaises(ValueError):h.read_sealed(p)
 def test_wrong_request_currency_not_relabelled(self):
  b=h.bundle(self.f.rows(),self.response(),now=NOW,binding_digest='digest');b['request_quote_currency']='EUR'
  with self.assertRaises(ValueError):h.validate_bundle(b)
 def test_existing_different_file_preserved(self):
  p=self.root/'new';h.store_once(p,{'one':1});before=p.read_bytes()
  with self.assertRaises(ValueError):h.store_once(p,{'one':2})
  self.assertEqual(p.read_bytes(),before)
 def test_store_symlink_refused(self):
  job=self.job();p=h.path_for(self.root,job,NOW);p.parent.mkdir(parents=True);target=self.root/'outside';target.write_text('{}');p.symlink_to(target)
  with self.assertRaises(ValueError):h.plan(self.root,self.demand,now=NOW)
 def test_transport_refuses_unrelated_paths(self):
  t=h.Transport.__new__(h.Transport);t._read_json=Mock()
  with self.assertRaises(ValueError):t.get_json('/simple/price',{},6)
  t._read_json.assert_not_called()
 def test_transport_passes_only_explicit_history_params(self):
  t=h.Transport.__new__(h.Transport);t._read_json=Mock(return_value={});t.get_json('/coins/source-id/market_chart',{'vs_currency':'jpy','days':365,'interval':'daily'},6);t._read_json.assert_called_once()
 def test_legacy_quote_transport_does_not_gain_history_permission(self):
  t=q.CoinGeckoTransport.__new__(q.CoinGeckoTransport);t._read_json=Mock()
  with self.assertRaises(ValueError):t.get_json('/coins/source-id/market_chart',{},6)
  t._read_json.assert_not_called()
 def test_plan_is_read_only(self):
  before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};h.plan(self.root,self.demand,now=NOW);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_summary_uses_latest_version_without_double_counting(self):
  self.collect();out=h.summary(self.root);self.assertEqual(out['source_pair_count'],1);self.assertEqual(out['latest_source_observation_count'],90);self.assertFalse(out['model_validation_proven'])

 def test_collector_lock_prevents_second_request(self):
  import fcntl
  directory=self.root/h.STORE;directory.mkdir(parents=True)
  with (directory/'collector.lock').open('w') as stream:
   fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);out=self.collect();self.assertEqual(out['status'],'HISTORY_COLLECTOR_BUSY');self.assertEqual(out['network_requests'],0)
 def test_failure_does_not_starve_other_source_pair(self):
  self.f.save([self.f.rows(),self.f.rows(quote_currency='EUR')]);self.demand=self.f.demand(('BRL','EUR'));original=self.get
  def fail(*a,**k):raise q.AcquisitionError('PROVIDER_HTTP_429')
  self.get=fail;self.collect();self.assertEqual(len(h.plan(self.root,self.demand,now=NOW)['jobs']),1);self.get=original;self.assertEqual(self.collect()['bundles_created'],1)
 def test_latest_bundle_only_counted_once_across_versions(self):
  job=self.job();yesterday=NOW-dt.timedelta(days=1);old=h.bundle(self.f.rows(),self.response(),now=yesterday,binding_digest='old-digest');h.store_once(h.path_for(self.root,job,yesterday),old);self.collect();summary=h.summary(self.root);self.assertEqual(summary['bundle_count'],2);self.assertEqual(summary['source_pair_count'],1);self.assertEqual(summary['latest_source_observation_count'],90)
 def test_oversized_document_not_written(self):
  path=self.root/'oversized'
  with self.assertRaises(ValueError):h.store_once(path,{'oversized':'x'*(2*1024*1024)})
  self.assertFalse(path.exists())
 def test_actual_normal_cycle_hook_uses_funded_research_context(self):
  import ast,types
  source=Path(__file__).resolve().parents[1]/'webapp/server.py';tree=ast.parse(source.read_text());refresh=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_refresh')
  imp=next(n for n in ast.walk(refresh) if isinstance(n,ast.ImportFrom) and n.module=='universal_portfolio.global_history_source_a24')
  assignment=next(n for n in ast.walk(refresh) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_a24_collect_history')
  ns={'ROOT':self.root,'universal_shadow':{},'_universal_result':types.SimpleNamespace(bridge=types.SimpleNamespace(intelligence={'funded_currency_research':self.demand}))}
  with patch.object(h,'collect',return_value={'status':'HOOK_TEST_ONLY'}) as collect:exec(compile(ast.Module(body=[imp,assignment],type_ignores=[]),'actual_history_hook','exec'),ns)
  collect.assert_called_once_with(self.root,self.demand);self.assertEqual(ns['universal_shadow']['global_history_acquisition']['status'],'HOOK_TEST_ONLY')
