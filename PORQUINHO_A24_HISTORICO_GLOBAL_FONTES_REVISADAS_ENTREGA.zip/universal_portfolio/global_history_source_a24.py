"""Historical provider observations acquired now, in an isolated research store.
No retrospective identity attribution, forecasts, learning or financial authority.
"""
import datetime as dt,fcntl,hashlib,json,math,os,re,tempfile
from decimal import Decimal
from pathlib import Path
from . import research_quote_acquisition_a24 as quotes
from .explicit_market_bindings_a24 import local,digest,canonical,load
SCHEMA='porquinho.global-history-source-a24/1.0'
STORE='data/brain/global_history_source_a24'
SAMPLING='PROVIDER_HISTORICAL_DAILY_OBSERVATION_NOT_CLOSE'
class HistoryError(ValueError):pass

def series_id(binding):
 return digest({**{k:binding[k] for k in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref','confirmed_at','effective_from')},'requested_days':365,'sampling':SAMPLING})
def path_for(root,job,now,attempt=False):
 key=series_id(job['binding'])
 rel=(f'attempts/{now.date().isoformat()}/{key}-{now.hour//6}.json' if attempt else f'bundles/{key}/{now.date().isoformat()}.json')
 return local(root,STORE+'/'+rel)

def read_sealed(path):
 stat=path.stat()
 if stat.st_size>2*1024*1024:raise HistoryError('HISTORY_FILE_SIZE_LIMIT')
 raw=path.read_bytes()
 if (stat.st_size,stat.st_mtime_ns,stat.st_ino)!=(path.stat().st_size,path.stat().st_mtime_ns,path.stat().st_ino):raise HistoryError('HISTORY_CHANGED_DURING_READ')
 obj=json.loads(raw)
 if not isinstance(obj,dict) or set(obj)!={'body','sha256'} or digest(obj['body'])!=obj['sha256']:raise HistoryError('HISTORY_DIGEST_MISMATCH')
 return obj['body']

def store_once(path,body):
 path.parent.mkdir(parents=True,exist_ok=True)
 if path.is_symlink():raise HistoryError('HISTORY_SYMLINK_REFUSED')
 raw=(canonical({'body':body,'sha256':digest(body)})+'\n').encode()
 if len(raw)>2*1024*1024:raise HistoryError('HISTORY_FILE_SIZE_LIMIT')
 if path.exists():
  if path.read_bytes()!=raw:raise HistoryError('EXISTING_HISTORY_PRESERVED')
  return False
 fd,name=tempfile.mkstemp(prefix='.history-',dir=path.parent)
 try:
  with os.fdopen(fd,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
  try:os.link(name,path)
  except FileExistsError:raise HistoryError('EXISTING_HISTORY_PRESERVED')
 finally:
  if os.path.exists(name):os.unlink(name)
 return True

def points(response,now):
 if not isinstance(response,dict) or not isinstance(response.get('prices'),list) or not 1<=len(response['prices'])<=400:raise HistoryError('HISTORY_PRICES_REQUIRED')
 def values(name,required=False):
  data=response.get(name,[])
  if not isinstance(data,list) or len(data)>400:raise HistoryError('HISTORY_SERIES_INVALID')
  out={}
  for item in data:
   if not isinstance(item,list) or len(item)!=2 or isinstance(item[0],bool):raise HistoryError('HISTORY_POINT_INVALID')
   try:
    ms=Decimal(str(item[0]));value=Decimal(str(item[1]))
    if not ms.is_finite() or ms!=ms.to_integral_value() or isinstance(item[1],bool) or not value.is_finite() or value<0 or (required and value==0):raise ValueError()
    at=dt.datetime.fromtimestamp(int(ms)/1000,dt.timezone.utc)
   except Exception:raise HistoryError('HISTORY_POINT_INVALID')
   if at.date()==now.date():continue # The current provider day may be incomplete.
   if at>now:raise HistoryError('HISTORY_FUTURE_POINT')
   if at.date()<now.date()-dt.timedelta(days=366):raise HistoryError('HISTORY_OUTSIDE_REQUEST_WINDOW')
   if int(ms) in out:raise HistoryError('DUPLICATE_HISTORY_TIMESTAMP')
   out[int(ms)]=(at,value)
  return out
 prices=values('prices',True);caps=values('market_caps');volumes=values('total_volumes');seen=set();out=[]
 for ms,(at,price) in sorted(prices.items()):
  day=at.date().isoformat()
  if day in seen:raise HistoryError('DUPLICATE_HISTORY_DAY')
  seen.add(day)
  out.append({'observation_date':day,'provider_observed_at':at.isoformat(),'price':str(price),
   'market_cap':str(caps[ms][1]) if ms in caps else None,'volume_24h':str(volumes[ms][1]) if ms in volumes else None})
 if not out:raise HistoryError('NO_COMPLETE_HISTORY_DAYS')
 return out

class Transport(quotes.CoinGeckoTransport):
 def get_json(self,path,params,timeout):
  if not re.fullmatch('/coins/[a-z0-9][a-z0-9_-]{0,127}/market_chart',path):raise HistoryError('HISTORY_PROVIDER_PATH_REFUSED')
  if set(params)!={'vs_currency','days','interval'} or params['days']!=365 or params['interval']!='daily' or not isinstance(params['vs_currency'],str) or not re.fullmatch('[a-z]+',params['vs_currency']):raise HistoryError('HISTORY_PROVIDER_PARAMS_REFUSED')
  return self._read_json(path,params,timeout)

def plan(root,demand,*,now=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc))
 q=quotes.plan(root,demand,now=now,include_observed=True);jobs=[];done=deferred=0
 for job in q['jobs']:
  p=path_for(root,job,now)
  if p.exists():validate_bundle(read_sealed(p),p);done+=1;continue
  attempt=path_for(root,job,now,True)
  if attempt.exists():
   body=read_sealed(attempt)
   if body.get('schema')!=SCHEMA or body.get('series_id')!=series_id(job['binding']) or body.get('requested_at','')[:10]!=now.date().isoformat():raise HistoryError('HISTORY_ATTEMPT_INVALID')
   deferred+=1;continue
  jobs.append(job)
 return {'status':'HISTORY_JOBS_PLANNED' if jobs else 'NO_ELIGIBLE_HISTORY_JOBS','jobs':sorted(jobs,key=lambda j:series_id(j['binding'])),
  'already_acquired_today':done,'deferred_in_six_hour_window':deferred,'blocked_reason_counts':q['blocked_reason_counts'],
  'binding_digest':q['binding_digest'],'network_requests':0,'training_requested':False,'financial_mutation':False}

def bundle(binding,response,*,now,binding_digest):
 records=points(response,now)
 raw=json.loads(json.dumps(response,default=str,allow_nan=False))
 return {'schema':SCHEMA,'kind':'HISTORICAL_PROVIDER_RESPONSE_ACQUIRED_NOW','series_id':series_id(binding),'binding':dict(binding),
  'fetched_at':now.isoformat(),'binding_digest':binding_digest,'requested_days':365,'requested_interval':'daily',
  'request_path':'/coins/'+binding['provider_id']+'/market_chart','request_quote_currency':binding['quote_currency'],
  'sampling':SAMPLING,'pricing_method':'PROVIDER_REPORTED_REQUESTED_CURRENCY','source_response':raw,'decoded_response_sha256':digest(raw),
  'observations':records,'authority':'RESEARCH_ONLY','economic_comparison_status':'NOT_VALIDATED',
  'historical_row_attestation':False,'past_forecast_availability_attested':False,'independent_archive_verified':False,
  'provider_internal_fx_verified':False,'training_requested':False,'financial_mutation':False,'canonical_publication_authorized':False,'execution_authorized':False}

def validate_bundle(body,path=None):
 if body.get('schema')!=SCHEMA or body.get('kind')!='HISTORICAL_PROVIDER_RESPONSE_ACQUIRED_NOW' or body.get('authority')!='RESEARCH_ONLY' or body.get('economic_comparison_status')!='NOT_VALIDATED':raise HistoryError('HISTORY_CONTRACT_INVALID')
 for key in ('historical_row_attestation','past_forecast_availability_attested','independent_archive_verified','provider_internal_fx_verified','training_requested','financial_mutation','canonical_publication_authorized','execution_authorized'):
  if body.get(key) is not False:raise HistoryError('HISTORY_AUTHORITY_INVALID')
 now=quotes.utc(dt.datetime.fromisoformat(body['fetched_at']));expected=bundle(body['binding'],body['source_response'],now=now,binding_digest=body['binding_digest'])
 if expected!=body:raise HistoryError('HISTORY_PROJECTION_MISMATCH')
 if path is not None and (path.stem!=now.date().isoformat() or path.parent.name!=body['series_id']):raise HistoryError('HISTORY_PATH_MISMATCH')
 return body

def collect(root,demand,*,now=None,transport=None,revalidate=None):
 test_clock=now is not None;now=quotes.utc(now or dt.datetime.now(dt.timezone.utc));calls=0;owned=False;handle=None
 result={'status':'HISTORY_NOT_REQUESTED','network_requests':0,'bundles_created':0,'observations_created':0,'training_requested':False,
  'financial_mutation':False,'canonical_publication_authorized':False,'execution_authorized':False,'legacy_store_written':False}
 try:
  prepared=plan(root,demand,now=now)
  if not prepared['jobs']:return {**result,**{k:v for k,v in prepared.items() if k not in ('jobs','binding_digest')}}
  directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True);lock=local(root,STORE+'/collector.lock')
  fd=os.open(lock,os.O_CREAT|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600);handle=os.fdopen(fd,'w')
  try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return {**result,'status':'HISTORY_COLLECTOR_BUSY'}
  prepared=plan(root,demand,now=now)
  if not prepared['jobs']:return {**result,'status':'NO_ELIGIBLE_HISTORY_JOBS'}
  job=prepared['jobs'][0];binding=job['binding'];revalidate=revalidate or (lambda:quotes.current_contexts(root))
  def valid():
   current=revalidate()
   return all(tuple(c) in current for c in job['funding_contexts']) and digest(load(root))==prepared['binding_digest']
  if not valid():raise HistoryError('HISTORY_ELIGIBILITY_CHANGED')
  try:
   if transport is None:transport=Transport(root);owned=True
   calls+=1;response=transport.get_json('/coins/'+binding['provider_id']+'/market_chart',{'vs_currency':binding['quote_currency'].lower(),'days':365,'interval':'daily'},timeout=6)
   fetched=now if test_clock else dt.datetime.now(dt.timezone.utc)
   if fetched.date()!=now.date():raise HistoryError('HISTORY_ACQUISITION_DAY_CHANGED')
   data=bundle(binding,response,now=fetched,binding_digest=prepared['binding_digest'])
   if not valid():raise HistoryError('HISTORY_ELIGIBILITY_CHANGED')
   created=store_once(path_for(root,job,fetched),data)
   result.update(status='HISTORY_SOURCE_RECORDED_RESEARCH_ONLY',bundles_created=int(created),observations_created=len(data['observations']) if created else 0)
  except Exception as exc:
   result.update(status='HISTORY_SOURCE_UNAVAILABLE',error_type=type(exc).__name__)
   code=str(exc)
   if re.fullmatch('PROVIDER_HTTP_[0-9]{3}',code):result['provider_http_status']=int(code[-3:])
  store_once(path_for(root,job,now,True),{'schema':SCHEMA,'series_id':series_id(binding),'requested_at':now.isoformat(),'outcome':result['status'],'provider_http_status':result.get('provider_http_status'),'error_type':result.get('error_type')})
 except Exception as exc:result.update(status='HISTORY_ACQUISITION_UNAVAILABLE',error_type=type(exc).__name__)
 finally:
  if owned and transport is not None:transport.close()
  if handle is not None:handle.close()
 result['network_requests']=calls
 return result

def summary(root):
 result={'schema':SCHEMA,'status':'NO_GLOBAL_HISTORY_BUNDLES','bundle_count':0,'source_pair_count':0,'latest_source_observation_count':0,
  'source_pairs_with_31_observations':0,'attempts_today':0,'attempt_outcome_counts':{},'provider_http_status_counts':{},'authority':'RESEARCH_ONLY','historical_row_attestation':False,'training_requested':False,
  'model_validation_proven':False,'canonical_publication_authorized':False,'execution_authorized':False,'financial_mutation':False,'legacy_store_written':False}
 try:
  today=dt.datetime.now(dt.timezone.utc).date().isoformat()
  attempts=local(root,STORE+'/attempts/'+today)
  files=sorted(attempts.glob('*.json')) if attempts.exists() else []
  if len(files)>4096:raise HistoryError('HISTORY_ATTEMPT_READ_LIMIT')
  counts={};http={}
  for path in files:
   path=local(root,str(path.relative_to(Path(root).resolve())));a=read_sealed(path)
   if a.get('schema')!=SCHEMA or a.get('requested_at','')[:10]!=today or a.get('outcome') not in ('HISTORY_SOURCE_RECORDED_RESEARCH_ONLY','HISTORY_SOURCE_UNAVAILABLE'):raise HistoryError('HISTORY_ATTEMPT_INVALID')
   counts[a['outcome']]=counts.get(a['outcome'],0)+1
   code=a.get('provider_http_status')
   if code is not None:
    if type(code) is not int or not 100<=code<=599:raise HistoryError('HISTORY_ATTEMPT_INVALID')
    http[str(code)]=http.get(str(code),0)+1
  result.update(attempts_today=len(files),attempt_outcome_counts=counts,provider_http_status_counts=http)
  directory=local(root,STORE+'/bundles')
  if not directory.exists():return result
  paths=sorted(directory.glob('*/*.json'))
  if len(paths)>4096 or sum(p.stat().st_size for p in paths)>64*1024*1024:raise HistoryError('HISTORY_READ_LIMIT')
  latest={};before={p:(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in paths}
  for path in paths:
   p=local(root,str(path.relative_to(Path(root).resolve())));body=validate_bundle(read_sealed(p),p)
   key=body['series_id']
   if key not in latest or body['fetched_at']>latest[key]['fetched_at']:latest[key]=body
  after_paths=sorted(directory.glob('*/*.json'))
  if paths!=after_paths or before!={p:(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in paths}:raise HistoryError('HISTORY_CHANGED_DURING_READ')
  return {**result,'status':'GLOBAL_HISTORY_SOURCES_OBSERVED_RESEARCH_ONLY' if paths else result['status'],'bundle_count':len(paths),'source_pair_count':len(latest),
   'latest_source_observation_count':sum(len(b['observations']) for b in latest.values()),'source_pairs_with_31_observations':sum(len(b['observations'])>=31 for b in latest.values())}
 except Exception as exc:return {**result,'status':'GLOBAL_HISTORY_INSPECTION_UNAVAILABLE','bundle_count':None,'source_pair_count':None,'latest_source_observation_count':None,'source_pairs_with_31_observations':None,'error_type':type(exc).__name__}
