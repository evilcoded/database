"""Funded-currency acquisition into a separate immutable research observation journal.

No symbol resolution, FX, model training, canonical promotion or financial orders.
"""
import datetime as dt
import fcntl,hashlib,json,math,os,re,time
from decimal import Decimal
from pathlib import Path
from urllib.parse import urlsplit
from .explicit_market_bindings_a24 import load,local,canonical,digest,text

SCHEMA='porquinho.research-quote-observation-a24/1.0'
STORE='data/brain/research_quote_observations_a24'
DEMAND_SCHEMA='porquinho.funded-currency-research-a24/1.0'
class AcquisitionError(ValueError):pass

def utc(value):
 if not isinstance(value,dt.datetime) or value.tzinfo is None or value.utcoffset() is None:raise AcquisitionError('AWARE_UTC_TIME_REQUIRED')
 return value.astimezone(dt.timezone.utc)
def key(row):return (row['instrument_id'],row['provider'].lower(),row['provider_id'],row['quote_currency'],row['observation_date'])
def record_id(row):return digest(list(key(row)))
def validate_observation(row):
 if not isinstance(row,dict) or row.get('schema')!=SCHEMA:raise AcquisitionError('OBSERVATION_SCHEMA_INVALID')
 for k in ('instrument_id','provider','provider_id','quote_currency','observation_date','identity_source_ref','fetched_at','provider_observed_at','binding_digest','response_sha256'):
  if not text(row.get(k)):raise AcquisitionError('OBSERVATION_FIELDS_REQUIRED')
 q=row['quote_currency']
 if not q.isascii() or not q.isalpha() or not q.isupper():raise AcquisitionError('QUOTE_INVALID')
 try:
  if not isinstance(row['price'],str):raise ValueError()
  price=Decimal(row['price']);day=dt.date.fromisoformat(row['observation_date'])
  fetched=utc(dt.datetime.fromisoformat(row['fetched_at']));observed=utc(dt.datetime.fromisoformat(row['provider_observed_at']))
 except Exception:raise AcquisitionError('OBSERVATION_PRICE_OR_TIME_INVALID')
 if not price.is_finite() or price<=0 or day!=observed.date() or fetched.date()!=day or not -30<=(fetched-observed).total_seconds()<=1800:raise AcquisitionError('OBSERVATION_PRICE_OR_TIME_INVALID')
 if row.get('authority')!='RESEARCH_ONLY' or row.get('economic_comparison_status')!='NOT_VALIDATED':raise AcquisitionError('OBSERVATION_AUTHORITY_INVALID')
 if row.get('pricing_method')!='PROVIDER_REPORTED_REQUESTED_CURRENCY' or row.get('sampling')!='FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE':raise AcquisitionError('OBSERVATION_UNIT_OR_SAMPLING_INVALID')
 for name in ('market_cap','volume_24h'):
  value=row.get(name)
  if value is not None:
   if not isinstance(value,str):raise AcquisitionError('OBSERVATION_OPTIONAL_VALUE_INVALID')
   try:n=Decimal(value)
   except Exception:raise AcquisitionError('OBSERVATION_OPTIONAL_VALUE_INVALID')
   if not n.is_finite() or n<0:raise AcquisitionError('OBSERVATION_OPTIONAL_VALUE_INVALID')
 for k in ('execution_authorized','automatic_execution_authorized','independent_archive_verified','fx_performed','provider_internal_fx_verified','source_availability_attested'):
  if row.get(k) is not False:raise AcquisitionError('OBSERVATION_AUTHORITY_INVALID')
 if row.get('record_id')!=record_id(row):raise AcquisitionError('OBSERVATION_ID_INVALID')

def storage_path(root,day):
 if isinstance(day,dt.date):day=day.isoformat()
 dt.date.fromisoformat(day)
 return local(root,STORE+'/'+day+'.jsonl')

def read_records(root,day=None):
 directory=local(root,STORE)
 if not directory.exists():return []
 if not directory.is_dir():raise AcquisitionError('OBSERVATION_DIRECTORY_REQUIRED')
 paths=[storage_path(root,day)] if day is not None else sorted(directory.glob('*.jsonl'))
 out=[];seen=set()
 for path in paths:
  p=storage_path(root,path.stem)
  if not p.exists():continue
  if p.stat().st_size>256*1024*1024:raise AcquisitionError('OBSERVATION_DAILY_STORE_LIMIT')
  previous='GENESIS'
  with p.open(encoding='utf-8') as stream:
   for line in stream:
    if len(line)>65536 or not line.endswith('\n'):raise AcquisitionError('PARTIAL_OBSERVATION_LINE')
    item=json.loads(line);body=item['body'];validate_observation(body)
    if body['observation_date']!=p.stem:raise AcquisitionError('OBSERVATION_PARTITION_DATE_MISMATCH')
    expected=hashlib.sha256((previous+'|'+canonical(body)).encode()).hexdigest()
    if item.get('previous_hash')!=previous or item.get('hash')!=expected:raise AcquisitionError('OBSERVATION_CHAIN_INVALID')
    if body['record_id'] in seen:raise AcquisitionError('DUPLICATE_OBSERVATION_ID')
    seen.add(body['record_id']);previous=expected;out.append(body)
 return out

def append_records(root,rows):
 if not rows:return 0
 seen=set()
 for row in rows:
  validate_observation(row)
  if row['record_id'] in seen:raise AcquisitionError('DUPLICATE_OBSERVATION_BATCH')
  seen.add(row['record_id'])
 days={row['observation_date'] for row in rows}
 if len(days)!=1:raise AcquisitionError('OBSERVATION_BATCH_DAY_NOT_UNIQUE')
 day=next(iter(days));p=storage_path(root,day);p.parent.mkdir(parents=True,exist_ok=True)
 # Lock is distinct from the journal inode; readers never create lock files.
 lock=local(root,STORE+'/'+day+'.lock')
 fd=os.open(lock,os.O_WRONLY|os.O_CREAT,0o600)
 with os.fdopen(fd,'w') as handle:
  fcntl.flock(handle,fcntl.LOCK_EX)
  existing=read_records(root,day=day);ids={r['record_id'] for r in existing};pending=[r for r in rows if r['record_id'] not in ids]
  if not pending:return 0
  previous='GENESIS'
  if p.exists():
   with p.open(encoding='utf-8') as stream:
    for line in stream:previous=json.loads(line)['hash']
  batch=[]
  for row in pending:
   h=hashlib.sha256((previous+'|'+canonical(row)).encode()).hexdigest()
   batch.append(canonical({'previous_hash':previous,'hash':h,'body':row})+'\n');previous=h
  fd=os.open(p,os.O_WRONLY|os.O_APPEND|os.O_CREAT,0o600)
  with os.fdopen(fd,'w',encoding='utf-8') as stream:stream.write(''.join(batch));stream.flush();os.fsync(stream.fileno())
 return len(pending)

def plan(root,demand,*,now=None,include_observed=False):
 now=utc(now or dt.datetime.now(dt.timezone.utc));blocked={};jobs={}
 def refuse(reason):blocked[reason]=blocked.get(reason,0)+1
 if demand.get('schema')!=DEMAND_SCHEMA or demand.get('status')!='OBSERVATION_DEMAND_PROJECTED' or demand.get('authority')!='NONE' or demand.get('automatic_execution_authorized') is not False:
  raise AcquisitionError('FUNDED_DEMAND_INVALID')
 contexts={(c['account_id'],c['currency']):c for c in demand['contexts'] if c.get('research_enabled') is True and c.get('execution_authorized') is False and c.get('automatic_execution_authorized') is False}
 document=load(root);bindings=document['bindings'];by={}
 for b in bindings:by.setdefault((b['instrument_id'],b['quote_currency']),[]).append(b)
 existing=set() if include_observed else {key(r) for r in read_records(root,day=now.date())};already=0
 requests=demand['research_requests']
 if not isinstance(requests,list) or len(requests)>20000:raise AcquisitionError('RESEARCH_DEMAND_LIMIT')
 for request in requests:
  ctx=contexts.get((request.get('account_id'),request.get('quote_currency')))
  if ctx and digest({k:v for k,v in ctx.items() if k!='context_fingerprint'})!=ctx.get('context_fingerprint'):
   refuse('FUNDING_CONTEXT_FINGERPRINT_INVALID');continue
  if not ctx or ctx.get('context_fingerprint')!=request.get('context_fingerprint') or request.get('purpose')!='OBSERVE_AND_MATURE_ONLY' or request.get('execution_authorized') is not False or request.get('automatic_execution_authorized') is not False:
   refuse('FUNDING_CONTEXT_INVALID');continue
  classes=ctx.get('allowed_asset_classes_from_active_plans') or []
  if classes and request.get('candidate_asset_class') not in classes:refuse('OUTSIDE_ACTIVE_PLAN_CLASSES');continue
  found=by.get((request.get('instrument_id'),request.get('quote_currency')),[])
  if not found:refuse('EXPLICIT_PROVIDER_QUOTE_BINDING_REQUIRED');continue
  # No arbitrary preference if multiple sources could satisfy the same request.
  if len(found)!=1:refuse('EXPLICIT_SOURCE_SELECTION_REQUIRED');continue
  b=found[0]
  if dt.date.fromisoformat(b['effective_from'])>now.date():refuse('BINDING_NOT_EFFECTIVE');continue
  if b['provider'].lower()!='coingecko':refuse('PROVIDER_ADAPTER_NOT_IMPLEMENTED');continue
  if not re.fullmatch('[a-z0-9][a-z0-9_-]{0,127}',b['provider_id']):refuse('PROVIDER_REQUEST_ID_INVALID');continue
  k=(b['instrument_id'],b['provider'].lower(),b['provider_id'],b['quote_currency'],now.date().isoformat())
  if k in existing:already+=1;continue
  job=jobs.setdefault(k,{'binding':dict(b),'funding_contexts':[]})
  pair=(ctx['account_id'],ctx['currency'],ctx['context_fingerprint'])
  if pair not in job['funding_contexts']:job['funding_contexts'].append(pair)
 return {'status':'PLANNED' if jobs else 'NO_ELIGIBLE_ACQUISITION_JOBS','jobs':list(jobs.values()),'blocked_reason_counts':blocked,
         'already_observed_request_count':already,'binding_digest':digest(document),'network_requests':0,
         'automatic_execution_authorized':False,'financial_mutation':False}

class CoinGeckoTransport:
 def __init__(self,root):
  import requests
  p=local(root,'config.json')
  config=json.loads(p.read_text()) if p.exists() else {}
  provider=config.get('provider') or {};base=provider.get('base_url') or 'https://api.coingecko.com/api/v3'
  u=urlsplit(base)
  if u.scheme!='https' or u.hostname not in {'api.coingecko.com','pro-api.coingecko.com'} or u.port is not None or u.username or u.password or u.query or u.fragment or u.path.rstrip('/')!='/api/v3':raise AcquisitionError('PROVIDER_ENDPOINT_NOT_ALLOWED')
  self.base=base.rstrip('/');self.session=requests.Session();self.session.headers.update({'accept':'application/json','user-agent':'Porquinho-A24-Research'})
  from .provider_credentials import resolve_provider_secret
  secret=resolve_provider_secret('coingecko',root=Path(root),env_fallback=provider.get('api_key_env','COINGECKO_API_KEY'))
  if secret:self.session.headers['x-cg-pro-api-key' if u.hostname=='pro-api.coingecko.com' else 'x-cg-demo-api-key']=secret
 def get_json(self,path,params,timeout):
  if path not in ('/simple/supported_vs_currencies','/simple/price'):raise AcquisitionError('PROVIDER_PATH_NOT_ALLOWED')
  return self._read_json(path,params,timeout)
 def _read_json(self,path,params,timeout):
  with self.session.get(self.base+path,params=params,timeout=timeout,allow_redirects=False,stream=True) as response:
   if response.status_code!=200:raise AcquisitionError('PROVIDER_HTTP_'+str(response.status_code))
   raw=bytearray();deadline=time.monotonic()+timeout
   for part in response.iter_content(4096):
    if time.monotonic()>deadline:raise AcquisitionError('PROVIDER_READ_DEADLINE')
    raw.extend(part)
    if len(raw)>2*1024*1024:raise AcquisitionError('PROVIDER_RESPONSE_LIMIT')
   return json.loads(raw,parse_float=Decimal)
 def close(self):self.session.close()

def current_contexts(root):
 from .funded_currency_research_a24 import build
 out=build(root)
 if out.get('status')!='OBSERVATION_DEMAND_PROJECTED':raise AcquisitionError('FUNDING_REVALIDATION_UNAVAILABLE')
 return {(c['account_id'],c['currency'],c['context_fingerprint']) for c in out['contexts'] if c.get('research_enabled') is True}

def collect(root,demand,*,now=None,transport=None,revalidate=None,max_jobs=50):
 explicit_test_clock=now is not None
 now=utc(now or dt.datetime.now(dt.timezone.utc));started=time.monotonic();owned=False;calls=0
 def base(status,**extra):
  return {'status':status,'observations_created':0,'network_requests':calls,'financial_mutation':False,
          'execution_performed':False,'automatic_execution_authorized':False,'canonical_publication_authorized':False,
          'training_requested':False,**extra}
 try:
  prepared=plan(root,demand,now=now);jobs=prepared['jobs']
  if not jobs:return base('NO_ELIGIBLE_ACQUISITION_JOBS',blocked_reason_counts=prepared['blocked_reason_counts'],already_observed_request_count=prepared['already_observed_request_count'])
  if not isinstance(max_jobs,int) or isinstance(max_jobs,bool) or not 1<=max_jobs<=100:raise AcquisitionError('ACQUISITION_BATCH_LIMIT_INVALID')
  revalidate=revalidate or (lambda:current_contexts(root))
  def valid(selected):
   current=revalidate()
   return all(tuple(c) in current for j in selected for c in j['funding_contexts'])
  if not valid(jobs):raise AcquisitionError('FUNDING_CONTEXT_CHANGED')
  if transport is None:transport=CoinGeckoTransport(root);owned=True
  calls+=1;supported=transport.get_json('/simple/supported_vs_currencies',{},timeout=6)
  if not isinstance(supported,list) or not all(isinstance(x,str) for x in supported):raise AcquisitionError('SUPPORTED_QUOTES_INVALID')
  supported=set(supported);eligible=[j for j in jobs if j['binding']['quote_currency'].lower() in supported]
  unsupported=len(jobs)-len(eligible)
  if not eligible:return base('PROVIDER_QUOTES_UNAVAILABLE',unsupported_quote_job_count=unsupported)
  offset=(int(now.timestamp()//600)*max_jobs)%len(eligible);ordered=eligible[offset:]+eligible[:offset];selected=ordered[:max_jobs]
  if time.monotonic()-started>8:raise AcquisitionError('ACQUISITION_TIME_BUDGET_EXCEEDED')
  params={'ids':','.join(sorted({j['binding']['provider_id'] for j in selected})),
          'vs_currencies':','.join(sorted({j['binding']['quote_currency'].lower() for j in selected})),
          'include_last_updated_at':'true','include_market_cap':'true','include_24hr_vol':'true','precision':'full'}
  calls+=1;response=transport.get_json('/simple/price',params,timeout=6)
  if not isinstance(response,dict):raise AcquisitionError('PRICE_RESPONSE_INVALID')
  response_hash=hashlib.sha256(json.dumps(response,sort_keys=True,separators=(',',':'),default=str,allow_nan=False).encode()).hexdigest()
  fetched=now if explicit_test_clock else dt.datetime.now(dt.timezone.utc)
  rows=[];rejected=0
  for job in selected:
   b=job['binding'];data=response.get(b['provider_id']);data=data if isinstance(data,dict) else {}
   price=data.get(b['quote_currency'].lower());stamp=data.get('last_updated_at')
   if isinstance(price,bool) or not isinstance(price,(int,float,Decimal)) or not Decimal(str(price)).is_finite() or Decimal(str(price))<=0 or isinstance(stamp,bool) or not isinstance(stamp,(int,float,Decimal)):
    rejected+=1;continue
   try:observed=dt.datetime.fromtimestamp(float(stamp),dt.timezone.utc)
   except (ValueError,OverflowError,OSError):rejected+=1;continue
   age=(fetched-observed).total_seconds()
   if age < -30 or age>1800 or observed.date()!=fetched.date():rejected+=1;continue
   row={k:b[k] for k in ('instrument_id','provider','provider_id','quote_currency','identity_source_ref')}
   row.update(schema=SCHEMA,observation_date=observed.date().isoformat(),provider_observed_at=observed.isoformat(),fetched_at=fetched.isoformat(),
              price=str(Decimal(str(price))),binding_digest=prepared['binding_digest'],response_sha256=response_hash,
              pricing_method='PROVIDER_REPORTED_REQUESTED_CURRENCY',provider_internal_fx_verified=False,source_availability_attested=False,
              authority='RESEARCH_ONLY',economic_comparison_status='NOT_VALIDATED',execution_authorized=False,
              automatic_execution_authorized=False,independent_archive_verified=False,fx_performed=False)
   def optional_value(value):
    if isinstance(value,bool) or not isinstance(value,(int,float,Decimal)):return None
    v=Decimal(str(value));return str(v) if v.is_finite() and v>=0 else None
   row.update(market_cap=optional_value(data.get(b['quote_currency'].lower()+'_market_cap')),
              volume_24h=optional_value(data.get(b['quote_currency'].lower()+'_24h_vol')),
              sampling='FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE',
              volume_semantics='PROVIDER_ROLLING_24H_NOT_CALENDAR_DAY_TOTAL')
   row['record_id']=record_id(row);rows.append(row)
  if time.monotonic()-started>15:raise AcquisitionError('ACQUISITION_TIME_BUDGET_EXCEEDED')
  if not valid(selected) or digest(load(root))!=prepared['binding_digest']:raise AcquisitionError('FUNDING_OR_BINDING_CHANGED_BEFORE_RECORDING')
  created=append_records(root,rows)
  return base('RESEARCH_OBSERVATIONS_RECORDED' if created else 'NO_NEW_VALID_OBSERVATIONS',observations_created=created,
              rejected_quote_job_count=rejected,unsupported_quote_job_count=unsupported,deferred_job_count=len(eligible)-len(selected),
              blocked_reason_counts=prepared['blocked_reason_counts'])
 except Exception as exc:
  return base('ACQUISITION_FAILED_CLOSED',reason=str(exc) if isinstance(exc,AcquisitionError) else type(exc).__name__)
 finally:
  if owned and transport is not None:
   try:transport.close()
   except Exception:pass
