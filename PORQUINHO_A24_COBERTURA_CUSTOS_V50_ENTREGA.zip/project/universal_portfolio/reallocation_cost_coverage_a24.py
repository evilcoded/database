"""Read-only exact-notional cost coverage. No quote scaling or documentary promotion."""
from decimal import Decimal,localcontext
from collections import Counter
from .account_cost_evidence_a24 import COMPONENTS,number
from .commission_funding_a24 import return_number

def leg(row,hypothesis,side,account,reviews):
    source=side=='SELL';iid=row['source_instrument_id' if source else 'destination_instrument_id']
    amount=number(hypothesis['source_sale_reference_amount' if source else 'destination_reference_amount'],True)
    candidates=[r for r in reviews if r.get('account_id')==row['account_id'] and r.get('instrument_id')==iid
                and r.get('currency')==row['currency'] and r.get('side')==side
                and r.get('institution_id')==account['institution_id']
                and r.get('institution_country')==account['_institution_country']
                and r.get('pricing_plan')==account.get('pricing_plan') and bool(r.get('pricing_plan'))
                and number(r['reference_amount'],True)==amount]
    documentary=next((x for x in row.get('documented_tariff_provisions',{}).get('legs',[]) if x.get('side')==side),{})
    conditional=hypothesis.get('conditional_category') is True
    components={n:{'status':'DOCUMENTED_CONDITIONAL_REFERENCE' if conditional else 'DOCUMENTED_REFERENCE',
                   'amount':hypothesis['sell_commission' if source else 'buy_commission'],
                   'source_ref':documentary.get('source_url')} if n=='brokerage' else {'status':'UNKNOWN','amount':None} for n in COMPONENTS}
    base={'side':side,'instrument_id':iid,'currency':row['currency'],'reference_amount':str(amount),'components':components,
          'status':'EXACT_CURRENT_COMPONENT_EVIDENCE_REQUIRED','total_cost':None,'evidence_id':None,
          'unresolved_conditions':documentary.get('unresolved_components',[]),'documentary_reference_promoted':False}
    if len(candidates)>1:return {**base,'status':'AMBIGUOUS_EXACT_COST_EVIDENCE_NOT_SELECTED'}
    if not candidates:return base
    r=candidates[0];components={n:{k:r['components'][n].get(k) for k in ('status','amount','source_ref','applicability_ref','as_of')} for n in COMPONENTS}
    complete=all(c['status'] in ('KNOWN','NOT_APPLICABLE') for c in components.values())
    return {**base,'status':'REVIEWED_COMPONENT_COVERAGE_COMPLETE' if complete else 'REVIEWED_COMPONENT_COVERAGE_PARTIAL',
            'components':components,'evidence_id':r['evidence_id'],'execution_venue_id':r['execution_venue_id'],
            'total_cost':str(sum((number(c['amount']) for c in components.values() if c['status']=='KNOWN'),Decimal(0))) if complete else None,
            'unresolved_conditions':base['unresolved_conditions']}

def assess(row,account,reviews):
    with localcontext() as ctx:
        ctx.prec=200
        cases=[]
        for h in row.get('commission_funding',{}).get('scenarios',[]):
            sell=leg(row,h,'SELL',account,reviews);buy=leg(row,h,'BUY',account,reviews)
            sold=number(h['source_sale_reference_amount'],True);principal=number(h['destination_reference_amount'],True)
            complete=all(l['total_cost'] is not None for l in (sell,buy));cash=None;models=[]
            if complete:
                cash=sold-principal-number(sell['total_cost'])-number(buy['total_cost'])
                if cash>=0:
                    for m in row.get('models',[]):
                        delta=principal*(1+return_number(m['destination_return_pct'])/100)+cash-sold*(1+return_number(m['source_return_pct'])/100)
                        models.append({'algorithm':m['algorithm'],'cohort_digest':m['cohort_digest'],'reviewed_cost_adjusted_uplift_amount':str(delta)})
            status=('REVIEWED_COSTS_FUND_EXISTING_HYPOTHESIS' if cash>=0 else 'REVIEWED_COSTS_REQUIRE_NEW_EXACT_NOTIONAL') if complete else 'FULL_CURRENT_COST_COVERAGE_REQUIRED'
            cases.append({'status':status,'sell_category':h['sell_category'],'buy_category':h['buy_category'],
                          'source_sale_reference_amount':str(sold),'destination_reference_amount':str(principal),
                          'remaining_source_reference_capital':h['remaining_source_reference_capital'],
                          'cash_remainder_after_reviewed_costs':str(cash) if cash is not None and cash>=0 else None,
                          'funding_shortfall':str(-cash) if cash is not None and cash<0 else None,
                          'legs':[sell,buy],'models':models,'selected':False,'recommendation_created':False,
                          'execution_authorized':False,'independent_attestation':False})
        return {'schema':'porquinho.reallocation-cost-coverage-a24/1.0','status':'EXACT_NOTIONAL_COST_COVERAGE_INSPECTED',
                'scenarios':cases,'status_counts':dict(Counter(c['status'] for c in cases)),
                'selected_amount':None,'execution_authorized':False,'financial_mutation':False,'history_write_performed':False}

def build(root,result,registered,*,now):
    import copy
    from .account_cost_evidence_a24 import load,current_scope,timestamp,CostError
    from .explicit_market_bindings_a24 import digest
    try:
        raw=load(root,now=now);active=[]
        for r in raw.values():
            try:current_scope(r,registered)
            except CostError:continue
            if timestamp(r['effective_from'])<=now<timestamp(r['effective_until']):active.append(r)
        projected=copy.deepcopy(result)
        for row in projected.get('rows',[]):
            account=registered.get(row['account_id'])
            if account:row['remaining_cost_coverage']=assess(row,account,active)
        if digest(raw)!=digest(load(root,now=now)):raise CostError('COST_COVERAGE_CHANGED_DURING_READ')
        projected['remaining_cost_coverage_status']='EXACT_CURRENT_COMPONENT_COVERAGE_INSPECTED'
        projected['remaining_cost_coverage_counts']=dict(Counter(c['status'] for r in projected.get('rows',[]) for c in r.get('remaining_cost_coverage',{}).get('scenarios',[])))
        return projected
    except Exception as exc:
        return {**result,'remaining_cost_coverage_status':'COST_COVERAGE_UNAVAILABLE_PRIOR_READINGS_PRESERVED',
                'remaining_cost_coverage_error_type':type(exc).__name__}
