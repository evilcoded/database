import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from decimal import Decimal as D
from unittest.mock import patch
from universal_portfolio import reallocation_cost_coverage_a24 as m
from universal_portfolio import research_tariff_context_a24 as tariffs
from universal_portfolio.account_cost_evidence_a24 import COMPONENTS,flags,SCHEMA
from test_a24_commission_funding import row,assess as funded

class Coverage(unittest.TestCase):
 def setUp(self):
  self.row=row();self.row['commission_funding']=funded(self.row,2)
  self.account={'account_id':'account','institution_id':'bank','_institution_country':'ZZ','currency':'ABC','pricing_plan':'Plan'}
 def quote(self,side,amount='0.5'):
  h=self.row['commission_funding']['scenarios'][0]
  return {'schema':SCHEMA,'confirmed':True,'component_coverage_reviewed':True,'account_id':'account','institution_id':'bank','institution_country':'ZZ','currency':'ABC','pricing_plan':'Plan','side':side,'instrument_id':'origin' if side=='SELL' else 'destination','reference_amount':h['source_sale_reference_amount' if side=='SELL' else 'destination_reference_amount'],'evidence_id':side,'execution_venue_id':'explicit-route','reviewed_by':'review','reviewed_at':'2026-10-19T00:00:00+00:00','effective_from':'2026-10-18T00:00:00+00:00','effective_until':'2026-10-20T00:00:00+00:00','components':{k:{'status':'KNOWN','amount':amount if k=='brokerage' else '0','currency':'ABC','unit':'CURRENCY_AMOUNT','source_kind':'ACCOUNT_PRICING_CONTRACT','source_ref':'official','applicability_ref':'explicit','as_of':'2026-10-18T00:00:00+00:00'} for k in COMPONENTS},**flags()}
 def get(self,reviews=()):return m.assess(self.row,self.account,reviews)['scenarios'][0]
 def test_missing_evidence_preserves_partial_documentary_commission(self):
  x=self.get();self.assertEqual(x['legs'][0]['components']['brokerage']['status'],'DOCUMENTED_REFERENCE');self.assertIsNone(x['legs'][0]['total_cost']);self.assertEqual(x['legs'][0]['components']['spread']['status'],'UNKNOWN')
 def test_complete_exact_evidence_replaces_not_adds_documentary_fee(self):
  x=self.get([self.quote('SELL'),self.quote('BUY')]);self.assertEqual(x['status'],'REVIEWED_COSTS_FUND_EXISTING_HYPOTHESIS');self.assertEqual(D(x['cash_remainder_after_reviewed_costs']),D('100')-D(x['destination_reference_amount'])-1)
 def test_partial_quote_cannot_create_total(self):
  q=self.quote('SELL');q['components']['taxes'].update(status='UNKNOWN',amount=None);x=self.get([q,self.quote('BUY')]);self.assertIsNone(x['legs'][0]['total_cost']);self.assertEqual(x['models'],[])
 def test_documentary_component_not_spliced_into_partial_review(self):
  q=self.quote('SELL');q['components']['brokerage'].update(status='UNKNOWN',amount=None);x=self.get([q]);self.assertEqual(x['legs'][0]['components']['brokerage']['status'],'UNKNOWN')
 def test_conflicting_venues_not_chosen(self):
  a=self.quote('SELL');b=copy.deepcopy(a);b.update(evidence_id='other',execution_venue_id='another');x=self.get([a,b]);self.assertEqual(x['legs'][0]['status'],'AMBIGUOUS_EXACT_COST_EVIDENCE_NOT_SELECTED')
 def test_account_identity_currency_plan_and_country_scope(self):
  for key in ['account_id','instrument_id','currency','pricing_plan','institution_id','institution_country','side']:
   q=self.quote('SELL');q[key]='other';self.assertEqual(self.get([q])['legs'][0]['status'],'EXACT_CURRENT_COMPONENT_EVIDENCE_REQUIRED',key)
 def test_omitted_pricing_plan_not_inferred(self):
  q=self.quote('SELL');del q['pricing_plan'];self.assertIsNone(self.get([q])['legs'][0]['evidence_id'])
 def test_quote_not_scaled_to_new_amount(self):
  q=self.quote('SELL');q['reference_amount']='50';self.assertIsNone(self.get([q])['legs'][0]['evidence_id'])
 def test_inapplicable_is_explicit_not_zero_fabrication(self):
  q=self.quote('SELL');q['components']['taxes'].update(status='NOT_APPLICABLE',amount=None);self.assertEqual(self.get([q])['legs'][0]['components']['taxes']['status'],'NOT_APPLICABLE')
 def test_full_costs_can_break_funding(self):
  x=self.get([self.quote('SELL','10'),self.quote('BUY','10')]);self.assertEqual(x['status'],'REVIEWED_COSTS_REQUIRE_NEW_EXACT_NOTIONAL');self.assertGreater(D(x['funding_shortfall']),0);self.assertIsNone(x['cash_remainder_after_reviewed_costs']);self.assertFalse(x['models'])
 def test_result_uses_both_total_costs_once(self):
  x=self.get([self.quote('SELL'),self.quote('BUY')]);h=self.row['commission_funding']['scenarios'][0];expected=D(h['destination_reference_amount'])*D('1.05')+D(x['cash_remainder_after_reviewed_costs'])-D('100')*D('.97');self.assertEqual(D(x['models'][0]['reviewed_cost_adjusted_uplift_amount']),expected)
 def test_inputs_and_authority_preserved(self):
  quotes=[self.quote('SELL'),self.quote('BUY')];before=copy.deepcopy((self.row,quotes));x=self.get(quotes);self.assertEqual(before,(self.row,quotes));self.assertFalse(x['selected']);self.assertFalse(x['execution_authorized']);self.assertFalse(x['recommendation_created'])
 def build(self,load):
  now=dt.datetime(2026,10,19,tzinfo=dt.timezone.utc)
  with patch.object(__import__('universal_portfolio.account_cost_evidence_a24',fromlist=['load']),'load',side_effect=load):return m.build('/unused',{'rows':[self.row]}, {'account':self.account},now=now)
 def test_expired_source_not_used(self):
  q=self.quote('SELL');q['effective_until']='2026-10-18T01:00:00+00:00';r=self.build([{'SELL':q},{'SELL':q}]);self.assertIsNone(r['rows'][0]['remaining_cost_coverage']['scenarios'][0]['legs'][0]['evidence_id'])
 def test_plan_changed_source_not_used(self):
  q=self.quote('SELL');q['pricing_plan']='OLD';r=self.build([{'SELL':q},{'SELL':q}]);self.assertIsNone(r['rows'][0]['remaining_cost_coverage']['scenarios'][0]['legs'][0]['evidence_id'])
 def test_store_change_preserves_existing_hypotheses(self):
  r=self.build([{}, {'x':self.quote('SELL')}]);self.assertEqual(r['rows'],[self.row]);self.assertIn('PRESERVED',r['remaining_cost_coverage_status'])
 def test_invalid_store_does_not_hide_brain_readings(self):
  r=self.build(ValueError('invalid'));self.assertEqual(r['rows'],[self.row]);self.assertIn('PRESERVED',r['remaining_cost_coverage_status'])
 def test_current_reviewed_evidence_integration(self):
  qs={side:self.quote(side) for side in ['SELL','BUY']};r=self.build([qs,qs]);self.assertEqual(r['remaining_cost_coverage_counts'],{'REVIEWED_COSTS_FUND_EXISTING_HYPOTHESIS':1})
 def test_actual_file_store_read_and_no_writes(self):
  with tempfile.TemporaryDirectory() as root:
   import test_a24_research_tariff_context as f
   h=f.TariffContext();h.setUp();r=h.build_fixture(root);p=Path(root)/'data/currency_registry.json';p.write_text(json.dumps({'schema':'porquinho.currency-registry/1.0','currencies':[{'currency_code':'EUR','active':True,'precision':2}]}));before={p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()};out=tariffs.build(root,r,now=h.now)
   self.assertEqual(out['remaining_cost_coverage_status'],'EXACT_CURRENT_COMPONENT_COVERAGE_INSPECTED');self.assertGreater(out['remaining_cost_coverage_counts']['FULL_CURRENT_COST_COVERAGE_REQUIRED'],0);self.assertEqual(before,{p:p.read_bytes() for p in Path(root).rglob('*') if p.is_file()})
 def test_no_hypotheses_no_coverage_fabricated(self):
  self.row['commission_funding']['scenarios']=[];self.assertEqual(m.assess(self.row,self.account,[])['scenarios'],[])
 def test_audit_exports_only_whitelisted_coverage_counts(self):
  from tools.reallocation_source_audit_v43 import project
  self.row['remaining_cost_coverage']={'status_counts':{'FULL_CURRENT_COST_COVERAGE_REQUIRED':4,'SECRET':3},'scenarios':[{'total_cost':'PRIVATE_COST'}]}
  out=project({'reallocation_analysis':{'rows':[self.row]}},{})
  self.assertNotIn('PRIVATE',json.dumps(out));self.assertNotIn('SECRET',json.dumps(out));self.assertEqual(out['pairs'][0]['remaining_cost_coverage_status_counts'],{'FULL_CURRENT_COST_COVERAGE_REQUIRED':4})
if __name__=='__main__':unittest.main()
