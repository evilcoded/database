"""Export only whitelisted identity/source diagnostics; never balances, orders or secrets."""
import datetime as dt,json,sys,zipfile,tempfile,os
from collections import Counter
from pathlib import Path

def project(report,registry):
 def strings(row,keys):return {k:row.get(k) if isinstance(row.get(k),str) else None for k in keys}
 def counts(raw,allowed):return {k:v for k,v in (raw or {}).items() if k in allowed and type(v) is int and v>=0}
 valuation_codes={'REGISTERED_POSITION_REVIEWED_SOURCE_REFERENCE','RESEARCH_ALIAS_NOT_FINANCIAL_IDENTITY','POSITION_QUANTITY_REQUIRED','EXACT_PROVIDER_ORIGIN_PRICE_REQUIRED','EXACT_PROVIDER_ORIGIN_PRICE_AMBIGUOUS','POSITIVE_QUANTITY_AND_PRICE_REQUIRED','EXACT_FINANCIAL_REFERENCE_AVAILABLE'}
 components={'brokerage','exchange_fees','spread','slippage','taxes','other_costs'}
 pairs=[]
 for p in report.get('reallocation_analysis',{}).get('rows',[]):
  if not p.get('models'):continue
  cost=p.get('cost_source_diagnostics') or {}
  pairs.append({**strings(p,('alternative_id','account_id','currency','source_instrument_id','destination_instrument_id','source_research_instrument_id','destination_research_instrument_id')),
   'research_alias_used':p.get('research_alias_used') is True,'financial_reference_capital_present':p.get('reference_capital') is not None,
   'valuation_state_counts':counts(p.get('valuation_state_counts'),valuation_codes),
   'documented_tariff_leg_status_counts':counts(dict(Counter(l.get('status') for l in (p.get('documented_tariff_provisions') or {}).get('legs',[]))),{'DOCUMENTED_COMMISSION_REFERENCE_PARTIAL','DOCUMENTED_TARIFF_SOURCE_REQUIRED','EXACT_PROVIDER_IDENTITY_REQUIRED','ACCOUNT_CURRENCY_MISMATCH','TARIFF_SOURCE_RECHECK_REQUIRED','AMBIGUOUS_TARIFF_POLICY_REVIEW_REQUIRED','ASSET_OR_TARIFF_BRACKET_REVIEW_REQUIRED'}),
   'commission_funding_status_counts':counts({(p.get('commission_funding') or {}).get('status'):1},{'COMMISSION_ONLY_SELF_FUNDED_HYPOTHESES','EXPLICIT_CURRENCY_PRECISION_REQUIRED','BOTH_DOCUMENTED_TARIFF_LEGS_REQUIRED','EXACT_ACCOUNT_REQUIRED','SAME_CURRENCY_REQUIRED','EXACT_FINANCIAL_IDENTITIES_REQUIRED','NO_SUPPORTED_COMMISSION_FUNDED_HYPOTHESIS','COMMISSION_FUNDING_UNAVAILABLE'}),
   'commission_funded_hypothesis_count':len((p.get('commission_funding') or {}).get('scenarios',[])),
   'remaining_cost_coverage_status_counts':counts((p.get('remaining_cost_coverage') or {}).get('status_counts'),{'REVIEWED_COSTS_FUND_EXISTING_HYPOTHESIS','REVIEWED_COSTS_REQUIRE_NEW_EXACT_NOTIONAL','FULL_CURRENT_COST_COVERAGE_REQUIRED'}),
   'cost_source_diagnostics':{**counts(cost,{'sell_review_count','buy_review_count'}),'unknown_component_counts':counts(cost.get('unknown_component_counts'),components)},
   'model_source_contexts':[strings(m,('algorithm','origin','source_provider','source_provider_id','destination_provider','destination_provider_id')) for m in p['models']]})
 fields=('pricing_plan','fee_plan','subscription_plan','pricing_contract_ref','fee_schedule_ref')
 banks=[strings(r,('institution_id','name','country','institution_type')) for r in registry.get('institutions',[])]
 accounts=[{**strings(r,('account_id','institution_id','currency','account_type','management_mode')),'declared_pricing_field_names':[k for k in fields if r.get(k) not in (None,'')]} for r in registry.get('accounts',[])]
 positions=[]
 for p in report.get('universal_portfolio',{}).get('positions',[]):
  positions.append({**strings(p,('position_id','instrument_id','account_id','currency','context_status','valuation_status')),'quantity_present':p.get('quantity') is not None,'reference_quote_present':p.get('reference_price') is not None})
 return {'schema':'porquinho.reallocation-source-audit-v43/1.0','status':'SOURCES_INSPECTED_NOT_REBOUND','pairs':pairs,'positions':positions,'institutions':banks,'accounts':accounts,
  'identity_identifiers_exported':True,'financial_amounts_exported':False,'transaction_records_exported':False,'raw_sources_exported':False,'identity_binding_created':False,'financial_mutation':False,'history_write_performed':False,'network_requests':0,'training_requested':False,'execution_authorized':False}

def identity_sources(root):
 from universal_portfolio.explicit_market_bindings_a24 import local
 specs={'data/canonical_position_identity_bindings.json':'bindings','data/opening_position_identity_bindings.json':'bindings',
  'data/universal_opening_state_shadow.json':'positions','data/instruments/market_provider_bindings_a24.json':'bindings',
  'data/universal_instrument_catalog.json':'instruments'}
 keys=('binding_id','position_domain','domain','position_id','account_id','portfolio_id','instrument_id','position_instrument_id','research_instrument_id','provider','provider_id','quote_currency','currency','symbol','asset_class')
 out={}
 for rel,key in specs.items():
  p=local(root,rel)
  if not p.exists():out[rel]={'status':'MISSING'};continue
  if p.stat().st_size>4*1024*1024:out[rel]={'status':'READ_LIMIT'};continue
  raw=p.read_bytes();doc=json.loads(raw)
  if raw!=p.read_bytes():raise ValueError('SOURCE_CHANGED_RETRY_AFTER_NORMAL_CYCLE')
  rows=doc.get(key) if isinstance(doc,dict) else None
  if not isinstance(rows,list):out[rel]={'status':'UNRECOGNIZED_CONTAINER'};continue
  records=[]
  for r in rows:
   if not isinstance(r,dict):continue
   item={k:r[k] for k in keys if isinstance(r.get(k),str)}
   ref=r.get('account_reference')
   if isinstance(ref,str):item['account_reference']=ref
   elif isinstance(ref,dict) and isinstance(ref.get('value'),str):item['account_reference']=ref['value']
   records.append(item)
  out[rel]={'status':'IDENTITY_FIELDS_ONLY','schema':doc.get('schema') if isinstance(doc.get('schema'),str) else None,'records':records}
 return out

def build(root):
 from universal_portfolio.economic_action_plan_a24 import source_versions
 from universal_portfolio.monitor_consolidation_a24 import inspect
 from universal_portfolio.explicit_market_bindings_a24 import local
 root=Path(root).resolve(strict=True);before=source_versions(root)
 path=local(root,'data/institution_accounts.json');raw=path.read_bytes() if path.exists() else b'{}'
 if len(raw)>4*1024*1024:raise ValueError('REGISTRY_READ_LIMIT')
 registry=json.loads(raw);report=inspect(root,include_financial=True);sources=identity_sources(root)
 if sources!=identity_sources(root) or before!=source_versions(root) or (path.read_bytes() if path.exists() else b'{}')!=raw:raise ValueError('SOURCE_CHANGED_RETRY_AFTER_NORMAL_CYCLE')
 data=project(report,registry);data['identity_sources']=sources;data['inspection_status']=report.get('status');data['observed_at']=report.get('observed_at');return data

def write(folder,root,data):
 folder=Path(folder).expanduser()
 if folder.is_symlink():raise ValueError('SYMLINK_OUTPUT_REFUSED')
 folder=folder.resolve();root=Path(root).resolve()
 if folder.is_relative_to(root):raise ValueError('OUTPUT_MUST_BE_OUTSIDE_PROJECT')
 folder.mkdir(parents=True,exist_ok=True)
 fd,name=tempfile.mkstemp(prefix='PORQUINHO_A24_FONTES_REALOCACAO_V43_',suffix='.zip',dir=folder);os.close(fd);path=Path(name)
 try:
  with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
   z.writestr('DIAGNOSTICO.json',json.dumps(data,ensure_ascii=False,indent=2))
   z.writestr('LEIA.txt','Somente identificadores, contas/instituições/moedas e estados de fontes. Sem saldos, quantidades, preços, previsões, transações ou arquivos brutos. Nenhum vínculo foi criado ou alterado. Compartilhe este ZIP somente se desejar a revisão das ligações e fontes.\n')
  path.chmod(0o600);return path
 except BaseException:
  path.unlink(missing_ok=True);raise
if __name__=='__main__':
 root=Path(sys.argv[1]).expanduser().resolve(strict=True);sys.path.insert(0,str(root))
 try:
  path=write(sys.argv[2] if len(sys.argv)>2 else Path.home()/'Downloads',root,build(root));print('ZIP_PARA_COMPARTILHAR='+str(path))
 except Exception as exc:
  print('DIAGNOSTICO_DE_FONTES_NAO_CONCLUIDO='+str(exc) if isinstance(exc,ValueError) else 'DIAGNOSTICO_DE_FONTES_NAO_CONCLUIDO='+type(exc).__name__);raise SystemExit(1)
