"""Account/currency research demand from existing canonical cash and planning.

Observation requests only. Does not fetch prices, train, certify or authorize orders.
"""
from collections import defaultdict
from decimal import Decimal,InvalidOperation
import hashlib,json
from pathlib import Path

SCHEMA='porquinho.funded-currency-research-a24/1.0'
class FundingContextError(ValueError):pass

def text(v):return isinstance(v,str) and bool(v) and v==v.strip()
def required(v):
 if not text(v):raise FundingContextError('EXPLICIT_IDENTITY_REQUIRED')
 return v

def currency(v):
 v=required(v)
 if not v.isascii() or not v.isalpha() or not v.isupper() or len(v)>16:raise FundingContextError('EXPLICIT_CURRENCY_INVALID')
 return v

def amount(v):
 if isinstance(v,bool) or v is None:raise FundingContextError('AMOUNT_INVALID')
 try:n=Decimal(str(v))
 except (InvalidOperation,TypeError,ValueError):raise FundingContextError('AMOUNT_INVALID')
 if not n.is_finite():raise FundingContextError('AMOUNT_INVALID')
 return n

def field(row,key,default=None):return row.get(key,default) if isinstance(row,dict) else getattr(row,key,default)
def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
def index(rows,key):
 out={}
 for row in rows:
  if not isinstance(row,dict):raise FundingContextError('REGISTRY_ROW_INVALID')
  k=required(row.get(key))
  if k in out:raise FundingContextError('DUPLICATE_REGISTRY_ID')
  out[k]=row
 return out

def project(*,cash,registry,budgets=(),plans=(),candidates=(),bindings=()):
 accounts=index(registry.get('accounts',[]),'account_id');institutions=index(registry.get('institutions',[]),'institution_id')
 budget_index=index(budgets,'budget_id');plan_index=index(plans,'plan_id')
 instrument_index={}
 for candidate in candidates:
  iid=required(candidate.get('instrument_id'));asset_class=candidate.get('asset_class')
  if iid in instrument_index and instrument_index[iid].get('asset_class')!=asset_class:raise FundingContextError('CANDIDATE_IDENTITY_CONFLICT')
  instrument_index[iid]=candidate
 balances=defaultdict(lambda:Decimal('0'))
 for row in cash:balances[(required(field(row,'account_id')),currency(field(row,'currency')))]+=amount(field(row,'amount'))
 contexts=[];requests=[]
 for (aid,cur),available in sorted(balances.items()):
  if available<=0:continue
  account=accounts.get(aid);institution=institutions.get(account.get('institution_id')) if account else None
  reason=None
  if account is None:reason='CASH_ACCOUNT_NOT_IN_REGISTRY'
  elif account.get('currency')!=cur:reason='CASH_ACCOUNT_CURRENCY_MISMATCH'
  elif institution is None or not text(institution.get('country')):reason='INSTITUTION_LOCALITY_UNAVAILABLE'
  active=[]
  for b in budget_index.values():
   if b.get('account_id')!=aid or b.get('currency')!=cur or b.get('status')!='ACTIVE':continue
   if b.get('authority')!='NONE' or b.get('ledger_semantics')!='NONE' or b.get('creates_cash') is not False or b.get('mutates_ledger') is not False:
    reason='PLANNING_BUDGET_AUTHORITY_INVALID';continue
   value=amount(b.get('amount'))
   if value<=0:reason='PLANNING_BUDGET_AMOUNT_INVALID';continue
   active.append(b)
  reserved=sum((amount(b['amount']) for b in active),Decimal('0'))
  if reserved>available:reason='ACTIVE_BUDGETS_EXCEED_CURRENT_CASH'
  active_ids=sorted(b['budget_id'] for b in active)
  linked=[]
  for p in plan_index.values():
   if p.get('status')!='ACTIVE' or p.get('planning_budget_id') not in active_ids:continue
   if p.get('source_account_id')!=aid or p.get('currency')!=cur or p.get('authority')!='NONE' or p.get('automatic_execution_authorized') is not False or p.get('execution_mode')!='MANUAL':
    reason='ACTIVE_PLAN_CONTEXT_OR_AUTHORITY_INVALID';continue
   linked.append(p)
  if len({p.get('planning_budget_id') for p in linked})!=len(linked):reason='MULTIPLE_ACTIVE_PLANS_FOR_BUDGET'
  for p in linked:
   cls=p.get('allowed_asset_classes')
   if not isinstance(cls,(list,tuple)) or not cls or not all(text(v) for v in cls):reason='ACTIVE_PLAN_CLASSES_INVALID'
  classes=sorted({cls for p in linked for cls in (p.get('allowed_asset_classes') or []) if text(cls)})
  country=institution.get('country') if institution else None
  context={'account_id':aid,'currency':cur,'institution_id':account.get('institution_id') if account else None,
           'institution_country':country,'canonical_cash_observed':str(available),
           'planning_budget_ids':active_ids,
           'planning_budget_intents':[{'budget_id':b['budget_id'],'amount':str(amount(b['amount']))} for b in sorted(active,key=lambda x:x['budget_id'])],
           'active_plan_ids':sorted(p['plan_id'] for p in linked),
           'active_plan_contexts':[{k:p.get(k) for k in ('plan_id','planning_budget_id','universe_id','period','strategy','allowed_asset_classes')} for p in sorted(linked,key=lambda x:x['plan_id'])],
           'investment_budget_amount':str(reserved) if active and reason is None else None,
           'capital_status':reason or ('ACTIVE_INVESTMENT_BUDGET' if active else 'CASH_DETECTED_INVESTMENT_BUDGET_REQUIRED'),
           'research_enabled':reason is None,'allowed_asset_classes_from_active_plans':classes,
           'execution_mode':'MANUAL','automatic_execution_authorized':False,'execution_authorized':False,
           'delegation_policy_id':None,'execution_performed':False,
           'requires_capital_revalidation':True,'requires_eligibility_revalidation':True,
           'requires_validated_sizing':True,'requires_idempotency_key':True}
  context['context_fingerprint']=fingerprint(context);contexts.append(context)
  if reason:continue
  for iid,candidate in sorted(instrument_index.items()):
   if classes and candidate.get('asset_class') not in classes:continue
   sources=[{'provider':b['provider'],'provider_id':b['provider_id'],'quote_currency':cur,
             'effective_from':b['effective_from'],'identity_source_ref':b['identity_source_ref']}
            for b in bindings if b.get('instrument_id')==iid and b.get('quote_currency')==cur]
   requests.append({'request_id':fingerprint([aid,cur,iid]),'context_fingerprint':context['context_fingerprint'],
                    'account_id':aid,'instrument_id':iid,'quote_currency':cur,'institution_country':country,
                    'candidate_asset_class':candidate.get('asset_class'),'purpose':'OBSERVE_AND_MATURE_ONLY',
                    'status':'READY_FOR_SOURCE_REVIEW' if sources else 'EXPLICIT_PROVIDER_QUOTE_BINDING_REQUIRED',
                    'eligibility_status':'REQUIRES_INSTRUMENT_VENUE_AND_PLAN_VALIDATION',
                    'source_candidates':sources,'data_acquisition_requested':False,'training_requested':False,
                    'recommendation_created':False,'execution_authorized':False,'automatic_execution_authorized':False})
 return {'schema':SCHEMA,'status':'OBSERVATION_DEMAND_PROJECTED','authority':'NONE','contexts':contexts,'research_requests':requests,
         'observed_funded_currencies':sorted({c['currency'] for c in contexts if c['research_enabled']}),
         'country_determines_currency':False,'cross_currency_aggregation':False,'silent_fx':False,
         'financial_mutation':False,'history_write_performed':False,'execution_performed':False,
         'canonical_publication_authorized':False,'automatic_execution_authorized':False}

def build(root,*,candidates=()):
 try:
  from .canonical_runtime_read_model import build as runtime
  from .investment_plan_runtime import _accounts
  from .planning_budget_store import PlanningBudgetStore
  from .investment_plan_store import InvestmentPlanStore
  from .explicit_market_bindings_a24 import load
  root=Path(root)
  paths=[root/'data'/v for v in ('transaction_ledger.jsonl','universal_opening_state_shadow.json','planning_budgets.json','investment_plans.json','institution_accounts.json','instruments/market_provider_bindings_a24.json')]
  paths+=list((root/'data').glob('*institution*account*.json'))
  def versions():
   return {str(p):(p.stat().st_size,p.stat().st_mtime_ns) if p.exists() else None for p in paths}
  before=versions()
  state=runtime(root);registry=_accounts(root)
  if registry.get('schema')!='porquinho.institution-account-registry/1.0':raise FundingContextError('ACCOUNT_REGISTRY_SCHEMA_INVALID')
  result=project(cash=state['cash'],registry=registry,
      budgets=PlanningBudgetStore(root/'data/planning_budgets.json').list(),
      plans=InvestmentPlanStore(root/'data/investment_plans.json').list(),candidates=candidates,bindings=load(root)['bindings'])
  if before!=versions():raise FundingContextError('SOURCE_CHANGED_DURING_READ_RETRY_REQUIRED')
  return result
 except Exception as exc:
  return {'schema':SCHEMA,'status':'UNAVAILABLE','reason':str(exc) if isinstance(exc,FundingContextError) else type(exc).__name__,
          'contexts':[],'research_requests':[],'observed_funded_currencies':[],
          'financial_mutation':False,'execution_performed':False,'automatic_execution_authorized':False,'canonical_publication_authorized':False}
