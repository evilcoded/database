import ast,copy,json,tempfile,types,unittest
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch
from universal_portfolio import funded_currency_research_a24 as m

ROOT=Path(__file__).resolve().parents[1]

def registry(cur='BRL',country='BR'):
 return {'schema':'porquinho.institution-account-registry/1.0','institutions':[{'institution_id':'bank','country':country}],
         'accounts':[{'account_id':'account','institution_id':'bank','currency':cur,'management_mode':'MANUAL','execution_enabled':False}]}
def budget(**extra):
 return dict({'budget_id':'budget','account_id':'account','currency':'BRL','amount':'50','status':'ACTIVE','authority':'NONE','ledger_semantics':'NONE','creates_cash':False,'mutates_ledger':False},**extra)
def plan(**extra):
 return dict({'plan_id':'plan','planning_budget_id':'budget','source_account_id':'account','currency':'BRL','status':'ACTIVE','authority':'NONE','automatic_execution_authorized':False,'execution_mode':'MANUAL','allowed_asset_classes':['CRYPTO']},**extra)
CANDIDATES=[{'instrument_id':'GLOBAL:CRYPTO:CRYPTO:TEST','asset_class':'CRYPTO','currency':'EUR'},
            {'instrument_id':'EXPLICIT:MARKET:CLASS:PRODUCT:SERIES','asset_class':'BOND','currency':'USD'}]
class Funding(unittest.TestCase):
 def run_context(self,cur='BRL',cash='100',**kw):
  inputs={'cash':cash if isinstance(cash,list) else [{'account_id':'account','currency':cur,'amount':cash}], 'registry':registry(cur), 'candidates':CANDIDATES}
  inputs.update(kw);return m.project(**inputs)
 def test_new_brl_cash_creates_brl_research_without_brl_positions(self):
  out=self.run_context(budgets=[budget()]);self.assertEqual(out['observed_funded_currencies'],['BRL']);self.assertEqual({r['quote_currency'] for r in out['research_requests']},{'BRL'})
  self.assertEqual(len(out['research_requests']),2);self.assertEqual(out['contexts'][0]['investment_budget_amount'],'50')
 def test_countries_do_not_set_currencies(self):
  out=self.run_context(cur='JPY',registry=registry('JPY','PT'));self.assertEqual(out['contexts'][0]['institution_country'],'PT');self.assertEqual(out['observed_funded_currencies'],['JPY'])
 def test_initial_three_currencies_are_not_a_whitelist(self):
  for cur in ('BRL','EUR','USD','JPY','CHF','USDT','XAU'):
   with self.subTest(cur=cur):self.assertEqual(self.run_context(cur=cur)['observed_funded_currencies'],[cur])
 def test_cash_without_budget_does_not_become_investible_amount(self):
  out=self.run_context();self.assertTrue(out['contexts'][0]['research_enabled']);self.assertIsNone(out['contexts'][0]['investment_budget_amount']);self.assertEqual(out['contexts'][0]['capital_status'],'CASH_DETECTED_INVESTMENT_BUDGET_REQUIRED')
 def test_zero_or_negative_cash_produces_no_requests(self):
  for value in ('0','-1'):
   with self.subTest(value=value):self.assertEqual(self.run_context(cash=value)['research_requests'],[])
 def test_nonfinite_or_boolean_amount_rejected(self):
  for value in ('NaN','Infinity',True,None):
   with self.subTest(value=value),self.assertRaises(m.FundingContextError):self.run_context(cash=value)
 def test_decimal_precision_preserved(self):
  out=self.run_context(cash='0.100000000000000001');self.assertEqual(out['contexts'][0]['canonical_cash_observed'],'0.100000000000000001')
 def test_missing_account_not_guessed(self):
  out=self.run_context(registry={'accounts':[],'institutions':[]});self.assertEqual(out['contexts'][0]['capital_status'],'CASH_ACCOUNT_NOT_IN_REGISTRY');self.assertFalse(out['research_requests'])
 def test_account_currency_mismatch_not_inferred_from_country(self):
  out=self.run_context(registry=registry('EUR'));self.assertEqual(out['contexts'][0]['capital_status'],'CASH_ACCOUNT_CURRENCY_MISMATCH');self.assertFalse(out['research_requests'])
 def test_missing_locality_is_explicit(self):
  out=self.run_context(registry=registry(country=''));self.assertEqual(out['contexts'][0]['capital_status'],'INSTITUTION_LOCALITY_UNAVAILABLE')
 def test_duplicate_accounts_rejected(self):
  r=registry();r['accounts']*=2
  with self.assertRaisesRegex(m.FundingContextError,'DUPLICATE'):self.run_context(registry=r)
 def test_two_accounts_same_currency_stay_separate(self):
  r=registry();r['accounts'].append(dict(r['accounts'][0],account_id='second'))
  out=self.run_context(registry=r,cash=[{'account_id':'account','currency':'BRL','amount':'10'},{'account_id':'second','currency':'BRL','amount':'20'}])
  self.assertEqual(len(out['contexts']),2);self.assertEqual(len({x['request_id'] for x in out['research_requests']}),4)
 def test_different_currencies_never_sum(self):
  r=registry();r['accounts'].append(dict(r['accounts'][0],account_id='other',currency='EUR'))
  out=self.run_context(registry=r,cash=[{'account_id':'account','currency':'BRL','amount':'100'},{'account_id':'other','currency':'EUR','amount':'10'}])
  self.assertEqual(out['observed_funded_currencies'],['BRL','EUR']);self.assertNotIn('total_cash',out);self.assertFalse(out['cross_currency_aggregation'])
 def test_budget_draft_not_promoted(self):
  out=self.run_context(budgets=[budget(status='DRAFT')]);self.assertIsNone(out['contexts'][0]['investment_budget_amount'])
 def test_budget_in_other_currency_not_used(self):
  out=self.run_context(budgets=[budget(currency='EUR')]);self.assertIsNone(out['contexts'][0]['investment_budget_amount'])
 def test_multiple_budgets_cannot_exceed_current_cash(self):
  out=self.run_context(budgets=[budget(amount='60'),budget(budget_id='other',amount='60')]);self.assertEqual(out['contexts'][0]['capital_status'],'ACTIVE_BUDGETS_EXCEED_CURRENT_CASH');self.assertFalse(out['research_requests'])
 def test_budget_authority_does_not_leak(self):
  out=self.run_context(budgets=[budget(authority='EXECUTE')]);self.assertEqual(out['contexts'][0]['capital_status'],'PLANNING_BUDGET_AUTHORITY_INVALID');self.assertFalse(out['research_requests'])
 def test_plan_classes_scope_research(self):
  out=self.run_context(budgets=[budget()],plans=[plan()]);self.assertEqual(len(out['research_requests']),1);self.assertEqual(out['research_requests'][0]['candidate_asset_class'],'CRYPTO')
 def test_plan_cannot_enable_automatic_execution(self):
  out=self.run_context(budgets=[budget()],plans=[plan(automatic_execution_authorized=True)]);self.assertFalse(out['research_requests']);self.assertFalse(out['automatic_execution_authorized'])
 def test_duplicate_active_plans_for_budget_refused(self):
  out=self.run_context(budgets=[budget()],plans=[plan(),plan(plan_id='other')]);self.assertEqual(out['contexts'][0]['capital_status'],'MULTIPLE_ACTIVE_PLANS_FOR_BUDGET')
 def test_plan_class_string_is_not_treated_as_characters(self):
  out=self.run_context(budgets=[budget()],plans=[plan(allowed_asset_classes='CRYPTO')]);self.assertEqual(out['contexts'][0]['capital_status'],'ACTIVE_PLAN_CLASSES_INVALID');self.assertFalse(out['research_requests'])
 def test_request_does_not_authorize_order_or_training(self):
  out=self.run_context(budgets=[budget()]);ctx=out['contexts'][0]
  for key in ('execution_authorized','automatic_execution_authorized','execution_performed'):self.assertIs(ctx[key],False)
  for key in ('requires_capital_revalidation','requires_eligibility_revalidation','requires_validated_sizing','requires_idempotency_key'):self.assertTrue(ctx[key])
  self.assertIsNone(ctx['delegation_policy_id']);self.assertFalse(out['research_requests'][0]['data_acquisition_requested']);self.assertFalse(out['research_requests'][0]['recommendation_created'])
 def test_existing_execute_account_does_not_grant_authority(self):
  r=registry();r['accounts'][0].update(management_mode='CONNECTED_EXECUTE',execution_enabled=True)
  out=self.run_context(registry=r);self.assertEqual(out['contexts'][0]['execution_mode'],'MANUAL');self.assertFalse(out['contexts'][0]['automatic_execution_authorized'])
 def test_identical_input_is_idempotent_and_unchanged(self):
  inputs={'registry':registry(),'cash':[{'account_id':'account','currency':'BRL','amount':'100'}],'budgets':[budget()],'candidates':CANDIDATES}
  before=copy.deepcopy(inputs);self.assertEqual(m.project(**inputs),m.project(**inputs));self.assertEqual(before,inputs)
 def test_cash_change_invalidates_context_but_not_demand_identity(self):
  a=self.run_context(cash='100');b=self.run_context(cash='101');self.assertNotEqual(a['contexts'][0]['context_fingerprint'],b['contexts'][0]['context_fingerprint']);self.assertEqual(a['research_requests'][0]['request_id'],b['research_requests'][0]['request_id'])
 def test_all_identity_components_preserved(self):
  out=self.run_context();self.assertEqual({r['instrument_id'] for r in out['research_requests']},{r['instrument_id'] for r in CANDIDATES})
 def test_no_provider_or_fx_is_fabricated(self):
  out=self.run_context();self.assertTrue(all(r['status']=='EXPLICIT_PROVIDER_QUOTE_BINDING_REQUIRED' and not r['source_candidates'] for r in out['research_requests']));self.assertFalse(out['silent_fx'])
 def test_existing_binding_is_only_source_review_candidate(self):
  binding={'instrument_id':CANDIDATES[0]['instrument_id'],'provider':'Provider','provider_id':'id','quote_currency':'BRL','effective_from':'2026-10-16','identity_source_ref':'explicit'}
  out=self.run_context(bindings=[binding]);r=next(r for r in out['research_requests'] if r['instrument_id']==binding['instrument_id']);self.assertEqual(r['status'],'READY_FOR_SOURCE_REVIEW');self.assertFalse(r['data_acquisition_requested'])
 def test_read_only_adapter_uses_existing_sources_and_never_creates_files(self):
  from universal_portfolio import canonical_runtime_read_model as runtime
  from universal_portfolio import investment_plan_runtime as plans
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);before=list(root.iterdir())
   with patch.object(runtime,'build',return_value={'cash':[types.SimpleNamespace(account_id='account',currency='BRL',amount=Decimal('10'))]}),patch.object(plans,'_accounts',return_value=registry()):out=m.build(root,candidates=CANDIDATES)
   self.assertEqual(out['observed_funded_currencies'],['BRL']);self.assertEqual(before,list(root.iterdir()))
 def test_missing_runtime_has_no_observational_balance_fallback(self):
  with tempfile.TemporaryDirectory() as tmp:out=m.build(tmp,candidates=CANDIDATES)
  self.assertEqual(out['status'],'UNAVAILABLE');self.assertEqual(out['contexts'],[])
 def test_real_flask_route_is_get_only_and_read_only(self):
  from flask import Flask,jsonify
  from universal_portfolio import universal_observation_bridge as bridge
  tree=ast.parse((ROOT/'webapp/server.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='a24_funding_research_contexts')
  app=Flask('a24test');ns={'app':app,'jsonify':jsonify,'ROOT':ROOT};exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_server_route','exec'),ns)
  expected=self.run_context(budgets=[budget()])
  with patch.object(bridge,'build_read_only_bridge',return_value=types.SimpleNamespace(intelligence={'funded_currency_research':expected})):
   response=app.test_client().get('/api/research/funding-contexts');self.assertEqual(response.status_code,200);self.assertEqual(response.json,expected)
   self.assertEqual(app.test_client().post('/api/research/funding-contexts').status_code,405)
 def test_route_reports_unavailable_without_financial_action(self):
  from flask import Flask,jsonify
  from universal_portfolio import universal_observation_bridge as bridge
  tree=ast.parse((ROOT/'webapp/server.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='a24_funding_research_contexts');app=Flask('a24unavailable');ns={'app':app,'jsonify':jsonify,'ROOT':ROOT};exec(compile(ast.Module(body=[node],type_ignores=[]),'actual_route','exec'),ns)
  with patch.object(bridge,'build_read_only_bridge',return_value=types.SimpleNamespace(intelligence={'funded_currency_research':{'status':'UNAVAILABLE'}})):
   self.assertEqual(app.test_client().get('/api/research/funding-contexts').status_code,409)
 def test_strategy_or_horizon_change_invalidates_context(self):
  a=self.run_context(budgets=[budget()],plans=[plan(strategy='A',period='30D')])
  b=self.run_context(budgets=[budget()],plans=[plan(strategy='B',period='60D')])
  self.assertNotEqual(a['contexts'][0]['context_fingerprint'],b['contexts'][0]['context_fingerprint'])
 def test_budget_redistribution_invalidates_context_even_with_same_total(self):
  a=self.run_context(budgets=[budget(amount='10'),budget(budget_id='second',amount='20')])
  b=self.run_context(budgets=[budget(amount='20'),budget(budget_id='second',amount='10')])
  self.assertNotEqual(a['contexts'][0]['context_fingerprint'],b['contexts'][0]['context_fingerprint'])
 def test_actual_universe_bridge_carries_funding_demand(self):
  from universal_portfolio.universal_observation_bridge import build_read_only_bridge
  expected=self.run_context(budgets=[budget()])
  with tempfile.TemporaryDirectory() as tmp,patch.object(m,'build',return_value=expected) as projection:
   result=build_read_only_bridge(tmp)
   self.assertEqual(result.intelligence['funded_currency_research'],expected);projection.assert_called_once()
if __name__=='__main__':unittest.main()
