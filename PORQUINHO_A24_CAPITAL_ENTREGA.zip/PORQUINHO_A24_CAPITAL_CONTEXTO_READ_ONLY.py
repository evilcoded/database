import sys,os,json
from collections import Counter
from pathlib import Path
root=Path(sys.argv[1]).resolve(strict=True);sys.path.insert(0,str(root))
def guard(event,args):
 if event=='open':
  mode,flags=args[1:3]
  if (isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):raise RuntimeError('READ_ONLY_WRITE_REFUSED')
 if event in {'os.remove','os.rename','os.mkdir','os.rmdir','os.chmod','os.truncate','os.link','os.symlink','subprocess.Popen','os.system','socket.connect','socket.bind'}:raise RuntimeError('READ_ONLY_SIDE_EFFECT_REFUSED')
sys.addaudithook(guard)
try:
 from universal_portfolio.universal_observation_bridge import build_read_only_bridge
 bridge=build_read_only_bridge(root);out=bridge.intelligence.get('funded_currency_research') or {}
 contexts=out.get('contexts',[]);requests=out.get('research_requests',[])
 print(json.dumps({'validation':'A24_FUNDED_CURRENCY_RESEARCH_READ_ONLY','status':out.get('status'),'reason':out.get('reason'),
   'positive_cash_context_count':len(contexts),'observed_funded_currencies':out.get('observed_funded_currencies',[]),
   'capital_status_counts':dict(Counter(c['capital_status'] for c in contexts)),
   'research_request_count':len(requests),'research_request_status_counts':dict(Counter(r['status'] for r in requests)),
   'candidate_count':len(bridge.candidates),'new_market_observations_collected':False,'training_requested':False,
   'financial_values_exported':False,'financial_mutation':False,'services_restarted':False,
   'automatic_execution_authorized':False,'canonical_publication_authorized':False},indent=2))
except Exception as exc:
 print(json.dumps({'validation':'A24_FUNDED_CURRENCY_RESEARCH_READ_ONLY','status':'INSPECTION_FAILED_CLOSED','error':type(exc).__name__,'financial_mutation':False,'automatic_execution_authorized':False},indent=2))
