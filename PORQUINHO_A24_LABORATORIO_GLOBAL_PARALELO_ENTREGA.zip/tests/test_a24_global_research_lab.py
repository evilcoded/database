"""Synthetic chronological and preservation checks; no live training or HTTP."""
import copy,datetime as dt,json,unittest,fcntl
from unittest.mock import patch
from pathlib import Path
import test_a24_global_history_source as fixture
from brain.evolution import global_research_lab_a24 as lab
from universal_portfolio import global_history_source_a24 as h
NOW=fixture.NOW
class Lab(unittest.TestCase):
 def setUp(self):
  self.f=fixture.History();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root;self.demand=self.f.demand
 def body(self,n=364):return h.bundle(self.f.f.rows(),self.f.response(n),now=NOW,binding_digest='fixture')
 def source(self,n=364):
  job=self.f.job();p=h.path_for(self.root,job,NOW);b=self.body(n);h.store_once(p,b);return p,b
 def runlab(self,**kw):return lab.run(self.root,self.demand,now=NOW,revalidate=lambda:{(c['account_id'],c['currency'],c['context_fingerprint']) for c in self.demand['contexts']},**kw)
 def summary(self,**kw):return lab.summary(self.root,self.demand,now=NOW,**kw)
 def test_364_points_compute_experiment(self):
  r=lab.experiment(self.body(),now=NOW);self.assertEqual(r['status'],'RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED');self.assertEqual(r['forecast']['horizon_value'],30);self.assertGreater(r['evaluation']['fold_count'],20)
 def test_strict_purged_train_boundary_each_fold(self):
  r=lab.experiment(self.body(),now=NOW)
  for f in r['evaluation']['fold_boundaries']:self.assertLess(f['last_training_label_end'],f['origin']);self.assertLess(f['origin'],f['target_observed_at'])
 def test_forecast_train_labels_precede_latest_provider_observation(self):
  r=lab.experiment(self.body(),now=NOW);self.assertLess(r['forecast']['model']['last_training_label_end'],r['forecast']['as_of_provider_observation'][:10])
 def test_no_calendar_target_date_fabricated(self):self.assertIsNone(lab.experiment(self.body(),now=NOW)['forecast']['future_target_date'])
 def test_historical_acquisition_not_past_forecast_or_certification(self):
  r=lab.experiment(self.body(),now=NOW)
  for k in lab.flags():self.assertEqual(r[k],lab.flags()[k])
  self.assertFalse(r['source_available_point_in_time_in_past']);self.assertTrue(r['evaluation_labels_overlap']);self.assertFalse(r['independent_test_sample_count_claimed'])
 def test_short_series_no_forecast(self):self.assertIsNone(lab.experiment(self.body(90),now=NOW)['forecast'])
 def test_minimum_exact_boundary(self):
  self.assertIsNone(lab.experiment(self.body(104),now=NOW)['forecast']);self.assertIsNotNone(lab.experiment(self.body(105),now=NOW)['forecast'])
 def test_baseline_is_matured_mean(self):
  x=[(float(i),float(i)/10) for i in range(60)];p,b,m=lab.fit_predict(x,10);self.assertAlmostEqual(b,sum(v for _,v in x)/60);self.assertEqual(m['training_label_count'],60)
 def test_future_prices_do_not_change_earlier_fold(self):
  b=self.body();response=copy.deepcopy(b['source_response']);first=lab.experiment(b,now=NOW)
  for point in response['prices'][201:]:point[1]=str(float(point[1])*2)
  changed=h.bundle(b['binding'],response,now=NOW,binding_digest='fixture');second=lab.experiment(changed,now=NOW)
  one=[f for f in first['evaluation']['fold_boundaries'] if f['target_observed_at']<=b['observations'][200]['observation_date']]
  two=[f for f in second['evaluation']['fold_boundaries'] if f['target_observed_at']<=b['observations'][200]['observation_date']]
  self.assertGreater(len(one),20);self.assertEqual(one,two)
 def test_binding_and_currency_preserved(self):
  b=self.body();r=lab.experiment(b,now=NOW)
  for k in ('instrument_id','provider','provider_id','quote_currency'):self.assertEqual(r[k],b['binding'][k])
 def test_stale_source_no_forecast(self):self.assertIsNone(lab.experiment(self.body(),now=NOW+dt.timedelta(days=5))['forecast'])
 def test_future_acquisition_refused(self):
  with self.assertRaises(ValueError):lab.experiment(self.body(),now=NOW-dt.timedelta(days=1))
 def test_unrepresentable_float_price_refused(self):
  b=self.body();response=copy.deepcopy(b['source_response']);response['prices'][0][1]='1e1000';b=h.bundle(b['binding'],response,now=NOW,binding_digest='fixture')
  with self.assertRaises(ValueError):lab.experiment(b,now=NOW)
 def test_processing_has_no_network(self):
  self.source()
  with patch.object(h.Transport,'get_json',side_effect=AssertionError('NO_HTTP')):self.assertEqual(self.runlab()['experiments_created'],1)
 def test_legacy_source_model_snapshot_and_memory_preserved(self):
  for rel in ('results/latest.json','results/prediction_lab.json','data/database/market_daily.csv','data/brain/memory.json'):
   p=self.root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'LEGACY')
  self.source();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};self.runlab()
  for p,raw in before.items():self.assertEqual(p.read_bytes(),raw)
 def test_repeat_preserves_bytes_and_mtime(self):
  self.source();self.runlab();before={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in (self.root/lab.STORE/'experiments').rglob('*.json')};self.assertEqual(self.runlab()['experiments_created'],0)
  self.assertEqual(before,{p:(p.read_bytes(),p.stat().st_mtime_ns) for p in before})
 def test_read_only_summary_pending_then_computed(self):
  self.source();self.assertEqual(self.summary()['contexts'][0]['status'],'AWAITING_GLOBAL_RESEARCH_PROCESSING');self.runlab();before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()};s=self.summary();self.assertEqual(s['forecast_count'],1);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()});self.assertNotIn('forecast',s['contexts'][0])
 def test_no_history_pending_explicit(self):self.assertEqual(self.summary()['contexts'][0]['status'],'AWAITING_GLOBAL_HISTORY');self.assertEqual(self.runlab()['experiments_created'],0)
 def test_removed_binding_not_consumed(self):
  self.source();self.f.f.save([]);self.assertEqual(self.summary()['context_count'],0);self.assertEqual(self.runlab()['experiments_created'],0)
 def test_revised_binding_not_reattributed(self):
  self.source();b=self.f.f.rows();b['identity_source_ref']='new-explicit-review';self.f.f.save([b]);self.assertEqual(self.summary()['contexts'][0]['status'],'AWAITING_GLOBAL_HISTORY')
 def test_no_funding_no_experiment(self):
  self.source();d=copy.deepcopy(self.demand);d['contexts']=[];self.assertEqual(lab.run(self.root,d,now=NOW)['experiments_created'],0)
 def test_changed_funding_before_write_refused(self):
  self.source();out=lab.run(self.root,self.demand,now=NOW,revalidate=lambda:set());self.assertEqual(out['experiments_created'],0);self.assertEqual(out['status'],'GLOBAL_RESEARCH_LAB_UNAVAILABLE')
 def test_corrupt_source_blocks_not_zero_ready(self):
  p,b=self.source();p.write_text('{}');self.assertEqual(self.summary()['status'],'GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE')
 def test_tampered_experiment_not_displayed(self):
  self.source();self.runlab();p=next((self.root/lab.STORE/'experiments').rglob('*.json'));body=h.read_sealed(p);body['forecast']['value']=999;p.unlink();h.store_once(p,body);self.assertEqual(self.summary()['status'],'GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE')
 def test_sealed_existing_different_experiment_preserved(self):
  p,b=self.source();target=self.root/lab.STORE/'experiments'/b['series_id']/(h.digest(b)+'.json');h.store_once(target,{'bad':1});before=target.read_bytes();self.assertEqual(self.runlab()['status'],'GLOBAL_RESEARCH_LAB_UNAVAILABLE');self.assertEqual(target.read_bytes(),before)
 def test_concurrent_lab_lock_refused(self):
  self.source();directory=self.root/lab.STORE;directory.mkdir(parents=True)
  with (directory/'lab.lock').open('w') as stream:
   fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB);self.assertEqual(self.runlab()['status'],'GLOBAL_LAB_BUSY')
 def test_summary_does_not_expose_account_or_numerical_forecast(self):
  self.source();self.runlab();s=json.dumps(self.summary());self.assertNotIn('account_id',s);self.assertNotIn('baseline_value',s);self.assertNotIn('slope',s)
 def test_one_new_experiment_per_cycle(self):
  self.f.f.save([self.f.f.rows(),self.f.f.rows(quote_currency='EUR')]);self.demand=self.f.f.demand(('BRL','EUR'))
  for job in h.plan(self.root,self.demand,now=NOW)['jobs']:
   body=h.bundle(job['binding'],self.f.response(364),now=NOW,binding_digest='fixture');h.store_once(h.path_for(self.root,job,NOW),body)
  self.assertEqual(self.runlab()['experiments_created'],1);self.assertEqual(self.summary()['forecast_count'],1);self.assertEqual(self.runlab()['experiments_created'],1);self.assertEqual(self.summary()['forecast_count'],2)
 def test_stale_existing_experiment_not_presented_current(self):
  self.source();self.runlab();s=lab.summary(self.root,self.demand,now=NOW+dt.timedelta(days=5));self.assertEqual(s['forecast_count'],0);self.assertEqual(s['contexts'][0]['status'],'STALE_SOURCE_NO_CURRENT_FORECAST')
 def test_unsupported_demand_unavailable(self):self.assertEqual(lab.summary(self.root,{},now=NOW)['status'],'GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE')
 def test_actual_cycle_hook_uses_same_funded_demand(self):
  import ast,types
  root=Path(__file__).resolve().parents[1];tree=ast.parse((root/'webapp/server.py').read_text());refresh=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_refresh');imp=next(n for n in ast.walk(refresh) if isinstance(n,ast.ImportFrom) and n.module=='brain.evolution.global_research_lab_a24');assignment=next(n for n in ast.walk(refresh) if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='_a24_run_global_lab');ns={'ROOT':self.root,'universal_shadow':{},'_universal_result':types.SimpleNamespace(bridge=types.SimpleNamespace(intelligence={'funded_currency_research':self.demand}))}
  with patch.object(lab,'run',return_value={'status':'TEST'}) as hook:exec(compile(ast.Module(body=[imp,assignment],type_ignores=[]),'actual_global_lab_hook','exec'),ns)
  hook.assert_called_once_with(self.root,self.demand)
 def test_gapped_dates_keep_observation_horizon(self):
  b=self.body();response=copy.deepcopy(b['source_response']);response['prices']=response['prices'][::2];response['market_caps']=[];response['total_volumes']=[]
  r=lab.experiment(h.bundle(b['binding'],response,now=NOW,binding_digest='fixture'),now=NOW)
  fold=r['evaluation']['fold_boundaries'][0];self.assertEqual((dt.date.fromisoformat(fold['target_observed_at'])-dt.date.fromisoformat(fold['origin'])).days,60);self.assertEqual(r['horizon_value'],30)
 def test_binding_change_before_write_refused(self):
  self.source()
  def changed():self.f.f.save([]);return self.f.current()
  self.assertEqual(lab.run(self.root,self.demand,now=NOW,revalidate=changed)['experiments_created'],0)
 def test_source_symlink_refused(self):
  p,b=self.source();target=self.root/'preserved';target.write_bytes(p.read_bytes());p.unlink();p.symlink_to(target);self.assertEqual(self.runlab()['status'],'GLOBAL_RESEARCH_LAB_UNAVAILABLE')
 def test_resealed_corruption_not_accepted_on_repeat(self):
  self.source();self.runlab();p=next((self.root/lab.STORE/'experiments').rglob('*.json'));body=h.read_sealed(p);body['forecast']['value']=999;p.unlink();h.store_once(p,body);self.assertEqual(self.runlab()['status'],'GLOBAL_RESEARCH_LAB_UNAVAILABLE')
 def test_old_experiment_version_preserved_when_source_changes(self):
  p,b=self.source();self.runlab();original=next((self.root/lab.STORE/'experiments').rglob('*.json'));raw=original.read_bytes();tomorrow=NOW+dt.timedelta(days=1);new=h.bundle(b['binding'],self.f.response(364),now=tomorrow,binding_digest='fixture');h.store_once(h.path_for(self.root,{'binding':b['binding']},tomorrow),new)
  self.assertEqual(lab.run(self.root,self.demand,now=tomorrow,revalidate=self.f.current)['experiments_created'],1);self.assertEqual(original.read_bytes(),raw)
