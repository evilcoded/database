"""Parallel global research experiment. Never a certified economic producer.
Provider history acquired now supports retrospective evaluation, not past forecasts.
"""
import datetime as dt
import fcntl
import math
import os
from pathlib import Path
from universal_portfolio import global_history_source_a24 as history
from universal_portfolio import research_quote_acquisition_a24 as quotes
from universal_portfolio.explicit_market_bindings_a24 import local,digest,load

SCHEMA='porquinho.global-research-lab-a24/1.0'
STORE='data/brain/global_research_lab_a24'
METHOD='MOMENTUM14_RIDGE1E-6_EXPANDING_PURGED30_V1'
HORIZON=30
MIN_TRAIN=60
LOOKBACK=14
MAX_FILES=4096
class LabError(ValueError):pass

def flags():
 return {'authority':'RESEARCH_ONLY','model_validation_proven':False,
  'expected_returns_certified':False,'canonical_publication_authorized':False,
  'execution_authorized':False,'financial_mutation':False,
  'past_forecast_availability_attested':False,'legacy_learning_modified':False}

def fit_predict(samples,x):
 """Fixed ridge slope, unpenalized intercept; no hyperparameter selection."""
 n=len(samples)
 if n<MIN_TRAIN:raise LabError('INSUFFICIENT_MATURED_TRAINING_LABELS')
 mx=sum(a for a,b in samples)/n;my=sum(b for a,b in samples)/n
 slope=sum((a-mx)*(b-my) for a,b in samples)/(sum((a-mx)**2 for a,b in samples)+1e-6)
 intercept=my-slope*mx;prediction=intercept+slope*x
 if not all(math.isfinite(v) for v in (prediction,slope,intercept,my)):raise LabError('NONFINITE_RESEARCH_FIT')
 return prediction,my,{'intercept':intercept,'slope':slope,'training_label_count':n}

def experiment(body,*,now):
 history.validate_bundle(body)
 fetched=quotes.utc(dt.datetime.fromisoformat(body['fetched_at']))
 if fetched>now:raise LabError('FUTURE_SOURCE_ACQUISITION')
 rows=body['observations'];n=len(rows)
 prices=[float(r['price']) for r in rows]
 if any(not math.isfinite(p) or p<=0 for p in prices):raise LabError('UNREPRESENTABLE_SOURCE_PRICE')
 result={'schema':SCHEMA,'method':METHOD,'series_id':body['series_id'],
  'instrument_id':body['binding']['instrument_id'],'provider':body['binding']['provider'],
  'provider_id':body['binding']['provider_id'],'quote_currency':body['binding']['quote_currency'],
  'source_body_sha256':digest(body),'source_fetched_at':body['fetched_at'],
  'sampling':body['sampling'],'observation_count':n,'horizon_unit':'OBSERVATIONS','horizon_value':HORIZON,
  'source_available_point_in_time_in_past':False,'evaluation_kind':'RETROSPECTIVE_RESEARCH_WITH_PURGED_LABELS',
  'evaluation_labels_overlap':True,'independent_test_sample_count_claimed':False,
  'forecast':None,'evaluation':None,**flags()}
 age=(now.date()-dt.date.fromisoformat(rows[-1]['observation_date'])).days
 if age>3:return {**result,'status':'STALE_SOURCE_NO_CURRENT_FORECAST'}
 if n<LOOKBACK+HORIZON+MIN_TRAIN+1:return {**result,'status':'INSUFFICIENT_HISTORY_FOR_RESEARCH_FIT'}
 features={i:prices[i]/prices[i-LOOKBACK]-1 for i in range(LOOKBACK,n)}
 labels={i:prices[i+HORIZON]/prices[i]-1 for i in range(LOOKBACK,n-HORIZON)}
 if not all(math.isfinite(x) for x in [*features.values(),*labels.values()]):raise LabError('NONFINITE_RESEARCH_FEATURE')
 def predict(i):
  # Strict embargo: a label ending at i is not used to predict at i.
  train=[j for j in labels if j+HORIZON<i]
  y,baseline,model=fit_predict([(features[j],labels[j]) for j in train],features[i])
  return y,baseline,{**model,'first_training_origin':rows[train[0]]['observation_date'],
   'last_training_origin':rows[train[-1]]['observation_date'],
   'last_training_label_end':rows[train[-1]+HORIZON]['observation_date']}
 errors=[];base_errors=[];folds=[]
 for i in sorted(labels):
  if sum(j+HORIZON<i for j in labels)<MIN_TRAIN:continue
  value,baseline,model=predict(i)
  errors.append(abs(value-labels[i]));base_errors.append(abs(baseline-labels[i]))
  folds.append({'origin':rows[i]['observation_date'],'target_observed_at':rows[i+HORIZON]['observation_date'],
   'last_training_label_end':model['last_training_label_end'],'training_label_count':model['training_label_count'],
   'prediction':value,'baseline_prediction':baseline,'realized_return':labels[i]})
 value,baseline,model=predict(n-1)
 evaluation={'fold_count':len(errors),'mean_absolute_error':sum(errors)/len(errors) if errors else None,
  'historical_mean_baseline_mae':sum(base_errors)/len(base_errors) if errors else None,
  'status':'RETROSPECTIVE_METRICS_NOT_MODEL_APPROVAL' if len(errors)>=20 else 'INSUFFICIENT_EVALUATION_FOLDS',
  'fold_boundaries':folds,'baseline':'EXPANDING_MATURED_TRAINING_LABEL_MEAN'}
 forecast={'value':value,'unit':'RETURN_FRACTION','baseline_value':baseline,
  'as_of_provider_observation':rows[-1]['provider_observed_at'],
  'future_target_date':None,'horizon_unit':'OBSERVATIONS','horizon_value':HORIZON,
  'model':model,'status':'EXPERIMENTAL_NOT_VALIDATED_NOT_A_RECOMMENDATION'}
 return {**result,'status':'RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED','forecast':forecast,'evaluation':evaluation}

def sources(root,demand,now):
 planned=quotes.plan(root,demand,now=now,include_observed=True)
 eligible={history.series_id(j['binding']):j for j in planned['jobs']}
 directory=local(root,history.STORE+'/bundles');paths=sorted(directory.glob('*/*.json')) if directory.exists() else []
 if len(paths)>MAX_FILES or sum(p.stat().st_size for p in paths)>64*1024*1024:raise LabError('SOURCE_READ_LIMIT')
 latest={};stats={}
 for path in paths:
  p=local(root,str(path.relative_to(Path(root).resolve())))
  stats[p]=(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino)
  body=history.validate_bundle(history.read_sealed(p),p)
  key=body['series_id']
  if key not in eligible:continue
  if body['binding']!=eligible[key]['binding']:raise LabError('CURRENT_BINDING_CONTEXT_MISMATCH')
  if key not in latest or body['fetched_at']>latest[key][1]['fetched_at']:latest[key]=(p,body)
 if paths!=(sorted(directory.glob('*/*.json')) if directory.exists() else []) or stats!={p:(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) for p in stats}:raise LabError('SOURCE_CHANGED_DURING_READ')
 return planned,eligible,latest

def run(root,demand,*,now=None,revalidate=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc));handle=None
 out={'schema':SCHEMA,'status':'GLOBAL_LAB_NOT_RUN','experiments_created':0,'network_requests':0,
  'training_scope':'NEW_ISOLATED_RESEARCH_FITS_ONLY',**flags()}
 try:
  planned,eligible,latest=sources(root,demand,now)
  if not latest:return {**out,'status':'AWAITING_ELIGIBLE_GLOBAL_HISTORY'}
  directory=local(root,STORE);directory.mkdir(parents=True,exist_ok=True)
  fd=os.open(local(root,STORE+'/lab.lock'),os.O_CREAT|os.O_WRONLY|getattr(os,'O_NOFOLLOW',0),0o600);handle=os.fdopen(fd,'w')
  try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
  except BlockingIOError:return {**out,'status':'GLOBAL_LAB_BUSY'}
  for key,(path,body) in sorted(latest.items()):
   source_hash=digest(body);target=local(root,STORE+'/experiments/'+key+'/'+source_hash+'.json')
   if target.exists():
    previous=history.read_sealed(target)
    stamp=quotes.utc(dt.datetime.fromisoformat(previous['computed_at']))
    if stamp>now or previous!={**experiment(body,now=stamp),'computed_at':stamp.isoformat()}:raise LabError('EXISTING_EXPERIMENT_PRESERVED')
    continue
   result=experiment(body,now=now)
   current=(revalidate or (lambda:quotes.current_contexts(root)))()
   if digest(load(root))!=planned['binding_digest'] or not all(tuple(c) in current for c in eligible[key]['funding_contexts']):raise LabError('ELIGIBILITY_CHANGED_BEFORE_LAB_WRITE')
   if history.read_sealed(path)!=body:raise LabError('SOURCE_CHANGED_BEFORE_LAB_WRITE')
   result['computed_at']=now.isoformat()
   history.store_once(target,result)
   return {**out,'status':'GLOBAL_RESEARCH_EXPERIMENT_RECORDED','experiments_created':1}
  return {**out,'status':'GLOBAL_RESEARCH_EXPERIMENTS_CURRENT'}
 except Exception as exc:return {**out,'status':'GLOBAL_RESEARCH_LAB_UNAVAILABLE','error_type':type(exc).__name__}
 finally:
  if handle is not None:handle.close()

def summary(root,demand,*,now=None):
 now=quotes.utc(now or dt.datetime.now(dt.timezone.utc))
 result={'schema':SCHEMA,'status':'GLOBAL_RESEARCH_LAB_INSPECTED','context_count':0,'forecast_count':0,
  'contexts':[],'network_requests':0,'history_write_performed':False,**flags()}
 try:
  planned,eligible,latest=sources(root,demand,now);contexts=[]
  for key,job in sorted(eligible.items()):
   binding=job['binding'];row={k:binding[k] for k in ('instrument_id','provider','provider_id','quote_currency')}
   row.update(series_id=key,status='AWAITING_GLOBAL_HISTORY',observation_count=0,evaluation_fold_count=0)
   if key in latest:
    path,body=latest[key];source_hash=digest(body)
    target=local(root,STORE+'/experiments/'+key+'/'+source_hash+'.json')
    row.update(status='AWAITING_GLOBAL_RESEARCH_PROCESSING',observation_count=len(body['observations']))
    if target.exists():
     stored=history.read_sealed(target);stamp=quotes.utc(dt.datetime.fromisoformat(stored['computed_at']))
     if stamp>now:raise LabError('FUTURE_EXPERIMENT')
     expected={**experiment(body,now=stamp),'computed_at':stamp.isoformat()}
     if stored!=expected:raise LabError('EXPERIMENT_PROJECTION_MISMATCH')
     stale=(now.date()-dt.date.fromisoformat(body['observations'][-1]['observation_date'])).days>3
     row.update(status='STALE_SOURCE_NO_CURRENT_FORECAST' if stale else stored['status'],
      evaluation_fold_count=(stored.get('evaluation') or {}).get('fold_count',0),computed_at=stamp.isoformat())
   contexts.append(row)
  return {**result,'context_count':len(contexts),'forecast_count':sum(c['status']=='RESEARCH_FORECAST_COMPUTED_NOT_VALIDATED' for c in contexts),'contexts':contexts}
 except Exception as exc:return {**result,'status':'GLOBAL_RESEARCH_LAB_INSPECTION_UNAVAILABLE','context_count':None,'forecast_count':None,'contexts':[],'error_type':type(exc).__name__}
