"""Read-only retrospective model assessment against the same matured-label baseline.
No persisted fitting, model selection, publication, monetary history rewrite or certification.
"""
import datetime as dt,math
from . import global_research_lab_a24 as lab
from universal_portfolio import global_history_source_a24 as history
from universal_portfolio.research_quote_acquisition_a24 import utc
from universal_portfolio.explicit_market_bindings_a24 import local,digest
SCHEMA='porquinho.global-model-evaluation-a24/1.0'
METHOD='PAIRED_MAE_AND_DISJOINT_30OBS_WINDOWS_V1'
class EvaluationError(ValueError):pass

def flags():return {'authority':'NONE','research_only':True,'model_validation_proven':False,'prospective_validation_proven':False,'comparison_authorized':False,'canonical_publication_authorized':False,'execution_authorized':False,'training_requested':False,'history_write_performed':False,'financial_mutation':False}
def finite(value):
 if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value):raise EvaluationError('FINITE_EVALUATION_NUMBER_REQUIRED')
 return float(value)

def metrics(folds):
 if not folds:return {'sample_count':0,'model_mae':None,'baseline_mae':None,'relative_mae_improvement_pct':None,'paired_absolute_error_difference':None,'model_win_count':0,'result':'NO_EVALUATION_SAMPLES'}
 model=[abs(finite(f['prediction'])-finite(f['realized_return'])) for f in folds]
 baseline=[abs(finite(f['baseline_prediction'])-finite(f['realized_return'])) for f in folds]
 a=sum(model)/len(model);b=sum(baseline)/len(baseline)
 result='EQUAL_MAE_TO_BASELINE' if math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-12) else 'LOWER_MAE_THAN_BASELINE' if a<b else 'HIGHER_MAE_THAN_BASELINE'
 improvement=(b-a)/b*100 if b>0 else None
 values=[a,b,a-b]+([improvement] if improvement is not None else [])
 if not all(math.isfinite(v) for v in values):raise EvaluationError('NONFINITE_EVALUATION_METRIC')
 return {'sample_count':len(folds),'model_mae':a,'baseline_mae':b,'relative_mae_improvement_pct':improvement,
  'paired_absolute_error_difference':a-b,'model_win_count':sum(x<y for x,y in zip(model,baseline)),'result':result}

def disjoint(folds):
 """Fixed earliest-origin schedule; next window starts AFTER prior target date.
No performance-based sample selection, no shared endpoint, no independence claim.
"""
 out=[];end=None
 for fold in folds:
  if end is None or fold['origin']>end:out.append(fold);end=fold['target_observed_at']
 return out

def assess(body,experiment,*,now):
 stamp=utc(dt.datetime.fromisoformat(experiment['computed_at']))
 if stamp>now or experiment!={**lab.experiment(body,now=stamp),'computed_at':stamp.isoformat()}:raise EvaluationError('EXPERIMENT_SOURCE_PROJECTION_MISMATCH')
 identity=body['binding'];base={'schema':SCHEMA,'method':METHOD,'series_id':body['series_id'],
  **{k:identity[k] for k in ('instrument_id','provider','provider_id','quote_currency')},
  'source_body_sha256':digest(body),'experiment_sha256':digest(experiment),'experiment_computed_at':experiment['computed_at'],
  'horizon_unit':'OBSERVATIONS','horizon_value':30,'sampling':body['sampling'],
  'baseline':'EXPANDING_MATURED_TRAINING_LABEL_MEAN','available_in_past_attested':False,
  'independence_of_samples_proven':False,'multiple_comparison_correction_applied':False,
  'policy':'DESCRIPTIVE_ASSESSMENT_NO_ACCEPTANCE_THRESHOLD_OR_AUTOMATIC_PROMOTION',**flags()}
 if (now.date()-dt.date.fromisoformat(body['observations'][-1]['observation_date'])).days>3:return {**base,'status':'STALE_SOURCE_NOT_CURRENT_MODEL_EVALUATION'}
 evaluation=experiment.get('evaluation')
 if not evaluation:return {**base,'status':'NO_MATURED_RESEARCH_EVALUATION'}
 folds=evaluation.get('fold_boundaries');dates=[r['observation_date'] for r in body['observations']];date_index={v:i for i,v in enumerate(dates)}
 if not isinstance(folds,list) or len(folds)!=evaluation['fold_count']:raise EvaluationError('COMPLETE_FOLD_LIST_REQUIRED')
 previous=None
 for fold in folds:
  start=fold.get('origin');end=fold.get('target_observed_at');train=fold.get('last_training_label_end')
  if start not in date_index or end not in date_index or train not in date_index or date_index[end]-date_index[start]!=30 or not train<start<end or (previous is not None and start<=previous):raise EvaluationError('PURGED_OBSERVATION_HORIZON_GEOMETRY_INVALID')
  if type(fold.get('training_label_count')) is not int or fold['training_label_count']<lab.MIN_TRAIN:raise EvaluationError('TRAINING_LABEL_POPULATION_INVALID')
  previous=start
 all_metrics=metrics(folds)
 if folds and (not math.isclose(all_metrics['model_mae'],evaluation['mean_absolute_error'],rel_tol=1e-9,abs_tol=1e-12) or not math.isclose(all_metrics['baseline_mae'],evaluation['historical_mean_baseline_mae'],rel_tol=1e-9,abs_tol=1e-12)):raise EvaluationError('STORED_METRICS_RECOMPUTATION_MISMATCH')
 nonoverlap=disjoint(folds);recent=folds[len(folds)//2:]
 return {**base,'status':'RETROSPECTIVE_ASSESSMENT_AVAILABLE_NOT_CERTIFIED','all_windows':all_metrics,
  'disjoint_windows':metrics(nonoverlap),'recent_half_windows':metrics(recent),
  'disjoint_window_boundaries':[{'origin':f['origin'],'target_observed_at':f['target_observed_at']} for f in nonoverlap],
  'recent_half_first_origin':recent[0]['origin'] if recent else None,
  'retrospective_evaluation_is_not_a_past_issued_forecast':True,
  'remaining_validation':['POINT_IN_TIME_SOURCE_AVAILABILITY_NOT_ATTESTED','PROSPECTIVE_FORECAST_OUTCOMES_NOT_PROVEN','ECONOMIC_COST_RISK_UTILITY_VALIDATION_SEPARATE']}

def inspect(root,demand,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc));rows=[]
 try:
  plan,eligible,latest=lab.sources(root,demand,now)
  for key,job in sorted(eligible.items()):
   row={'series_id':key,**{k:job['binding'][k] for k in ('instrument_id','provider','provider_id','quote_currency')},'status':'AWAITING_GLOBAL_HISTORY'}
   if key in latest:
    source,body=latest[key];source_hash=digest(body);p=local(root,lab.STORE+'/experiments/'+key+'/'+source_hash+'.json')
    row['status']='AWAITING_GLOBAL_RESEARCH_PROCESSING'
    if p.exists():
     before=(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino);experiment=history.read_sealed(p)
     row=assess(body,experiment,now=now)
     if before!=(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) or history.read_sealed(source)!=body:raise EvaluationError('EVALUATION_SOURCE_CHANGED_DURING_READ')
   rows.append(row)
  available=[r for r in rows if r['status']=='RETROSPECTIVE_ASSESSMENT_AVAILABLE_NOT_CERTIFIED']
  return {'schema':SCHEMA,'status':'GLOBAL_MODEL_ASSESSMENT_INSPECTED','context_count':len(rows),'assessed_context_count':len(available),
   'all_window_result_counts':{result:sum(r['all_windows']['result']==result for r in available) for result in ('LOWER_MAE_THAN_BASELINE','HIGHER_MAE_THAN_BASELINE','EQUAL_MAE_TO_BASELINE')},
   'network_requests':0,'contexts':rows,**flags()}
 except Exception as exc:return {'schema':SCHEMA,'status':'GLOBAL_MODEL_ASSESSMENT_UNAVAILABLE','context_count':None,'assessed_context_count':None,'contexts':[],'error_type':type(exc).__name__,'network_requests':0,**flags()}
