import copy,datetime as dt,unittest
from unittest.mock import patch
import test_a24_global_research_lab as fixture
from brain.evolution import global_model_evaluation_a24 as e
from universal_portfolio import global_history_source_a24 as h
NOW=fixture.NOW
class Assessment(unittest.TestCase):
 def setUp(self):
  self.f=fixture.Lab();self.f.setUp();self.addCleanup(self.f.doCleanups);self.root=self.f.root;self.demand=self.f.demand
 def ready(self):self.f.source();self.f.runlab();return e.inspect(self.root,self.demand,now=NOW)
 def fold(self,p=1,b=2,y=0):return {'prediction':p,'baseline_prediction':b,'realized_return':y}
 def test_better(self):self.assertEqual(e.metrics([self.fold()])['result'],'LOWER_MAE_THAN_BASELINE')
 def test_worse(self):self.assertEqual(e.metrics([self.fold(3)])['result'],'HIGHER_MAE_THAN_BASELINE')
 def test_tie(self):self.assertEqual(e.metrics([self.fold(2)])['result'],'EQUAL_MAE_TO_BASELINE')
 def test_zero_baseline(self):self.assertIsNone(e.metrics([self.fold(1,0)])['relative_mae_improvement_pct'])
 def test_empty(self):self.assertIsNone(e.metrics([])['model_mae'])
 def test_nonfinite(self):
  for v in (float('inf'),float('nan'),True):
   with self.assertRaises(ValueError):e.metrics([self.fold(v)])
 def test_disjoint_no_shared_endpoint(self):
  folds=[{'origin':x,'target_observed_at':x+30} for x in range(100)]
  self.assertEqual([f['origin'] for f in e.disjoint(folds)],[0,31,62,93])
 def test_real_geometry_and_recent_half(self):
  r=self.ready();self.assertEqual(r['assessed_context_count'],1);c=r['contexts'][0]
  self.assertEqual(c['all_windows']['sample_count'],230);self.assertEqual(c['recent_half_windows']['sample_count'],115);self.assertEqual(c['disjoint_windows']['sample_count'],8)
  bounds=c['disjoint_window_boundaries']
  for a,b in zip(bounds,bounds[1:]):self.assertLess(a['target_observed_at'],b['origin'])
 def test_inspection_preserves_all_bytes_and_mtimes(self):
  self.ready();before={p:(p.read_bytes(),p.stat().st_mtime_ns) for p in self.root.rglob('*') if p.is_file()}
  with patch.object(h.Transport,'get_json',side_effect=AssertionError('NETWORK_FORBIDDEN')):r=e.inspect(self.root,self.demand,now=NOW)
  self.assertEqual(r['assessed_context_count'],1);self.assertEqual(before,{p:(p.read_bytes(),p.stat().st_mtime_ns) for p in self.root.rglob('*') if p.is_file()})
 def test_no_authority_or_training(self):
  c=self.ready()['contexts'][0]
  for k,v in e.flags().items():self.assertEqual(c[k],v)
  self.assertFalse(c['available_in_past_attested']);self.assertFalse(c['independence_of_samples_proven'])
 def test_missing_history_pending(self):self.assertEqual(e.inspect(self.root,self.demand,now=NOW)['contexts'][0]['status'],'AWAITING_GLOBAL_HISTORY')
 def test_missing_experiment_pending(self):
  self.f.source();self.assertEqual(e.inspect(self.root,self.demand,now=NOW)['contexts'][0]['status'],'AWAITING_GLOBAL_RESEARCH_PROCESSING')
 def test_tampered_experiment_refused(self):
  body=self.f.body();x={**e.lab.experiment(body,now=NOW),'computed_at':NOW.isoformat()};x['evaluation']['fold_boundaries'][0]['prediction']+=1
  with self.assertRaises(ValueError):e.assess(body,x,now=NOW)
 def test_stale_not_current_evaluation(self):
  self.ready();r=e.inspect(self.root,self.demand,now=NOW+dt.timedelta(days=5));self.assertEqual(r['assessed_context_count'],0);self.assertEqual(r['contexts'][0]['status'],'STALE_SOURCE_NOT_CURRENT_MODEL_EVALUATION')
 def test_exact_context_preserved(self):
  c=self.ready()['contexts'][0];body=self.f.body()
  for k in ('instrument_id','provider','provider_id','quote_currency'):self.assertEqual(c[k],body['binding'][k])
 def test_future_computation_refused(self):
  body=self.f.body();x={**e.lab.experiment(body,now=NOW),'computed_at':(NOW+dt.timedelta(days=1)).isoformat()}
  with self.assertRaises(ValueError):e.assess(body,x,now=NOW)
