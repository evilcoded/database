import unittest,tempfile,importlib.util,sys,os,json,io,signal
from pathlib import Path
from unittest.mock import patch,Mock
from contextlib import redirect_stdout
spec=importlib.util.spec_from_file_location('a24activation',str(Path(__file__).resolve().parent/'PORQUINHO_A24_ATIVAR_CONSOLIDACAO_V18.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Activation(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  self.root=Path(self.tmp.name)/'project';self.root.mkdir();self.home=Path(self.tmp.name)/'home';self.home.mkdir()
  (self.root/'.venv/bin').mkdir(parents=True);self.python=self.root/'.venv/bin/python';self.python.write_text('placeholder');self.python.chmod(0o700)
  self.phase='old';self.gets=0;self.clock=0
 def listeners(self,port):
  if port==8787:return [8787]
  return {'old':[1001],'stopped':[],'new':[1002]}[self.phase]
 def kill(self,pid,sig):
  self.assertEqual((pid,sig),(1001,signal.SIGTERM));self.phase='stopped'
 def popen(self,args,**kwargs):
  self.assertEqual(args,[str(self.python),'-m','webapp.server']);self.assertEqual(kwargs['cwd'],self.root)
  self.assertTrue(kwargs['start_new_session']);self.phase='new'
  p=Mock();p.pid=1002;p.poll.return_value=None;return p
 def status(self):
  self.gets+=1
  return {'snapshot':{'timestamp':'2026-10-15T00:00:00+00:00' if self.gets<=2 else '2026-10-15T01:00:00+00:00'},'jobs':[]}
 def shell(self,args):
  if args[-1]=='pid=':return '' if self.phase!='old' else '1001'
  if args[-1]=='lstart=':return 'TEST_BRIDGE_START' if '8787' in args else 'TEST_START'
  raise AssertionError(args)
 def monotonic(self):self.clock+=5;return self.clock
 def mocks(self):
  from contextlib import ExitStack
  stack=ExitStack();self.addCleanup(stack.close)
  stack.enter_context(patch.object(m,'monitor_ui_status',return_value={'endpoint_observed':True,'diagnostic_revision':'GLOBAL_MODEL_ASSESSMENT_1','observed_manual_trade_costs':{'schema':'porquinho.observed-trade-costs-a24/1.0'},'account_cost_evidence':{'schema':'porquinho.account-cost-evidence-a24/1.0'},'research_economic_components':{'schema':'porquinho.research-economic-components-a24/1.0'},'global_model_evaluation':{'schema':'porquinho.global-model-evaluation-a24/1.0'},'global_research_lab':{'schema':'porquinho.global-research-lab-a24/1.0'},'economic_set_producer_diagnostic':{'schema':'porquinho.economic-component-set-producer-a24/1.0'},'scoped_economic_comparison_summary':{'schema':'porquinho.scoped-economic-comparisons-a24/1.0'}}));stack.enter_context(patch.object(m,'EXPECTED',{}));stack.enter_context(patch.object(Path,'home',return_value=self.home))
  stack.enter_context(patch.object(m,'listeners',side_effect=self.listeners));stack.enter_context(patch.object(m,'identify',return_value='TEST_START'))
  stack.enter_context(patch.object(m,'status',side_effect=self.status));stack.enter_context(patch.object(m,'shell',side_effect=self.shell))
  self.killmock=stack.enter_context(patch.object(m.os,'kill',side_effect=self.kill))
  self.spawn=stack.enter_context(patch.object(m.subprocess,'Popen',side_effect=self.popen))
  stack.enter_context(patch.object(m.time,'sleep'));stack.enter_context(patch.object(m.time,'monotonic',side_effect=self.monotonic))
  stack.enter_context(redirect_stdout(io.StringIO()))
 def test_restart_only_identified_process_and_preserve_bridge(self):
  self.mocks();m.main(self.root)
  self.killmock.assert_called_once_with(1001,signal.SIGTERM);self.spawn.assert_called_once()
  report=json.loads(next((self.home/'Downloads').glob('PORQUINHO_A24_MODEL_ASSESSMENT_ACTIVATION_*.json')).read_text())
  self.assertTrue(report['bridge_listener_unchanged']);self.assertTrue(report['new_snapshot_observed'])
  self.assertFalse(report['manual_refresh_requested']);self.assertFalse(report['financial_endpoint_requested'])
  self.assertEqual(report['capture']['new_cold_start_records'],0)
 def test_busy_worker_refuses_before_signal(self):
  self.mocks()
  with patch.object(m,'status',return_value={'snapshot':{},'jobs':[{'status':'running'}]}):
   with self.assertRaisesRegex(RuntimeError,'ACTIVE_OR_QUEUED'):m.main(self.root)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_wrong_listener_count_refuses(self):
  self.mocks()
  with patch.object(m,'listeners',return_value=[1,2]):
   with self.assertRaisesRegex(RuntimeError,'EXACTLY_ONE'):m.main(self.root)
  self.killmock.assert_not_called()
 def test_wrong_source_hash_refuses(self):
  self.mocks()
  with patch.object(m,'EXPECTED',{'missing.py':'bad'}):
   with self.assertRaisesRegex(RuntimeError,'SOURCE_HASH'):m.main(self.root)
  self.killmock.assert_not_called()
 def test_verify_only_does_not_restart(self):
  self.mocks();m.main(self.root,verify_only=True)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_existing_activation_marker_prevents_duplicate_restart(self):
  self.mocks();directory=self.home/'Downloads';directory.mkdir()
  (directory/'.porquinho_a24_last_activation.json').write_text(json.dumps({'root':str(self.root),'pid':1001,'process_started_at':'TEST_START','hashes':{}}))
  m.main(self.root);self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_job_appearing_at_recheck_refuses(self):
  self.mocks()
  values=[{'snapshot':{},'jobs':[]},{'snapshot':{},'jobs':[{'status':'queued'}]}]
  with patch.object(m,'status',side_effect=values):
   with self.assertRaisesRegex(RuntimeError,'STATE_CHANGED'):m.main(self.root)
  self.killmock.assert_not_called()
 def test_changed_process_at_recheck_refuses(self):
  self.mocks()
  with patch.object(m,'identify',side_effect=['OLD','DIFFERENT']):
   with self.assertRaisesRegex(RuntimeError,'STATE_CHANGED'):m.main(self.root)
  self.killmock.assert_not_called()
 def test_identify_checks_uid_root_binary_and_module(self):
  m.LSOF='lsof'
  def run(args):
   if args[-1]=='uid=':return str(os.getuid())
   if args[-1]=='command=':return str(self.python)+' -m webapp.server'
   if args[-1]=='-Fn':return 'p1001\nn'+str(self.root)
   if args[-1]=='lstart=':return 'START'
   raise AssertionError(args)
  with patch.object(m,'shell',side_effect=run):self.assertEqual(m.identify(1001,self.root,self.python),'START')
  def bad(args):return str(self.python)+' app.py' if args[-1]=='command=' else run(args)
  with patch.object(m,'shell',side_effect=bad):
   with self.assertRaisesRegex(RuntimeError,'LAUNCHER'):m.identify(1001,self.root,self.python)
 def test_forecast_old_changes_are_reported(self):
  directory=self.root/'data/brain/prospective/buy_forecasts';directory.mkdir(parents=True)
  p=directory/'a.json';p.write_text('{}');before=m.forecasts(self.root);p.write_text('{"changed":true}')
  self.assertEqual(m.report_capture(self.root,before)['old_forecast_files_changed_or_removed'],1)
class GlobalGuards(unittest.TestCase):
 setUp=Activation.setUp
 listeners=Activation.listeners
 kill=Activation.kill
 popen=Activation.popen
 status=Activation.status
 shell=Activation.shell
 monotonic=Activation.monotonic
 mocks=Activation.mocks

 def test_shared_bridge_listener_refuses_before_signal(self):
  self.mocks()
  with patch.object(m,'listeners',return_value=[1001]):
   with self.assertRaisesRegex(RuntimeError,'SHARED_BRIDGE'):m.main(self.root)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_bridge_change_at_recheck_refuses_before_signal(self):
  self.mocks();calls=0
  def port(p):
   nonlocal calls
   if p==8787:
    calls+=1;return [8787] if calls==1 else [8788]
   return [1001]
  with patch.object(m,'listeners',side_effect=port):
   with self.assertRaisesRegex(RuntimeError,'BRIDGE_CHANGED'):m.main(self.root)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_ignored_sigterm_does_not_start_second_server(self):
  self.mocks()
  with patch.object(m.os,'kill'):
   with self.assertRaisesRegex(RuntimeError,'OLD_PROCESS_DID_NOT_EXIT'):m.main(self.root)
  self.spawn.assert_not_called()
 def test_source_change_at_recheck_refuses(self):
  self.mocks()
  with patch.object(m,'verify_sources',side_effect=[None,RuntimeError('SOURCE_CHANGED')]):
   with self.assertRaisesRegex(RuntimeError,'SOURCE_CHANGED'):m.main(self.root)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_old_marker_with_other_source_hashes_requires_restart(self):
  self.mocks();directory=self.home/'Downloads';directory.mkdir()
  (directory/'.porquinho_a24_last_activation.json').write_text(json.dumps({'root':str(self.root),'pid':1001,'process_started_at':'TEST_START','hashes':{'old':'hash'}}))
  m.main(self.root);self.killmock.assert_called_once();self.spawn.assert_called_once()
 def test_malformed_journal_aborts_before_signal(self):
  self.mocks();directory=self.root/'results';directory.mkdir();(directory/'p35e_research_forecast_issuance.jsonl').write_text('broken')
  with self.assertRaises(ValueError):m.main(self.root)
  self.killmock.assert_not_called();self.spawn.assert_not_called()
 def test_after_read_failure_does_not_hide_successful_restart(self):
  self.mocks()
  with patch.object(m,'binding_diagnostics',side_effect=[{},ValueError('changed')]):m.main(self.root)
  report=json.loads(next((self.home/'Downloads').glob('PORQUINHO_A24_MODEL_ASSESSMENT_ACTIVATION_*.json')).read_text())
  self.assertTrue(report['porquinho_restarted']);self.assertEqual(report['bindings_after']['inspection']['status'],'READ_UNAVAILABLE_OR_CHANGED_RETRY_DIAGNOSTICS')
 def test_rewritten_issuance_prefix_is_reported_and_refused(self):
  self.mocks()
  before={'issuance':{'status':'VERIFIED_LOCAL_CHAIN_UNATTESTED','records':1,'_tail_hash':'old'}}
  after={'issuance':{'status':'VERIFIED_LOCAL_CHAIN_UNATTESTED','records':1,'_prior_prefix_hash':'different'}}
  with patch.object(m,'binding_diagnostics',side_effect=[before,after]):
   with self.assertRaisesRegex(RuntimeError,'PRIOR_ISSUANCE_PREFIX_CHANGED'):m.main(self.root)
  report=json.loads(next((self.home/'Downloads').glob('PORQUINHO_A24_MODEL_ASSESSMENT_ACTIVATION_*.json')).read_text())
  self.assertFalse(report['prior_issuance_prefix_preserved']);self.assertFalse(report['independent_global_identity_binding_proven'])
class ReaderEvidence(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve();(self.root/'results').mkdir()
  self.when='2026-10-16T10:00:00+00:00';self.now=m.parse_time('2026-10-16T12:00:00+00:00');self.when_after='2026-10-16T11:00:00+00:00'
  self.contract={'schema':'porquinho.global-market-reader-a24/1.0','status':'READ_ONLY_INPUT_INSPECTED_NOT_CERTIFIED','storage_status':'EXACT_CONTENT_MIGRATION_VERIFIED','source_sha256':'a'*64,'source_row_count':1,'unit_evidence_counts':{'UNIT_UNRESOLVED':1},'legacy_values_preserved':True,'historical_row_attestation':False,'training_authorized_by_reader':False,'canonical_publication_authorized':False,'legacy_contract':{'sha256':'codehash','historical_row_attestation':False}}
  self.addCleanup(patch.stopall);patch.object(m,'EXPECTED',{'tools/fetch_history.py':'codehash'}).start()
 def write(self,stamp=None,contract=None):
  (self.root/'results/prediction_lab.json').write_text(json.dumps({'trained_at':stamp or self.when_after,'input_contract':self.contract if contract is None else contract}))
 def evidence(self,confirmed=True):return m.reader_evidence(self.root,self.when,confirmed,now=self.now)
 def test_fresh_contract_and_verified_process_prove_reader(self):
  self.write();self.assertTrue(self.evidence()['loaded_reader_proven'])
 def test_stale_lab_cannot_prove_reader(self):
  self.write(stamp='2026-10-16T09:00:00+00:00');self.assertFalse(self.evidence()['loaded_reader_proven'])
 def test_future_timestamp_cannot_prove_reader(self):
  self.write(stamp='2026-10-17T10:00:00+00:00');self.assertFalse(self.evidence()['loaded_reader_proven'])
 def test_unknown_activation_cannot_prove_reader(self):
  self.write();self.assertFalse(self.evidence(False)['loaded_reader_proven'])
 def test_old_lab_without_contract_cannot_prove_reader(self):
  (self.root/'results/prediction_lab.json').write_text('{}');self.assertEqual(self.evidence()['status'],'INPUT_CONTRACT_NOT_YET_OBSERVED')
 def test_count_or_authority_mismatch_refused(self):
  for key,value in [('source_row_count',2),('canonical_publication_authorized',True),('historical_row_attestation',True)]:
   c=dict(self.contract);c[key]=value;self.write(contract=c);self.assertFalse(self.evidence()['loaded_reader_proven'])
 def test_reader_validation_does_not_write_lab_or_make_requests(self):
  self.write();p=self.root/'results/prediction_lab.json';before=p.read_bytes()
  with patch.object(m,'status',side_effect=AssertionError('network')),patch.object(m.os,'kill',side_effect=AssertionError('signal')):self.evidence()
  self.assertEqual(before,p.read_bytes())
 def test_lock_blocks_duplicate_activator(self):
  import fcntl
  home=self.root/'home';(home/'Downloads').mkdir(parents=True);lock=home/'Downloads/.porquinho_a24_activation.lock'
  with lock.open('w') as stream:
   fcntl.flock(stream,fcntl.LOCK_EX|fcntl.LOCK_NB)
   with patch.object(Path,'home',return_value=home),patch.object(m,'main') as main:
    with self.assertRaisesRegex(RuntimeError,'ALREADY_RUNNING'):m.locked_main(self.root/'separate_project')
    main.assert_not_called()
class ActivationObservation(unittest.TestCase):
 setUp=Activation.setUp
 listeners=Activation.listeners
 kill=Activation.kill
 popen=Activation.popen
 status=Activation.status
 shell=Activation.shell
 monotonic=Activation.monotonic
 mocks=Activation.mocks
 def report(self):return json.loads(next((self.home/'Downloads').glob('PORQUINHO_A24_MODEL_ASSESSMENT_ACTIVATION_*.json')).read_text())
 def test_updated_endpoint_proves_ui_without_new_lab_timestamp(self):
  self.mocks();m.main(self.root);r=self.report();self.assertEqual(r['status'],'GLOBAL_MODEL_ASSESSMENT_ACTIVATED_AND_OBSERVED');self.assertFalse(r['global_reader']['loaded_reader_proven'])
 def test_old_endpoint_revision_does_not_prove_updated_ui(self):
  self.mocks()
  with patch.object(m,'monitor_ui_status',return_value={'endpoint_observed':True}):m.main(self.root)
  self.assertEqual(self.report()['status'],'WAITING_FOR_GLOBAL_MODEL_ASSESSMENT_RESULT')
 def test_partial_diagnostic_not_labelled_full_consolidation(self):
  self.mocks()
  with patch.object(m,'monitor_ui_status',return_value={'endpoint_observed':True,'diagnostic_revision':'GLOBAL_MODEL_ASSESSMENT_1','observed_manual_trade_costs':{'schema':'porquinho.observed-trade-costs-a24/1.0'},'account_cost_evidence':{'schema':'porquinho.account-cost-evidence-a24/1.0'},'research_economic_components':{'schema':'porquinho.research-economic-components-a24/1.0'},'global_model_evaluation':{'schema':'porquinho.global-model-evaluation-a24/1.0'},'global_research_lab':{'schema':'porquinho.global-research-lab-a24/1.0'},'economic_set_producer_diagnostic':{'schema':'porquinho.economic-component-set-producer-a24/1.0'},'scoped_economic_comparison_summary':{'schema':'porquinho.scoped-economic-comparisons-a24/1.0'},'status':'PARTIAL_READ_ONLY_OBSERVATION'}):m.main(self.root)
  self.assertEqual(self.report()['status'],'GLOBAL_MODEL_ASSESSMENT_ACTIVATED_PARTIAL_DIAGNOSTIC')
class StreamingStatus(unittest.TestCase):
 def test_large_ignored_snapshot_payload_keeps_only_status_fields(self):
  obj={'snapshot':{'ignored':'x'*1048576,'timestamp':'2026-10-16T10:00:00Z'},'jobs':[{'status':'done','ignored':'x'*1000}]}
  result=m.StatusReader(io.BytesIO(json.dumps(obj).encode())).read();self.assertEqual(result,{'snapshot':{'timestamp':'2026-10-16T10:00:00Z'},'jobs':[{'status':'done'}]})
 def test_unknown_job_status_refused(self):
  with self.assertRaisesRegex(RuntimeError,'CONTRACT'):m.StatusReader(io.BytesIO(b'{"snapshot":{},"jobs":[{"status":"unknown"}]}')).read()
class MonitorEndpoint(unittest.TestCase):
 def response(self,data,status=200):
  response=Mock();response.status=status;response.read.return_value=json.dumps(data).encode();response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False);return response
 def test_ui_probe_uses_get_and_returns_only_diagnostic_summary(self):
  data={'schema':'porquinho.monitor-consolidation-a24/1.0','status':'READ_ONLY_OBSERVATION','financial_mutation':False,'history_write_performed':False,'execution_authorized':False,'canonical_publication_authorized':False,'positions':[{'account_id':'private'}],'research_capture':{'verified_records_today':12}}
  opener=Mock();opener.open.return_value=self.response(data)
  with patch.object(m,'build_opener',return_value=opener):out=m.monitor_ui_status()
  request=opener.open.call_args.args[0];self.assertEqual(request.get_method(),'GET');self.assertTrue(out['endpoint_observed']);self.assertNotIn('positions',out)
 def test_ui_probe_rejects_authority_or_schema_change(self):
  opener=Mock();opener.open.return_value=self.response({'schema':'wrong'})
  with patch.object(m,'build_opener',return_value=opener):
   with self.assertRaisesRegex(RuntimeError,'CONTRACT'):m.monitor_ui_status()
if __name__=='__main__':unittest.main(verbosity=2)
