"""Local explicit policy review/validation/configuration. No services or trades."""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from universal_portfolio import account_action_policy_store_a24 as store
from universal_portfolio.investment_plan_runtime import _accounts
from universal_portfolio.investment_plan_store import InvestmentPlanStore


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--root', type=Path, default=ROOT)
    sub = cli.add_subparsers(dest='command', required=True)
    sub.add_parser('status')
    for name in ('check', 'apply'):
        cmd = sub.add_parser(name)
        cmd.add_argument('review_file', type=Path)
        if name == 'apply':
            cmd.add_argument('--expected-digest', required=True)
            cmd.add_argument('--confirm', required=True)
    args = cli.parse_args()
    root = args.root.resolve(strict=True)
    now = dt.datetime.now(dt.timezone.utc)
    if args.command == 'status':
        result = store.summary(store.load(root), now=now)
    else:
        p = args.review_file
        if p.is_symlink() or p.stat().st_size > 128 * 1024:
            raise store.StoreError('LOCAL_BOUNDED_REVIEW_FILE_REQUIRED')
        row = json.loads(p.read_bytes())
        if args.command == 'check':
            registry = _accounts(root)
            accounts = registry.get('accounts', []) if isinstance(registry, dict) else registry
            before = store.load(root)
            after = store.append(before, row, accounts=accounts,
                                 plans=InvestmentPlanStore(root / 'data/investment_plans.json').list(), now=now)
            result = {'status': 'REVIEW_CHECKED_NOT_APPLIED', 'expected_digest': store.head(before),
                      'new_version_would_be_created': after != before,
                      'execution_authorized': False, 'model_validation_created': False}
        else:
            result = store.configure(root, row, expected_digest=args.expected_digest,
                                     confirmation=args.confirm, now=now)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('POLICY_CONFIGURATION_REFUSED:' + (str(exc) if isinstance(exc, store.StoreError) else type(exc).__name__))
