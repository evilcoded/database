"""Read-only explicit policy inputs -> existing risk/liquidity/concentration gates.
No default limits, policy certification, order sizing, publication or financial writes.
"""
import datetime as dt,json
from collections import Counter
from pathlib import Path
from . import economic_action_plan_a24 as actions
from . import account_action_policy_store_a24 as registry
from . import universal_adaptive_risk_policy_authority as risk
from . import universal_adaptive_liquidity_policy_authority as liquidity
from . import universal_concentration_policy_authority as concentration
from .universal_risk_evidence_authority import build_risk_evidence
from .universal_liquidity_evidence_authority import build_liquidity_evidence
from .explicit_market_bindings_a24 import local,digest
from .research_quote_acquisition_a24 import utc
SCHEMA='porquinho.economic-action-policy-a24/1.0'
INPUT_SCHEMA='porquinho.action-policy-inputs-a24/1.0'
SOURCE='results/governed_economic_components_a24.json'
INPUT_KEY='action_policy_inputs_a24'
DIMENSIONS=('risk','liquidity','concentration')
SCOPE=('case_id','alternative_id','instrument_id','account_id','currency','horizon_unit','horizon_value')
class PolicyError(ValueError):pass

def instant(value):
 if not isinstance(value,str):raise PolicyError('AWARE_POLICY_TIMESTAMP_REQUIRED')
 return utc(dt.datetime.fromisoformat(value.replace('Z','+00:00')))

def unavailable(reason):return {'status':'POLICY_ASSESSMENT_UNAVAILABLE','acceptable':None,'reasons':[reason]}

def evaluate(dimension,item,scope,*,now):
 try:
  raw=item.get(dimension+'_policy')
  if not isinstance(raw,dict):return unavailable('EXPLICIT_POLICY_REQUIRED')
  if raw.get('account_id')!=scope['account_id'] or raw.get('currency')!=scope['currency']:raise PolicyError('POLICY_ACCOUNT_CURRENCY_MISMATCH')
  if instant(raw.get('effective_from'))>now:raise PolicyError('POLICY_NOT_EFFECTIVE_YET')
  if item.get(dimension+'_effective_until') is None:raise PolicyError('EXPLICIT_POLICY_VALIDITY_END_REQUIRED')
  if instant(item[dimension+'_effective_until'])<=now:raise PolicyError('POLICY_OR_ASSESSMENT_EXPIRED')
  horizon=scope['horizon_unit']+':'+str(scope['horizon_value'])
  if isinstance(raw.get('threshold'),bool):raise PolicyError('NUMERIC_THRESHOLD_NOT_BOOLEAN')
  if dimension in ('risk','liquidity'):
   evidence=item.get(dimension+'_evidence')
   if not isinstance(evidence,dict):return unavailable('EXPLICIT_VALIDATED_EVIDENCE_REQUIRED')
   if isinstance(evidence.get('value'),bool):raise PolicyError('NUMERIC_EVIDENCE_NOT_BOOLEAN')
   if evidence.get('instrument_id')!=scope['instrument_id']:raise PolicyError('EVIDENCE_INSTRUMENT_MISMATCH')
   if instant(evidence.get('observed_at'))>now:raise PolicyError('FUTURE_POLICY_EVIDENCE')
   if dimension=='risk':
    if raw.get('horizon')!=horizon or evidence.get('horizon')!=horizon:raise PolicyError('EXPLICIT_POLICY_HORIZON_MISMATCH')
    p=risk.build_policy(raw);built=build_risk_evidence(evidence)
    result=risk.evaluate_policy(p.get('policy'),built.get('evidence'),account_id=scope['account_id'],currency=scope['currency'])
   else:
    if item.get('liquidity_horizon')!=horizon:raise PolicyError('EXPLICIT_POLICY_HORIZON_MISMATCH')
    p=liquidity.build_policy(raw);built=build_liquidity_evidence(evidence)
    result=liquidity.evaluate_policy(p.get('policy'),built.get('evidence'),account_id=scope['account_id'],currency=scope['currency'],requested_amount=None)
   reasons=list(p.get('reasons',()))+list(built.get('reasons',()))+list(result.get('reasons',()))
  else:
   if item.get('concentration_horizon')!=horizon:raise PolicyError('EXPLICIT_POLICY_HORIZON_MISMATCH')
   current=item.get('current_exposure');after=item.get('counterfactual_exposure')
   if not isinstance(current,dict) or not isinstance(after,dict):return unavailable('EXPLICIT_CURRENT_AND_COUNTERFACTUAL_EXPOSURE_REQUIRED')
   if raw.get('plan_id') and raw['plan_id'] not in scope.get('active_plan_ids',[]):raise PolicyError('POLICY_PLAN_SCOPE_MISMATCH')
   for exposure in (current,after):
    if exposure.get('instrument_id')!=scope['instrument_id'] or exposure.get('account_id')!=scope['account_id'] or exposure.get('currency')!=scope['currency']:raise PolicyError('EXPOSURE_SCOPE_MISMATCH')
    if instant(exposure.get('observed_at'))>now:raise PolicyError('FUTURE_EXPOSURE')
   from .funded_currency_research_a24 import amount
   scenario=amount(item.get('scenario_reference_amount'))
   if scenario<=0 or after.get('scenario_reference_amount') is None or amount(after['scenario_reference_amount'])!=scenario:raise PolicyError('EXPLICIT_MATCHING_COUNTERFACTUAL_AMOUNT_REQUIRED')
   if after.get('counterfactual') is not True:raise PolicyError('COUNTERFACTUAL_NOT_ACTUAL_EXPOSURE_REQUIRED')
   for exposure in (current,after):
    if exposure.get('metric_unit')!='FRACTION':raise PolicyError('EXPLICIT_CONCENTRATION_FRACTION_UNIT_REQUIRED')
    if exposure.get('validation_status')!='VALIDATED_FOR_SHADOW_POLICY_ASSESSMENT' or not all(isinstance(exposure.get(k),str) and exposure[k].strip() for k in ('source_ref','validation_ref')):raise PolicyError('VALIDATED_EXPOSURE_PROVENANCE_REQUIRED')
   p=concentration.build_policy(raw);result=concentration.evaluate_policy(policy_result=p,current_exposure=current,counterfactual_exposure=after)
   reasons=list(p.get('reasons',()))+list(result.get('reasons',()))
  acceptable=result.get('acceptable')
  if acceptable is not None and type(acceptable) is not bool:raise PolicyError('BOOLEAN_POLICY_ASSESSMENT_REQUIRED')
  return {'status':result['status'],'acceptable':acceptable,'reasons':sorted(set(reasons)),
   'policy_id':raw.get('policy_id'),'policy_input_digest':digest(raw),'source':raw.get('source'),
   'validation_ref':raw.get('validation_ref'),'independent_attestation':False}
 except Exception as exc:return unavailable(str(exc) if isinstance(exc,PolicyError) else type(exc).__name__)

def project(action_plan,document=None,*,now,active_plans=(),policy_store=None):
 if action_plan.get('schema')!=actions.SCHEMA or action_plan.get('status')!='ACTION_CONTEXTS_PROJECTED_NOT_COMPARATOR_READY':raise PolicyError('CURRENT_ACTION_CONTEXTS_REQUIRED')
 if any(action_plan.get(k)!=v for k,v in actions.flags().items()):raise PolicyError('NONAUTHORIZING_ACTION_CONTEXTS_REQUIRED')
 policy_store=registry.empty() if policy_store is None else registry.checked(policy_store)
 reusable=registry.current(policy_store,now=now);matches=0
 alternatives=[{**a,'case_id':c['case_id']} for c in action_plan['cases'] for a in c['alternatives']];by_id={a['alternative_id']:a for a in alternatives}
 if len(by_id)!=len(alternatives):raise PolicyError('UNIQUE_ALTERNATIVE_SCOPE_REQUIRED')
 inputs={}
 if document is not None:
  if not isinstance(document,dict) or document.get('schema')!=INPUT_SCHEMA or not isinstance(document.get('assessments'),list) or len(document['assessments'])>2000:raise PolicyError('EXPLICIT_POLICY_INPUT_SCHEMA_REQUIRED')
  if document.get('execution_authorized') is not False or document.get('comparison_authorized') is not False:raise PolicyError('NONAUTHORIZING_POLICY_INPUTS_REQUIRED')
  for item in document['assessments']:
   if not isinstance(item,dict):raise PolicyError('POLICY_ASSESSMENT_MAPPING_REQUIRED')
   aid=item.get('alternative_id');scope=by_id.get(aid)
   if aid in inputs:raise PolicyError('AMBIGUOUS_POLICY_INPUTS_REFUSED')
   if scope is None or any(item.get(k)!=scope.get(k) for k in SCOPE):raise PolicyError('ACTION_POLICY_SCOPE_MISMATCH')
   if type(item.get('horizon_value')) is not int:raise PolicyError('EXPLICIT_HORIZON_REQUIRED')
   if instant(item.get('as_of'))>now:raise PolicyError('FUTURE_POLICY_INPUT')
   if instant(item.get('effective_until'))<=now:raise PolicyError('POLICY_INPUT_EXPIRED')
   if item.get('action_context_digest')!=digest(scope):raise PolicyError('POLICY_INPUT_BOUND_TO_DIFFERENT_ACTION_CONTEXT')
   inputs[aid]=item
 cash_limits={(c['account_id'],c['currency']):c.get('capital_ceiling') for c in action_plan['cases'] if c['resource_kind']=='CASH'}
 quantity_limits={c['case_id']:c.get('quantity_upper_bound') for c in action_plan['cases']}
 rows=[]
 for a in alternatives:
  item=inputs.get(a['alternative_id']);scope={**a,'active_plan_ids':[p['plan_id'] for p in active_plans if p.get('status')=='ACTIVE' and p.get('authority')=='NONE' and p.get('execution_mode')=='MANUAL' and p.get('automatic_execution_authorized') is False and p.get('source_account_id')==a['account_id'] and p.get('currency')==a['currency']]}
  dimensions={}
  for d in DIMENSIONS:
   try:
    reusable_policy=registry.select(reusable,scope,d,plans=active_plans)
    selected=dict(item or {})
    if reusable_policy:
     matches+=1
     if selected.get(d+'_policy') is not None and digest(selected[d+'_policy'])!=digest(reusable_policy['definition']):raise registry.StoreError('DIRECT_AND_REUSABLE_POLICY_CONFLICT')
     if selected.get(d+'_policy') is None:
      selected[d+'_policy']=reusable_policy['definition']
      selected[d+'_effective_until']=reusable_policy['effective_until']
      selected[d+'_horizon']=scope['horizon_unit']+':'+str(scope['horizon_value'])
    dimensions[d]=evaluate(d,selected,scope,now=now) if selected else unavailable('EXPLICIT_POLICY_INPUT_NOT_SUPPLIED')
   except registry.StoreError as exc:dimensions[d]=unavailable(str(exc))
  values=[x['acceptable'] for x in dimensions.values()]
  combined=False if False in values else None if None in values else True
  rows.append({**{k:a.get(k) for k in SCOPE},'kind':a['kind'],'dimensions':dimensions,
    'scenario_guardrails_acceptable':combined,
    'action_context_digest':digest(a),'scenario_reference_amount':item.get('scenario_reference_amount') if item else None,
    'requested_amount':None,'suggested_amount':None,'sizing_created':False,'sizing_authorized_by_guardrails':False,
    'sizing_guardrail_context':{**{k:a.get(k) for k in ('instrument_id','account_id','currency','horizon_unit','horizon_value')},
      'risk_policy_acceptable':dimensions['risk']['acceptable'],'liquidity_policy_acceptable':dimensions['liquidity']['acceptable'],'concentration_policy_acceptable':dimensions['concentration']['acceptable'],
      'financial_capacity':cash_limits.get((a['account_id'],a['currency'])) if a['kind'] in ('DEPLOY_CASH','INCREASE') else None,
      'available_quantity_upper_bound':quantity_limits.get(a['case_id']) if a['kind'] in ('SELL','REDUCE','REALLOCATE') else None,
      'liquidity_capacity':None,'suggested_amount':None,'risk_and_policy_models_still_required':True,'resources_reserved':False},
    'remaining_economic_blockers':list(a['blocking_reasons']),**actions.flags()})
 return {'schema':SCHEMA,'status':'ACTION_POLICY_GATES_ASSESSED_SHADOW_ONLY','input_count':len(inputs),'assessments':rows,'reusable_policy_registry':registry.summary(policy_store,now=now),'reusable_policy_match_count':matches,
  'policy_input_validation_is_independent_attestation':False,'plan_strategy_converted_to_threshold':False,**actions.flags()}

def summarize(value):
 if value.get('schema')!=SCHEMA:raise PolicyError('ACTION_POLICY_SCHEMA_REQUIRED')
 if value.get('status')!='ACTION_POLICY_GATES_ASSESSED_SHADOW_ONLY':return {k:v for k,v in value.items() if k!='assessments'}
 rows=value['assessments'];dimensions={}
 for d in DIMENSIONS:
  values=[r['dimensions'][d] for r in rows]
  dimensions[d]={'acceptable_count':sum(v['acceptable'] is True for v in values),'blocked_count':sum(v['acceptable'] is False for v in values),
   'unavailable_count':sum(v['acceptable'] is None for v in values),'reason_counts':dict(Counter(reason for v in values for reason in v.get('reasons',[])))}
 return {'schema':SCHEMA,'status':value['status'],'input_count':value['input_count'],'alternative_count':len(rows),'dimensions':dimensions,
  'input_source_contract':SOURCE+'#'+INPUT_KEY,'reusable_policy_registry':value.get('reusable_policy_registry'),'reusable_policy_match_count':value.get('reusable_policy_match_count',0),'all_guardrails_acceptable_count':sum(r['scenario_guardrails_acceptable'] is True for r in rows),'suggested_amounts_created':0,
  'policy_input_validation_is_independent_attestation':False,'plan_strategy_converted_to_threshold':False,**actions.flags()}

def build(root,action_plan,*,now=None):
 now=utc(now or dt.datetime.now(dt.timezone.utc))
 try:
  root=Path(root).resolve(strict=True)
  if action_plan.get('source_version_digest')!=digest(actions.source_versions(root)):raise PolicyError('ACTION_SOURCES_CHANGED_BEFORE_POLICY_CHECK')
  p=local(root,SOURCE);before=None;document=None
  if p.exists():
   s=p.stat();before=(s.st_size,s.st_mtime_ns,s.st_ino)
   if s.st_size>16*1024*1024:raise PolicyError('POLICY_INPUT_SIZE_LIMIT')
   body=json.loads(p.read_bytes());digest(body)
   if not isinstance(body,dict):raise PolicyError('GOVERNED_SOURCE_MAPPING_REQUIRED')
   document=body.get(INPUT_KEY)
  from .investment_plan_store import InvestmentPlanStore
  stored=registry.load(root)
  result=project(action_plan,document,now=now,active_plans=InvestmentPlanStore(root/'data/investment_plans.json').list(),policy_store=stored)
  if registry.head(stored)!=registry.head(registry.load(root)):raise PolicyError('POLICY_REGISTRY_CHANGED_DURING_READ')
  after=(p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ino) if p.exists() else None
  if before!=after or action_plan['source_version_digest']!=digest(actions.source_versions(root)):raise PolicyError('POLICY_OR_ACTION_SOURCES_CHANGED_DURING_READ')
  result['source_ref']=SOURCE if document is not None else None
  return result
 except Exception as exc:return {'schema':SCHEMA,'status':'ACTION_POLICY_INPUT_UNAVAILABLE','reason':str(exc) if isinstance(exc,PolicyError) else type(exc).__name__,'assessments':[],**actions.flags()}
