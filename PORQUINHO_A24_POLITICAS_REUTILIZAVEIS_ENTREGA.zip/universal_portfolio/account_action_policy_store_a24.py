"""Explicit user policies, versioned independently of learning and transactions."""
import datetime as dt
import fcntl
import json
import math
import os
import tempfile
from pathlib import Path
from .explicit_market_bindings_a24 import local, digest
from .research_quote_acquisition_a24 import utc

SCHEMA = 'porquinho.account-action-policy-store-a24/1.0'
SOURCE = 'data/account_action_policies_a24.json'
CONFIRM = 'CONFIRM_USER_POLICIES_RESEARCH_ONLY'
SCOPE = ('dimension', 'account_id', 'currency', 'plan_id', 'horizon_unit', 'horizon_value')


class StoreError(ValueError):
    pass


def instant(value):
    if not isinstance(value, str):
        raise StoreError('AWARE_TIMESTAMP_REQUIRED')
    return utc(dt.datetime.fromisoformat(value.replace('Z', '+00:00')))


def empty():
    return {'schema': SCHEMA, 'versions': []}


def head(store):
    return digest(store)


def checked(store):
    if not isinstance(store, dict) or set(store) != {'schema', 'versions'} or store['schema'] != SCHEMA or not isinstance(store['versions'], list) or len(store['versions']) > 2000:
        raise StoreError('POLICY_STORE_SCHEMA_INVALID')
    previous = None
    latest = {}
    for row in store['versions']:
        body = {k: v for k, v in row.items() if k != 'record_digest'}
        if row.get('previous_record_digest') != previous or row.get('record_digest') != digest(body):
            raise StoreError('POLICY_VERSION_CHAIN_INVALID')
        pid = row.get('policy_id')
        old = latest.get(pid)
        if not isinstance(pid, str) or not pid.strip() or type(row.get('revision')) is not int or row['revision'] != (old['revision'] + 1 if old else 1):
            raise StoreError('POLICY_REVISION_INVALID')
        if old and any(row.get(k) != old.get(k) for k in SCOPE):
            raise StoreError('VERSION_SCOPE_CHANGE_REFUSED')
        if row.get('status') not in ('ACTIVE', 'REVOKED') or row.get('execution_authorized') is not False or row.get('comparison_authorized') is not False:
            raise StoreError('NONAUTHORIZING_POLICY_VERSION_REQUIRED')
        instant(row.get('recorded_at'))
        previous = row['record_digest']
        latest[pid] = row
    return store


def load(root):
    p = local(Path(root).resolve(strict=True), SOURCE)
    if not p.exists():
        return empty()
    before = p.stat()
    if before.st_size > 8 * 1024 * 1024:
        raise StoreError('POLICY_STORE_SIZE_LIMIT')
    value = json.loads(p.read_bytes())
    after = p.stat()
    if (before.st_size, before.st_mtime_ns, before.st_ino) != (after.st_size, after.st_mtime_ns, after.st_ino):
        raise StoreError('POLICY_STORE_CHANGED_DURING_READ')
    return checked(value)


def latest(store):
    return {r['policy_id']: r for r in checked(store)['versions']}


def validate(row, *, accounts, plans):
    from . import universal_adaptive_risk_policy_authority as risk
    from . import universal_adaptive_liquidity_policy_authority as liquidity
    from . import universal_concentration_policy_authority as concentration
    allowed = {'policy_id', 'revision', 'status', 'effective_from', 'effective_until', 'definition', *SCOPE}
    if not isinstance(row, dict) or set(row) != allowed:
        raise StoreError('EXACT_USER_POLICY_FIELDS_REQUIRED')
    if not isinstance(row['policy_id'], str) or not row['policy_id'].strip() or type(row['revision']) is not int or row['revision'] < 1:
        raise StoreError('EXPLICIT_POLICY_ID_AND_REVISION_REQUIRED')
    dimension = row['dimension']
    if dimension not in ('risk', 'liquidity', 'concentration'):
        raise StoreError('POLICY_DIMENSION_INVALID')
    if row['status'] not in ('ACTIVE', 'REVOKED'):
        raise StoreError('POLICY_STATUS_INVALID')
    if row['horizon_unit'] not in ('OBSERVATIONS', 'DAYS') or type(row['horizon_value']) is not int or row['horizon_value'] <= 0:
        raise StoreError('EXPLICIT_HORIZON_REQUIRED')
    if instant(row['effective_until']) <= instant(row['effective_from']):
        raise StoreError('POLICY_VALIDITY_INTERVAL_INVALID')
    matches = [a for a in accounts if a.get('account_id') == row['account_id'] and a.get('currency') == row['currency']]
    if len(matches) != 1:
        raise StoreError('EXACT_ACCOUNT_CURRENCY_REQUIRED')
    if row['plan_id'] is not None:
        matches = [p for p in plans if p.get('plan_id') == row['plan_id'] and p.get('source_account_id') == row['account_id'] and p.get('currency') == row['currency'] and p.get('status') == 'ACTIVE' and p.get('execution_mode') == 'MANUAL' and p.get('authority') == 'NONE' and p.get('automatic_execution_authorized') is False]
        if len(matches) != 1:
            raise StoreError('EXACT_ACTIVE_MANUAL_PLAN_REQUIRED')
    raw = row['definition']
    if not isinstance(raw, dict) or raw.get('source') != 'USER_DEFINED' or raw.get('validated') is not True:
        raise StoreError('EXPLICIT_REVIEWED_USER_POLICY_REQUIRED')
    for key in ('policy_id', 'account_id', 'currency', 'effective_from'):
        if raw.get(key) != row[key]:
            raise StoreError('POLICY_DEFINITION_SCOPE_MISMATCH')
    if raw.get('plan_id') is not None and raw['plan_id'] != row['plan_id']:
        raise StoreError('POLICY_DEFINITION_PLAN_MISMATCH')
    if dimension == 'risk' and raw.get('horizon') != row['horizon_unit'] + ':' + str(row['horizon_value']):
        raise StoreError('POLICY_DEFINITION_HORIZON_MISMATCH')
    numeric = [c.get('threshold') for c in raw.get('constraints', [])] if dimension == 'concentration' else [raw.get('threshold')]
    for value in numeric:
        if isinstance(value, bool) or value is None:
            raise StoreError('EXPLICIT_NUMERIC_THRESHOLD_REQUIRED')
        try:
            if not math.isfinite(float(value)):
                raise ValueError()
        except (TypeError, ValueError, OverflowError):
            raise StoreError('FINITE_THRESHOLD_REQUIRED')
    builder = {'risk': risk, 'liquidity': liquidity, 'concentration': concentration}[dimension]
    result = builder.build_policy(raw)
    if result.get('policy') is None:
        raise StoreError('POLICY_DEFINITION_REJECTED:' + ','.join(result.get('reasons', ())))
    version = raw.get('version') if dimension == 'concentration' else raw.get('policy_version')
    if version != str(row['revision']):
        raise StoreError('POLICY_DEFINITION_REVISION_MISMATCH')
    return json.loads(json.dumps(row, allow_nan=False))


def append(store, row, *, accounts, plans, now):
    row = validate(row, accounts=accounts, plans=plans)
    previous = latest(store).get(row['policy_id'])
    if previous and any(row[k] != previous[k] for k in SCOPE):
        raise StoreError('VERSION_SCOPE_CHANGE_REFUSED')
    if previous and row['revision'] == previous['revision'] and all(row[k] == previous[k] for k in row):
        return store
    if row['revision'] != (previous['revision'] + 1 if previous else 1):
        raise StoreError('NEXT_POLICY_REVISION_REQUIRED')
    if row['status'] == 'REVOKED' and previous is None:
        raise StoreError('CANNOT_REVOKE_UNKNOWN_POLICY')
    row.update(recorded_at=utc(now).isoformat(), reviewed_by='USER',
               execution_authorized=False, comparison_authorized=False,
               previous_record_digest=store['versions'][-1]['record_digest'] if store['versions'] else None)
    row['record_digest'] = digest(row)
    result = {**store, 'versions': [*store['versions'], row]}
    return checked(result)


def current(store, *, now):
    now = utc(now)
    return [r for r in latest(store).values() if r['status'] == 'ACTIVE' and instant(r['recorded_at']) <= now and instant(r['effective_from']) <= now < instant(r['effective_until'])]


def select(rows, scope, dimension, *, plans):
    candidates = [r for r in rows if r['dimension'] == dimension and all(r[k] == scope.get(k) for k in ('account_id', 'currency', 'horizon_unit', 'horizon_value'))]
    plan_ids = [p['plan_id'] for p in plans if p.get('status') == 'ACTIVE' and p.get('authority') == 'NONE' and p.get('execution_mode') == 'MANUAL' and p.get('automatic_execution_authorized') is False and p.get('source_account_id') == scope['account_id'] and p.get('currency') == scope['currency']]
    candidates = [r for r in candidates if r['plan_id'] is None or r['plan_id'] in plan_ids]
    if len(candidates) > 1:
        raise StoreError('AMBIGUOUS_REUSABLE_POLICY')
    return candidates[0] if candidates else None


def resolve(store, scope, dimension, *, now, plans):
    return select(current(store, now=now), scope, dimension, plans=plans)


def summary(store, *, now):
    rows = current(store, now=now)
    return {'version_count': len(store['versions']), 'current_policy_count': len(rows),
            'current_dimension_counts': {d: sum(r['dimension'] == d for r in rows) for d in ('risk', 'liquidity', 'concentration')},
            'registry_digest': head(store), 'source': SOURCE,
            'user_policy_is_model_validation': False, 'execution_authorized': False}


def configure(root, row, *, expected_digest, confirmation, now=None):
    if confirmation != CONFIRM:
        raise StoreError('EXPLICIT_USER_POLICY_CONFIRMATION_REQUIRED')
    from .investment_plan_runtime import _accounts
    from .investment_plan_store import InvestmentPlanStore
    root = Path(root).resolve(strict=True)
    now = utc(now or dt.datetime.now(dt.timezone.utc))
    p = local(root, SOURCE)
    lock = local(root, SOURCE + '.lock')
    fd = os.open(lock, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'a+') as stream:
        fcntl.flock(stream, fcntl.LOCK_EX)
        store = load(root)
        if head(store) != expected_digest:
            raise StoreError('POLICY_STORE_CHANGED_REVIEW_AGAIN')
        from .economic_action_plan_a24 import source_versions
        sources = source_versions(root)
        registry = _accounts(root)
        accounts = registry.get('accounts', []) if isinstance(registry, dict) else registry
        plans = InvestmentPlanStore(root / 'data/investment_plans.json').list()
        result = append(store, row, accounts=accounts, plans=plans, now=now)
        if sources != source_versions(root):
            raise StoreError('FINANCIAL_CONTEXT_CHANGED_REVIEW_AGAIN')
        if head(load(root)) != head(store):
            raise StoreError('POLICY_STORE_CHANGED_BEFORE_WRITE')
        if result != store:
            fd, tmp = tempfile.mkstemp(prefix='.action-policy-', dir=p.parent)
            try:
                with os.fdopen(fd, 'w') as output:
                    json.dump(result, output, ensure_ascii=False, indent=2)
                    output.write('\n'); output.flush(); os.fsync(output.fileno())
                local(root, SOURCE)
                os.replace(tmp, p)
                directory_fd = os.open(p.parent, os.O_RDONLY)
                try: os.fsync(directory_fd)
                finally: os.close(directory_fd)
            finally:
                if os.path.exists(tmp):
                    os.unlink(tmp)
        return {'status': 'USER_POLICY_VERSION_RECORDED' if result != store else 'ALREADY_RECORDED',
                **summary(result, now=now), 'historical_versions_preserved': True,
                'financial_mutation': False, 'canonical_publication_authorized': False}
