import copy
import datetime as dt
import json
import tempfile
import unittest
from pathlib import Path
import test_a24_economic_action_policy as fixtures
from universal_portfolio import account_action_policy_store_a24 as s
from universal_portfolio import economic_action_policy_a24 as p

NOW = fixtures.NOW


class ReusablePolicies(unittest.TestCase):
    def setUp(self):
        f = fixtures.Policies()
        f.setUp()
        self.item = f.item()
        self.action = f.action
        self.plans = f.kw['plans']
        self.accounts = [{'account_id': 'account', 'currency': 'BRL'}]
        self.scope = f.a

    def row(self, dimension='risk'):
        definition = copy.deepcopy(self.item[dimension + '_policy'])
        definition.update(source='USER_DEFINED', policy_id='user-' + dimension)
        definition['version' if dimension == 'concentration' else 'policy_version'] = '1'
        return {'policy_id': definition['policy_id'], 'revision': 1, 'status': 'ACTIVE',
                'dimension': dimension, 'account_id': 'account', 'currency': 'BRL',
                'plan_id': None, 'horizon_unit': 'OBSERVATIONS', 'horizon_value': 30,
                'effective_from': definition['effective_from'],
                'effective_until': self.item['effective_until'], 'definition': definition}

    def add(self, store=None, row=None):
        return s.append(store if store is not None else s.empty(), row or self.row(),
                        accounts=self.accounts, plans=self.plans, now=NOW)

    def project(self, store, item=None):
        document = None if item is None else {'schema': p.INPUT_SCHEMA,
            'execution_authorized': False, 'comparison_authorized': False, 'assessments': [item]}
        return p.project(self.action, document, now=NOW, active_plans=self.plans, policy_store=store)

    def next_revision(self, row):
        row = copy.deepcopy(row)
        row['revision'] += 1
        row['definition']['version' if row['dimension'] == 'concentration' else 'policy_version'] = str(row['revision'])
        return row

    def test_missing_store_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(s.load(tmp), s.empty())
            self.assertEqual(list(Path(tmp).iterdir()), [])

    def test_all_three_original_builders_accept_user_definitions(self):
        for dimension in p.DIMENSIONS:
            self.assertEqual(s.validate(self.row(dimension), accounts=self.accounts, plans=self.plans)['dimension'], dimension)

    def test_no_default_threshold(self):
        row = self.row(); row['definition'].pop('threshold')
        with self.assertRaises(s.StoreError): self.add(row=row)

    def test_boolean_not_number(self):
        row = self.row('concentration'); row['definition']['constraints'][0]['threshold'] = True
        with self.assertRaises(s.StoreError): self.add(row=row)

    def test_nonfinite_threshold_refused(self):
        row = self.row(); row['definition']['threshold'] = float('inf')
        with self.assertRaises(s.StoreError): self.add(row=row)

    def test_currency_not_inferred_or_converted(self):
        row = self.row(); row['currency'] = 'USD'
        with self.assertRaises(s.StoreError): self.add(row=row)

    def test_optional_plan_must_be_real_active_same_account_currency(self):
        row = self.row(); row['plan_id'] = 'unknown'
        with self.assertRaises(s.StoreError): self.add(row=row)

    def test_matching_plan_policy_resolves(self):
        row = self.row(); row['plan_id'] = self.plans[0]['plan_id']
        store = self.add(row=row)
        self.assertIsNotNone(s.resolve(store, self.scope, 'risk', now=NOW, plans=self.plans))
        self.assertIsNone(s.resolve(store, self.scope, 'risk', now=NOW, plans=[]))

    def test_days_and_observations_not_interchanged(self):
        store = self.add()
        self.assertIsNone(s.resolve(store, {**self.scope, 'horizon_unit': 'DAYS'}, 'risk', now=NOW, plans=self.plans))

    def test_expiry_and_no_retroactive_use(self):
        store = self.add()
        self.assertEqual(s.current(store, now=NOW - dt.timedelta(seconds=1)), [])
        self.assertEqual(s.current(store, now=NOW + dt.timedelta(hours=1)), [])

    def test_naive_time_refused(self):
        row = self.row(); row['effective_until'] = '2026-10-18T00:00:00'
        with self.assertRaises(ValueError): self.add(row=row)

    def test_version_preserves_prior_definition(self):
        row = self.row(); first = self.add(row=row); old = copy.deepcopy(first)
        second = self.next_revision(row); second['definition']['threshold'] = .1
        result = self.add(first, second)
        self.assertEqual(first, old)
        self.assertEqual(result['versions'][0], old['versions'][0])
        self.assertEqual(len(result['versions']), 2)
        self.assertEqual(s.current(result, now=NOW)[0]['definition']['threshold'], .1)

    def test_exact_replay_idempotent(self):
        row = self.row(); first = self.add(row=row)
        self.assertEqual(self.add(first, row), first)

    def test_same_revision_changed_refused(self):
        row = self.row(); first = self.add(row=row); row['definition']['threshold'] = .1
        with self.assertRaises(s.StoreError): self.add(first, row)

    def test_scope_cannot_move_between_versions(self):
        row = self.row(); first = self.add(row=row); row = self.next_revision(row); row['horizon_value'] = 60; row['definition']['horizon'] = 'OBSERVATIONS:60'
        with self.assertRaises(s.StoreError): self.add(first, row)

    def test_revoke_preserves_versions_and_disables_use(self):
        row = self.row(); first = self.add(row=row); row = self.next_revision(row); row['status'] = 'REVOKED'
        result = self.add(first, row)
        self.assertEqual(len(result['versions']), 2)
        self.assertEqual(s.current(result, now=NOW), [])

    def test_chain_tamper_refused(self):
        store = self.add(); store['versions'][0]['definition']['threshold'] = .1
        with self.assertRaises(s.StoreError): s.checked(store)

    def test_multiple_matching_policies_are_not_chosen(self):
        store = self.add(); row = self.row(); row['policy_id'] = row['definition']['policy_id'] = 'second'
        store = self.add(store, row)
        r = self.project(store)
        self.assertEqual(r['assessments'][0]['dimensions']['risk']['reasons'], ['AMBIGUOUS_REUSABLE_POLICY'])

    def test_reuse_for_multiple_alternatives_without_duplicate_inputs(self):
        result = self.project(self.add())
        self.assertEqual(result['input_count'], 0)
        self.assertGreater(result['reusable_policy_match_count'], 1)
        self.assertEqual(result['reusable_policy_registry']['current_policy_count'], 1)
        self.assertTrue(all(r['dimensions']['risk']['acceptable'] is None for r in result['assessments']))

    def test_explicit_validated_evidence_still_required(self):
        store = self.add(); item = copy.deepcopy(self.item); item.pop('risk_policy'); item.pop('risk_effective_until')
        result = self.project(store, item)
        self.assertIs(result['assessments'][0]['dimensions']['risk']['acceptable'], True)
        item['risk_evidence']['maturity'] = 'OBSERVED'
        self.assertIsNone(self.project(store, item)['assessments'][0]['dimensions']['risk']['acceptable'])

    def test_conflicting_direct_definition_refused(self):
        result = self.project(self.add(), self.item)
        self.assertEqual(result['assessments'][0]['dimensions']['risk']['reasons'], ['DIRECT_AND_REUSABLE_POLICY_CONFLICT'])

    def test_summary_omits_private_definition_and_keeps_authority_false(self):
        result = self.project(self.add())
        summary = json.dumps(p.summarize(result))
        self.assertNotIn('"threshold"', summary)
        self.assertNotIn('"account_id"', summary)
        self.assertFalse(result['execution_authorized'])
        self.assertTrue(all(r['suggested_amount'] is None for r in result['assessments']))

    def test_wrong_confirmation_no_files_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(s.StoreError): s.configure(tmp, self.row(), expected_digest='', confirmation='yes')
            self.assertEqual(list(Path(tmp).iterdir()), [])

    def test_configure_store_only_with_concurrency_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); (root / 'data').mkdir()
            (root / 'data/institution_accounts.json').write_text(json.dumps({'accounts': self.accounts}))
            sentinel = root / 'data/transaction_ledger.jsonl'; sentinel.write_text('preserved history\n')
            before = sentinel.read_bytes()
            row = self.row()
            result = s.configure(root, row, expected_digest=s.head(s.empty()), confirmation=s.CONFIRM, now=NOW)
            self.assertEqual(result['status'], 'USER_POLICY_VERSION_RECORDED')
            self.assertEqual(sentinel.read_bytes(), before)
            saved = (root / s.SOURCE).read_bytes()
            with self.assertRaises(s.StoreError): s.configure(root, self.next_revision(row), expected_digest='old', confirmation=s.CONFIRM, now=NOW)
            self.assertEqual((root / s.SOURCE).read_bytes(), saved)
            again = s.configure(root, row, expected_digest=result['registry_digest'], confirmation=s.CONFIRM, now=NOW)
            self.assertEqual(again['status'], 'ALREADY_RECORDED')
