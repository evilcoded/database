import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from decimal import Decimal
from universal_portfolio import research_economic_series_a24 as s,research_quote_acquisition_a24 as q
NOW=dt.datetime(2026,10,16,12,tzinfo=dt.timezone.utc)
class Series(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name).resolve()
 def row(self,offset=0,**kw):
  day=NOW-dt.timedelta(days=60-offset)
  r={'schema':q.SCHEMA,'instrument_id':'GLOBAL:EXACT:IDENTITY','provider':'Provider','provider_id':'explicit-id','quote_currency':'JPY',
  'observation_date':day.date().isoformat(),'identity_source_ref':'reviewed-source','fetched_at':day.isoformat(),'provider_observed_at':day.isoformat(),
  'binding_digest':'a'*64,'response_sha256':'b'*64,'price':str(100+offset),'authority':'RESEARCH_ONLY','economic_comparison_status':'NOT_VALIDATED',
  'pricing_method':'PROVIDER_REPORTED_REQUESTED_CURRENCY','sampling':s.SAMPLING,
  'execution_authorized':False,'automatic_execution_authorized':False,'independent_archive_verified':False,'fx_performed':False,'provider_internal_fx_verified':False,'source_availability_attested':False}
  r.update(kw);r['record_id']=q.record_id(r);return r
 def project(self,rows,**kw):return s.project(rows,now=NOW,**kw)
 def test_one_observation_has_no_return_or_forecast(self):
  out=self.project([self.row()]);self.assertEqual(out['realized_label_count'],0);self.assertFalse(out['comparison_authorized']);self.assertFalse(out['training_authorized']);self.assertNotIn('expected_return',out['series'][0])
 def test_thirty_points_not_thirty_forward_intervals(self):self.assertEqual(self.project([self.row(i) for i in range(30)])['realized_label_count'],0)
 def test_thirty_one_points_exact_realized_return(self):
  out=self.project([self.row(i) for i in range(31)]);r=out['series'][0]['realized_outcomes'][0];self.assertEqual(Decimal(r['realized_price_return_pct']),Decimal('30'));self.assertEqual(r['elapsed_calendar_days'],30);self.assertFalse(out['model_validation_proven'])
 def test_irregular_calendar_gap_not_days_horizon(self):
  out=self.project([self.row(i*2) for i in range(31)]);self.assertEqual(out['series'][0]['realized_outcomes'][0]['elapsed_calendar_days'],60);self.assertEqual(out['horizon_unit'],'OBSERVATIONS')
 def test_negative_realized_return_preserved(self):
  out=self.project([self.row(i,price=str(100-i)) for i in range(31)]);self.assertEqual(Decimal(out['series'][0]['realized_outcomes'][0]['realized_price_return_pct']),Decimal('-30'))
 def test_prices_remain_exact_strings(self):self.assertEqual(self.project([self.row(price='0.000000000000123456789')])['series'][0]['observations'][0]['price'],'0.000000000000123456789')
 def test_currency_partition_no_fx(self):self.assertEqual(self.project([self.row(),self.row(quote_currency='CHF')])['series_count'],2)
 def test_instrument_partition_no_suffix_join(self):self.assertEqual(self.project([self.row(),self.row(instrument_id='OTHER:EXACT:IDENTITY')])['series_count'],2)
 def test_provider_partition(self):self.assertEqual(self.project([self.row(),self.row(provider='Other')])['series_count'],2)
 def test_provider_id_partition(self):self.assertEqual(self.project([self.row(),self.row(provider_id='Other')])['series_count'],2)
 def test_identity_evidence_change_never_pooled(self):
  rows=[self.row(i,identity_source_ref='one' if i<15 else 'two') for i in range(31)];out=self.project(rows);self.assertEqual(out['series_count'],2);self.assertEqual(out['realized_label_count'],0)
 def test_registry_digest_changes_retain_per_row_provenance(self):
  rows=[self.row(i,binding_digest=str(i)*64) for i in range(2)];out=self.project(rows);self.assertEqual(out['series_count'],1);self.assertNotEqual(*[p['binding_digest'] for p in out['series'][0]['observations']])
 def test_future_record_refused(self):
  with self.assertRaisesRegex(ValueError,'FUTURE'):self.project([self.row(61)])
 def test_duplicate_record_refused(self):
  with self.assertRaises(ValueError):self.project([self.row(),self.row()])
 def test_wrong_sampling_refused(self):
  with self.assertRaises(ValueError):self.project([self.row(sampling='DAILY_CLOSE')])
 def test_bad_price_refused(self):
  for price in ('0','-1','NaN','Infinity'):
   with self.assertRaises(ValueError):self.project([self.row(price=price)])
 def test_invalid_horizon_refused(self):
  for value in (True,0,-1,1.5,10001):
   with self.assertRaises(ValueError):self.project([],horizon_observations=value)
 def test_unordered_records_sorted_and_source_unchanged(self):
  rows=[self.row(2),self.row(0),self.row(1)];before=copy.deepcopy(rows);self.assertEqual(self.project(rows)['series'][0]['observations'][0]['record_id'],rows[1]['record_id']);self.assertEqual(rows,before)
 def test_empty_build_is_read_only(self):self.assertEqual(s.build(self.root,now=NOW)['observation_count'],0);self.assertEqual(list(self.root.iterdir()),[])
 def test_real_journal_read_and_summary_redaction(self):
  for i in range(31):q.append_records(self.root,[self.row(i)])
  before={p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
  with patch('socket.socket.connect',side_effect=AssertionError('network')),patch('subprocess.Popen',side_effect=AssertionError('process')):out=s.summary(self.root,now=NOW)
  self.assertEqual(out['realized_label_count'],1);self.assertNotIn('series',out);self.assertEqual(before,{p:p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
 def test_corrupt_chain_unavailable_not_zero(self):
  q.append_records(self.root,[self.row()]);p=q.storage_path(self.root,self.row()['observation_date']);p.write_text(p.read_text().replace('GENESIS','wrong'))
  out=s.summary(self.root,now=NOW);self.assertEqual(out['status'],'RESEARCH_SERIES_INSPECTION_UNAVAILABLE');self.assertIsNone(out['observation_count'])
 def test_changes_during_read_refused(self):
  def changing(root):q.append_records(root,[self.row()]);return [self.row()]
  with patch.object(s,'read_records',side_effect=changing):
   with self.assertRaisesRegex(ValueError,'CHANGED_DURING_READ'):s.build(self.root,now=NOW)
 def test_symlink_store_refused(self):
  p=self.root/q.STORE;p.parent.mkdir(parents=True);target=self.root/'elsewhere';target.mkdir();p.symlink_to(target,target_is_directory=True);self.assertEqual(s.summary(self.root,now=NOW)['status'],'RESEARCH_SERIES_INSPECTION_UNAVAILABLE')
 def test_existing_economic_source_consumes_journal_without_lab(self):
  from universal_portfolio.economic_evidence_source_status_a2 import evidence_source_status
  q.append_records(self.root,[self.row()]);out=evidence_source_status(self.root);self.assertEqual(out['research_market_series']['series_count'],1);self.assertFalse(out['comparison_authorized']);self.assertEqual(out['reason'],'LAB_RESULT_MISSING')
 def test_existing_monitor_consumes_series_without_authority(self):
  from universal_portfolio.monitor_consolidation_a24 import inspect
  q.append_records(self.root,[self.row()]);out=inspect(self.root,now=NOW,runtime_reader=lambda root:{'authority':'NONE','ledger_write':False,'positions':[]});self.assertEqual(out['research_economic_series']['series_count'],1);self.assertFalse(out['canonical_publication_authorized'])

 def test_monitor_reports_series_failure_as_partial(self):
  from universal_portfolio.monitor_consolidation_a24 import inspect
  with patch.object(s,'read_records',side_effect=ValueError('corrupt')):out=inspect(self.root,now=NOW,runtime_reader=lambda root:{'authority':'NONE','ledger_write':False,'positions':[]})
  self.assertEqual(out['status'],'PARTIAL_READ_ONLY_OBSERVATION');self.assertTrue(any(i['source']=='research_economic_series' for i in out['issues']));self.assertIsNone(out['research_economic_series']['series_count'])
