"""Read-only source frames for economic research. Never forecasts or validates models."""
import datetime as dt
from decimal import Decimal,localcontext
from .explicit_market_bindings_a24 import local,digest
from .research_quote_acquisition_a24 import STORE,read_records,validate_observation,utc
SCHEMA='porquinho.research-economic-series-a24/1.0'
SAMPLING='FIRST_VALID_CAPTURE_PER_UTC_DAY_NOT_CLOSE'

def project(records,*,now,horizon_observations=30):
 now=utc(now)
 if type(horizon_observations) is not int or not 1<=horizon_observations<=10000:raise ValueError('OBSERVATION_HORIZON_REQUIRED')
 groups={};seen=set()
 for r in records:
  validate_observation(r)
  if r['record_id'] in seen:raise ValueError('DUPLICATE_RESEARCH_OBSERVATION')
  seen.add(r['record_id'])
  if dt.datetime.fromisoformat(r['fetched_at']).astimezone(dt.timezone.utc)>now:raise ValueError('FUTURE_RESEARCH_OBSERVATION')
  key=(r['instrument_id'],r['provider'].lower(),r['provider_id'],r['quote_currency'],r['identity_source_ref'],r['sampling'],r['pricing_method'])
  groups.setdefault(key,[]).append(r)
 series=[]
 for key,rows in sorted(groups.items()):
  rows=sorted(rows,key=lambda r:r['observation_date']);days=[r['observation_date'] for r in rows]
  if len(days)!=len(set(days)):raise ValueError('DUPLICATE_SOURCE_SERIES_DATE')
  points=[{k:r[k] for k in ('observation_date','price','record_id','binding_digest','response_sha256','provider_observed_at','fetched_at')} for r in rows]
  outcomes=[]
  with localcontext() as ctx:
   ctx.prec=40
   for index in range(horizon_observations,len(rows)):
    first,last=rows[index-horizon_observations],rows[index]
    outcomes.append({'start_record_id':first['record_id'],'end_record_id':last['record_id'],
     'start_date':first['observation_date'],'end_date':last['observation_date'],
     'elapsed_calendar_days':(dt.date.fromisoformat(last['observation_date'])-dt.date.fromisoformat(first['observation_date'])).days,
     'realized_price_return_pct':str((Decimal(last['price'])/Decimal(first['price'])-1)*100),
     'interpretation':'RESEARCH_REALIZED_PRICE_RETURN_NOT_EXPECTED_RETURN_OR_MODEL_VALIDATION'})
  series.append({'series_id':digest(list(key)),'instrument_id':key[0],'provider':key[1],'provider_id':key[2],
   'quote_currency':key[3],'identity_source_ref':key[4],'sampling':key[5],'pricing_method':key[6],
   'observation_count':len(rows),'observations':points,'realized_outcomes':outcomes,
   'status':'RESEARCH_LABELS_OBSERVED_NOT_MODEL_VALIDATED' if outcomes else 'ACCUMULATING_OBSERVATIONS',
   'horizon_unit':'OBSERVATIONS','horizon_value':horizon_observations,
   'authority':'RESEARCH_ONLY','comparison_authorized':False,'training_authorized':False})
 return {'schema':SCHEMA,'status':'RESEARCH_SERIES_OBSERVED' if series else 'NO_RESEARCH_OBSERVATIONS',
  'series':series,'series_count':len(series),'observation_count':len(records),
  'series_with_realized_labels':sum(bool(s['realized_outcomes']) for s in series),
  'realized_label_count':sum(len(s['realized_outcomes']) for s in series),
  'horizon_unit':'OBSERVATIONS','horizon_value':horizon_observations,'sampling':SAMPLING,
  'cross_currency_aggregation':False,'legacy_history_consumed':False,'expected_returns_certified':False,
  'model_validation_proven':False,'training_authorized':False,'comparison_authorized':False,
  'canonical_publication_authorized':False,'execution_authorized':False,'financial_mutation':False,'history_write_performed':False}

def build(root,*,now=None,horizon_observations=30):
 now=utc(now or dt.datetime.now(dt.timezone.utc));directory=local(root,STORE)
 def snapshot():
  if not directory.exists():return {}
  if not directory.is_dir():raise ValueError('RESEARCH_DIRECTORY_REQUIRED')
  paths=sorted(directory.glob('*.jsonl'))
  if len(paths)>4096:raise ValueError('RESEARCH_PARTITION_LIMIT')
  result={}
  for p in paths:
   p=local(root,STORE+'/'+p.name);dt.date.fromisoformat(p.stem);stat=p.stat()
   if not p.is_file():raise ValueError('RESEARCH_FILE_REQUIRED')
   result[p.name]=(stat.st_size,stat.st_mtime_ns,stat.st_ino)
  if sum(s[0] for s in result.values())>64*1024*1024:raise ValueError('RESEARCH_READ_SIZE_LIMIT')
  return result
 before=snapshot();records=read_records(root)
 if before!=snapshot():raise ValueError('RESEARCH_CHANGED_DURING_READ')
 out=project(records,now=now,horizon_observations=horizon_observations)
 out['source_files_stable_during_read']=True
 return out

def summary(root,*,now=None):
 try:
  out=build(root,now=now)
  return {k:v for k,v in out.items() if k!='series'}
 except Exception as exc:
  return {'schema':SCHEMA,'status':'RESEARCH_SERIES_INSPECTION_UNAVAILABLE','error_type':type(exc).__name__,
   'series_count':None,'observation_count':None,'realized_label_count':None,
   'model_validation_proven':False,'training_authorized':False,'comparison_authorized':False,
   'canonical_publication_authorized':False,'execution_authorized':False,'financial_mutation':False,'history_write_performed':False}
